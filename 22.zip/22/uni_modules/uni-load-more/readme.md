

### LoadMore 加载更多
> **组件名：uni-load-more**
> 代码块： `uLoadMore`


用于列表中，做滚动加载使用，展示 loading 的各种状态。


### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-load-more)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 


