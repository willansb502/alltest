<template>
  <view :id="state.elId" class="v-tabs">
    <scroll-view
      id="scrollContainer"
      :scroll-x="scroll"
      :scroll-left="scroll ? state.scrollLeft : 0"
      :scroll-with-animation="scroll"
      :style="{ position: fixed ? 'fixed' : 'relative', zIndex: 1993 }"
    >
      <view
        class="v-tabs__container"
        :style="{
          display: scroll ? 'inline-flex' : 'flex',
          whiteSpace: scroll ? 'nowrap' : 'normal',
          background: bgColor,
          height,
          padding
        }"
      >
        <view
          :class="['v-tabs__container-item', { disabled: !!v.disabled }]"
          v-for="(v, i) in tabs"
          :key="i"
          :style="{
            color: state.current == i ? activeColor : color,
            fontSize: state.current == i ? fontSize : fontSize,
            fontWeight: bold && state.current == i ? 'bold' : '',
            transform: state.current == i ? 'scale(1.1)' : 'none',
            justifyContent: !scroll ? 'center' : '',
            flex: scroll ? '' : 1,
            padding: paddingItem
          }"
          @click="change(i)"
        >
          {{ field ? v[field] : v.name }}
        </view>
        <view
          v-if="!pills"
          :class="['v-tabs__container-line', { animation: lineAnimation }]"
          :style="{
            background: lineColor,
            width: state.lineWidth + 'px',
            height: lineHeight,
            borderRadius: lineRadius,
            left: state.lineLeft + 'px',
            transform: `translateX(-${state.lineWidth / 2}px)`
          }"
        ></view>
        <view
          v-else
          :class="['v-tabs__container-pills', { animation: lineAnimation }]"
          :style="{
            background: pillsColor,
            borderRadius: pillsBorderRadius,
            left: state.pillsLeft + 'px',
            width: state.currentWidth + 'px',
            height
          }"
        ></view>
      </view>
    </scroll-view>
    <view
      class="v-tabs__placeholder"
      :style="{
        height: fixed ? height : '0',
        padding
      }"
    ></view>
  </view>
</template>

<script setup>
import { onMounted,nextTick,reactive,watch } from 'vue'
const emits = defineEmits(["change","input"])
const props = defineProps({
    value: {
      type: Number,
      default: 0
    },
    tabs: {
      type: Array,
      default () {
        return []
      }
    },
    bgColor: {
      type: String,
      default: '#fff'
    },
    padding: {
      type: String,
      default: '0'
    },
    color: {
      type: String,
      default: '#333'
    },
    activeColor: {
      type: String,
      default: '#2979ff'
    },
    fontSize: {
      type: String,
      default: '34rpx'
    },
    activeFontSize: {
      type: String,
      default: '32rpx'
    },
    bold: {
      type: Boolean,
      default: true
    },
    scroll: {
      type: Boolean,
      default: true
    },
    height: {
      type: String,
      default: '70rpx'
    },
    lineColor: {
      type: String,
      default: '#2979ff'
    },
    lineHeight: {
      type: String,
      default: '6rpx'
    },
    lineScale: {
      type: Number,
      default: 0.5
    },
    lineRadius: {
      type: String,
      default: '10rpx'
    },
    pills: {
      type: Boolean,
      default: false
    },
    pillsColor: {
      type: String,
      default: '#2979ff'
    },
    pillsBorderRadius: {
      type: String,
      default: '10rpx'
    },
    field: {
      type: String,
      default: ''
    },
    fixed: {
      type: Boolean,
      default: false
    },
    paddingItem: {
      type: String,
      default: '0 22rpx'
    },
    lineAnimation: {
      type: Boolean,
      default: true
    }
})
const state = reactive({
  elId: '',
  lineWidth: 30,
  currentWidth: 0, // 当前选项的宽度
  lineLeft: 0, // 滑块距离左侧的位置
  pillsLeft: 0, // 胶囊距离左侧的位置
  scrollLeft: 0, // 距离左边的位置
  containerWidth: 0, // 容器的宽度
  current: 0, // 当前选中项
  ifFirst:true
})
// 产生随机字符串
const randomString = (len) =>{
  len = len || 32
  let $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678' /****默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1****/
  let maxPos = $chars.length
  let pwd = ''
  for (let i = 0; i < len; i++) {
    pwd += $chars.charAt(Math.floor(Math.random() * maxPos))
  }
  return pwd
}
// 切换事件
const change = (index) =>{
  const isDisabled = !!props.tabs[index].disabled
  if (state.current !== index && !isDisabled) {
    state.current = index
    emits("change",index)
  }
  getTabItemWidth()
}
// 获取左移动位置
const getTabItemWidth = () =>{
    let query = uni
        .createSelectorQuery()
        // #ifndef MP-ALIPAY
        .in(this)
      // #endif
      // 获取容器的宽度
      query
        .select(`#scrollContainer`)
        .boundingClientRect((data) => {
          if (!state.containerWidth && data) {
            state.containerWidth = data.width
          }
        })
        .exec()
      // 获取所有的 tab-item 的宽度
      query
        .selectAll('.v-tabs__container-item')
        .boundingClientRect((data) => {
          if (!data) {
            return
          }
          let lineLeft = 0
          let currentWidth = 0
          if (data) {
            for (let i = 0; i < data.length; i++) {
              if (i < state.current) {
                lineLeft += data[i].width
              } else if (i == state.current) {
                currentWidth = data[i].width
              } else {
                break
              }
            }
          }
          // 当前滑块的宽度
          state.currentWidth = currentWidth
          // 缩放后的滑块宽度
          state.lineWidth = currentWidth * props.lineScale * 0.5
          // 滑块作移动的位置
          state.lineLeft = lineLeft + currentWidth / 2
          // 胶囊距离左侧的位置
          state.pillsLeft = lineLeft
          // 计算滚动的距离左侧的位置
          if (props.scroll) {
            state.scrollLeft = state.lineLeft - state.containerWidth / 2
          }
        })
        .exec()
}
onMounted(() => {
  state.elId = 'xfjpeter_' + randomString()
  state.current = props.value
}) 

watch(() =>props.value, (newVal) => {
  state.current = newVal
  if(state.ifFirst){
    setTimeout(() => {
      getTabItemWidth()
    }, 1000);
    setTimeout(() => {
      getTabItemWidth()
    }, 2000);        
  }else{
    nextTick(() => {
      getTabItemWidth()
    })
  }
  state.ifFirst=false;
},{ immediate: true })

watch(() => state.current, (newVal) => {
  emits("input",newVal)
},{ immediate: true })

watch(() => props.tabs, (newVal) => {
  nextTick(() => {
    getTabItemWidth()
  })
},{ immediate: true })
</script>

<style lang="scss" scoped>
.v-tabs {
  width: 100%;
  box-sizing: border-box;
  overflow: hidden;
  padding-bottom: 16rpx;
  ::-webkit-scrollbar {
    display: none;
  }

  &__container {
    min-width: 100%;
    position: relative;
    display: inline-flex;
    align-items: center;
    white-space: nowrap;
    overflow: hidden;

    &-item {
      display: flex;
      align-items: center;
      height: 100%;
      position: relative;
      z-index: 10;
      // padding: 0 11px;
      transition: all 0.3s;
      white-space: nowrap;
      &.disabled {
        opacity: 0.5;
        color: #999;
      }
    }

    &-line {
      position: absolute;
      bottom: 0;
    }

    &-pills {
      position: absolute;
      z-index: 9;
    }
    &-line,
    &-pills {
      &.animation {
        transition: all 0.3s linear;
      }
    }
  }
  .v-tabs__container-item{
     transition:all ease-in;
  }
}
</style>
