export async function _requestAwait(requestUrl,data) {
    let host=""
    // #ifdef APP-PLUS
        if(requestUrl.indexOf('/apidl')>-1){
            requestUrl=requestUrl.replace('apidl','api')
            host="http://139.162.22.207:6633"
        }else{
            host="https://madoucun.cc"
        }
    // #endif
    let res, err
    try {
        res = await uni.request({
            header:{
                "Server-Origin":"https://kuaibo.club"
            },
            method:'POST',
            url: host+requestUrl,
            dataType: 'text',
            data: data
        });
    } catch(e){
        err=e
    }
    if (err) {
        console.log('request fail', err);
        // uni.showModal({
        //     content: err.errMsg,
        //     showCancel: false
        // });
    } else {
        return JSON.parse(res.data);
    }
}
  

