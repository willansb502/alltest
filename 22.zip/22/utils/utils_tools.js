export function commonToPage(url) {
  // #ifdef APP-PLUS
    plus.runtime.openURL(url, function(res) {
    });
  // #endif
  // #ifndef APP-PLUS
    window.open(url)
  // #endif  
}


