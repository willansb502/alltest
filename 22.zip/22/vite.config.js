import { defineConfig } from 'vite';
import uni from '@dcloudio/vite-plugin-uni';

export default defineConfig({
  server: {
    proxy: {
      "/api.php": {
        target: "https://madoucun.cc",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api.php/, "api.php"),
      },
      "/apidl": {
        target: "http://139.162.22.207:6633",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/apidl/, "api"),
      }      
    }   
  },
	plugins: [uni()],
});