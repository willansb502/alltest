rm -rf zhanqunbao.zip
rm -rf zhanqunbao
pnpm run fanhaoshe
pnpm run xkmcn
zip -q -r zhanqunbao.zip zhanqunbao
# scp  zhanqunbao.zip  root@162.251.93.58:/home/www/wwwroot/h5
# ssh  root@162.251.93.58 "/home/www/wwwroot/h5/jieya.sh"