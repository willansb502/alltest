(function () {
  // 渠道码  
  var stat_code="";
  // 列表
  var stat_list={
    'all':{
      name:"百度",
      src:"https://hm.baidu.com/hm.js?e257f02301abc25217a5014af88c7064"
    },
    'muoucpc01':{
      name:"51la",
      initCk:"JwJtefTVH6GK361U"
    } 
  };
  // 百度添加
  var baiduAdd=function(src){
    var hm = document.createElement("script");
    hm.src = src;
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(hm, s);
  };
  // 51la添加
  var la51Add=function(initCk){
    var hm = document.createElement("script");
    hm.src = '//sdk.51.la/js-sdk-pro.min.js';
    hm.charset="UTF-8";
    hm.id="LA_COLLECT";
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(hm, s);
    window.onload=function(){
      LA.init({id:initCk,ck:initCk})
    }  
  };
  function GetQuery(key) {
    var search = location.search.slice(1); 
    var arr = search.split("&");
    for (var i = 0; i < arr.length; i++) {
      var ar = arr[i].split("=");
      if (ar[0] == key) {
        return ar[1];
      }
    }
  }
  stat_code=GetQuery('dc');

  if(!stat_code||!stat_list[stat_code]){
    return  baiduAdd(stat_list["all"].src)
  };
  // 检测渠道
  for (var key in stat_list) {
    var element = stat_list[key];
    if(key==stat_code&&element.name=="51la"){
      la51Add(element.initCk)
    }else if(key==stat_code&&element.name=="百度"){
      baiduAdd(stat_list[key].src)
    }   
  };    
})()   