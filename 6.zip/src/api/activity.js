
import request from '@/utils/request'
// home api
import api from './index'

// 活动列表
export function activity_list(data) {
  return request({
    url: api.activity_list,
    method: 'post',
    data
  })
}
// 活动详情
export function activity_detail(data) {
  return request({
    url: api.activity_detail,
    method: 'post',
    data
  })
}
// 活动领取
export function advertise_click(data) {
  return request({
    url: api.advertise_click,
    method: 'post',
    data
  })
}
// 新手活动
export function xs_activity_list(data) {
  return request({
    url: api.xs_activity_list,
    method: 'post',
    data
  })
}

