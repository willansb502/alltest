
import request from '@/utils/request'
let BASEURL
const apiType = 'app'
apiType === 'h5app' ? BASEURL = '/api/h5app' : BASEURL = '/api/app'

// 漫画首页
export function comicsHome(data) {
  return request({
    url: BASEURL + '/comics/home',
    method: 'post',
    data
  })
}
// 漫画详情
export function comicsDetail(data) {
  return request({
    url: BASEURL + '/comics/detail',
    method: 'post',
    data
  })
}

// 漫画换一换
export function comicsTopicChange(data) {
  return request({
    url: BASEURL + '/comicsTopic/change',
    method: 'post',
    data
  })
}

// 漫画更多
export function comicsTopicList(data) {
  return request({
    url: BASEURL + '/comicsTopic/list', // 漫画更多
    method: 'post',
    data
  })
}

// 作者作品
export function comicsAuthor(data) {
  return request({
    url: BASEURL + '/comics/author', // 漫画作者作品,
    method: 'post',
    data
  })
}

// 标签作品
export function comicsTagListById(data) {
  return request({
    url: BASEURL + '/comicsTag/listById', // 标签作品
    method: 'post',
    data
  })
}

// 漫画评论
export function comCommentList(data) {
  return request({
    url: BASEURL + '/comment/list', // 评论列表
    method: 'post',
    data
  })
}


// 添加评论
export function comCommentAdd(data) {
  return request({
    url: BASEURL + '/comment/add', // 添加评论,
    method: 'post',
    data
  })
}

// 漫画查看权限
export function comicsChapterIsLook(data) {
  return request({
    url: BASEURL + '/comicsChapter/isLook', // 漫画查看权限
    method: 'post',
    data
  })
}

//漫画支付
export function comicsPay(data) {
  return request({
    url: BASEURL + '/comics/pay', // 漫画支付
    method: 'post',
    data
  })
}

//漫画再次较验
export function comicsChapterPics(data) {
  return request({
    url: BASEURL + '/comicsChapter/pics', // 漫画再次较验,
    method: 'post',
    data
  })
}

// 漫画合集购买
export function comicsTopicCtPay(data) {
  return request({
    url: BASEURL + '/comicsTopic/ctPay', 
    method: 'post',
    data
  })
}



