
import request from '@/utils/request'
// home api
import api from './index'

// 帖子列表
export function community_list(data) {
  return request({
    url: api.community_list,
    method: 'post',
    data
  })
}

// 帖子详情
export function community_detail(data) {
  return request({
    url: api.community_detail,
    method: 'post',
    data
  })
}
// 帖子购买
export function community_pay(data) {
  return request({
    url: api.community_pay,
    method: 'post',
    data
  })
}
// 帖子发布
export function community_publish(data) {
  return request({
    url: api.community_publish,
    method: 'post',
    data
  })
}
// 帖子详情
export function user_publish(data) {
  return request({
    url: api.user_publish,
    method: 'post',
    data
  })
}
// 小视频列表详情
export function user_media(data) {
  return request({
    url: api.user_media,
    method: 'post',
    data
  })
}
