
import request from '@/utils/request'
// home api
import api from './index'

// 推荐商家列表
export function dating_bosses(data) {
  return request({
    url: api.dating_bosses,
    method: 'post',
    data
  })
}
// 约炮分类详情 楼凤，上门，商家 type 1 2 3
export function dating_category(data) {
  return request({
    url: api.dating_category,
    method: 'post',
    data
  })
}
// 经纪人详情
export function bosses_detail(data) {
  return request({
    url: api.bosses_detail,
    method: 'post',
    data
  })
}

// 城市列表 city_list
export function city_list(data) {
  return request({
    url: api.city_list,
    method: 'post',
    data
  })
}
// 验车报告列表
export function report_publish(data) {
  return request({
    url: api.report_publish,
    method: 'post',
    data
  })
}
// 获取验车报告 dating_report
export function dating_report(data) {
  return request({
    url: api.dating_report,
    method: 'post',
    data
  })
}
// 发布上门信息
export function dating_publish(data) {
  return request({
    url: api.dating_publish,
    method: 'post',
    data
  })
}
// 约炮支付 dating_pay
/** *
 * type 1楼凤  2外围(上门) 3商家
 * objectId id
 * connect 联系方式
 *
 */
export function dating_pay(data) {
  return request({
    url: api.dating_pay,
    method: 'post',
    data
  })
}
// 约炮举报 dating_complaint
export function dating_complaint(data) {
  return request({
    url: api.dating_complaint,
    method: 'post',
    data
  })
}
// 楼凤详情 loufeng_detail
export function loufeng_detail(data) {
  return request({
    url: api.loufeng_detail,
    method: 'post',
    data
  })
}
// 上门详情 model_detail
export function model_detail(data) {
  return request({
    url: api.model_detail,
    method: 'post',
    data
  })
}
// 楼凤配置信息
export function dating_config(data) {
  return request({
    url: api.dating_config,
    method: 'post',
    data
  })
}
