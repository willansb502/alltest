const BASEURL = '/api/app';
const api = {
  // 系统配置板块======================
  config: BASEURL + '/ping/config', // 获取配置
  faq_list: BASEURL + '/faq/list', // 常见问题列表
  collect: BASEURL + '/collect/add', // 统一收藏接口
  paytypeinfo: BASEURL + '/gold/paytypeinfo', // 支付列表及信息 /api/app/gold/paytypeinfo
  uploadImgs: BASEURL + '/upload/images', // 多图上传  /api/app/upload/images
  uploadOneImg: BASEURL + '/upload/img', // 多图上传  /api/app/upload/img
  uploadVideo: BASEURL + '/vid/upload', // 视频上传  /vid/upload
  comment_list: BASEURL + '/comment/list', // 评论列表  /api/app/comment/list
  comment_add: BASEURL + '/comment/add', // 发表评论  /api/app/comment/add
  care_add: BASEURL + '/care/add', // 添加关注 /api/app/care/add
  care_cancel: BASEURL + '/care/cancel', // 取消关注 /api/app/care/cancel
  login_captcha: BASEURL + '/login/captcha', // api/app/login/captcha 获取验证码
  bind_Phone: BASEURL + '/login/bindMobile', // /api/app/login/bindMobile  绑定手机
  kf: BASEURL + '/custom/getEndpoint', // /custom/getEndpoint
  phone_login: BASEURL + '/login/phone', // 手机号登录/api/app/login/phone
  apps_list: BASEURL + '/apps/list', // 应用中心 /api/app/apps/list
  checkin_list: BASEURL + '/checkin/list', // 签到记录列表  /api/app/checkin/list
  checkin_click: BASEURL + '/checkin/click', // 用户签到  /api/app/checkin/click
  checkin_setup: BASEURL + '/checkin/setup', // 签到规则 /api/app/checkin/setup




  // 首页视频板块
  index_home: BASEURL + '/media/homev2', // 首页数据(旧版)
  index_home_3: BASEURL + '/media/homev3', // 首页数据
  cfgAccessDomain: BASEURL + '/ping/cfgAccessDomain', // 线路选择  
  media_details: BASEURL + '/media/topic/details', // 常见问题列表
  media_actor_info: BASEURL + '/media/actor/info', // 女优详情信息列表
  media_actor_details: BASEURL + '/media/actor/details', // 女优详情信息列表



  // 搜索
  search_hot: BASEURL + '/hotsearch/list', // 热门搜索
  search: BASEURL + '/search/detailsV2', // 搜索

  // 热门标签
  hot_tag_list: BASEURL + '/media/tag/list', // 热门标签
  tag_detail: BASEURL + '/media/tag/details', // 标签详情

  // 活动 /api/app/activity/list /api/app/activity/detail /api/app/advertise/click
  activity_list: BASEURL + '/activity/list', // 活动列表
  activity_detail: BASEURL + '/activity/detail', // 活动详情
  advertise_click: BASEURL + '/mission/reward', // 点击获取活动奖励
  xs_activity_list: BASEURL + '/mission/info', // 新手活动列表 /api/app/mission/info

  // 用户板块==================================
  ykInfo: BASEURL + '/login/guest', // 游客信息
  userInfo: BASEURL + '/user/info', // 用户信息
  userQrcode: BASEURL + '/user/qrcode', // 账号凭证
  transList: BASEURL + '/trans/list', // 交易记录 /api/app/trans/list
  update_info: BASEURL + '/user/info/modify', // /api/app/user/info/modify 修改用户信息
  user_avatar: BASEURL + '/user/avatar', // 默认头像/api/app/user/avatar
  care_list: BASEURL + '/care/list', // 关注列表 /api/app/care/list
  care_fans: BASEURL + '/care/fans', // 粉丝列表 /api/app/care/fans
  redeemcode_list: BASEURL + '/redeemcode/list', // 兑换记录 /api/app/redeemcode/list
  redeemcode_user: BASEURL + '/redeemcode/use', // 使用兑换码 /api/app/redeemcode/use /api/app/message/list
  message_list: BASEURL + '/message/list', // 获取消息列表 /api/app/message/list
  message_dialog: BASEURL + '/message/dialog', // 获取私信列表   /api/app/message/dialog
  withdrawal_info: BASEURL + '/withdrawal/info', // /api/app/withdrawal/info
  withdrawal_submit: BASEURL + '/withdrawal/submit', // 申请提现 /api/app/withdrawal/submit
  user_income: BASEURL + '/user/invite/income', // 我的邀请信息 api/app/user/invite/income
  config_contact: BASEURL + '/config/contact',       // 交流群 /api/app/config/contact
  publish_list: BASEURL + '/publish/list',       // 我的发布列表 /api/app/publish/list
  publish_del: BASEURL + '/publish/del',       // 删除发布信息 /api/app/publish/del
  collect_list: BASEURL + '/collect/list',       // 我的收藏列表 /api/app/collect/list
  collect_del: BASEURL + '/collect/del',       // 批量删除我的收藏 /api/app/collect/del
  pay_history: BASEURL + '/media/pay/history',       // 我的购买列表 /api/app/media/pay/history
  msg_info: BASEURL + '/message/info',       // 获取私聊信息 /api/app/message/info
  msg_send: BASEURL + '/message/send',       // 发送私信 /api/app/message/send
  user_qrcode_info: BASEURL + '/user/qrcode/info',       // 二维码找回账户信息   /api/app/user/qrcode/info


  // 约炮板块=======================
  dating_bosses: BASEURL + '/dating/boss/recoment', // 商家列表
  dating_category: BASEURL + '/dating/category', // 约炮分类详情 type 1楼凤 2上门 3商家
  bosses_detail: BASEURL + '/dating/boss/detail', // 获取经纪人详情详情
  city_list: BASEURL + '/dating/city', // 获取经纪人详情详情
  report_publish: BASEURL + '/dating/report/publish', // 发布体验报告/api/app/dating/report/publish
  dating_report: BASEURL + '/dating/report', // 获取验车报告
  dating_publish: BASEURL + '/dating/publish', // 发布上门消息报告/api/app/dating/report/publish

  dating_pay: BASEURL + '/dating/pay', // 楼凤支付 /api/app/dating/pay
  dating_complaint: BASEURL + '/dating/complaint', // 楼凤举报 /api/app/dating/complaint /api/app/dating/loufeng/detail
  loufeng_detail: BASEURL + '/dating/loufeng/detail', // 楼凤详情 /api/app/dating/loufeng/detail
  model_detail: BASEURL + '/dating/model/detail', // 上门详情 /api/app/dating/model/detail
  dating_config: BASEURL + '/dating/config', // 上门配置  /api/app/dating/config

  // 视频播放页相关接口
  video_play: BASEURL + '/media/play', // 视频播放 /api/app/media/play
  video_pay: BASEURL + '/media/pay', // 视频付费 /api/app/media/pay
  video_tag: BASEURL + '/media/tag', // 视频标签 /api/app/media/tag
  video_like: BASEURL + '/media/like', // 猜你喜欢 /api/app/media/like

  // 社区
  community_list: BASEURL + '/post/list', // 帖子列表 /api/app/post/list
  community_detail: BASEURL + '/post/detail', // 帖子详情 /api/app/post/detail
  community_pay: BASEURL + '/post/pay', // 帖子购买 /api/app/post/pay
  community_publish: BASEURL + '/post/publish', // 帖子发布 /api/app/post/publish
  user_publish: BASEURL + '/post/publish/list', // 帖子发布 /api/app/post/publish/list
  user_media: BASEURL + '/media/user', // 帖子发布 /api/app/media/user

  // 会员卡
  vip_list: BASEURL + '/card/list', // /api/app/card/listi/app/recharge/submit
  recharge_sumbit: BASEURL + '/recharge/submit', // /api/app/recharge/submit 会员卡充值

  // 合集购买
  gather_buy: BASEURL + '/media/gather/pay' // /api/app/recharge/submit 会员卡充值
}

export default api
