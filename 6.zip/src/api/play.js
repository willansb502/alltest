
// axios
import request from '@/utils/request'
// home api
import api from './index'

// 视频播放
export function video_play(data) {
  return request({
    url: api.video_play,
    method: 'post',
    data
  })
}
// 视频付费
export function video_pay(data) {
  return request({
    url: api.video_pay,
    method: 'post',
    data
  })
}
// 视频标签
export function video_tag(data) {
  return request({
    url: api.video_tag,
    method: 'post',
    data
  })
}
// 猜你喜欢
export function video_like(data) {
  return request({
    url: api.video_like,
    method: 'post',
    data
  })
}



