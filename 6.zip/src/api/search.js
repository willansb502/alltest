
import request from '@/utils/request'
// home api
import api from './index'
const baseData = import.meta.env;
// 热门搜索
export function search_hot(data) {
  return request({
    url: api.search_hot,
    method: 'post',
    data
  })
}
// 搜索
export function search(data) {
  return request({
    url: api.search,
    method: 'post',
    data
  })
}
// 分类搜索
export function tag_detail(data) {
  return request({
    url: api.tag_detail,
    method: 'post',
    data
  })
}
// 热门标签
export function hot_tag_list(data) {
  return request({
    baseURL: baseData.VITE_APP_baseApi,     
    url: api.hot_tag_list,
    method: 'post',
    data
  })
}
