<template>
  <div>
    <transition :name="transitionName">
      <div v-show="state.visible" class="back-to-ceiling" @click="backToTop">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 66 66" class="svg">
          <g fill="none" fill-rule="evenodd">
            <g>
              <g>
                <g>
                  <g>
                    <path
                      fill="#262222"
                      d="M0 0H66V66H0z"
                      transform="translate(-1744 -3252) translate(-29 1723) translate(1773 1529)"
                    />
                    <path
                      stroke="#FFF"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      stroke-width="3"
                      d="M40 22.338l-7-7.107-7 7.107m7-7.107v19.292-19.292z"
                      transform="translate(-1744 -3252) translate(-29 1723) translate(1773 1529)"
                    />
                    <text
                      fill="#FFF"
                      stroke="#FFF"
                      font-family="MicrosoftYaHei, Microsoft YaHei"
                      font-size="12"
                      transform="translate(-1744 -3252) translate(-29 1723) translate(1773 1529)"
                    >
                      <tspan x="9" y="55.646">返回顶部</tspan>
                    </text>
                  </g>
                </g>
              </g>
            </g>
          </g>
        </svg>
      </div>
    </transition>
  </div>
</template>
<script setup>
const props = defineProps({
  // 在什么高度显示
  visibilityHeight: {
    type: Number,
    default: 200
  },
  /**
   * 滚动到什么高度
   */
  backPosition: {
    type: Number,
    default: 0
  },
  customStyle: {
    type: Object,
    default: function () {
      return {
        right: '50px',
        bottom: '50px',
        width: '40px',
        height: '40px',
        'border-radius': '4px',
        'line-height': '45px',
        background: '66ccff',
        zIndex: 999
      }
    }
  },
  transitionName: {
    type: String,
    default: 'fade'
  }
})

const state = reactive({
  visible: false,
  interval: null,
  isMoving: false
})

const handleScroll =() =>{
  state.visible = window.pageYOffset > props.visibilityHeight
}

const backToTop =() =>{
  if (state.isMoving) return
  const start = window.pageYOffset
  let i = 0
  state.isMoving = true
  state.interval = setInterval(() => {
    const next = Math.floor(easeInOutQuad(10 * i, start, -start, 500))
    if (next <= props.backPosition) {
      window.scrollTo(0, props.backPosition)
      clearInterval(state.interval)
      state.isMoving = false
    } else {
      window.scrollTo(0, next)
    }
    i++
  }, 16.7)
}

const easeInOutQuad =(t, b, c, d) =>{
  if ((t /= d / 2) < 1) return (c / 2) * t * t + b
  return (-c / 2) * (--t * (t - 2) - 1) + b
}

onMounted(() => {
  window.addEventListener('scroll', handleScroll)
}) 

onUnmounted(() => { 
  window.removeEventListener('scroll', handleScroll)
  if (state.interval) {
    clearInterval(state.interval)
  }
})

</script>

<style lang="scss" scoped>
.back-to-ceiling {
  position: fixed;
  display: inline-block;
  text-align: center;
  cursor: pointer;
  right: 16px;
  bottom: 84px;
  width: 40px;
  height: 40px;
  line-height: 45px;
  border-radius: 10px;
  z-index: 999;
  overflow: hidden;
}

.back-to-ceiling:hover {
  background: rgba(#262222, 0.9);
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s;
}

.fade-enter,
.fade-leave-to {
  opacity: 0;
}

@media screen and (min-width: 960px) {
  .back-to-ceiling {
    width: 50px;
    height: 50px;
  }
}
</style>
