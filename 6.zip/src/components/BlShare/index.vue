<template>
  <van-share-sheet
    class="md-share-popup"
    :value="isShow"
    :options="options"
    :title="title"
    :description="description"
    :close-on-click-overlay="false"
    @select="select"
    @cancel="cancel"
    @click-overlay="cancel"
  >
  </van-share-sheet>
</template>
<script setup>
import { getAssetsFile } from '@/utils/utils_tools'
// 向组件传递方法
const emits = defineEmits(["cancel","select"])
const props = defineProps({
  value: {
    type: Boolean,
    default() {
      return false
    }
  },
  options: {
    type: Array,
    default() {
      return [
        { name: '本片鏈接', icon: 'link' },
        { name: 'APP下載鏈接', icon: getAssetsFile('short-video/down.png') },
        { name: '分享頁二維碼', icon: 'qrcode' },
        { name: '個人中心', icon: getAssetsFile('footer/06_defaultActive.png') }
      ]
    }
  },
  title: {
    type: String,
    default() {
      return '立即分享給好友'
    }
  },
  description: {
    type: String,
    default() {
      return '分享面板'
    }
  },
  isShow: {
    type: Boolean,
    default() {
      return false
    }
  }
})
const cancel = () =>{
  emits("cancel",false)
}
const select = (option, index) =>{
  emits("select",option, index)
}
</script>

<style lang="scss" scoped>
.md-share-popup {
  max-width: 1260px;
  left: 0;
  right: 0;
  margin: 0 auto;
  background: $mainBgColor;
  color: $mainTxtColor1;
  z-index: 9999999;
}

:deep()  {
  .van-share-sheet__title {
    color: $mainTxtColor1;
  }
  .van-share-sheet__description {
    color: $mainTxtColor1;
  }
  .van-share-sheet__cancel {
    background: $btnBg;
  }
  .van-share-sheet__cancel::before {
    display: block;
    height: 8px;
    background: $btnBg;
    content: ' ';
  }
  .van-share-sheet__option {
    &:nth-child(4) {
      .van-share-sheet__icon {
        filter: brightness(100);
      }
    }
  }
}
</style>
