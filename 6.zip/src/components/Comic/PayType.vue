<template>
  <!-- 单个漫画 -->
  <div class="payType-wrap">
    <div
      v-if="item.payType == 0 || item.comicsPayType == 0 || item.hGamePayType == 0"
      class="free"
      :style="[{ 'border-top-left-radius': imgRadius }, { 'border-bottom-right-radius': imgRadius }]"
    >
      <span>免费</span>
    </div>
    <div
      v-if="item.payType == 1 || item.comicsPayType == 1 || item.hGamePayType == 1"
      class="free vip"
      :style="[{ 'border-top-left-radius': imgRadius }, { 'border-bottom-right-radius': imgRadius }]"
    >
      <span>VIP</span>
    </div>
    <div
      v-if="item.payType == 2 || item.comicsPayType == 2 || item.hGamePayType == 2"
      class="free price"
      :style="[{ 'border-top-left-radius': imgRadius }, { 'border-bottom-right-radius': imgRadius }]"
    >
      <div class="coin">
        <img src="@/assets/imgs/index/gold.png" alt="" />
        {{ changeGold(item.price) }}
      </div>
    </div>
  </div>
</template>
<script setup>
import { changeGold } from '@/utils/filter'
const props = defineProps({
  item: {
    type: Object,
    default() {
      return {}
    }
  },
  imgRadius: {
    type: String,
    default() {
      return '0.15rem'
    }
  }
})
</script>

<style lang="scss" scoped>
.payType-wrap {
  z-index: 2;
  position: absolute;
  top: 0;
  left: 0;
  font-size: 0;
  .free {
    z-index: 1;
    padding: 0.01rem 0.06rem;
    background-image: linear-gradient(to right, #9fe954, #4e982e);
    color: $mainTxtColor1;
    font-size: 0.16rem;
    font-weight: 600;
    text-align: center;
    // border-top-left-radius: 0.15rem;
    // border-bottom-right-radius: 0.15rem;
    span {
      display: inline-block;
      transform: scale(0.9);
    }
    .coin {
      display: flex;
      align-items: center;
      transform: scale(0.9);
    }
  }
  .vip {
    background: linear-gradient(to right, #fd9c3a, #fc342d);
    min-width: 0.64rem;
  }
  .price {
    padding: 0.01rem 0.06rem;
    background: linear-gradient(to right, #493afd, #752dfc);
    display: flex;
    align-items: center;
    justify-content: center;
    img {
      width: 0.24rem;
      height: 0.24rem;
      margin-right: 0.05rem;
    }
  }
}
</style>
