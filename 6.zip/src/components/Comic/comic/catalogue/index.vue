<template>
    <van-popup
      v-model:show="catalogueObj.show"
      class="catalogue-popup"
      round
      position="bottom"
    >
      <main class="catalogue-list">
        <div class="title">
          <div>目录</div>
          <div class="sort" @click="fn_sortDer">
            <img src="@/assets/imgs/comics/sort.png" alt="">
            <div v-if="state.sortDer">正序</div>
            <div v-else>反序</div>
          </div>
        </div>
        
        <ul class="catalogue">
          <CatalogueItem
            v-for="(item, index) in list" :item="item" :key="index"            
          ></CatalogueItem>
        </ul>  
      </main>
    </van-popup>    

</template>
<script setup>
const CatalogueItem = defineAsyncComponent(() => import('@/components/Comic/comic/catalogue/item.vue'))
const state = reactive({
  sortDer:true,
  list:[]
})
const props = defineProps({
  catalogueObj: {
    type: Object,
    default() {
      return {}
    },
  },
})

//排序
const fn_sortDer =() => {
  state.sortDer=!state.sortDer; 
  state.list=state.list.reverse();
}

//初始化数据
const initDatas =() => {
  state.list=JSON.parse(JSON.stringify(props.catalogueObj.list));
  //动画
  setTimeout(() => {
    props.catalogueObj.show=true;
  }, 100);
}

</script>

<style lang="scss" scoped>
.catalogue-popup{
  left: auto;
  max-width: $pcMaxWidth;
}
.catalogue-list{
  padding: 0.3rem 0.3rem 0 0.66rem;
  position: relative;
  background: $mainBgColor;
  border-top-left-radius: 0.44rem;
  border-top-right-radius: 0.44rem;
  &::before{
    content: "";
    position: absolute;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 0;
    height: 0;
    border-width: 0.18rem;
    border-style: solid;
    border-color: #ff8b00 transparent transparent transparent;      
  }     
  .title{
    position: relative;
    text-align: center;
    font-size: 0.36rem;
    color: #6a6a6a;
    .sort{
      font-size: 0.24rem;
      position: absolute;
      top: 0.1rem;
      right: 0;
      display: flex;
      align-items: center;
      img{
        width: 0.26rem;
        height: 0.21rem;
        margin-right: 0.1rem;
      }

    }
  }
  .catalogue{
    @include scrollbar-hide;
    max-height:8.24rem;
    overflow-y:auto ;
    display: flex;
    flex-wrap: wrap;
    margin-top: 0.2rem;
    padding-bottom: 0.3rem;
  }
}

</style>
