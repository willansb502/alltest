<template>
  <div>
    <li @click="toPicview" :class="[{ isNew: item.isNew }, { isFree: item.isFree }, { nowChapter: state.nowChapter }]">
      第{{ item.indexName }}话
    </li>
    <DmPopup ref="popupMsg"></DmPopup>
  </div>
</template>
<script setup>
import { picViewRightTo } from '@/utils/utils_tools'
const DmPopup = defineAsyncComponent(() => import('@/components/Popup/index.vue'))
import { useStore } from 'vuex'
const store = useStore()
const router = useRouter()
const route = useRoute()

const state = reactive({
  nowChapter: false,
  bookshelfList:computed(() => store.state.history.bookshelfList),
})
// 组件传值
const props = defineProps({
  item: {
    type: Object,
    default() {
      return {}
    }
  }
})




//漫画预览页，直接拿id显示当前
const toPicview =async () =>{
  if (route.path.includes('/comics/pic-view/')) {
    if (state.nowChapter) return
  }
  picViewRightTo(props.item.id)
}

//收藏位置
const findIndex =async () =>{
  let newItem = {}
  //数据库找出这本书
  state.bookshelfList.forEach(element1 => {
    element1.list.forEach(element2 => {
      if (element2.id == +route.params.id) {
        newItem = element2
      }
    })
  })
  //对比这本书看到的章节和当前章节是否相等
  if (props.item.indexName == newItem.hasViewNum) {
    state.nowChapter = true
  }
}
onMounted(async () => {
  //漫画预览页，直接拿id显示当前
  if (route.path.includes('/comics/pic-view/')) {
    if (+route.params.id == props.item.id) {
      state.nowChapter = true
    }
  }
  //漫画介绍页，拿缓存记录上次已看到的页面
  if (route.path.includes('/comics/decial/')) {
    // findIndex();
  }
})

</script>

<style lang="scss" scoped>
li {
  font-size: 0.24rem;
  margin-right: 0.12rem;
  margin-bottom: 0.2rem;
  border-radius: 0.1rem;
  color: $mainTxtColor1;
  width: 1.1rem;
  height: 0.63rem;
  background: $mainBgColor;
  @include flex-center;
  border: 1px solid #eeeeee;
  span {
    transform: scale(0.8);
  }
  &:nth-child(5n) {
    margin-right: 0;
  }
  // &.isNew{
  //   background: url("../../../../assets/imgs/comics/isNew.png");
  //   background-size:100% 100% ;
  // }
  &.isFree {
    background: url('../../../../assets/imgs/comics/isNew.png');
    background-size: 100% 100%;
  }
  &.nowChapter {
    color: #ff7777;
    background: url('../../../../assets/imgs/comics/isNew-red.png') top right no-repeat;
    background-size: 0.22rem 0.22rem;
  }
}
@media screen and (min-width: 750px) {
  li {
    width: 2.1rem;
  }
  li:hover {
    background: rgb(45, 39, 56);
    cursor: pointer;
  }
}
</style>
