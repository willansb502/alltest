<template>
  <van-pull-refresh v-model="state.refreshing" @refresh="onRefresh" style="min-height: 100vh">

    <div class="tuijian-container">
      <!-- 所有主题   -->
      <ul class="topic-list">
        <li v-for="(itemTopic, index) in state.topicList" :key="itemTopic.id" :name="index">
          <!-- 最热同人推荐 swiper卡片-->
          <CardSwiper v-if="itemTopic.showType == 1 && itemTopic.comicsList.length" :itemTopic="itemTopic"></CardSwiper>
          <!-- 专题一swiper 3张错位共6张 -->
          <D3Swiper
            v-else-if="itemTopic.showType == 2 && itemTopic.comicsList.length"
            :itemTopic="itemTopic"
          ></D3Swiper>
          <!-- 六宫格一行3个 变态专区 -->
          <DmThreeBox
            v-else-if="itemTopic.showType == 3 && itemTopic.comicsList.length"
            :itemTopic="itemTopic"
          ></DmThreeBox>
          <!-- 专题二瀑布流 -->
          <DmWaterfall
            v-else-if="itemTopic.showType == 4 && itemTopic.comicsList.length"
            :itemTopic="itemTopic"
          ></DmWaterfall>
          <!-- 本月热门 -->
          <DmMonthHot
            v-else-if="itemTopic.showType == 5 && itemTopic.comicsList.length"
            :itemTopic="itemTopic"
          ></DmMonthHot>
          <!-- 合集专区一行3个 -->
          <DmCollection
            v-else-if="itemTopic.showType == 6 && itemTopic.topicInfo.length"
            :itemTopic="itemTopic"
          ></DmCollection>
          <!-- 倒计时 -->
          <div v-if="state.advertise && index == 0" class="countDown-wrap" @click="clickImg(state.advertise)">
            <DecryptImg :imgURL="state.advertise.cover"></DecryptImg>
            <div class="content">
              <van-count-down :time="state.timeOut" format="DD:HH:mm:ss" class="left-wrap">
                <template #default="timeData">
                  <div class="time">
                    <div>{{ timeData.days }}</div>
                    <div>天</div>
                  </div>
                  <div class="dot">:</div>
                  <div class="time">
                    <div>{{ timeData.hours }}</div>
                    <div>时</div>
                  </div>
                  <div class="dot">:</div>
                  <div class="time">
                    <div>{{ timeData.minutes }}</div>
                    <div>分</div>
                  </div>
                  <div class="dot">:</div>
                  <div class="time">
                    <div>{{ timeData.seconds }}</div>
                    <div>秒</div>
                  </div>
                </template>
              </van-count-down>
              <div class="right-wrap">
                <div>{{ state.advertise.title }}</div>
              </div>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </van-pull-refresh>
</template>
<script setup>
import { showToast } from 'vant';
import { comicsHome } from '@/api/comics' //api列表
//  import  moment  from "moment"

const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const D3Swiper = defineAsyncComponent(() => import('@/components/Comic/topic/d3Swiper.vue'))
const CardSwiper = defineAsyncComponent(() => import('@/components/Comic/topic/cardSwiper.vue'))
const DmWaterfall = defineAsyncComponent(() => import('@/components/Comic/topic/waterfall.vue'))
const DmThreeBox = defineAsyncComponent(() => import('@/components/Comic/topic/threeBox/index.vue'))
const DmCollection = defineAsyncComponent(() => import('@/components/Comic/topic/collection/index.vue'))
const DmMonthHot = defineAsyncComponent(() => import('@/components/Comic/topic/monthHot.vue'))
const props = defineProps({
  nowTabItem: {
    type: Object,
    default() {
      return {}
    }
  }
})
const state = reactive({
  //加载刷新
  pageNum: 1,
  //正式服需要5即可
  pageSize: 20,
  refreshing: false,
  loading: false,
  finished: false,
  //倒计时
  timeOut: 0,
  //倒计时
  advertise: '',
  //轮播广告
  newAdvertise: [],
  //主题
  topicList: [],
  // cartongAD:computed(() => store.getters['cartongAD']),
  // comicsCategory:computed(() => store.getters['config/homeAd'])    
})

// 倒计时
// const computedTime = () =>{
//   if (!state.advertise) return
//   let currentTime = moment().valueOf() //当前时间戳
//   let SetTimeStr = moment(state.advertise.timeOut).valueOf()
//   const timeDiff = SetTimeStr - currentTime
//   if (timeDiff) {
//     state.timeOut = timeDiff
//   }
// }

// 首页数据请求
const getList =async (type) =>{
  const res = await comicsHome({
    id: props.nowTabItem.id
  })
  if (res.code === 200 && res.data) {
    state.refreshing = false
    state.loading = false
    //倒计时
    state.advertise = res.data.advertise
    state.newAdvertise = res.data.newAdvertise
    if (!res.data || !res.data.topicList || res.data.topicList.length < state.pageSize) {
      state.finished = true
    }
    if (type == 'pull') state.topicList = []
    if (res.data.topicList) state.topicList = [...state.topicList, ...res.data.topicList]
    // computedTime();
  } else {
    state.finished = true
    state.refreshing = false
    state.loading = false
    return showToast(res.tip)
  }
}
//上拉加载更多
const onLoad = () =>{
  state.pageNum += 1
  getList()
}
// 刷新
const onRefresh = () =>{
  state.pageNum = 1
  state.finished = false
  state.loading = true
  getList('pull')
}

onMounted(() => {
  onRefresh()
})

</script>

<style lang="scss" scoped>
.tuijian-container {
  //时间倒计时
  .countDown-wrap {
    position: relative;
    height: 1.7rem;
    width: 100%;
    color: $mainTxtColor1;
    box-shadow: 0 0.06rem 0.1rem rgba($color: #000, $alpha: 0.1) inset;
    padding-top: 0.2rem;
    .content {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.26rem 1.02rem 0.26rem 0.84rem;
      .left-wrap {
        display: flex;
        .time {
          // width: .44rem;
          font-size: 0.36rem;
          line-height: 0.44rem;
          text-align: center;
          color: $mainTxtColor1;
          white-space: nowrap;
        }
        .dot {
          color: $mainTxtColor1;
          text-align: center;
          width: 0.2rem;
          font-size: 0.28rem;
        }
      }
      .right-wrap {
        @include flex-column-center;
        div {
          text-align: center;
          max-width: 2.5rem;
          font-size: 0.28rem;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
          white-space: normal;
        }
      }
    }
  }
}
</style>
