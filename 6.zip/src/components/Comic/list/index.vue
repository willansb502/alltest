<template>
<div class="home-video-list">
  <Tab
    :addClass="'comics-list-tab'"
    :swipeable="false"
    :titles="state.tabListObj.list"
    :animated="true"
    :background="'#151515'"
    :titleActiveColor="'#f77f77'"
    :titleInactiveColor="'#939496'"
  >
    <template v-slot:default="scope">
      <div class="tab-main">
        <HomeVideoListItem 
          :nowTabIteParent="nowTabItem"
          :nowTabItem="scope.item"
        ></HomeVideoListItem>
      </div>
    </template>
  </Tab>   
</div>
</template>
<script setup>
const Tab = defineAsyncComponent(() => import('@/components/JavTab.vue'))
const HomeVideoListItem = defineAsyncComponent(() => import('@/components/Comic/list/item.vue'))
const props = defineProps({
  nowTabItem:{
    type: Object,
    default() {
      return {};
    },      
  }   
})

const state = reactive({
  tabListObj:{
    active:0,
    list:[
      {name:"最新",id:0},
      {name:"推荐",id:1},
      {name:"人气",id:2}          
    ]
  }
})


</script>

<style lang="scss" scoped>
</style>
