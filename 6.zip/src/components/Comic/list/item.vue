<template>
<div class="home-comic-list">
  <van-pull-refresh v-model="state.refreshing" @refresh="onRefresh">
    <van-list
      v-model:loading="state.loading"
      :finished="state.finished"
      finished-text="暂时没有更多数据！"
      @load="onLoad"
      :immediate-check="false"
      error-text="请求失败，点击重新加载"
    >
    <div class="list-wrap">
      <ul>
        <DmComicCard v-for="(item, index) in state.comicsList" :item="item" :key="index"></DmComicCard>
      </ul>
    </div>    
    </van-list>
  </van-pull-refresh>    
</div>

</template>
<script setup>
import { showToast } from 'vant';
import { comicsHome} from '@/api/comics' //api列表
const DmComicCard = defineAsyncComponent(() => import('@/components/Comic/oneCard/index.vue'))
const state = reactive({
  pageNum: 1,
  pageSize: 10,
  refreshing: false,
  loading: false,
  finished: false,
  comicsList:[]
})

const props = defineProps({
  nowTabItem:{
    type: Object,
    default() {
      return {};
    },      
  },  
  nowTabIteParent:{
    type: Object,
    default() {
      return {};
    },      
  }  
})

// 首页数据请求
const getList =  async (type) => {
  const res = await comicsHome({
    id: props.nowTabIteParent.id,
    pageNum: state.pageNum,
    pageSize: state.pageSize,
    sort: props.nowTabItem.id
  })
  if (res.code === 200 && res.data) {
    state.refreshing = false;
    state.loading = false;
    if (!res.data || !res.data.comicsList ||res.data.comicsList.length < state.pageSize){
      state.finished = true;
    }
    if(type=="pull") state.comicsList = [];
    if(res.data.comicsList) state.comicsList = [...state.comicsList, ...res.data.comicsList];
  } else {
    state.finished = true;
    state.refreshing = false;
    state.loading = false;
    return showToast(res.tip)
  }
}
//上拉加载更多
const onLoad = () => {
  state.pageNum += 1
  getList();
}

// 刷新
const onRefresh = () => {
  state.pageNum = 1;
  state.finished = false;
  state.loading = true;
  getList('pull');
}


onMounted(() => {
  onRefresh()
})

</script>

<style lang="scss" scoped>
:deep() {
  .list-wrap {
    padding:0.1rem 0.37rem;
    ul {
      display: flex;
      flex-wrap: wrap;
      //justify-content: space-between;
    }
  } 
}
</style>
