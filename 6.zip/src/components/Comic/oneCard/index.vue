<template>
  <!-- 单个漫画 -->
  <li @click="clickImg(item)">
    <div class="md-img">
      <div class="md-img-bg1"></div>
      <div class="md-img-bg2"></div>
      <DecryptImg :needPadding="false" :imgRadius="'0.15rem'" class="home-pos-w100" :imgURL="item.coverImg">
        <DmComicCardPayType :item="item"></DmComicCardPayType>
      </DecryptImg>
    </div>

    <div class="decial-wrap">
      <div class="decial">
        <div>{{ item.title }}</div>
        <div>{{ item.desc }}</div>
      </div>
      <div class="likes"></div>
    </div>
  </li>
</template>
<script setup>
const DmComicCardPayType = defineAsyncComponent(() => import('@/components/Comic/PayType.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const router = useRouter()
const props = defineProps({
  item: {
    type: Object,
    default() {
      return {}
    }
  }
})
const clickImg =(item) => {
  if (route.name == 'ComicsDecial') {
    return router.replace(`/comics/decial/${item.id}`)
  }
  router.push(`/comics/decial/${item.id}`)
}

</script>

<style lang="scss" scoped>
//<!-- 一行3个 -->
li {
  position: relative;
  display: flex;
  flex-direction: column;
  width: 33.333333%;
  margin-top: 0.3rem;
  z-index: 2;
  box-sizing: border-box;
  padding: 0 0.12rem;
  .md-img-bg1 {
    display: inline-block;
    background: #741348;
    opacity: 0.4;
    width: 90%;
    height: 0.4rem;
    top: -0.2rem;
    border-top-left-radius: 0.1rem;
    border-top-right-radius: 0.1rem;
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
  }
  .md-img-bg2 {
    content: '';
    display: inline-block;
    background: #741348;
    opacity: 0.2;
    width: 80%;
    height: 0.4rem;
    top: -0.1rem;
    border-top-left-radius: 0.1rem;
    border-top-right-radius: 0.1rem;
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
  }

  .md-img {
    position: relative;
    padding-top: 140%;
    :deep()  {
      img {
        border-radius: 0.05rem;
      }
    }
  }
  .home-pos-w100 {
    position: absolute;
    top: 0;
    width: 100%;
    height: 100%;
  }
  .decial-wrap {
    width: 100%;
    border-radius: 0.12rem;
    .decial {
      display: flex;
      flex-direction: column;
      div {
        &:first-child {
          text-align: center;
          padding-top: 0.12rem;
          font-size: 0.22rem;
          color: #fff;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 1;
          white-space: normal;
        }
        &:last-child {
          font-size: 0.16rem;
          color: #a0a0a0;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
          white-space: normal;
        }
      }
    }
  }
}

@media screen and (min-width: 750px) {
  li {
    width: 16.666%;
  }
}
</style>
