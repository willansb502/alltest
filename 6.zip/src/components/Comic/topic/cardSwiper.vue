<template>
  <div class="rem-daily">
    <div class="bgImg">
      <img :src="bgImg"/>        
    </div>
    <div class="wrap">
      <div class="main">
        <div class="swiper-container" 
          :class="'swiperCard'+itemTopic.id"
          @touchmove.stop>
          <div class="swiper-wrapper">
            <div
              ref="swiper-slide-scale"
              class="swiper-slide"
              v-for="item in swiperList"
              :key="item.id"
            >
              <div class="item"  @click="clickImg(item)">
                <DmComicCardPayType :item="item"></DmComicCardPayType>
                <div class="decial-wrap">
                  <div>
                    <img src="@/assets/imgs/comics/fire.png" alt="">
                    {{numberFilter(item.watchTimes)}}
                  </div>
                  <div>{{item.title}}</div>
                  <div>{{item.desc}}</div>
                  <div>作者：{{item.author?item.author:'暂无'}}</div>
                </div>
                <DecryptImg :needPadding="false" class="md-img" :imgRadius="'0.12rem'" :lazy="false"  :imgURL="item.coverImg" />
              </div>
            </div>
          </div>
        </div>          
      </div>

    </div>

  </div>
</template>
<script setup>
import { handleVerAutoImg} from '@/utils/utils_tools'
import { numberFilter} from '@/utils/filter'
const router = useRouter()
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const DmComicCardPayType = defineAsyncComponent(() => import('@/components/Comic/PayType.vue'))
const state = reactive({
  bgImg:"",
  swiperList: [],
  imgCDN:computed(() => store.getters['cdn'])
})
const props = defineProps({
  itemTopic: {
    type: Object,
    default() {
      return {}
    },
  }
})
//初始化轮播
const initSwiper = () => {
  new Swiper({
    //防止一个页面多个轮播
    el: '.swiperCard'+props.itemTopic.id,
    effect: 'cards',
    cardsEffect: {
      slideShadows: true,
    },
    // delay: 5000,
    // autoplay:true,
    on: {
      slideChangeTransitionStart: function () {
        setTimeout(() => {
          that.$refs["swiper-slide-scale"].forEach((item)=>{
            if(item.className=="swiper-slide swiper-slide-visible swiper-slide-active"){
              state.bgImg=item.children[0].children[2].children[0].children[0].src;
            }
          });          
        }, 300);            
      },
    },
  })
}
//批量获取图片
const getCardList =async () => {
  if(!props.itemTopic.comicsList) return;
  state.swiperList=JSON.parse(JSON.stringify(props.itemTopic.comicsList));
  initSwiper();
  const res = await handleVerAutoImg(state.imgCDN + state.swiperList[0].coverImg)
  state.bgImg=res;
}
const clickImg = (item) => {
  router.push(`/comics/decial/${item.id}`)
}  

onMounted(async () => {
  getCardList()
}) 

  // activated() {
  //   initSwiper();
  // },     
</script>

<style lang="scss" scoped>
//推荐专区，每日推荐
.rem-daily {
  position: relative;
  height: 9.52rem;
  // margin-top: 0.44rem;
  &::before{
    content: "";
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0; 
    bottom: 0;
    background: rgba($color: #000000, $alpha: 0.7);
    -webkit-backdrop-filter: blur(0.1rem);
    backdrop-filter: blur(0.1rem);      
  }     
  .bgImg{
    width: 100%;
    height: 100%;
    font-size: 0;   
    img{
      width: 100%;
      height: 100%;
    }
  }
  .wrap{
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    .main{
      padding-top: 0.77rem;
      .swiper-container {
        display: flex;
        align-items: center;
        justify-content: center;
        .swiper-slide {
          border-radius: 0.24rem;
          height: 7.97rem;
          .item {
            position: relative;
            font-size: 0.24rem;
            color: $mainTxtColor1;
            margin-left: 0.76rem;
            width: 70%;
            height: 100%;
            .decial-wrap {
              width: 100%;
              position: absolute;
              border-radius: 0.44rem;
              background: rgba($color: #000000, $alpha:0.3);
              bottom: 0;
              padding: 0.2rem 0.37rem;
              div{
                &:nth-child(1){
                  @include flex-align-center;
                  img{
                    margin-right: 0.05rem;
                    width: 0.28rem;
                  }
                }
                &:nth-child(2){
                  font-size: 0.28rem;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  display: -webkit-box;
                  -webkit-box-orient: vertical;
                  -webkit-line-clamp: 1;
                  white-space: normal;                  
                }
                &:nth-child(3){
                  overflow: hidden;
                  text-overflow: ellipsis;
                  display: -webkit-box;
                  -webkit-box-orient: vertical;
                  -webkit-line-clamp: 2;
                  white-space: normal;  
                  color: #ccc;                
                }
                &:nth-child(4){
                  text-align: right;
                }                                                
              }
              // white-space: nowrap;
              // position: absolute;
              // bottom: 0.32rem;
              // left: 50%;
              // transform: translateX(-50%);
              // z-index: 9;
              // font-size:0.26rem ;
            }
            .bg-img {
              width: 100%;
              height: 100%;
              border-radius: 0.24rem;
              object-fit: cover;
            }
          }
        }
      }
    }

  }

}
</style>
