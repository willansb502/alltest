<template>
  <!-- 合集一行3个 -->
  <div class="collection-wrap">
    <div class="header">
      <div>{{ itemTopic.name }}</div>
      <div class="desc">{{ itemTopic.desc }}</div>
    </div>
    <!--切换面板 -->
    <Tab
      :addClass="'comics-sub-tab'"
      @change="change"
      :swipeable="true"
      :sticky="false"
      :titles="itemTopic.topicInfo"
      :animated="true"
      :background="'#323232'"
      :titleActiveColor="'#ff8b00'"
      :titleInactiveColor="'#ccc'"
      :ifScrollTop="false"
    >
      <template v-slot:default="scope">
        <div class="tab-main">
          <component :itemTopic="itemTopic" :tabItemDatas="scope" :is="'CollectionList'"></component>
        </div>
      </template>
    </Tab>
  </div>
</template>
<script setup>
const CollectionList = defineAsyncComponent(() => import('@/components/Comic/topic/collection/list.vue'))
const Tab = defineAsyncComponent(() => import('@/components/JavTab.vue'))
const props = defineProps({
  itemTopic: {
    type: Object,
    default() {
      return {}
    }
  }
})
const state = reactive({
  activeId: 0
})
const change =() => {
  state.activeId = id
}
onMounted(async () => {
  if (props.itemTopic.topicInfo.length) state.activeId = props.itemTopic.topicInfo[0].id
}) 

</script>

<style lang="scss" scoped>
//<!-- 一行3个 -->
.collection-wrap {
  box-shadow: 0 0.06rem 0.1rem rgba($color: #000, $alpha: 0.1);
  .header {
    display: flex;
    align-items: center;
    padding: 0.3rem 0.37rem;
    div {
      &:first-child {
        font-size: 0.28rem;
        color: #ccc;
        background-image: -webkit-linear-gradient(left, #f4ce4e, #d4c156);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-weight: 600;
      }
    }
    div {
      &:last-child {
        color: #ccc;
        opacity: 0.5;
        font-size: 0.24rem;
        padding-left: 0.1rem;
      }
    }
  }
  .list-wrap {
    padding: 0 0.37rem;
    ul {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      li {
        display: flex;
        flex-direction: column;
        width: 2.1rem;
        margin-bottom: 0.2rem;
        .md-img {
          height: 2.86rem;
        }
        .decial-wrap {
          width: 100%;
          border-radius: 0.12rem;
          .decial {
            display: flex;
            flex-direction: column;
            div {
              &:first-child {
                padding-top: 0.12rem;
                font-size: 0.28rem;
                color: #ccc;
              }
              &:last-child {
                font-size: 0.18rem;
                color: #a0a0a0;
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 2;
                white-space: normal;
              }
            }
          }
        }
      }
    }
  }
}

@media screen and (min-width: 750px) {
  .list-wrap {
    padding: 0 0.37rem;
    ul {
      li {
        width: 16.2% !important;
      }
    }
  }
}
</style>
