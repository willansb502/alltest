<template>
  <!-- 一行3个 -->
  <div class="threeBox-wrap">
    <div class="list-wrap">
      <ul>
        <DmComicCard v-for="(item, index) in state.comicsList" :item="item" :key="index"></DmComicCard>
      </ul>
    </div>
    <div class="btn">
      <div @click="fn_more">查看更多</div>
      <div @click="fn_comicsTopicChange"><van-icon name="replay" />换一换</div>
    </div>
  </div>
</template>
<script setup>
import { showToast } from 'vant';
const router = useRouter()
import { comicsTopicChange } from '@/api/comics' //api列表
const DmComicCard = defineAsyncComponent(() => import('@/components/Comic/oneCard/index.vue'))
const props = defineProps({
  itemTopic: {
    type: Object,
    default() {
      return {}
    }
  },
  activeId: {
    type: Number,
    default() {
      return 0
    }
  },
  tabItemDatas: {
    type: Object,
    default() {
      return {}
    }
  }
})
const state = reactive({
  comicsList: []
})


//查看更多
const fn_more =async () => {
  router.push({
    path: `/comics/more`,
    query: {
      id: props.tabItemDatas.item.id,
      name: props.tabItemDatas.item.name
    }
  })
}
const fn_comicsTopicChange =async () => {
  const res = await comicsTopicChange({
    id: props.tabItemDatas.item.id
  })
  if (res.code === 200 && res.data) {
    state.comicsList = res.data.list
  } else {
    return showToast(res.tip)
  }
}
onMounted(async () => {
  state.comicsList = props.itemTopic.topicInfo[props.tabItemDatas.index].comicsList
}) 
</script>

<style lang="scss" scoped>
//<!-- 一行3个 -->
.threeBox-wrap {
  position: relative;
  padding-bottom: 0.3rem;
  display: flex;
  flex-direction: column;
 //justify-content: flex-end;
  .list-wrap {
    padding: 0 0.37rem;
    ul {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      li {
        display: flex;
        flex-direction: column;
        width: 2.1rem;
        margin-bottom: 0.2rem;
        .md-img {
          height: 2.86rem;
        }
        .decial-wrap {
          width: 100%;
          border-radius: 0.12rem;
          .decial {
            display: flex;
            flex-direction: column;
            div {
              &:first-child {
                padding-top: 0.12rem;
                font-size: 0.28rem;
                color: #6a6a6a;
              }
              &:last-child {
                font-size: 0.18rem;
                color: #a0a0a0;
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 2;
                white-space: normal;
              }
            }
          }
        }
      }
    }
  }
  .btn {
    display: flex;
    width: 5rem;
    margin: 0 auto;
    margin-top: 0.1rem;
    div {
      width: 1.72rem;
      height: 0.6rem;
      line-height: 0.6rem;
      text-align: center;
      border-radius: 0.22rem;
      box-shadow: 0.06rem 0.06rem 0.1rem rgba($color: #000, $alpha: 0.1);
      font-size: 0.22rem;
      margin: 0 auto;
      background: $mainBgColor;
      color: rgb(255, 139, 0);
      // &:first-child{
      //   color:#ff7777;
      // }
    }
  }
}
@media screen and (min-width: 750px) {
  .list-wrap {
    padding: 0 0.37rem;
    ul {
      li {
        width: 16.2% !important;
      }
    }
  }
}
</style>
