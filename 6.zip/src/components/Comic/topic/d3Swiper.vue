<template>
  <div class="rem-daily">
    <MoreHeader :itemTopic="itemTopic"></MoreHeader>
    <div
      style="
        width: 100%;
        position: relative;
        -webkit-transition: background 1s ease-in;
        -moz-transition: background 1s ease-in;
        -o-transition: background 1s ease-in;
        transition: background 1s ease-in;
        background-size: cover;
        -webkit-transition: background 1s;
        transition: background 1s;
      "
      :style="[state.bgImg ? { 'background-image': 'url(' + state.bgImg + ')' } : '']"
    >
      <div class="slide-mark"></div>
      <div class="swiper-container" :class="'d3Swiper' + itemTopic.id" @touchmove.stop>
        <div class="swiper-wrapper">
          <div ref="swiperSlideScale" class="swiper-slide" v-for="item in state.swiperList" :key="item.id">
            <div class="swiper-slide-inner" @click="clickImg(item)">
              <DmComicCardPayType :item="item"></DmComicCardPayType>

              <DecryptImg
                :needPadding="false"
                class="md-img"
                :imgRadius="'0.12rem'"
                :lazy="false"
                :imgURL="item.coverImg"
              />
            </div>
            <div class="decial-wrap van-ellipsis" style="font-size: 0.16rem; text-align: center">
              {{ item.title }}
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="line"></div>
  </div>
</template>
<script setup>
import { useStore } from 'vuex'
const store = useStore()
const router = useRouter()
import { handleVerAutoImg } from '@/utils/utils_tools'
const DmComicCardPayType = defineAsyncComponent(() => import('@/components/Comic/PayType.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const MoreHeader = defineAsyncComponent(() => import('@/components/Comic/topic/moreHeader.vue'))
let swiperSlideScale = ref(null);
const state = reactive({
  tot: null,
  bgImg: '',
  swiperList: [],
  mySwiper: null,
  //初始化
  initialSlide: 3,
  imgCDN:computed(() => store.getters['cdn'])  
})
const props = defineProps({
  itemTopic: {
    type: Object,
    default() {
      return {}
    }
  }
})
//初始化轮播
const initSwiper = () => {
  state.mySwiper = new Swiper({
    //防止一个页面多个轮播
    el: '.d3Swiper' + props.itemTopic.id,
    // loop: true,
    initialSlide: state.initialSlide,
    slidesPerView: 3,
    centeredSlides: true,
    grabCursor: true,
    observeParents: true,
    observer: true,
    breakpoints: {
      //当swiper宽度大于等于768
      768: {
        slidesPerView: 5,
        spaceBetween: 10
      },
      1540: {
        slidesPerView: 6,
        spaceBetween: 20
      }
    },
    on: {
      // slideChangeTransitionStart: function () {
      //   if (state.swiperList[state.activeIndex]) state.bgImg = state.swiperList[state.activeIndex].coverImg
      // }
    }
  })
  state.mySwiper.on('slideChange', () => {
    state.tot = setTimeout(() => {
      swiperSlideScale.forEach(item => {
        if (item.className == 'swiper-slide swiper-slide-active') {
          state.bgImg = item.getElementsByTagName('img')[0].src
        }
      })
    }, 300)
  })
}
//批量获取图片
const getCardList = () => {
  if (!props.itemTopic.comicsList) return
  state.swiperList = JSON.parse(JSON.stringify(props.itemTopic.comicsList))
  //获取背景图片
  getImg(state.swiperList[state.initialSlide])
  initSwiper()
}
//获取背景图片
const getImg = async (element) => {
  const res = await handleVerAutoImg(state.imgCDN + element.coverImg)
  state.bgImg = res
}

const clickImg = async (item) => {
  router.push(`/comics/decial/${item.id}`)
} 

onMounted(async () => {
  getCardList()
}) 
 
onUnmounted(() => {
  clearTimeout(state.tot)  
})
</script>

<style lang="scss" scoped>
//推荐专区，每日推荐
.rem-daily {
  .header {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    padding: 0 0.17rem 0.2rem 0.17rem;
    box-shadow: 0 0.06rem 0.1rem rgba(0, 0, 0, 0.1);
    div {
      &:first-child {
        font-size: 0.32rem;
        color: #6a6a6a;
      }
      &:last-child {
        background: $mainBgColor;
        @include flex-center;
        font-size: 0.24rem;
        width: 1.02rem;
        height: 0.46rem;
        color: #ff8b00;
        border-radius: 0.12rem;
        box-shadow: 0.06rem 0.06rem 0.1rem rgba($color: #000, $alpha: 0.1);
      }
    }
  }
  .slide-mark {
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 0;
    background: rgba(220, 211, 211, 0.25);
    backdrop-filter: blur(5px);
    -webkit-backdrop-filter: blur(5px);
  }
  .swiper-container {
    position: relative;
    padding-top: 0.66rem;
    padding-bottom: 0.66rem;
    width: 100%;
    background-position: center center;
    background-size: 100% auto;
    &::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
    }

    .swiper-slide {
      cursor: pointer;
      padding-top: 48%;
      position: relative;
      padding: 0 0.2rem;

      .swiper-slide-inner {
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 0;
        position: relative;
        font-size: 0.24rem;
        color: $mainTxtColor1;

        .decial-wrap {
          text-align: center;
          position: absolute;
          bottom: 0.32rem;
          left: 50%;
          transform: translateX(-50%);
          z-index: 9;
          font-size: 0.24rem;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 1;
          white-space: normal;
          width: 100%;
          padding: 0 0.2rem;
        }
        .bg-img {
          width: 100%;
          height: 100%;
          border-radius: 0.24rem;
          object-fit: cover;
          border: 1px solid #9c7a55;
        }
        .md-img {
          height: 100%;
          overflow: hidden;
        }
      }
    }
    .swiper-slide-active {
      transform: scale(1.2);
      transition: all 0.5s;
      .item {
        border-radius: 0.24rem;
        box-shadow: 0.06rem 0.06rem 0.1rem rgba($color: #000, $alpha: 0.1);
      }
    }
  }
  .line {
    width: 100%;
    height: 0.1rem;
    box-shadow: 0 -0.06rem 0.1rem rgba(0, 0, 0, 0.1);
  }
}
</style>
