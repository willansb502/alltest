<template>
  <!-- 一行1个,本月热门 -->
  <div class="monthHot-wrap">
    <div class="header">
      <div>{{ itemTopic.name }}</div>
    </div>
    <div class="list-wrap">
      <ul>
        <li v-for="(item, index) in itemTopic.comicsList" :key="index" @click="clickImg(item)">
          <DecryptImg class="md-img" :imgRadius="'0.15rem'" :imgURL="item.coverImg">
            <DmComicCardPayType :item="item"></DmComicCardPayType>
          </DecryptImg>
          <div class="text">
            <div>{{ item.title }}</div>
            <div>{{ item.desc }}</div>
          </div>
          <div class="rank">
            {{ item.rank }}
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>
<script setup>
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const DmComicCardPayType = defineAsyncComponent(() => import('@/components/Comic/PayType.vue'))
const router = useRouter()
const props = defineProps({
  itemTopic: {
    type: Object,
    default() {
      return {}
    }
  }
})
const clickImg = (item) =>{
  router.push(`/comics/decial/${item.id}`)
}
</script>

<style lang="scss" scoped>
//<!-- 一行1个,本月热门-->
.monthHot-wrap {
  padding-bottom: 0.3rem;
  .header {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    padding: 0.3rem 0.37rem;
    div {
      &:first-child {
        font-size: 0.32rem;
        color: #fcca35;
      }
    }
  }
  .list-wrap {
    ul {
      display: flex;
      flex: 1;
      flex-direction: column;
      li {
        padding: 0 0.6rem;
        position: relative;
        display: flex;
        align-items: center;
        width: 6.83rem;

        height: 2.18rem;
        border-radius: 0.41rem;
        background: rgb(23, 23, 23);
        margin: 0 auto;
        margin-bottom: 0.2rem;
        .md-img {
          width: 1.38rem;
          height: 1.84rem;
          margin-right: 0.2rem;
          box-shadow: 0 0 0.1rem 0 rgba($color: #000000, $alpha: 0.3);
          :deep()  {
            .warp {
              height: 100% !important;
            }
          }
        }
        .text {
          div {
            &:first-child {
              padding-top: 0.2rem;
              width: 3.92rem;
              font-size: 0.3rem;
              color: #fff;
              padding-bottom: 0.05rem;
              overflow: hidden;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 1;
              white-space: normal;
            }
            &:last-child {
              width: 3.92rem;
              font-size: 0.22rem;
              color: #b0a799;
              overflow: hidden;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              white-space: normal;
            }
          }
        }
        .rank {
          line-height: 0.96rem;
          text-align: center;
          width: 0.88rem;
          height: 0.96rem;
          background: #ce9f66;
          position: absolute;
          right: 0.3rem;
          top: -0.1rem;
          color: $mainTxtColor1;
          font-size: 0.22rem;
          padding-bottom: 0.9rem;
          border-bottom-left-radius: 0.24rem;
          border-bottom-right-radius: 0.24rem;
          background: url('../../../assets/imgs/comics/hot.png');
          background-size: 100% 100%;
        }
      }
    }
  }
}
@media screen and (min-width: 960px) {
  .list-wrap {
    ul {
      flex-flow: row wrap !important;
      width: 100%;
      li {
        cursor: pointer;
        display: inline-block;
        width: 30% !important;
        .md-img {
          width: 1.68rem !important;
          height: 2.2rem !important;
        }
      }
    }
  }
}
</style>
