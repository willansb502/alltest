<template>
  <div class="header">
    <div class="decial-wrap">
      <span class="name">{{itemTopic.name}}</span>
      <!-- 有价格 -->
      <div class="buy-wrap" v-if="itemTopic.price">
        <div v-if="!itemTopic.isBuy" @click="fn_buyHj" class="doNotPay" >
          共{{itemTopic.comicsCount}}部  
          <div class="buy-btn">
            <div class="price">
              <img src="@/assets/imgs/index/gold.png" alt="">
              {{changeGold(itemTopic.price,2)}}
            </div>
            <div  class="btn">
              购买
            </div>
          </div>          
        </div>
        <div v-else class="hasBuy">
          共{{itemTopic.comicsCount}}部  
          <div>已购买</div>
        </div>
      </div>      
      <span v-else class="desc">
        <span>{{itemTopic.desc}}</span>
      </span>
    </div>
    <div class="more" @click="$router.push(
      { path: `/comics/more`,query:{
        id:itemTopic.id,
        name:itemTopic.name
      }}
    )">
      更多<img src="@/assets/imgs/comics/to-right.png" alt="">
    </div>
  </div>    
</template>
<script setup>
import { showToast } from 'vant'
import { changeGold } from '@/utils/filter'
import { comicsTopicCtPay } from '@/api/comics' //api列表
const router = useRouter()

const props = defineProps({
  itemTopic: {
    type: Object,
    default() {
      return {}
    },
  } 
})
//合集购买
const fn_buyHj =async () =>{
  const res = await comicsTopicCtPay({
    id: props.itemTopic.id,
  });
  if (res.code === 200&&res.data.code===200) {
    showToast("合集购买成功");
    props.itemTopic.isBuy=true;
  } else {
    showToast(res.data.msg||res.tip);
    if(res.data.msg=='余额不足'){
      router.push({path:`/mine/wallet`});          
    }        
  }   
}

</script>

<style lang="scss" scoped>
  .header{
    display: flex;
    justify-content: space-between;
    align-items: flex-end;

    padding: 0.1rem 0.37rem ;
    .decial-wrap{
      font-size: 0.28rem;
      color: #fff;
      display: flex;
      align-items: center; 
      .name{
        background-image: -webkit-linear-gradient(left, #f4ce4e, #edcc6a);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;    
        font-weight: 600;         
      }       
      .desc{
        color:#ccc;
        opacity: 0.5;
        font-size: 0.24rem;
        padding-left: 0.1rem;               
      }  
      .desc,.name{
        max-width: 3rem;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1;
        white-space: normal;  
      }   
      .buy-wrap{
        .doNotPay{
          font-size: 0.24rem;
          display: inline-block;
          display: flex;
          align-items: center;
          margin-left: 0.1rem;
          .buy-btn{
            margin-left: 0.22rem;
            @include box-shadow-all;
            background: $mainBgColor;
            display: flex;
            align-items: center;
            border-radius: 0.12rem;
            .price{
              display: flex;
              align-items: center;
              padding: 0.12rem 0.19rem;
              img{
                margin-right: 0.05rem;
                width: 0.25rem;
              }
            }
            .btn{
              padding: 0.12rem 0.19rem;
              background: #e15d59;
              color: $mainTxtColor1;
              border-radius: 0.12rem;
            }
          }          
        }
        .hasBuy{
          font-size: 0.24rem;
          display: flex;
          align-items: center;
          margin-left: 0.1rem;
          div{
            margin-left: 0.22rem;
            font-size: 0.24rem;
            padding: 0.12rem 0.19rem;
            background: #e15d59;
            color: #fff;
            border-radius: 0.12rem;            
          }

        }
      }         
    }
    .more{
      @include flex-center;
      font-size: 0.24rem;
      width: 1.02rem;
      height: 0.46rem;
      color: #ccc;
      border-radius: 0.12rem;
      img{
        filter: brightness(100);
        margin-left: 0.08rem;
        width: 0.124rem;
      }
    }        
  }
</style>
