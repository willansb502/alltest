<template>
  <!-- 一行3个 -->
  <div class="threeBox-wrap">
    <MoreHeader :itemTopic="itemTopic"></MoreHeader>
    <div class="list-wrap">
      <ul>
        <DmComicCard v-for="(item, index) in itemTopic.comicsList" :item="item" :key="index"></DmComicCard>
      </ul>
    </div>
  </div>
</template>
<script setup>
const DmComicCard = defineAsyncComponent(() => import('@/components/Comic/oneCard/index.vue'))
const MoreHeader = defineAsyncComponent(() => import('@/components/Comic/topic/moreHeader.vue'))
const props = defineProps({
  itemTopic: {
    type: Object,
    default() {
      return {}
    },
  }
})
</script>

<style lang="scss" scoped>
//<!-- 一行3个 -->
.threeBox-wrap {
  box-shadow: 0 0.06rem 0.1rem rgba($color: #000, $alpha: 0.1);
  padding-bottom: 0.1rem;
  .list-wrap {
    padding: 0 0.17rem;
    ul {
      display: flex;
      flex-wrap: wrap;
      //justify-content: space-between;
    }
  }
}
</style>
