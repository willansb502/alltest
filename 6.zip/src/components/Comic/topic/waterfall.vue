<template>
  <!-- 专题二瀑布流 -->
  <div class="waterfall-wrap">
    <MoreHeader :itemTopic="itemTopic"></MoreHeader>
    <div class="list-wrap">
      <ul>
        <li @click="clickImg(item)" v-for="(item, index) in itemTopic.comicsList" :key="index" :class="'item' + index">
          <DmComicCardPayType :item="item"></DmComicCardPayType>
          <DecryptImg
            :needPadding="false"
            :imgRadius="'0.12rem'"
            :lazy="false"
            class="md-img"
            :imgURL="item.coverImg"
          />
          <div class="decial-wrap" :class="'txt' + index">
            <div class="decial">
              <div>{{ item.title }}</div>
              <div>{{ item.desc }}</div>
            </div>
          </div>
          <div class="likes">
            <img src="@/assets/imgs/comics/fire.png" alt="" />
            {{numberFilter(item.watchTimes)}}
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>
<script setup>
import { numberFilter } from '@/utils/filter'
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const DmComicCardPayType = defineAsyncComponent(() => import('@/components/Comic/PayType.vue'))
const MoreHeader = defineAsyncComponent(() => import('@/components/Comic/topic/moreHeader.vue'))
const router = useRouter()
const props = defineProps({
  itemTopic: {
    type: Object,
    default() {
      return {}
    }
  }
})
const clickImg = (item) =>{
  router.push(`/comics/decial/${item.id}`)
}
</script>

<style lang="scss" scoped>
//瀑布流
.waterfall-wrap {
  box-shadow: 0 0.06rem 0.1rem rgba($color: #000, $alpha: 0.1);
  padding-bottom: 0.1rem;
  .list-wrap {
    ul {
      column-count: 2;
      column-gap: 0.2rem;
      padding: 0 0.35rem;
      li {
        position: relative;
        width: 3.28rem;
        height: 4.49rem;
        box-shadow: 0.06rem 0.06rem 0.1rem rgba($color: #000, $alpha: 0.1);
        margin-bottom: 0.2rem;
        border-radius: 0.12rem;
        .md-img {
          :deep()  {
            .warp {
              border-radius: 0.12rem;
            }
          }
        }
        &.item0,
        &.item5 {
          height: 4.49rem;
        }
        .decial-wrap {
          position: absolute;
          width: 100%;
          left: 0;
          bottom: 0;
          background: rgba($color: rgb(125, 120, 120), $alpha: 0.8);
          border-radius: 0.12rem;
          padding: 0.13rem;
          .decial {
            text-align: right;
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            div {
              &:first-child {
                font-size: 0.24rem;
                color: #fff;
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 1;
                white-space: normal;
              }
              &:last-child {
                max-width: 60%;
                font-size: 0.18rem;
                color: #ccc;
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 2;
                white-space: normal;
                min-height: 0.5rem;
              }
            }
          }
          &.txt5,
          &.txt0 {
            background: $mainBgColor;
          }
        }
        .likes {
          font-size: 0.24rem;
          color: rgb(240, 1, 1);
          position: absolute;
          bottom: 0.2rem;
          @include flex-align-center;
          img {
            width: 0.28rem;
            margin-right: 0.05rem;
          }
        }
      }
    }
  }
}
@media screen and (min-width: 750px) {
  //瀑布流
  .waterfall-wrap {
    margin: 0 auto;
    
    .list-wrap {
      ul {
        @include flexbox($jc: flex-start, $ai: flex-start, $fd: row, $fw: nowrap);
        li {
          width: 4.98rem;
          height: 6.69rem;
          cursor: pointer;
          margin: 0 auto;
          &.item0,
          &.item5 {
            height: 6.69rem;
          }
        }
      }
    }
  }
}
</style>
