<template>
  <div class="comment" :class="{'active':state.list.length}"   >
    <div class="header">{{state.newComments}}条评论</div>
    <van-pull-refresh  v-if="state.list.length" :disabled="disabledPull"  v-model="state.isLoading" @refresh="onRefresh">
      <van-list
        v-model:loading="state.loading"
        :finished="state.finished"
        finished-text=""
        @load="onLoad"
        :immediate-check="false"
      >
      <div class="content-main-wrap">
        <div class="content-main" v-for="item in state.list" :key="item.id">
          <DecryptImg class="user-header" :imgURL="item.userAvatar" />
          <!-- 第一层用户 -->
          <div class="comment-user">
            <div class="first-comment">
              <div class="comment-user-name">
                {{ item.userName }}
                <span v-if="item.userId === publisher.userId" class="zuoze">作者</span>
              </div>
              <div class="text">
                <p class="comment-user-text">
                  {{ item.text }}
                </p>
                <!-- 回复按钮，时间 -->
                <div class="comment-user-res">
                  <p class="comment-user-time">
                    {{ timeDiff(item.createdAt) }}
                  </p>
                  <!-- 回复 -->
                  <div class="resTxt" @click.stop="clickRespondText(item)">
                    回复
                  </div>
                </div>
              </div>
              <!-- 展开 -->
              <div
                class="comment-user-open"
                v-if="item.commentCount && item.id !== state.activeIndex"
              >

                <div class="comment-user-open-right" @click="openSon(item)">
                  <span>展开 {{ item.commentCount }} 条回复</span>
                </div>
              </div>
              <!-- 第二层用户评论 -->
              <template v-if="item.id === state.activeIndex">
                <div
                  class="second-comment"
                  v-for="sItem in state.secondList"
                  :key="sItem.id"
                >
                  <DecryptImg class="user-header" :imgURL="sItem.userAvatar" />
                  <div class="second-comment-main">
                    <div class="comment-user-name comment-user-name2">
                      {{ sItem.userName }}
                      <span v-if="sItem.userId === 10551" class="zuoze"
                        >作者</span
                      >
                      <span class="color">回复</span> {{item.userName}} <span class="color">的评论</span>
                    </div>
                    <div class="text">
                      <div class="comment-user-text">
                        {{ sItem.text }}
                      </div>
                      <!-- 回复按钮，时间 -->
                      <div class="comment-user-res">
                        <p class="comment-user-time">
                          {{ timeDiff(sItem.createdAt) }}
                        </p>
                        <!-- 回复 -->
                        <!-- <div
                          class="resTxt"
                          @click.stop="clickRespondText(item)"
                        >
                          回复
                        </div> -->
                      </div>
                    </div>
                  </div>
                </div>
              </template>
            </div>
          </div>
        </div>        
      </div>

      </van-list>
    </van-pull-refresh>
    <div class="public-noData">
      暂无更多数据
    </div>    
    <!-- 评论 -->
    <div class="submit-box">
      <div class="line-bot"></div>
      <!-- 是否为会员 -->
      <div class="submit-btn" @click="toVip" v-if="!state.isVipMember">
        开通VIP 立即评论
      </div>
      <div class="submit-input" v-else>
        <van-field v-model="state.text" :placeholder="state.placeholder" />
        <span class="submit-txt" @click="addComment">发送</span>
      </div>
    </div>
  </div>    
</template>

<script setup>
import { showToast } from 'vant'
const router = useRouter()
import { timeDiff } from '@/utils/filter'
import { comCommentList,comCommentAdd} from '@/api/comics' //api列表
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const emits = defineEmits(["addComments"])
const props = defineProps({
  disabledPull: {
    // 评论对象id
    type: Boolean,
    default() {
      return false
    },
  },

  objectId: {
    // 评论对象id
    type: Number,
    default() {
      return 0
    },
  },
  objectype: {
    //评论类型
    type: Number,
    default() {
      return 0
    },
  },
  publisher: {
    // 发布者id
    type: Object,
    default() {
      return {}
    },
  },
})

const state = reactive({
  text: '', //评论内容
  placeholder:"喜欢就给个评论支持一下～",
  pageNum: 1,
  pageSize: 10,
  activeIndex: 0, // 展开的id
  newComments: 0, //评论数
  parentsId: undefined, // 父级回复id
  list: [], // 评论列表
  secondList: [], //二级评论列表
  //上拉加载
  loading: false,
  //上拉加载完成
  finished: false,
  //下拉刷新
  isLoading: false,
  //评论状态
  commentReady:true,
  isVipMember:computed(() => store.getters['isMember'])
})
onMounted(async () => {
  // 一级列表请求参数
  const data = {
    objectId: props.objectId,
    objectType: props.objectype,
    pageNum: 1,
    pageSize: state.pageSize,
    parentsId: undefined,
  }
  getCommentList(data)
})
// 跳转vip开通页面
const toVip = () =>{
  router.push('/vip')
}
// 点击回复按钮
const clickRespondText = (item) =>{
  state.placeholder=`回复 ${item.userName}`;
  if (!state.isVipMember) {
    return showToast('会员才参与可以评论!')
  }
  state.parentsId = item.id
}

// 获取评论列表
const getCommentList =async (data,type) =>{
  state.loading = true
  const res = await comCommentList(data)
  if (res.code === 200) {
    // 有parentsId 为二级列表请求
    state.loading = false;
    state.isLoading = false;
    //防止出现两个刷新
    if(type=="pull"||type=='comment') state.list = [] ,state.secondList = [];

    if (data.parentsId) {
      if (!res.data ||!res.data.list|| res.data.list.length < state.pageSize) {
        state.finished = true
      }
      if(res.data.list) state.secondList = [...state.secondList, ...res.data.list]
    } else {
      if (!res.data || !res.data.list||res.data.list.length < state.pageSize) {
        state.finished = true
      }
      if(res.data.list) state.list = [...state.list, ...res.data.list]
    };
    //评论数算上子集
    state.newComments=state.list.length;
    state.list.forEach((item)=>{
      state.newComments=state.newComments+item.commentCount;
    });
  } else {
    state.loading = false
    state.isLoading = false
    state.finished = true
    return showToast(res.tip || res.data)
  }
}  
// 发布评论 
const addComment =async (data,type) =>{
  if(!state.commentReady){
    return showToast('评论操作过快!');
  }
  state.commentReady=false;
  if (!state.text) {
    return showToast('请输入评论内容!');
  }
  const res = await comCommentAdd({
    objectId: props.objectId, // 对象id
    objectType: props.objectype, // 对象类型
    parentsId: state.parentsId, // 上级id
    // replyId: replyId, // 回复id
    // score: score, // 评分 没有为0
    text: state.text,
  })
  state.activeIndex = 0
  if (res.code === 200) {
    state.commentReady=true;
    state.text = null
    state.newComments += 1;
    state.parentsId = undefined // 每次发布做一次清除操作
    const data = {
      objectId: props.objectId,
      objectType: props.objectype,
      pageNum: state.pageNum,
      pageSize: state.pageSize,
      parentsId: state.parentsId,
    }
    getCommentList(data,'comment');
    emits("addComments")    
    state.placeholder=`喜欢就给个评论支持一下～`;
    return showToast('评论成功');
    
  } else {
    state.commentReady=true;
    state.loading = false
    state.isLoading = false
    state.finished = true
    return showToast(res.tip || res.data)
  }
}  
// 打开二级评论列表
const openSon =(item) =>{
  state.activeIndex = item.id
  state.pageNum = 1
  state.finished = false

  state.parentsId = item.id
  const data = {
    objectId: props.objectId,
    objectType: props.objectype,
    pageNum: state.pageNum,
    pageSize: state.pageSize,
    parentsId: item.id,
  }
  state.secondList = []
  getCommentList(data)
}
//上拉刷新
const onRefresh =() =>{
  //表示处于可以下拉状态
  state.finished = false
  state.loading = true
  state.activeIndex = 0
  // 一级列表请求参数
  const data = {
    objectId: props.objectId,
    objectType: props.objectype,
    pageNum: 1,
    pageSize: state.pageSize,
    parentsId: undefined,
  }
  getCommentList(data,"pull")
}
//下拉加载
const onLoad =() =>{
  state.pageNum += 1
  // 一级列表请求参数
  const data = {
    objectId: props.objectId,
    objectType: props.objectype,
    pageNum: state.pageNum,
    pageSize: state.pageSize,
    parentsId: state.parentsId,
  }
  getCommentList(data)
}
</script>

<style lang="scss" scoped>
.comment{
  position: relative;
  background: $mainBgColor;
  border-top-right-radius: 0.8rem;
  border-top-left-radius: 0.8rem;
  //没有评论数，三角+下面空白需要隐藏
  &.active{
    padding-bottom: 1.5rem;
    &::before{
      content: "";
      position: absolute;
      top: 0;
      left: 50%;  
      transform: translateX(-50%);   
      width: 0;
      height: 0;
      border-width: 0.18rem;
      border-style: solid;
      border-color: #ff8b00 transparent transparent transparent;    
    }    
  }
  .header{
    font-size: 0.26rem;
    text-align: center;
    padding: 0.3rem 0;
    margin: 0 0.3rem;
    border-bottom: 1px solid #eee;
    color: #6a6a6a;
  }
}
//  评论主体内容
.content-main-wrap{
  height: 4.4rem;
  overflow: auto;  
  @include scrollbar-hide;
  .content-main {
    display: flex;
    padding:0.3rem 0 ;
    margin: 0 0.3rem;
    box-sizing: border-box;
    max-width: 100%;
    border-bottom: 0.02rem solid #eee;
    &:last-child{
       border-bottom: 0;
    }
    .user-header {
      width: 0.5rem;
      height: 0.5rem;
      border-radius: 50%;
      margin-right: 0.2rem;
      :deep()  {
        .warp {
          font-size: 0;
          border-radius: 50%;
        }
        .img {
          border-radius: 50%;
          width: 0.5rem;
          height: 0.5rem;
        }
      }
    }
    .comment-user {
      max-width: 100%;
      .first-comment,
      .second-comment {
        font-size: 0.22rem;
        color: $mainTxtColor1;
        margin-top: 0.1rem;
        .zuoze {
          display: inline-block;
          width: 0.65rem;
          height: 0.37rem;
          // background: #999999;
          background: #ff8b00;

          font-size: 0.24rem;
          color: $mainTxtColor1;
          text-align: center;
          line-height: 0.37rem;
          border-radius: 0.05rem;
        }
        .comment-user-name {
          font-size: 0.30rem;
          color: $mainTxtColor1;
          &.comment-user-name2{
              font-size: 0.26rem;
          }
        }
        .comment-user-time {
          font-size: 0.18rem;
          color: #999999;
          margin: 0;
          margin-right: 0.3rem;
        }
        .comment-user-text {
          max-width: 100%;
          font-size: 0.18rem;
          word-break: break-all;
          word-wrap: break-word;
          margin: 0;
          color: #6a6a6a;
          opacity: 0.8rem;
          margin: 0.1rem 0;
          font-size: 0.24rem;
        }
      }
    }
  }
}

// 回复文本样式
.resTxt {
  display: flex;
  align-items: center;
  color: #999999;
  img {
    width: 0.35rem;
    margin-right: 0.1rem;
  }
}
.second-comment {
  display: flex;
  .user-header {
    width: 0.5rem;
    height: 0.5rem;
    border-radius: 50%;
    margin-right: 0.2rem;
  }
}
.comment-user-res {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
// 展开回复
.comment-user-open {

  &-right {
    color: #ff8b00;
  }
}
//无数据样式
.public-noData {
  color: #ccc;
  font-size: 0.24rem; 
  display: flex;
  align-items: center;
  justify-content: center; 
  padding:0.5rem 0;
}
// 提交按钮
.submit-box {
  position: fixed;
  padding: 0 0.3rem;
  width: 100%;
  max-width: $pcMaxWidth;
  bottom: 0;
  font-size: 0.3rem;
  background-color: $mainBgColor;
  border-top: 1px solid #e9e9e9;
  // 评论发送按钮
  .submit-input {
    position: relative;
    display: flex;
    align-items: center;
    margin: 0.3rem auto;
    font-size: 0.26rem;
    .submit-txt {
      @include box-shadow-all;
      position: absolute;
      right: -0.04rem;
      width: 1.2rem;
      height: 0.68rem;
      background-color: $mainBgColor;
      border-radius: 0.3rem;
      color: #ff8b00;
      text-align: center;
      line-height: 0.68rem;
    }
    :deep()  {
      .van-cell {
        @include box-shadow-all;
        border-radius: 0.3rem;
        padding: 0.1rem 0.2rem;
        .van-field__control{
          text-indent: 0.2rem;
        }
      }
    }
  }

  // 开通会员提示按钮
  .submit-btn {
    color: $mainTxtColor1;
    background: $btnBg;
    width: 6rem;
    height: 0.68rem;
    line-height: 0.68rem;
    text-align: center;
    margin: 0.3rem auto;
    border-radius: 0.5rem;
  }
}
.color{
  color: #333;
}
</style>
