<template>
  <div class="community-default">
    <div class="item-data" :class="!isDetail ? 'noDetail' : ''" @click="toDetail(itemData)">
      <!-- 头部头像 -->
      <div class="top-avatar" @click.stop="$router.push(`/up/index/${itemData.base.userId}`)">
        <DecryptImg class="avatar" :imgURL="itemData.base.userAvatar" />
        <p>{{ itemData.base.userName }}</p>
        <span @click.stop="clickPrivateLetter(itemData.base)">私信</span>
        <span v-if="!status" class="care" @click.stop="addCare(itemData)">{{ itemData.base.isCare ? '取消关注' : '关注' }}</span>
        <div class="status" v-if="status">
          <span class="tg" v-if="status === 1">审核通过</span>
          <span class="ds" v-if="status === 3">待审核</span>
          <van-popover v-model="state.showPopover" theme="dark" trigger="click">
            <span class="txt">{{ itemData.base.remark }}</span>
            <template #reference>
              <div
                @click.stop="state.showPopover ? (state.showPopover = false) : (state.showPopover = true)"
                class="jj"
                v-if="status === 4"
              >
                审核拒绝
                <van-icon name="question" color="#ff1919" />
              </div>
            </template>
          </van-popover>
        </div>
      </div>
      <!-- 列表信息展示 -->
      <div v-if="!isDetail">
        <!-- 文本 -->
        <div class="desc-txt" ref="textBox" v-if="itemData.node && itemData.node.text">
          <span ref="spanBox">{{ itemData.node.text }}</span>

        </div>
      <!-- 展开字符 -->
        <div class="more" v-if="itemData.node && itemData.node.text && state.ifOver">展开</div>
        <!-- 图片展示最多显示2排 -->
        <div class="img-list" v-if="itemData.node && itemData.node.imgs && itemData.node.imgs.length > 0">
          <DecryptImg
            class="img-item"
            v-for="(img, index) in itemData.node.imgs"
            :needPadding="false"
            :key="index"
            :imgURL="img"
          />
        </div>
      </div>

      <!-- 详情信息展示 -->
      <div v-else>
        <div class="detail-data" v-for="(isDetailItem, index) in itemData.nodes" :key="index">
          <div class="desc-txt">{{ isDetailItem.text }}</div>
          <div class="img-list">
            <DecryptImg
              class="img-item"
              :needPadding="false"
              v-for="(img,index) in isDetailItem.imgs"
              :key="index"
              :imgURL="img"
              ref="refImg"
              @clickImg="clickImg"
            />
          </div>
        </div>
      </div>
      <!-- 视频展示 -->
      <div class="video-cover" v-if="itemData.base.videoCover" @click.stop="fn_playVideo(itemData)">
        <DecryptImg class="sm-video" :needPadding="false" :imgURL="itemData.base.videoCover">
          <van-icon name="play" color="#fff" size="60" />
        </DecryptImg>
      </div>
      <!-- 底部信息展示 -->
      <div class="footer">
        <div class="footer-left">
          <div class="left-like" @click.stop="addLike(itemData)">
            <img src="@/assets/imgs/red-path.svg" alt="" v-if="itemData.base.isLike" />
            <img src="@/assets/imgs/white-path.svg" alt="" v-else />
            {{ numberFilter(itemData.base.likes)}}
          </div>
          <div class="left-comments">
            <img src="@/assets/imgs/comments.svg" alt="" />
            {{ numberFilter(itemData.base.comments)}}
          </div>
          <div>浏览次数：{{numberFilter(itemData.base.watches)}}</div>
        </div>
        <div
          class="footer-right"
          @click.stop="goBuyPost(itemData.base)"
          v-if="!isDetail && itemData.base.price && !itemData.base.isBought"
        >
          <span>{{ changeGold(itemData.base.price) }}</span>
          <img src="@/assets/imgs/index/gold.png" alt="" />
          购买
        </div>
        <div v-if="itemData.base.price && itemData.base.isBought" class="footer-right">已购买</div>
      </div>
    </div>
    <!-- 详情图片跳转 -->
    <DecryptImg
      class="img-link"
      @click.stop="txtLink(itemData.pictureLink)"
      v-if="isDetail && itemData.pictureLink"
      :needPadding="false"
      :imgURL="itemData.jumpPicture"
    >
    </DecryptImg>
    <!-- 详情文字跳转 -->
    <div class="txt-link" v-if="isDetail && itemData.titleLink" @click.stop="txtLink(itemData.titleLink)">
      {{ itemData.jumpTitle }}
    </div>
    <!-- 共多少条评论 -->
    <div class="comments-count" v-if="isDetail">
      全部评论
      <span>{{ itemData.base.comments }}</span>
    </div>
    <!-- 社区视频播放 -->
    <!-- <ComPlayVideo ref="ComPlayVideo" /> -->
    <JavShowBuy
      :title="'购买此帖子需支付'"
      :showBuy="state.showBuy"
      :width="'80%'"
      :position="'center'"
      @shoudBuy="shoudBuy(itemData.base)"
      @closed="closed"
      :price="changeGold(itemData.base.price)"
    />
    <div @click.stop="checkItem(itemData)" v-if="showMask" class="sel-wrap">
      <img v-if="!itemData.clickMask" src="@/assets/imgs/mine/sel-default.png" alt="" />
      <img v-else src="@/assets/imgs/mine/sel-active.png" alt="" />
    </div>
  </div>
</template>

<script setup>
import { showToast } from 'vant';
import { care_add, collect } from '@/api/home'
import { community_pay } from '@/api/community'
import { showImagePreview } from 'vant'
import { handleParamsRouteJump, handleURlParams} from '@/utils/utils_tools'
import { numberFilter,changeGold } from '@/utils/filter'
const router = useRouter()
let spanBox = ref(null)
let textBox = ref(null)
let refImg = ref(null)
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const JavShowBuy = defineAsyncComponent(() => import('@/components/JavShowBuy.vue'))
const ComPlayVideo = defineAsyncComponent(() => import('@/components/Community/video.vue'))

const props = defineProps({
  itemData: {
    type: Object,
    default: {
      node: {},
      nodes: [],
      base: {}   
    }
  },
  isDetail: {
    type: Boolean,
    default: false
  },  
  status: {
    type: Boolean,
    default: false
  },
  showMask: {
    type: Boolean,
    default: false
  },       
})

const state = reactive({
  showBuy: false,
  showPopover: false,
  spliceList: [],
  ifOver: false,
  isMember:computed(() => store.getters['isMember']) 
})


const closed = (showBuy) =>{
  state.showBuy = showBuy
}

// 删除记录点击事件
const checkItem = (item) =>{
  state.showBuy = showBuy
  item.clickMask = !item.clickMask
  if (item.clickMask) {
    if (state.spliceList.length > 0) {
      state.spliceList.map((sItem, index, arr) => {
        if (item.base.id === sItem) {
          arr.splice(index, 1, item.id)
        }
      })
      state.spliceList.push(item.base.id)
    } else {
      state.spliceList.push(item.base.id)
    }
  } else {
    state.spliceList.map((sItem, index) => {
      if (item.base.id === sItem) {
        state.spliceList.splice(index, 1)
      }
    })
  }
  // 向组件传递方法
  const emits = defineEmits(["clickItem"])
  // 向父组件传递方法
  emits("clickItem",state.spliceList)  
}

// 详情跳转
const toDetail = (item) =>{
  if (!item.base.price || (item.base.price && item.base.isBought)) {
    router.push(`/community/detail?id=${item.base.id}`)
  } else {
    return showToast('购买后才可查看详情！')
  }
}

// 点击私信
const clickPrivateLetter = (data) =>{
  if (state.isMember) {
    router.push({
      path: `/oneSession/${data.userId}`,
      query: {
        nickName: data.userName,
        avatar: data.userAvatar
      }
    })
  } else {
    showToast('开通会员才能发起私聊！')
  }
}

// 关注用户
const addCare =async (item) =>{
  try {
    const res = await care_add({
      id: item.base.userId,
      add: !item.base.isCare
    })
    if (res.code === 200) {
      item.base.isCare = !item.base.isCare
      if (item.base.isCare) {
        return showToast('关注成功')
      } else {
        return showToast('取消关注')
      }
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    return showToast('请求失败，请稍后再试')
  }  
}

// 播放视频
const fn_playVideo = (item) =>{
  if (props.isDetail) {
    this.$refs['ComPlayVideo'].fn_playVideo(item.base.videoUrl, item.videoCover)
  } else {
    if (!item.base.price || (item.base.price && item.base.isBought)) {
      router.push(`/community/detail/${item.base.id}`)
    } else {
      return showToast('购买后才可查看详情！')
    }
  }
}

// 添加喜欢
const addLike =async (item) =>{
  try {
    const res = await collect({
      flag: !item.base.isLike,
      object_id: item.base.id,
      collect_type: 5
    })
    if (res.code === 200) {
      item.base.isLike = !item.base.isLike
      if (item.base.isLike) {
        item.base.likes += 1
        return showToast('收藏成功')
      } else {
        item.base.likes -= 1
        return showToast('取消收藏')
      }
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    return showToast('请求失败，请稍后再试')
  }
}

// 图片预览
const clickImg = (imgUrl) =>{
  if (props.isDetail) {
    const imgArr = []
    let index = 0

    const domArr = refImg.value
    domArr.forEach((itemBlob, indexBlob) => {
      if (imgUrl === itemBlob.imgURL) {
        index = indexBlob
      }
      imgArr.push(itemBlob.realUrl)
    })
    showImagePreview({
      images: imgArr, // 需要预览的图片 URL 数组
      showIndex: true, // 是否显示页码
      loop: true, // 是否开启循环播放
      startPosition: index // 图片预览起始位置索引
    })
  }
}

// 帖子购买
const goBuyPost = (data) =>{
  state.showBuy = true
}  
    
// 购买弹窗购买按钮
const shoudBuy =async (data) =>{
  try {
    const res = await community_pay({
      id: data.id
    })
    if (res.code === 200 && res.data.code === 200) {
      data.isBought = true
      state.showBuy = false
      return showToast('购买成功')
    } else {
      return showToast(res.data.msg)
    }
  } catch (error) {
    console.log(error)
    return showToast('请求错误，请稍后再试！')
  }
}  


// 详情活动跳转
const txtLink = (url) =>{
  const code = handleURlParams(url)
  handleParamsRouteJump(code)
} 

onMounted(async () => {
  // 判断是否显示展开收起按钮
  if (props.itemData.node && props.itemData.node.text && !props.isDetail) {
    state.ifOver = spanBox.value.offsetHeight > textBox.value.offsetHeight
  }
}) 

  
</script>

<style lang="scss" scoped>
.community-default {
  position: relative;
  color: #fff;
}
.item-data {
  padding: 0.3rem 0.25rem;
  border-radius: 0.12rem;
  margin-bottom: 0.3rem;
  // 文本
  .desc-txt {
    font-size: 0.26rem;
    color: #939496;
    white-space: pre-line;
  }
}
.noDetail {
  // box-shadow: $shadow;
  background: $mainBgColor;
  border-bottom: 0.01rem solid #5b5b6f;
  // 文本
  .desc-txt {
    @include textoverflow(3);
    font-size: 0.26rem;
    color: #939496;
    white-space: pre-line;
    position: relative;
  }
}
// 顶部头像
.top-avatar {
  @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
  font-size: 0.22rem;
  margin-bottom: 0.2rem;
  white-space: nowrap;
  p {
    margin: 0;
    font-size: 0.28rem;
    font-weight: 600;
    margin-left: 0.19rem;
  }
  .avatar {
    width: 0.64rem;
    height: 0.64rem;
    border-radius: 50%;
    :deep()  {
      .warp {
        width: 100%;
        height: 100%;
        img {
          width: 100%;
          height: 100%;
          border-radius: 50%;
        }
      }
    }
  }
  span {
    padding: 0.01rem 0.23rem;
    border: 0.02rem solid #fd9a3a;
    color: #fd9a3a;
    border-radius: 0.19rem;
    margin-left: 0.3rem;
  }
}

.more {
  margin: 0.2rem 0;
  color: #fd9a3a;
  font-size: 0.26rem;
  text-align: right;
  margin: 0;
}
.img-list {
  @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: wrap);
  margin: 0.3rem 0;
  .img-item {
    width: 32%;
    max-width: 2.06rem;
    height: 2.06rem;
    margin-right: 0.1rem;
    margin-top: 0.1rem;
  }
  .img-item:nth-child(3n) {
    margin-right: 0;
  }
}
.video-cover {
  margin: 0 auto;
}
.sm-video {
  position: relative;
  :deep()  {
    .warpNoPadding {
      img {
        object-fit: contain;
        max-height: 6.9rem;
      }
    }
  }
  .van-icon-play {
    position: absolute;
    top: 50%;
    left: 50%;
    @include transformCenter();
  }
}
// 底部信息
.footer {
  font-size: 0.24rem;
  margin-top: 0.27rem;
  @include flexbox();
  &-left {
    @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
    div {
      display: flex;
      align-items: center;
      img {
        margin-right: 0.1rem;
      }
    }
    .left-like {
      margin-right: 0.22rem;
      img {
        width: 0.3rem;
        height: 0.27rem;
      }
    }
    .left-comments {
      margin-right: 0.35rem;
      img {
        width: 0.28rem;
        height: 0.26rem;
      }
    }
  }
  &-right {
    color: $mainTxtColor1;
    font-size: 0.24rem;
    background: linear-gradient(to right, #fd9c3a, #fc342d);
    padding: 0.03rem 0.27rem;
    border-radius: 0.34rem;
    span {
      font-size: 0.32rem;
    }
    img {
      width: 0.22rem;
      height: 0.22rem;
      margin: 0 0.03rem;
    }
  }
}
// 评论数量
.comments-count {
  border-top: 0.02rem solid #5b5b6f;
  border-bottom: 0.02rem solid #5b5b6f;
  padding: 0.14rem 0;
  width: 100%;
  font-size: 0.28rem;
  color: #a2a3a4;
  text-align: center;
  span {
    margin-left: 0.2rem;
    display: inline-block;
  }
}
.img-link {
  width: 100%;
}
.txt-link {
  @include textoverflow();
  font-size: 0.26rem;
  padding: 0.02rem 0.3rem;
  text-align: center;
  width: 3.64rem;
  border: 0.02rem solid #9493b1;
  color: orange;
  margin: 0.3rem auto;
  border-radius: 0.12rem;
}
.status {
  font-size: 0.24rem;
  margin-left: 0.32rem;
  width: 1.5rem;

  :deep()  {
    .van-popover__wrapper {
      padding: 0;
      white-space: nowrap;
    }
  }
  span {
    border: none;
  }
  .tg {
    color: #00bc6c;
  }
  .jj {
    color: #ff1919;
  }
}
</style>
<style lang="scss">
.van-popover--dark {
  .van-popover__content {
    font-size: 0.28rem !important;
    padding: 0.1rem;
    color: #ff1919;
  }
}
// 选择视频
.sel-wrap {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  z-index: 9;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: flex-end;
  border-radius: 0.12rem;
  img {
    width: 0.4rem;
    height: 0.4rem;
  }
}
</style>
