<template>
  <div class="lf-list">
    <div class="lf-card" @click="$router.push(`/lfDetail/${item.id}`)" v-for="(item, index) in list" :key="index">
      <DecryptImg class="lf-card-img" :needPadding="false" :imgURL="item.images ? item.images[0] : ''" />
      <div
        class="lf-card-info"
        :style="{
          background: index > 5 ? state.color[index % 6] : state.color[index]
        }"
      >
        <h3 class="title">{{ item.title }}</h3>
        <div class="info-detail">
          <span>{{ item.age }}</span>
          <div class="line"></div>
          <span>颜值{{ item.beautyScore }}</span>
        </div>
        <span class="label">{{ item.cityName }}</span>
      </div>
      <div @click.stop="checkItem(item)" v-if="showMask" class="sel-wrap">
        <img v-if="!item.clickMask" src="@/assets/imgs/mine/sel-default.png" alt="" />
        <img v-else src="@/assets/imgs/mine/sel-active.png" alt="" />
      </div>
    </div>
  </div>
</template>

<script setup>
const emits = defineEmits(["clickItem"])
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const props = defineProps({
  list: {
    type: Array,
    default: []
  },
  showMask: {
    type: Boolean,
    default: false
  }   
})
const state = reactive({
  color: [
    'linear-gradient(to right, #de8498, #4e3f43)',
    'linear-gradient(to right, #75b49969, #74a997)',
    'linear-gradient(to right, #787057, #404845)',
    'linear-gradient(to right, #cfbcdd, #151518)',
    'linear-gradient(to right, #998269, #271f1c)',
    'linear-gradient(to right, #000000, #bfb8b5)'
  ],
  spliceList: []
})
// 删除记录点击事件
const checkItem = (item) =>{
  item.clickMask = !item.clickMask
  if (item.clickMask) {
    if (state.spliceList.length > 0) {
      state.spliceList.map((sItem, index, arr) => {
        if (item.id === sItem) {
          arr.splice(index, 1, item.id)
        }
      })
      state.spliceList.push(item.id)
    } else {
      state.spliceList.push(item.id)
    }
  } else {
    state.spliceList.map((sItem, index) => {
      if (item.id === sItem) {
        state.spliceList.splice(index, 1)
      }
    })
  }
  emits("clickItem",state.spliceList)
}
</script>

<style lang="scss" scoped>
.lf-list {
  padding: 0 0.03rem;
  @include flexbox($jc: space-between, $ai: flex-start, $fd: row, $fw: wrap);
}
.lf-card {
  border-radius: 0.12rem;
  margin-bottom: 0.2rem;
  position: relative;
  &-img {
    width: 3.2rem !important;
    height: 4rem;
    :deep()  {
      .warpNoPadding {
        img {
          border-top-right-radius: 0.12rem;
          border-top-left-radius: 0.12rem;
        }
      }
    }
  }
  &-info {
    width: 3.2rem;
    background: #f7fcff;
    padding: 0.25rem 0.2rem 0.13rem 0.25rem;
    font-size: 0.22rem;
    border-bottom-right-radius: 0.12rem;
    border-bottom-left-radius: 0.12rem;
    color: #2b3346;
    box-shadow: $shadow;
    .title {
      @include textoverflow();
      font-weight: 600;
      margin: 0;
      color:#fff
    }
    .info-detail {
      @include textoverflow();
      @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
      color: #b6b8ba;
      margin: 0.1rem 0;
      font-weight: 500;
      span {
        color: #fff;
        white-space: nowrap;
      }
      .line {
        margin: 0 0.2rem;
        background: #b6b8ba;
        width: 0.04rem;
        height: 0.3rem;
      }
    }
    .label {
      @include textoverflow();
      padding: 0.06rem 0.1rem;
      font-weight: 500;
      max-width: 1.5rem;
      text-align: center;

      background: linear-gradient(to right, #fbe07c, #ffbb10);
      border-radius: 0.21rem;
    }
  }
}
// 选择视频
.sel-wrap {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  z-index: 9;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: flex-end;
  border-radius: 0.12rem;
  img {
    width: 0.4rem;
    height: 0.4rem;
  }
}
</style>
