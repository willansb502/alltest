<template>
  <div class="merchant-card">
    <div class="card-head">
      <DecryptImg class="header-avatar" :imgURL="item.avatar" />
      <span style="white-space: nowrap;">{{ item.name }}</span>
      <div class="label" v-if="item.recomment">推荐</div>
    </div>
    <!-- 妹子图片列表 -->
    <ul class="girls-img">
      <li v-for="girl in item.recommentGirl" :key="girl.id">
        <DecryptImg class="img" :imgURL="girl.images[0]" :needPadding="false" />
      </li>
    </ul>
    <!-- 商家信息 -->
    <div class="boss-info">
      <div>妹子 {{ numberFilter(item.girls)}}</div>
      <div class="line"></div>
      <div>成交 {{ numberFilter(item.orders) }}</div>
      <div class="line"></div>
      <div>粉丝 {{ numberFilter(item.fans) }}</div>
    </div>
  </div>
</template>

<script setup>
import { numberFilter } from '@/utils/filter'
import  DecryptImg from '@/components/DecryptImg/index.vue'
const props = defineProps({
  item: {
    type: Object,
    default() {
      return {}
    }
  }
})
</script>

<style lang="scss" scoped>
.merchant-card {
  font-size: 0.28rem;
  width: 4.61rem;

  background: $mainBgColor;
  flex-shrink: 0;
  border-radius: 0.12rem;
  padding: 0.2rem 0.3rem;
  .card-head {
    @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
    .header-avatar {
      width: 0.8rem;
      margin-right: 0.1rem;
      :deep()  {
        .warp {
          border-radius: 50%;
        }
      }
    }
    .label {
      width: 0.8rem;
      height: 0.32rem;
      padding: 0.01rem 0;
      line-height: 0.3rem;
      background: linear-gradient(to right, #fbe07c, #ffbb10);
      text-align: center;
      margin-left: 0.26rem;
      border-radius: 0.05rem;
      font-size: 0.22rem;
      box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
    }
  }
  // 妹子图片
  .girls-img {
    @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
    overflow-x: scroll;
    margin: 0.2rem 0;
    li {
      margin-right: 0.1rem;
      .img {
        width: 1.2rem;
        height: 1.2rem;
      }
    }
    li:last-child {
      margin-right: 0;
    }
  }

  .girls-img::-webkit-scrollbar {
    /*滚动条整体样式*/
    width: 10px; /*高宽分别对应横竖滚动条的尺寸*/
    height: 10px;
  }
  .girls-img::-webkit-scrollbar-thumb {
    /*滚动条里面小方块*/
    border-radius: 10px;
    box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
     background: #83807e;
  }
  .girls-img::-webkit-scrollbar-track {
    /*滚动条里面轨道*/
    box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
    border-radius: 10px;
  }

  // 经纪人信息
  .boss-info {
    font-size: 0.24rem;
    @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
    div {
      white-space: nowrap;
    }
    .line {
      width: 0.04rem;
      height: 0.17rem;
      background: #666666;
      margin: 0 0.2rem;
    }
  }
}


</style>
