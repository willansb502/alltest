<template>
  <div class="sj-card">
    <div class="item" v-for="item in list"  :key="item.id" @click="$router.push(`/bosses/detail/${item.id}`)">
      <div class="top-avatar">
        <DecryptImg class="avatar" :imgURL="item.avatar" />
        <div class="avatar-right">
          <div class="avatar-right-top">
            <p class="name">{{ item.name }}</p>
            <p class="recommend" v-if="item.recomment">推荐</p>
          </div>
          <!-- 商家信息 -->
          <div class="boss-info">
            <div>认证妹子 {{ item.girls }}</div>
            <div>成交 {{ item.orders }}</div>
            <div>数量 {{ numberFilter(item.fans) }}</div>
          </div>
        </div>
      </div>
      <!-- 妹子图片列表 -->
      <ul
        class="girls-img"
        @touchmove.stop
        v-if=" item.recommentGirl && item.recommentGirl[0] && item.recommentGirl[0].images.length > 0"
      >
        <li v-for="(girl, index) in item.recommentGirl[0].images" :key="index">
          <DecryptImg class="girls-img-item" :needPadding="false" :imgURL="girl" />
        </li>
      </ul>
      <div class="noData" v-else>暂无可推荐妹子</div>
    </div>
  </div>
</template>

<script setup>
import { numberFilter } from '@/utils/filter'
import DecryptImg from "@/components/DecryptImg/index.vue"
const props = defineProps({
  list: {
    type: Array,
    default: []
  }
})
</script>

<style lang="scss" scoped>
.item {
  width: 100%;
  height: 4.43rem;
  padding: 0.44rem 0.5rem;
  margin: 0;
  margin-bottom: 0.15rem;
  box-shadow: $shadow;
  background-color: $mainBgColor;
  border-radius: 0.2rem;
  .top-avatar {
    @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
    font-size: 0.32rem;
    padding-bottom: 0.3rem;
    border-bottom: $border;
    .avatar {
      width: 1rem;
      border-radius: 0.12rem;
      margin-right: 0.29rem;
      :deep()  {
        .warp {
          border-radius: 0.12rem;
          border-radius: 50%;
        }
      }
    }
    .avatar-right-top {
      font-weight: 500;
      margin-bottom: 0.18rem;
      @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
      p {
        margin: 0;
      }
      .name {
        margin-right: 0.2rem;
      }
    }
    .boss-info {
      @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
      color: #757381;
      font-size: 0.24rem;
      flex-shrink: 0;
      div {
        margin-right: 0.42rem;
        white-space: nowrap;
      }
      div:last-child {
        margin-right: 0;
      }
    }
    .recommend {
      width: 0.8rem;
      height: 0.32rem;
      padding: 0.01rem 0;
      line-height: 0.3rem;
      background: linear-gradient(to right, #fbe07c, #ffbb10);
      text-align: center;
      margin-left: 0.26rem;
      border-radius: 0.05rem;
      font-size: 0.22rem;
      box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
    }
  }
  // 妹子图片
  .girls-img {
    margin: 0.3rem 0;
    @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
    overflow-x: scroll;
    li {
      width: 1.78rem;
      height: 1.78rem;
      margin-right: 0.1rem;
      flex-shrink: 0;
    }
    &-item {
      height: 100%;
    }
  }
}
.noData {
  font-size: 0.26rem;
  text-align: center;
  margin-top: 0.5rem;
  color: #4d4c54;
}
</style>
