<template>
  <div class="lf-list">
    <div class="lf-card" @click="$router.push(`/dating/sm_detail/${item.id}`)" v-for="(item,index) in list"  :key="index">
      <DecryptImg class="lf-card-img" :needPadding="false" :imgURL="item.images ? item.images[0] : ''">
        <!-- 判断是否有视频 -->
        <div class="sm-video" v-if="item.videoUrl">
          <van-icon name="play" color="#fff" size="40" />
        </div>
      </DecryptImg>
      <div class="lf-card-info">
        <h3 class="title">{{ item.title }}</h3>
        <div class="info-detail">
          <span>{{ item.girlHeight }}cm</span>
          <div class="line"></div>
          <span>{{ item.girlAge }}岁</span>
          <div class="line"></div>
          <span>{{ fillterCup(item.cupValue) }}</span>
        </div>
        <div class="price">
          <div class="price-left">
            ¥<span>{{ changeGold(item.price)}}</span>
          </div>
          <span class="price-right">{{ item.sells }}人已购买</span>
        </div>
      </div>
        <div @click.stop="checkItem(item)" v-if="showMask" class="sel-wrap">
          <img v-if="!item.clickMask" src="@/assets/imgs/mine/sel-default.png" alt="" />
          <img v-else src="@/assets/imgs/mine/sel-active.png" alt="" />
        </div>
    </div>
  </div>
</template>

<script setup>
import { changeGold } from '@/utils/filter'
import DecryptImg from "@/components/DecryptImg/index.vue"
import { fillterCup } from '@/utils/filter'
const props = defineProps({
  list: {
    type: Array,
    default: []
  },
  showMask: {
    type: Boolean,
    default:false
  }
})

const state = reactive({
  spliceList:[]
})

// 删除记录点击事件
const checkItem = async (item) => {
  item.clickMask = !item.clickMask
  if (item.clickMask) {
    if (state.spliceList.length > 0) {
      state.spliceList.map((sItem, index, arr) => {
        if (item.id === sItem) {
          arr.splice(index, 1, item.id)
        }
      })
      state.spliceList.push(item.id)
    } else {
      state.spliceList.push(item.id)
    }
  } else {
    state.spliceList.map((sItem, index) => {
      if (item.id === sItem) {
        state.spliceList.splice(index, 1)
      }
    })
  }
  // 向组件传递方法
  const emits = defineEmits(["clickItem"])
  emits("clickItem",state.spliceList) 
}
</script>

<style lang="scss" scoped>
.lf-list {
  padding: 0 0.03rem;
  @include flexbox($jc: space-between, $ai: center, $fd: row, $fw: wrap);
}
.lf-card {
   position: relative;
  border-radius: 0.12rem;
  margin-bottom: 0.2rem;
  &-img {
    width: 3.2rem !important;
    height: 4rem;
    position: relative;
    :deep()  {
      .warpNoPadding {
        img {
          border-top-right-radius: 0.12rem;
          border-top-left-radius: 0.12rem;
        }
      }
    }
    .sm-video {
      position: absolute;
      width: 100%;
      height: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      top: 0;
      left: 0;
      background: rgba($color: #000000, $alpha: 0.5);
    }
  }
  &-info {
    background: #f7fcff;
    width: 3.2rem;
    padding: 0.25rem 0.2rem 0.13rem 0.25rem;
    font-size: 0.22rem;
    border-bottom-right-radius: 0.12rem;
    border-bottom-left-radius: 0.12rem;
    color: #2b3346;
    box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
    .title {
      @include textoverflow();
      font-weight: 600;
      margin: 0;
    }
    .info-detail {
      @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);

      color: #b6b8ba;
      margin: 0.1rem 0;
      font-weight: 500;
      span {
        white-space: nowrap;
      }
      .line {
        margin: 0 0.2rem;
        background: #b6b8ba;
        width: 0.04rem;
        height: 0.3rem;
      }
    }
    .price {
      @include flexbox($jc: space-between, $ai: center, $fd: row, $fw: nowrap);
      font-weight: 500;
      font-size: 0.22rem;

      .price-left {
        background: linear-gradient(to right, #fbe07c, #ffbb10);
        border-radius: 0.21rem;
        padding: 0.06rem 0.23rem;
        text-align: center;
        display: block;
        margin-right: 0.1rem;
        span {
          font-size: 0.32rem;
        }
      }
      .price-right {
        @include textoverflow();
        color: #939496;
        font-size: 0.2rem;
        max-width: 1.4rem;
      }
    }
  }
}
 // 选择视频
.sel-wrap {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  z-index: 9;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: flex-end;
  border-radius: 0.12rem;
  img {
    width: 0.4rem;
    height: 0.4rem;
  }
}
</style>
