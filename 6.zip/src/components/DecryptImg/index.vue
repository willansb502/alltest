<template>
  <lazy-component v-if="hasLazy" class="default" @show="handler" :style="[imgRadius ? { 'border-radius': imgRadius } : '']">
    <div
      :class="needPadding ? 'warp' : 'warpNoPadding'"
      @click="imgClick"
      :style="[{ paddingTop: needPadding ? paddingNum : 0 }]"
    >
      <img
        ref="decryptImg"
        :style="[imgRadius ? { 'border-radius': imgRadius } : '']"
        :class="needPadding ? 'imgTag' : 'imgNoPadding'"
        :src="state.realUrl ? state.realUrl : 'https://xkmcn.net/static/homec.png'"
        @click="imgClick"
        :key="state.imgCDN + imgURL"
        draggable="false"
        ondragstart="return false;"
      />
      <slot></slot>
    </div>
  </lazy-component>
  <div v-else class="default" :style="[imgRadius ? { 'border-radius': imgRadius } : '']">
    <div
      :class="needPadding ? 'warp' : 'warpNoPadding'"
      @click="imgClick"
      :style="[{ paddingTop: needPadding ? paddingNum : 0 }]"
    >
      <img
        ref="decryptImg"
        :style="[imgRadius ? { 'border-radius': imgRadius } : '']"
        :class="needPadding ? 'imgTag' : 'imgNoPadding'"
        :src="state.realUrl ? state.realUrl : 'https://xkmcn.net/static/homec.png'"
        @click="imgClick"
        :key="state.imgCDN + imgURL"
        draggable="false"
        ondragstart="return false;"
      />
      <slot></slot>
    </div>
  </div>  
</template>

<script setup>
import { handleVerAutoImg } from '@/utils/utils_tools'
import { IMAGE_DB_CONFIG, START_IMAGE_DB_KEY } from '@/config/imgConfig.js'
import { TIME_OUT_NUMBER_KEY } from '@/config/imgConfig.js'
const { max_time_consuming, time_out_max_number } = IMAGE_DB_CONFIG
const emits = defineEmits(["clickImg"])
let decryptImg = ref(null)
const props = defineProps({
  hasLazy: {
    typeof: Boolean,
    default() {
      return true
    }
  },    
  // 图片路径
  imgURL: {
    typeof: String,
    default() {
      return ''
    }
  },
  // 默认padding值
  paddingNum: {
    typeof: String,
    default() {
      return '100%'
    }
  },
  // 是否需要padding
  needPadding: {
    typeof: Boolean,
    default() {
      return true
    }
  },
  //圆角
  imgRadius: ''      
})
const state = reactive({
  realUrl: false,
  status: 1,
  timeConsuming: 0,
  imgCDN:computed(() => store.getters['cdn'])
})
const handler = () =>{
  props.imgURL ? getBlobUri() : (state.realUrl = false)
}


// 解密并获取base64图片地址
const getBlobUri =async () =>{
  if (!props.imgURL) return
  const startTime = new Date().getTime()
  const baseUri = await handleVerAutoImg(`${state.imgCDN}${props.imgURL}`)
  if (baseUri && baseUri.length && state.status === 1) {
    state.realUrl = baseUri
    state.status = 2
    if (decryptImg) decryptImg.value.style.objectFit = 'cover'
  } else state.status = 0
  // 计算执行耗时事件
  state.timeConsuming = new Date().getTime() - startTime
  // 每一次超时当前+1
  const timeOutN = IMAGE_DB_CONFIG[TIME_OUT_NUMBER_KEY]
  const startDb = IMAGE_DB_CONFIG[START_IMAGE_DB_KEY]

  if (state.timeConsuming >= max_time_consuming) {
    IMAGE_DB_CONFIG[TIME_OUT_NUMBER_KEY] += 1
  }
  // 超过最大次数 关闭 IndexDB
  if (timeOutN > time_out_max_number && startDb) IMAGE_DB_CONFIG[START_IMAGE_DB_KEY] = false
}
// 方法传递
const imgClick = () =>{
  emits("clickImg",props.imgURL)
}
    
onMounted(() => {
  if(!props.hasLazy) handler();
  if (!props.imgURL) state.status = 0;
})

watch(() => props.imgURL, (newValue) => {
  if (n) {
    state.status = 1
    getBlobUri()
  }
},{ immediate: true })

</script>

<style scoped lang='scss'>
.default {
  width: 100%;
}
.warp {
  width: 100%;
  position: relative;
  overflow: hidden;
  font-size: 0;
}
.warpNoPadding {
  width: 100%;
  height: 100%;
  overflow: hidden;
  font-size: 0;
  background: #00000099;
}
.imgTag {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  object-fit: cover;
}
.imgNoPadding {
  @include ios-forbid-img;
  width: 100%;
  height: 100%;
  //object-fit: contain;
  transition: all 0.6s;
  -webkit-user-drag: none;
}
.load-error {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.loading {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
</style>
