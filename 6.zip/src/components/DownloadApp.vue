<template>
  <div class="download-wrap">
    <img  class="btn" @click="clickDown" src="@/assets/imgs/download.png" alt="">
    <van-overlay :show="state.downShow" @click="state.downShow = false">
      <div class="down-wrapper">
        <p style="font-size: 0.28rem">请手机扫码再点下载</p>
        <div class="qrcode-warp">
          <qrcode-vue class="qrcode" :value="state.playURL" level="H" :size="150" />
        </div>
      </div>
    </van-overlay>
  </div>
</template>
<script setup>
import $device from "current-device";
import QrcodeVue from 'qrcode.vue'
import { useStore } from 'vuex'
const store = useStore()
const baseUrl = import.meta.env.VITE_APP_baseUrl
import { publicDownload} from '@/utils/utils_tools'
const state = reactive({
  downShow: false,
  playURL:''
})

onMounted(() => {
  let param="";
  if(store.getters['getChannel']&&store.getters['getChannel'].dc){
    param='?dc='+store.getters['getChannel'].dc
  };
  if(store.getters['getChannel']&&store.getters['getChannel'].pc){
    param='?pc='+store.getters['getChannel'].pc
  };     
  state.playURL = baseUrl+param;
})
const clickDown =() =>{
  if($device.desktop()){
    state.downShow=!state.downShow;
  }else{
    publicDownload(true);
  }
}
</script>
<style lang="scss" scoped>
.down-wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-flow: column wrap;
  height: 100%;
  .qrcode-warp {
    padding: 0.2rem 0.2rem;
    background: #fff;
    font-size: 0;
  }
}


.btn{
  position: fixed;
  bottom: 150px;
  right: 16px;
  z-index: 999; 
  width: 40px;
  height: 40px;  
  cursor: pointer;
}
@media screen and (min-width: 960px) {
  .btn {
    width: 50px;
    height: 50px; 
    bottom: 160px; 
  }
}
</style>
