<template>
  <div class="common-header-wrap" >
    <div class="left">
      <van-icon class="user-center" name="wap-nav"  size="24"/>
    </div>
    <div class="right">
      <slot name="right"></slot>
    </div>
    
  </div>
</template>

<script setup>
const emits = defineEmits(["goBack","onClickRight"])
const router = useRouter()
const props = defineProps({
  hasSuperiorClick: {
    type: Boolean,
    default() {
      return false
    }
  },
  title: {
    type: String,
    default() {
      return ''
    }
  },
  color: {
    type: String,
    default() {
      return '#fff'
    }
  }
})
const onClickLeft =() =>{
  if (props.hasSuperiorClick) {
    emits("goBack")
  } else {
    router.go(-1)
  }
}

const onClickRight =() =>{
  emits("onClickRight")
}

</script>

<style lang="scss" scoped>
.common-header-wrap{
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  display: flex;
  justify-content: space-between;
  color: $mainTxtColor1;
  padding: 0.25rem 0.25rem;
  .left{
    display: flex;
  }
  .right{
    display: flex;
  }
}
</style>
