<template>
  <div class="home-card-list-scroll">
    <div
      class="home-card-body-base"
      :style="{
        width: state.forCount * 2.74 + 'rem'
      }"
    >
      <div v-for="(nyItem, key) in state.forCount" :key="'nyItem' + key" class="home-card-body-width-ac">
        <div
          class="home-card-body-bg"
          :style="{
            background: color[2]
          }"
        ></div>
        <div style="padding-top: 120%; position: relative; cursor: pointer" @click="clickMuActorItem(key)">
          <div class="home-card-body-content">
            <template v-if="nyList[key]">
              <div class="home-pos-w100">
                <DecryptImg :imgURL="nyList[key].avatar" :needPadding="false" style="height: 100%"> </DecryptImg>
                <div class="home-card-body-content" style="z-index: 333; background: #ad96960f">
                  <div
                    style="
                      position: absolute;
                      bottom: 0;
                      width: 100%;
                      height: 0.4rem;
                      font-size: 0.16rem;
                      padding: 0.1rem 0.18rem;
                      background: #150b0b75;
                      backdrop-filter: blur(5px);
                      -webkit-backdrop-filter: blur(5px);
                      display: flex;
                      flex-flow: row wrap;
                      align-items: center;
                      justify-content: center;
                      color: #f4ce4e;
                      font-size: 0.2rem;
                    "
                  >
                    <span style="margin: 0 0.05rem" v-if="nyList[key].watchCount"
                      ><van-icon color="red" name="like" />{{ numberFilter(nyList[key].watchCount) }}</span
                    >
                    <span style="margin: 0 0.05rem" v-if="nyList[key].movieCount"
                      ><van-icon color="#000" name="live" />{{ nyList[key].movieCount }}部</span
                    >
                  </div>
                </div>
              </div>
            </template>
          </div>
        </div>
        <div style="min-height: 0.66rem; margin: 0.2rem 0; text-align: center; font-size: 0.24rem; cursor: pointer">
          {{ nyList[key] ? nyList[key].name : '' }}
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { numberFilter } from '@/utils/filter'
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const router = useRouter()
const props = defineProps({
  nyList: {
    type: Array,
    default: []
  },
  color: {
    type: Array,
    default: [
      'linear-gradient(to right, #de8498, #0f0b0c)',
      'linear-gradient(to right, #75b49969, #0f0b0c)',
      'linear-gradient(to right, #787057, #0f0b0c)',
      'linear-gradient(to right, #cfbcdd, #0f0b0c)',
      'linear-gradient(to right, #e4ac70, #0f0b0c)',
      'linear-gradient(to right, #000000, #0f0b0c)'
    ]
  }
})
const state = reactive({
  forCount: 6
})
const clickMuActorItem = (key) => {
  if (props.nyList.length && props.nyList.length > 0 && props.nyList[key]) {
    router.push(`/actor/detail/${props.nyList[key]['id']}`)
  }
}
</script>

<style lang="scss" scoped>
// 名优馆推荐
.home-card-body-width-ac {
  position: relative;
  width: 2.5rem;
  margin: 0.02rem 0.12rem;
  display: inline-block;
  vertical-align: top;
  top: 0.14rem;
}
.home-card-body-base {
  font-size: 0.16rem;
  line-height: 1.2;
  position: relative;
  color: #fff;
  height: auto;
}
.home-card-list-scroll {
  overflow-x: scroll;
  overflow-y: hidden;
  vertical-align: top;
}
.home-card-body-content {
  position: absolute;
  z-index: 1;
  top: 0;
  width: 100%;
  height: 100%;
  display: flex;
  flex-flow: row wrap;
  border-radius: 0.16rem;
  overflow: hidden;
}
.home-pos-w100 {
  position: absolute;
  top: 0;
  width: 100%;
  height: 100%;
}
.home-card-body-bg {
  position: absolute;
  width: 89%;
  top: -0.08rem;
  padding-top: 90%;
  border-radius: 0.16rem;
  overflow: hidden;
  left: 0;
  right: 0;
  margin: auto;
}

@media screen and (min-width: 750px) {
  .home-card-body-base {
    width: auto !important;
  }
  .home-card-list-scroll {
    overflow: hidden;
  }
  .home-card-body-width-ac {
    width: 3.5rem;
  }
}
</style>