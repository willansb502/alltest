<template>
  <div class="home-btn-warp">
    <ul class="home-btn-list">
      <li
        class="nav-item"
        v-for="(item, index) in state.tabbars"
        @click="toPage(item)"
        :key="index"
        :class="{
          'nav-2': item.isHidden
        }"
      >
        <img :src="item.img" alt="" />
        <div class="name" :class="{ activeClassTabName: $route.path === item.path }">{{ item.name }}</div>
      </li>
    </ul>

    <ul class="home-btn-list pc" style="margin-top: 0.2rem" v-if="tags.length > 0">
      <template v-for="(tagItem, index) in tags">
        <li class="tag" v-if="tagItem && tagItem.name" @click="toPage(tagItem)" :key="'tag' + index">
          <div style="padding-top: 100%; position: relative">
            <div class="home-card-body-content">
              <template v-if="tagItem">
                <div
                  style="position: relative"
                  :style="{
                    width: '100%',
                    paddingTop: '100%'
                  }"
                  @click="() => $router.push(`tag/detail/1?name=${tagItem.name}`)"
                >
                  <div class="home-pos-w100">
                    <DecryptImg v-if="tagItem.cover" :imgURL="tagItem.cover" :needPadding="false" class="item-bg">
                    </DecryptImg>
                    <div
                      style="
                        display: flex;
                        flex-flow: row wrap;
                        justify-content: center;
                        align-items: center;
                        width: 100;
                        height: 100%;
                        color: #f4ce4e;
                        font-size: 0.46rem;
                      "
                      v-else
                    >
                      {{ tagItem.name && tagItem.name.substring(0, 2) }}
                    </div>
                  </div>
                </div>
              </template>
            </div>
          </div>
          <div style="padding: 0.1rem 0; text-align: center; font-size: 0.24rem; opacity: 46%">{{ tagItem.name }}</div>
        </li>
      </template>
    </ul>
  </div>
</template>
<script setup>
import { getAssetsFile } from '@/utils/utils_tools.js'
const router = useRouter()
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const props = defineProps({
  tags: {
    type: Array,
    default: () => []
  },
  list: {
    type: Array,
    default: () => []
  }
})
const state = reactive({
  tabbars: [
    {
      name: '发现',
      isHidden: true,
      path: '/home',
      img:getAssetsFile('index/mu-btn-list/1_1.png') 
    },
    { 
      name: '推荐', 
      isHidden: false, 
      path: '/recommend', 
      img:getAssetsFile('index/mu-btn-list/1_02.png') 
    },
    {
      name: '国产传媒',
      isHidden: false,
      path: '/home/sub?name=国产',
      img:getAssetsFile('index/mu-btn-list/1_03.png')
    },
    {
      name: 'AV长视频',
      isHidden: false,
      path: '/home/sub?name=AV',
      img:getAssetsFile('index/mu-btn-list/1_04.png')
    },
    {
      name: '原创内容',
      isHidden: false,
      path: '/home/sub?name=原创',
      img:getAssetsFile('index/mu-btn-list/1_05.png')
    },

    {
      name: '小视频',
      isHidden: false,
      path: '/home/sub?name=小视频',
      img:getAssetsFile('index/mu-btn-list/1_06.png')
    },
    {
      name: '抖阴',
      isHidden: true,
      path: '/short_video',
      img:getAssetsFile('index/mu-btn-list/1_07.png')
    },
    {
      name: '动漫',
      isHidden: false,
      path: '/home/sub?name=动漫',
      img:getAssetsFile('index/mu-btn-list/1_08.png')
    },
    {
      name: '禁漫天堂',
      isHidden: true,
      path: '/comics',
      img:getAssetsFile('index/mu-btn-list/1_09.png')
    },
    {
      name: '欧美精选',
      isHidden: false,
      path: '/home/sub?name=AV&type=om',
      img:getAssetsFile('index/mu-btn-list/1_10.png')
    },
    {
      name: '社区广场',
      isHidden: true,
      path: '/community',
      img:getAssetsFile('index/mu-btn-list/1_11.png')
    },
    {
      name: '名优馆',
      isHidden: false,
      path: '/home/actor',
      img:getAssetsFile('index/mu-btn-list/1_12.png')
    },
    {
      name: '标签',
      isHidden: false,
      path: '/hot_tag/1',
      img:getAssetsFile('index/mu-btn-list/1_12.png')
    },

    {
      name: '推广赚钱',
      isHidden: true,
      path: '/mine/agent',
      img:getAssetsFile('index/mu-btn-list/1_14.png')
    },
    {
      name: '签到',
      isHidden: true,
      path: '/signIn',
      img:getAssetsFile('index/mu-btn-list/1_15.png')
    },
    {
      name: '会员中心',
      isHidden: true,
      path: '/vip',
      img:getAssetsFile('index/mu-btn-list/1_16.png')
    },

    {
      name: '活动中心',
      isHidden: true,
      path: '/activity',
      img:getAssetsFile('index/mu-btn-list/1_17.png')
    },
    {
      name: '约炮楼风',
      path: '/dating',
      isHidden: true,
      img:getAssetsFile('index/mu-btn-list/1_18.png')
    },
    {
      name: '个人中心',
      isHidden: true,
      path: '/mine',
      img:getAssetsFile('index/mu-btn-list/1_19.png')
    },

    {
      name: '在线导航',
      isHidden: false,
      path: '/application',
      img:getAssetsFile('index/mu-btn-list/1_20.png')
    }
  ]
})

const toPage = (item) => {
  router.push(item.path)
}
</script>
<style lang="scss" scoped>
//首页跳转导航
.home-btn-list {
  position: relative;
  top: -0.12rem;
  display: flex;
  flex-wrap: wrap;
  background: #000000;
  box-shadow: 0 0.03rem 0.12rem 0 #8977777d;
  border-radius: 0.12rem;
  margin: 0 0.15rem;
  padding-top: 0.22rem;
  box-sizing: border-box;
  .nav-2 {
    display: none;
  }
  .nav-item {
    padding-bottom: 0.2rem;
    text-align: center;
    width: 20%;
    color: #fff;
    font-size: 0.24rem;
    .name {
      opacity: 0.8;
      font-weight: 400;
      padding-top: 0.1rem;
    }
    img {
      width: 0.78rem;
      height: 0.78rem;
      object-fit: contain;
    }
  }
  .tag {
    display: none;
  }

  .activeClassTabName {
    color: #efa243 !important;
  }
}

@media screen and (max-width: 750px) {
  .home-btn-list.pc {
    display: none;
  }
}
@media screen and (min-width: 750px) {
  .home-btn-list {
    .nav-item {
      width: 20%;
      img {
        width: 0.68rem;
        height: 0.68rem;
        object-fit: contain;
      }
    }
    .nav-2 {
      display: block;
    }
    .tag {
      position: relative;
      width: 20%;
      padding: 0.22rem 0.42rem;
      display: inline-block;
      vertical-align: top;
      top: 0.08rem;
    }
    .home-pos-w100 {
      position: absolute;
      top: 0;
      width: 100%;
      height: 100%;
    }
    .home-card-body-content {
      position: absolute;
      z-index: 1;
      top: 0;
      width: 100%;
      display: flex;
      flex-flow: row wrap;
      border-radius: 0.16rem;

      overflow: hidden;
    }
  }
}
@media screen and (min-width: 1060px) {
  .home-btn-list {
    .nav-item {
      width: 10%;
      img {
        width: 1rem;
        height: 1rem;
        object-fit: contain;
      }
    }
    .nav-2 {
      display: block;
    }
    .tag {
      position: relative;
      width: 10%;
      padding: 0.22rem 0.42rem;
      display: inline-block;
      vertical-align: top;
      top: 0.08rem;
    }
    .home-pos-w100 {
      position: absolute;
      top: 0;
      width: 100%;
      height: 100%;
    }
    .home-card-body-content {
      position: absolute;
      z-index: 1;
      top: 0;
      width: 100%;
      display: flex;
      flex-flow: row wrap;
      border-radius: 0.16rem;
      overflow: hidden;
    }
    li:hover {
      cursor: pointer;
      .name {
        color: #f0a244;
      }
    }
  }
}
</style>