<template>
  <div class="home-index">
    <div class="tab-main">
      <PullUp
        @refreshData="refreshData"
        @moreData="moreData"
        :finished="state.finished"
        :loading="state.loading"
        :refreshing="state.refreshing"
        :skeleton="state.skeleton"
      >
        <Actor :list="state.recomendActorList" />
        <!-- 列表 -->
        <p class="all-title">全部女优</p>
        <ul class="all-list">
          <li @click="$router.push(`/actor/detail/${item.id}`)" v-for="item in state.actorList" :key="item.id">
            <DecryptImg :imgURL="item.avatar" />
            <p>{{ item.name }}</p>
          </li>
        </ul>
      </PullUp>
    </div>
  </div>
</template>

<script setup>
import { showToast } from 'vant';
import { index_home } from '@/api/home'
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const Actor = defineAsyncComponent(() => import('@/components/JavActor.vue'))
const props = defineProps({
  type: {
    type: Number,
    default: 0
  } 
})
const state = reactive({
  pageNum: 1,
  pageSize: 30,
  actorList: [],
  recomendActorList: [],
  loading: false,
  skeleton: false,
  refreshing: false,
  finished: false // 每次请求到的数据长度
})
// 上拉加载更多
const moreData = (loading) =>{
  state.loading = loading
  state.pageNum += 1
  getCartoonPage()
}

// 下啦刷新
const refreshData = (refreshing) =>{
  state.refreshing = refreshing
  state.loading = true
  state.finished = false
  state.actorList = []
  state.pageNum = 1
  state.skeleton = true
  getCartoonPage()
}

// 获取首页数据
const getCartoonPage =async (refreshing) =>{
  try {
    const res = await index_home({
      id: props.type,
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      state.refreshing = false
      state.loading = false
      if (state.pageNum === 1) {
        state.recomendActorList = res.data.recomendActorList
      } else {
        res.data.recomendActorList
          ? (state.recomendActorList = res.data.recomendActorList)
          : ''
      }
      state.actorList = [...state.actorList, ...res.data.actorList]
      if (!res.data.actorList || res.data.actorList.length < state.pageSize) {
        state.finished = true
      }
    } else {
      state.refreshing = false
      state.loading = false
      state.finished = true
      return showToast(res.tip)
    }
  } catch (error) {
    state.finished = true
    state.refreshing = false
    state.loading = false
    console.log(error)
    showToast('请求错误，请稍后再试!')
  }
}

onMounted(() => {
  refreshData()
})
</script>

<style lang="scss" scoped>
.tab-main {
  margin: 0 0.25rem;
  .all-title {
    margin: 0.3rem 0 0.1rem 0;
    font-size: 0.3rem;
    font-weight: 600;
    color: transparent;
    background: $txtActive;
    -webkit-background-clip: text;
  }
  .all-list {
    border-radius: 0.05rem;
    @include flexbox($jc: flex-start, $ai: flex-start, $fd: row, $fw: wrap);
    padding: 0.3rem 0.25rem 0 0.25rem;
    li {
      margin-bottom: 0.3rem;
      width: 19%;
      text-align: center;
      margin-right: 8%;
      p {
        margin: 0;
        margin-top: 0.2rem;
        font-size: 0.24rem;
      }
      .default {
        :deep()  {
          .warp {
            border-radius: 50%;
          }
        }
      }
    }
    li:nth-child(4n) {
      margin-right: 0;
    }
  }


}
@media screen and (min-width: 750px) {
  .tab-main {
    .all-list {
      li {
        width: 8%;
        margin-right: 2%;
      }
      li:nth-child(4n) {
        margin-right: 2%;
      }
      li:nth-child(10n) {
        margin-right: 0;
      }
    }
  }
}
</style>
