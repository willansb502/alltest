<template>
  <div class="cartoon-default">
    <!-- 循环卡片 -->
    <div class="cartoon-default-main">
      <JavBgNav @navChange="navChange" :titles="state.childCategory" :active="state.indexActive" />
      <PullUp
        @refreshData="refreshData"
        @moreData="moreData"
        :finished="state.finished"
        :loading="state.loading"
        :refreshing="state.refreshing"
      >
        <!-- 循环卡片 -->
        <div class="cartoon-list-main">
          <component
            :typeTxt="'默认'"
            :id="type"
            :sort="state.sort"
            :list="state.mediaList"
            :is="compComponent(showType)"
          ></component>
        </div>
      </PullUp>
    </div>
  </div>
</template>

<script setup>
import { showToast } from 'vant';
import { index_home } from '@/api/home'
const JavShortFour = defineAsyncComponent(() => import('@/components/JavShortFour.vue'))
const JavFourCard = defineAsyncComponent(() => import('@/components/JavFourCard.vue'))
const JavBigList = defineAsyncComponent(() => import('@/components/JavBigList.vue'))
const JavShortSix = defineAsyncComponent(() => import('@/components/JavShortSix.vue'))
const JavTitleMore = defineAsyncComponent(() => import('@/components/JavTitleMore.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const JavBgNav = defineAsyncComponent(() => import('@/components/JavBgNav.vue'))
const props = defineProps({
  type: {
    type: String,
    default: 0
  },
  showMask: {
    type: Boolean,
    default: false
  }   
})
const state = reactive({
  childCategory: [
    { id: 0, name: '最新发布' },
    { id: 1, name: '最热观看' },
    { id: 2, name: '最受好评' }
  ],
  pageNum: 1,
  pageSize: 12,
  indexActive: 0,
  mediaList: [],
  loading: false,
  refreshing: false,
  sort: 0,
  finished: false 
})
const navChange = (index) =>{
  state.sort = index
  refreshData()
}
// 上拉加载更多
const moreData = (loading) =>{
  state.loading = loading
  state.pageNum += 1
  getCartoonPage()
}
// 下啦刷新
const refreshData = (refreshing) =>{
  state.refreshing = refreshing
  state.loading = true
  state.finished = false
  state.mediaList = []
  state.pageNum = 1
  getCartoonPage()
}
// 展示方式  1:专题 2:默认 3:长列表 4:女优 5:推荐
const compComponent = (showType) =>{
  switch (showType) {
    case 2:
      return 'JavShortFour'
    case 3:
      return 'JavBigList'
    default:
      return 'JavShortFour'
  }
}
// 获取首页数据
const getCartoonPage = () =>{
  try {
    const res = await index_home({
      id: props.type,
      pageNum: state.pageNum,
      pageSize: state.pageSize,
      sort: state.sort
    })
    if (res.code === 200) {
      state.refreshing = false
      state.loading = false
      state.mediaList = [...state.mediaList, ...res.data.mediaList]
      if (res.data.mediaList.length < state.pageSize || !res.data.mediaList) {
        state.finished = true
      }
    } else {
      state.finished = true
      state.refreshing = false
      state.loading = false
    }
  } catch (error) {
    state.finished = true
    state.refreshing = false
    state.loading = false
    console.log(error)
    showToast('请求错误，请稍后再试!')
  }
}
onMounted(() => {
  refreshData()
})
</script>

<style lang="scss" scoped>
.cartoon-default-main {
  margin-top: 0.5rem;
  //  padding: 0 0.25rem;
}

</style>

