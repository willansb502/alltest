<template>
  <div class="home-header-wrap">
    <div class="home-header">
      <van-icon name="wap-nav" @click="openMenuBtn" size="24" />
      <img
        v-if="$route.path === '/comics'"
        class="book"
        @click="$router.push(`/comic/bookshelf`)"
        src="@/assets/imgs/comics/book.png"
        alt=""
      />

      <div class="search-input" @click="$router.push('/search/index')">
        <van-icon name="search" size="16" />
        搜番号 女优 标题等
      </div>
      <div class="logo" @click="clickLogo">
        <img :src="`${baseUrl}${logoName}`" alt="" />
      </div>
    </div>
  </div>
</template>

<script setup>
const logoName = import.meta.env.VITE_APP_logoName
const baseUrl = import.meta.env.VITE_APP_baseUrl
const emits = defineEmits(["openMenuBtn","clickHeader"])
const router = useRouter()
const clickLogo = () =>{
  router.push('/')
}
const openMenuBtn = () =>{
  emits("openMenuBtn")
}
const toTagList = () =>{
  emits("clickHeader")
}
</script>

<style lang="scss" scoped>
.home-header-wrap {
  width: 100%;
  background: $mainBgDeepColor;
  position: fixed;
  top: 0;
  left: 50%;
  @include transformCenter(-50%, 0);
  z-index: 10;
}
.home-header {
  @include flexbox($jc: space-between, $ai: center, $fd: row, $fw: nowrap);
  //@include transformCenter(-50%, 0);
  width: 100%;
  // max-width: $pcMaxWidth;
  padding: 0 0.12rem;
  z-index: 10;
  height: 1rem;
  color: $cardTitle;
  .logo {
    cursor: pointer;
    display: block;
    width: 30%;
    font-size: 0;
    padding: 0 0.05rem;
    img {
      width: 100%;
      height: 100%;
      object-fit: contain;
    }
  }
  h2 {
    margin: 0 0.25rem 0 0.1rem;
    font-size: 16px;
    font-weight: 600;
    white-space: nowrap;
  }
  .search-input {
    background: linear-gradient(to right, #1f1f21, #2c2f31);
    @include textoverflow();
    width: 100%;
    max-width: 1300px;
    height: 0.6rem;
    line-height: 0.62rem;
    border-radius: 0.25rem;
    color: #939496;
    font-size: 0.24rem;
    margin-left: 0.11rem;
    margin-right: 0.11rem;
    .van-icon-search {
      margin-right: 0.1rem;
    }
  }

  .search-icon {
    margin: 0 0.164rem 0 0.19rem;
  }
  .meassage-icon {
    .van-info--dot {
      top: 0.12rem;
      right: 0.08rem;
    }
  }
  .book {
    filter: brightness(100);
    margin: 0 0.16rem;
    width: 0.48rem;
  }
}
@media screen and (min-width: 875px) {
  .home-header {
    padding: 0 5%;
    .logo {
      display: block;
      width: auto;
      height: 0.5rem;
      font-size: 0;
      margin-right: 0.2rem;

      img {
        width: 100%;
        height: 100%;
      }
    }
  }
}
</style>
