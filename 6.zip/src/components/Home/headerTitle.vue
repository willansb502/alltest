<template>
  <div
    style="
      display: flex;
      flex-flow: row wrap;
      justify-content: space-between;
      align-items: center;
      padding: 0.12rem 0.12rem;
      line-height: 0.6rem;
    "
  >
    <div style="display: flex; flex-flow: row wrap; justify-content: flex-start; align-items: center">
      <h3 style="width: auto; padding: 0 0.1rem 0 0.2rem; color: #fff" :class="calssName">{{ title }}</h3>
      <span
        v-if="hasMoreBtn"
        style="position: relative; top: 0.01rem; font-size: 0.22rem; color: #ccc; cursor: pointer"
        @click="clickMore"
        >{{ moreText }}</span
      >
    </div>
    <p v-if="hasReplayBtn" @click="clickReplayBtn" class="hasReplayBtn"><van-icon name="replay" />换一换</p>
  </div>
</template>

<script setup>
const emits = defineEmits(["clickReplayBtn","clickMore"])
const props = defineProps({
  moreText: {
    type: String,
    default: '更多>>'
  },
  title: {
    type: String,
    required: true,
    default: '今日片单'
  },
  calssName: {
    type: String,
    default: 'home-card-title'
  },
  hasMoreBtn: {
    type: Boolean,
    default: () => true
  },
  hasReplayBtn: {
    type: Boolean,
    default: () => true
  }
})

const clickMore = () =>{
  emits("clickMore")
}
const clickReplayBtn = () =>{
  emits("clickReplayBtn")
}

</script>

<style lang="scss" scoped>
.home-card-title {
  font-size: 0.28rem;
  padding: 0.12rem 0.1rem;
  margin: 0 0;
  color: $cardTitle;
}
.home-card-sub-title {
  font-size: 0.28em;
  padding: 0.12rem 0.1rem;
  margin: 0 0;
  color: #aba9a9;
}
.hasReplayBtn {
  cursor: pointer;
  color: $cardTitle;
  font-size: 0.24rem;
  padding: 0 0.2rem;
  margin: 0 0;
}
@media screen and (min-width: 750px) {
  .home-card-title {
    font-size: 0.34rem;
  }
  .home-card-sub-title {
    font-size: 0.28rem;
  }
}
</style>