<template>
  <div class="home-index">
    <div class="tab-main">
      <!-- 专题顶部标签 -->
      <div class="card-list" v-if="showType === 1 && state.tagList.length">
        <DecryptImg
          v-for="(item, index) in state.tagList"
          @clickImg="$router.push(`/tag/detail/${$route.meta.location}?name=${item.name}`)"
          :key="item.cover"
          :imgURL="item.cover"
          class="card-img"
          :needPadding="false"
        >
          <div class="title">{{ item.name }}</div>
          <div
            class="more-bg"
            @click.stop="$router.push(`/hot_tag/${$route.meta.location}`)"
            v-if="index === state.tagList.length - 1"
          >
            更多标签
          </div>
        </DecryptImg>
        <i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i>
      </div>

      <!-- 列表 -->
      <PullUp
        @refreshData="refreshData"
        @moreData="moreData"
        :finished="state.finished"
        :loading="state.loading"
        :refreshing="state.refreshing"
      >
        <MuBtnList :tags="[]" style="margin: 0.25rem 0"></MuBtnList>
        <!-- 推荐类 -->
        <!-- <template v-if="navItem.item.showType === 5">
          <div v-for="(item, index) in state.remDataList" :key="index">
            <JavBigList v-if="item.longList.length" style="margin: 0 0.25rem" :list="item.longList"></JavBigList>

            <JavShortFour
              style="margin: 0 0.25rem"
              v-if="item.shortList.length && showRemShortVideoType == 'sub'"
              :id="navItem.item.id"
              :typeTxt="'默认'"
              :list="item.shortList"
            >
            </JavShortFour>

            <JavSortVideoBigRow
              v-if="item.shortList.length && showRemShortVideoType != 'sub'"
              :list="item.shortList"
              :id="navItem.item.id"
              :typeTxt="'默认'"
            >
            </JavSortVideoBigRow>

            <JavShortFour
              :typeTxt="'默认'"
              v-if="item.avList.length"
              style="margin: 0 0.25rem"
              :list="item.avList"
            ></JavShortFour>
          </div>
        </template> -->

        <!-- 专题类  -->
        <div class="home-index-main">
          <!-- 循环卡片 -->
          <div v-for="(item, index) in state.topicList" :key="item.id">
            <JavTitleMore
              v-if="item.mediaList && item.mediaList.length > 0"
              :price="item.price"
              :title="item.name"
              :isBuy="item.isBuy"
              :desc="item.desc"
              :id="item.id"
              @lookMore="lookMore(item)"
            />
            <component
              :typeID="type"
              :id="item.id"
              :list="item.mediaList"
              :is="compComponent(item.showType)"
            ></component>
            <!-- 中间活动倒计时 -->
            <div
              class="activity-card"
              v-if="index === 0 && state.newAdvertise.timeOut && showType === 5"
              @click="activityBtn(state.newAdvertise.href)"
            >
              <DecryptImg class="card-img" :imgURL="state.newAdvertise.cover" :needPadding="false" />
              <!-- 活动倒计时 -->
              <div class="advertiseTimeOut">
                <span class="txt">倒计时</span>
                <van-count-down :time="time" millisecond>
                  <template #default="timeData">
                    <span class="advertiseTimeOut-block">{{
                      timeData.days >= 10 ? timeData.days : `0${timeData.days}`
                    }}</span>
                    <span class="advertiseTimeOut-txt">:</span>
                    <span class="advertiseTimeOut-block">{{
                      timeData.hours >= 10 ? timeData.hours : `0${timeData.hours}`
                    }}</span>
                    <span class="advertiseTimeOut-txt">:</span>
                    <span class="advertiseTimeOut-block">{{
                      timeData.minutes >= 10 ? timeData.minutes : `0${timeData.minutes}`
                    }}</span>
                    <span class="advertiseTimeOut-txt">:</span>
                    <span class="advertiseTimeOut-block">{{
                      timeData.seconds >= 10 ? timeData.seconds : `0${timeData.seconds}`
                    }}</span>
                  </template>
                </van-count-down>
              </div>
            </div>
          </div>
        </div>
      </PullUp>
    </div>
  </div>
</template>

<script setup>
import { showToast } from 'vant';
import { index_home } from '@/api/home'
const router = useRouter()
import { handleParamsRouteJump, handleURlParams } from '@/utils/utils_tools'
const MuBtnList = defineAsyncComponent(() => import('@/components/Home/MuBtnList.vue'))
const JavShortFour = defineAsyncComponent(() => import('@/components/JavShortFour.vue'))
const JavFourCard = defineAsyncComponent(() => import('@/components/JavFourCard.vue'))
const JavBigList = defineAsyncComponent(() => import('@/components/JavBigList.vue'))
const JavSortVideoBigRow = defineAsyncComponent(() => import('@/components/JavSortVideoBigRow.vue'))
const JavShortSix = defineAsyncComponent(() => import('@/components/JavShortSix.vue'))
const JavTitleMore = defineAsyncComponent(() => import('@/components/JavTitleMore.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))

const props = defineProps({
  type: {
    type: Number,
    default: 0
  },
  showType: {
    type: Number,
    default: 0
  },
  navItem: {
    type: Object,
    default: {}
  },
  showRemShortVideoType: {
    type: Number,
    default: 0
  }
})
const state = reactive({
  pageNum: 1,
  pageSize: 12,
  topicList: [],
  tagList: [],
  loading: false,
  refreshing: false,
  sort: null,
  newAdvertise: {}, //中间活动广告
  finished: false, // 每次请求到的数据长度
  // 推荐
  remDataList: [],  
})
// 导航跳转
const toPage = (item) =>{
  router.push(item.path)
}
// 活动广告跳转
const activityBtn = (href) =>{
  const code = handleURlParams(href)
  handleParamsRouteJump(code)
}
// 专题详情跳转
const lookMore = (item) =>{
  router.push(`/media_detail/${item.id}?title=${item.name}&showType=${item.showType}&price=${item.price}`)
}

// 上拉加载更多
const moreData = (loading) =>{
  state.loading = loading
  state.pageNum += 1
  getCartoonPage()
}

// 下啦刷新
const refreshData = (refreshing) =>{
  state.refreshing = refreshing
  state.loading = true
  state.finished = false
  state.topicList = []
  state.remDataList = []
  state.pageNum = 1
  getCartoonPage()
}
// 展示方式  1:横版(三排两列)长视频大横排 2:横版(大列表) 3:竖版(两排三列)短视频四宫格 4:竖版(三排两列)短视频六宫格
const compComponent = (showType) =>{
  switch (showType) {
    case 1:
      return 'JavFourCard'
    case 2:
      return 'JavBigList'
    case 3:
      return 'JavShortSix'
    case 4:
      return 'JavShortFour'
    default:
      return 'JavShortSix'
  }
}  
// 获取首页数据
const getCartoonPage =async () =>{
  try {
    const res = await index_home({
      id: props.type,
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })

    if (res.code === 200) {
      state.refreshing = false
      state.loading = false
      // 推荐页特殊处理
      // if (props.navItem.item.showType === 5) {
      //   return fn_recommend(res)
      // }

      if (state.pageNum === 1) {
        if (res.data && res.data.tagList && res.data.tagList.length) {
          state.tagList = res.data.tagList.splice(0, 8)
        } else {
          state.tagList = []
        }
        if (res.data.newAdvertise) {
          state.newAdvertise = res.data.newAdvertise
        } else {
          state.newAdvertise = {}
        }
      } else {
        if (res.data.tagList && res.data.tagList.length) state.tagList = res.data.tagList
        if (res.data.newAdvertise) state.newAdvertise = res.data.newAdvertise
      }

      state.topicList = [...state.topicList, ...res.data.topicList]

      if (res.data.topicList.length < state.pageSize || !res.data.topicList) {
        state.finished = true
      }
    } else {
      state.refreshing = false
      state.loading = false
      state.finished = true
      showToast(res.tip)
    }
  } catch (error) {
    state.finished = true
    state.refreshing = false
    state.loading = false
    console.log(error)
    showToast('请求错误，请稍后再试!')
  }
}    
// 推荐页面数据整理 
const fn_recommend =(res) =>{
  const obj = {
    avList: res.data.avList ? (res.data.avList.length >= 14 ? res.data.avList.slice(0, 12) : res.data.avList) : [],
    longList: res.data.longList
      ? res.data.longList.length > 14
        ? res.data.longList.slice(0, 14)
        : res.data.longList
      : [],
    shortList: res.data.shortList
      ? res.data.shortList.length > 13
        ? res.data.shortList.slice(0, 13)
        : res.data.shortList
      : []
  }
  state.remDataList.push(obj)
  if (res.data.avList.length < state.pageSize || !res.data.avList) {
    state.finished = true
  }
}  

onMounted(() => {
  refreshData()
}) 

const time = computed(() => {
  return {
    const nowTiem = new Date().getTime()
    const newTime = Date.parse(state.newAdvertise.timeOut)
    const other = newTime - nowTiem
    if (other && other > 0) {
      return other
    } else {
      return false
    }
  }
})
</script>

<style lang="scss" scoped>
//首页跳转导航
.home-btn-list {
  display: flex;
  flex-wrap: wrap;
  padding-top: 0.2rem;
  background: $mainBgColor;
  box-shadow: 0 0.03rem 0.12rem 0 #29000000;
  border-radius: 0.05rem;
  margin: 0 0.25rem;
  margin-bottom: 0.25rem;
  li {
    padding-bottom: 0.4rem;
    text-align: center;
    width: 20%;
    color: $mainTxtColor1;
    font-size: 0.24rem;
    .name {
      padding-top: 0.1rem;
    }
    &:nth-child(1) {
      img {
        width: 0.42rem;
      }
    }
    &:nth-child(2) {
      img {
        width: 0.48rem;
      }
    }
    &:nth-child(3) {
      img {
        width: 0.4rem;
      }
    }
    &:nth-child(4) {
      img {
        width: 0.4rem;
      }
    }
    &:nth-child(5) {
      img {
        width: 0.364rem;
      }
    }

    &:nth-child(6) {
      img {
        width: 0.44rem;
      }
    }
    &:nth-child(7) {
      img {
        width: 0.28rem;
      }
    }
    &:nth-child(8) {
      img {
        width: 0.366rem;
      }
    }
    &:nth-child(9) {
      img {
        width: 0.38rem;
      }
    }
    &:nth-child(10) {
      img {
        width: 0.4rem;
      }
    }
  }
}
//推荐以外的主题
.card-list {
  @include flexbox($jc: space-between, $ai: center, $fd: row, $fw: wrap);
  padding-top: 0;
  margin-top: 0.3rem;
  .card-img {
    width: 1.5rem;
    height: 1.9rem;
    border-radius: 0.1rem;
    margin-bottom: 0.2rem;
    position: relative;
    :deep()  {
      .warpNoPadding {
        border-radius: 0.1rem;
        img {
          border-radius: 0.1rem;
        }
      }
    }
    .title {
      position: absolute;
      @include transformCenter(-50%, 0);
      left: 50%;
      bottom: 0;
      width: 100%;
      height: 0.4rem;
      text-align: center;
      line-height: 0.4rem;
      background: rgba($color: #000000, $alpha: 0.5);
      font-size: 0.2rem;
      border-bottom-left-radius: 0.1rem;
      border-bottom-right-radius: 0.1rem;
      color: $mainTxtColor1;
    }
    .more-bg {
      position: absolute;
      left: 0;
      bottom: 0;
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba($color: #000000, $alpha: 0.7);
      font-size: 0.2rem;
      border-radius: 0.1rem;

      color: $mainTxtColor1;
    }
  }
  i {
    width: 1.5rem;
  }
}
.activity-card {
  position: relative;
  .card-img {
    height: 1.5rem;
    width: 100%;
  }
  .advertiseTimeOut {
    position: absolute;
    right: 0.3rem;
    top: 0.45rem;
    display: flex;
    align-items: center;
    .txt {
      margin-right: 0.2rem;
      font-size: 0.3rem;
      color: $mainTxtColor1;
    }
    &-txt {
      color: $mainTxtColor1;
      font-size: 0.3rem;

      font-weight: 600;
      margin: 0 0.02rem;
    }
    &-block {
      width: 0.4rem;
      height: 0.4rem;
      background: $mainBgColor;
      border-radius: 0.06rem;
      font-weight: 600;
      color: #000;
      font-size: 0.32rem;
      padding: 0 0.1rem;
    }
  }
}
</style>
