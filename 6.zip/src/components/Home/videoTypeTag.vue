<template>
  <div class="video-type">
    <div class="video-type-vip" v-if="payType === 1">VIP</div>
    <div class="video-type-gold" v-if="payType === 2">
      <img src="@/assets/imgs/index/gold.png" alt="" />
      {{ changeGold(price) }}
    </div>
    <div class="video-type-free" v-if="payType === 0">免费</div>
  </div>
</template>

<script setup>
import { changeGold } from '@/utils/filter'
const props = defineProps({
  payType: {
    type: Number,
    default: 3
  },
  price: {
    type: Number,
    default: 0
  }
})
</script>

<style lang="scss" scoped>
.video-type {
  position: absolute;
  top: -0.03rem;
  left: -0.06rem;
  color: $mainTxtColor1;
  font-size: 0.16rem;
  font-weight: 600;
  transform: scale(0.95);
  &-vip {
    width: 0.64rem;
    height: 0.29rem;
    border-bottom-right-radius: 0.12rem;
    border-top-left-radius: 0.12rem;
    text-align: center;
    line-height: 0.29rem;
    background: linear-gradient(to right, #fd9c3a, #fc342d);
  }
  &-gold {
    min-width: 0.68rem;
    height: 0.29rem;
    border-bottom-right-radius: 0.12rem;
    border-top-left-radius: 0.12rem;
    text-align: center;
    line-height: 0.29rem;
    background: linear-gradient(to right, #493afd, #752dfc);
    img {
      width: 0.19rem;
      height: 0.19rem;
    }
  }
  &-free {
    width: 0.64rem;
    height: 0.29rem;
    border-bottom-right-radius: 0.4rem;
    border-top-left-radius: 0.12rem;
    text-align: center;
    line-height: 0.29rem;
    background: linear-gradient(to right, #00cd01, #06ac04);
  }
}
@media screen and (min-width: 960px) {
  .video-type {
    font-size: 16px;
    &-vip {
      width: 0.84rem;
      height: 0.38rem;
      line-height: 0.38rem;
    }
    &-gold {
      min-width: 0.84rem;
      height: 0.38rem;
      line-height: 0.38rem;
      img {
        width: 0.19rem;
        height: 0.19rem;
      }
    }
    &-free {
      width: 0.84rem;
      height: 0.38rem;
      line-height: 0.38rem;
    }
  }
}
</style>