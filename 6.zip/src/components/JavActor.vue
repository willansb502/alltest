<template>
  <div class="actor-list">
    <div class="actor-detail" @click="$router.push(`/actor/detail/${item.id}`)" v-for="item in list" :key="item.id">
      <div class="top">
        <div class="top-left">
          <DecryptImg :imgURL="item.avatar" />
          <div class="counts">
            <div class="name">{{ item.name }}</div>
            <div class="counts-detail">
              <div class="video-num">
                <img src="@/assets/imgs/index/videos.svg" alt="" />
                {{numberFilter(item.movieCount)}}
              </div>
              <div class="watchs-num">
                <img src="@/assets/imgs/index/watchs.svg" alt="" />
                {{numberFilter(item.watchCount)}}
              </div>
            </div>
          </div>
        </div>
        <div class="top-right">进入专题</div>
      </div>
      <ul class="video-list" @touchmove.stop v-if="item.mediaList && item.mediaList.length > 0">
        <li class="video-item" v-for="sItem in item.mediaList" :key="sItem.id">
          <DecryptImg :imgURL="sItem.coverImg" :needPadding="false" class="item-bg">
            <!-- 视频分类标签 -->
            <div class="video-type">
              <div class="video-type-vip" v-if="sItem.payType === 1">VIP</div>
              <div class="video-type-gold" v-if="sItem.payType === 2">
                <img src="@/assets/imgs/index/gold.png" alt="" />
                {{ changeGold(sItem.price) }}
              </div>
              <div class="video-type-free" v-if="sItem.payType === 0">免费</div>
            </div>
            <!-- 视频详情标签 -->
            <div class="vide-detail-type">
              <img v-if="sItem.showTags === '无码'" src="@/assets/imgs/index/video-ma.svg" alt="" />
              <img v-if="sItem.showTags === '中文'" src="@/assets/imgs/index/video-zhong.svg" alt="" />
            </div>
            <!-- 时间 -->
            <div class="video-time">
              <img src="@/assets/imgs/index/card-play.svg" alt="" />
              {{ secondToDate(sItem.playTime) }}
            </div>
          </DecryptImg>
          <!-- 影片描述 -->
          <div class="item-desc">{{ sItem.title }}</div>
        </li>
      </ul>
      <div @click.stop="checkItem(item)" v-if="showMask" class="sel-wrap">
        <img v-if="!item.clickMask" src="@/assets/imgs/mine/sel-default.png" alt="" />
        <img v-else src="@/assets/imgs/mine/sel-active.png" alt="" />
      </div>
    </div>
  </div>
</template>

<script  setup>
import { defineProps, defineEmits,reactive} from "vue";
import { changeGold,secondToDate,numberFilter } from '@/utils/filter'
import DecryptImg from "@/components/DecryptImg/index.vue"
const props = defineProps({
  list: {
    type: Array,
    default: []
  },
  showMask: {
    type: Boolean,
    default:false
  }
})

const state = reactive({
  spliceList: []
})

const checkItem = async (item) => {
  item.clickMask = !item.clickMask
  if (item.clickMask) {
    if (state.spliceList.length > 0) {
      state.spliceList.map((sItem, index, arr) => {
        if (item.id === sItem.id) {
          arr.splice(index, 1, item.id)
        }
      })
      state.spliceList.push(item.id)
    } else {
      state.spliceList.push(item.id)
    }
  } else {
    state.spliceList.map((sItem, index) => {
      if (item.id === sItem.id) {
        state.spliceList.splice(index, 1)
      }
    })
  }
  // 向组件传递方法
  const emits = defineEmits(["clickItem"])
  // 向父组件传递方法
  emits("clickItem",state.spliceList)  
};

</script>

<style lang="scss" scoped>
.actor-list {
  margin-top: 0.3rem;
  .actor-detail {
    background: $mainBgColor;
    box-shadow: $shadow;
    border-radius: 0.05rem;
    margin-bottom: 0.3rem;
    padding: 0.3rem 0.25rem;
    position: relative;
    .top {
      @include flexbox();
      font-size: 0.32rem;
      .top-left {
        @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
        .default {
          width: 1.2rem;
          margin-right: 0.3rem;
          :deep()  {
            .warp {
              border-radius: 50%;
              img {
                border-radius: 50%;
                width: 100%;
                height: 100%;
              }
            }
          }
        }
      }
      .counts {
        .name {
          font-size: 0.32rem;
          font-weight: 600;
          margin-bottom: 0.1rem;
          @include textoverflow();
          color: transparent;
          background: $txtActive;
          -webkit-background-clip: text;
        }
        .counts-detail {
          @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
          .video-num {
            margin-right: 0.4rem;
          }
          .video-num,
          .watchs-num {
            display: flex;
            align-items: center;
            font-size: 0.2rem;
            img {
              width: 0.21rem;
              height: 0.16rem;
              margin-right: 0.08rem;
            }
          }
        }
      }
    }
    .top-right {
      border: 1px solid #1d2436;
      border-radius: 0.3rem;
      width: 1.5rem;
      height: 0.5rem;
      text-align: center;
      line-height: 0.45rem;
      font-size: 0.26rem;
    }
  }
}
.video-list::-webkit-scrollbar {
  /*滚动条整体样式*/
  width: 10px; /*高宽分别对应横竖滚动条的尺寸*/
  height: 10px;
}
.video-list::-webkit-scrollbar-thumb {
  /*滚动条里面小方块*/
  border-radius: 10px;
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  background: #83807e;
}
.video-list::-webkit-scrollbar-track {
  /*滚动条里面轨道*/
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  border-radius: 10px;
  background: #241e1e;
}
.video-list {
  @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
  overflow-y: scroll;
  margin-top: 0.3rem;
}
.video-item {
  width: 2.04rem;
  margin: 0 0.2rem 0 0;
  flex-shrink: 0;
  .item-bg {
    height: 2.7rem;
    position: relative;
    border-radius: 0.12rem;
    :deep()  {
      .warpNoPadding {
        border-radius: 0.12rem;
      }
    }
    .video-type {
      position: absolute;
      top: -0.03rem;
      left: -0.06rem;
      color: $mainTxtColor1;
      font-size: 0.26rem;
      font-weight: 600;
      transform: scale(0.8);

      &-vip {
        width: 0.64rem;
        height: 0.29rem;
        border-bottom-right-radius: 0.12rem;
        border-top-left-radius: 0.12rem;
        text-align: center;
        line-height: 0.29rem;
        background: linear-gradient(to right, #fd9c3a, #fc342d);
      }
      &-gold {
        min-width: 0.68rem;
        height: 0.29rem;
        border-bottom-right-radius: 0.12rem;
        border-top-left-radius: 0.12rem;
        text-align: center;
        line-height: 0.29rem;
        background: linear-gradient(to right, #493afd, #752dfc);
        img {
          width: 0.19rem;
          height: 0.19rem;
          margin-right: 0.02rem;
        }
      }
      &-free {
        width: 0.64rem;
        height: 0.29rem;
        border-bottom-right-radius: 0.12rem;
        border-top-left-radius: 0.12rem;
        text-align: center;
        line-height: 0.29rem;
        background: linear-gradient(to right, #00cd01, #06ac04);
      }
    }
  }

  // 详情标签
  .vide-detail-type {
    position: absolute;
    top: 0;
    right: 0;
    img {
      width: 0.25rem;
      height: 0.25rem;
      margin-top: 0.06rem;
    }
    img:first-child {
      margin-top: 0;
    }
  }
  // 底部时间
  .video-time {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 0.33rem;
    color: $mainTxtColor1;
    line-height: 0.33rem;
    padding-left: 0.16rem;
    font-size: 0.24rem;
    background: rgba($color: #000000, $alpha: 0.6);
    border-bottom-right-radius: 0.12rem;
    border-bottom-left-radius: 0.12rem;
    img {
      width: 0.18rem;
      height: 0.18rem;
      margin-right: 0.02rem;
    }
  }
  .item-desc {
    @include textoverflow(1);
    font-size: 0.26rem;
    margin-top: 0.1rem;
  }
}
// 选择视频
.sel-wrap {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  z-index: 9;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: flex-end;
  border-radius: 0.12rem;
  img {
    width: 0.4rem;
    height: 0.4rem;
  }
}

@media screen and (min-width: 750px) {
  .video-list {
    overflow-y: hidden;
  }

  .video-item {
    width: 4.24rem;
    padding: 0 0.2rem 0 0;
    flex-shrink: 0;
    .item-bg {
      height: 5rem;
    }
  }
}
</style>
