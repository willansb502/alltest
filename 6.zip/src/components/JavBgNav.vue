<template>
  <div class="bg-nav">
    <ul :class="['javDefault', needFixed ? 'javBgNavFixed' : '']">
      <li
        @click="change(item.id)"
        :class="item.id === childActive ? 'active' : ''"
        v-for="item in titles"
        :key="item.id"
        :text="item.name"
      >
        {{ item.name }}

      </li>
    </ul>
  </div>
</template>

<script setup>
const emits = defineEmits(["navChange"])
const props = defineProps({
  titles: {
    type: Array,
    default: [],
  },
  active: {
    type: Number,
    default: 0
  },
  needFixed: {
    type: Boolean,
    default: false
  }  
})

const state = reactive({
  childActive: 0
})

const change =(id) =>{
  if (state.childActive !== id) {
    state.childActive = id
    emits("navChange", state.childActive)
  }
}

watch(() => state.active, (n) => {
  state.childActive = n
},{ immediate: true })

</script>

<style lang="scss" scoped>
.javDefault {
  background: $mainBgDeepColor;
  box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
  border-radius: 0.12rem;
  width: 100%;
  height: 0.88rem;
  font-size: 0.28rem;
  margin-bottom: 0.1rem;
  @include flexbox($jc: center, $ai: center, $fd: row, $fw: nowrap);
  li {
    color: rgb(147, 148, 150);
    @include flexbox($jc: center, $ai: center, $fd: column, $fw: nowrap);
  }
}

.javBgNavFixed {
  position: fixed;
  max-width: calc(750px - 0.5rem);
  left: 50%;
  @include transformCenter(-50%, 0);
}
.active {
  color: #450835;
  font-weight: 600;
}

.active::after {
  content: '';
  width: 0.36rem;
  display: block;
  height: 0.08rem;
  margin-top: 0.03rem;
  background: $txtActive;
  border-radius: 0.12rem;
}
</style>
