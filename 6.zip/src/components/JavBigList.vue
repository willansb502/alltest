<template>
  <div class="big-list" v-if="list && list.length > 0">
    <div class="big-list-item" v-for="(item, index) in list" :key="index" @click="toPlay(item)">
      <div class="item-bg">
        <div class="bg-position">
          <div
            style="
              position: absolute;
              width: 93%;
              top: -0.14rem;
              padding-top: 50%;
              border-radius: 0.16rem;
              overflow: hidden;
              left: 0;
              right: 0;
              margin: auto;
            "
            :style="{
              background: index > 5 ? color[index % 6] : color[index]
            }"
          ></div>
          <DecryptImg :imgURL="item.coverImg" :needPadding="false" class="bg-position-img">
            <!-- 视频分类标签 -->
            <div class="video-type">
              <div class="video-type-vip" v-if="item.payType === 1">VIP</div>
              <div class="video-type-gold" v-if="item.payType === 2">
                <img src="@/assets/imgs/index/gold.png" alt="" />
                {{ changeGold(item.price) }}
              </div>
              <div class="video-type-free" v-if="item.payType === 0">免费</div>
            </div>
            <!-- 视频详情标签 -->
            <div class="vide-detail-type">
              <img v-if="item.showTags === '无码'" src="@/assets/imgs/index/video-ma.svg" alt="" />
              <img v-if="item.showTags === '中文'" src="@/assets/imgs/index/video-zhong.svg" alt="" />
            </div>
            <!-- 时间 -->
            <div class="video-time">
              <div class="item-desc">{{ item.title }}</div>
            </div>
          </DecryptImg>
        </div>
        <!-- 影片描述 -->
        <!-- <div class="item-desc">{{ item.title }}</div> -->
      </div>
    </div>
  </div>
</template>
<script setup>
import { changeGold } from '@/utils/filter'
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const props = defineProps({
  typeID: {
    type: Number,
    default() {
      return 0
    }
  },
  id: {
    type: Number,
    default() {
      return 0
    }
  },
  list: {
    type: Array,
    default() {
      return []
    }
  }
})
const state = reactive({
  color: [
    'linear-gradient(to right, #de8498, #f86b8b)',
    'linear-gradient(to right, #75b49969, #6bf8c7)',
    'linear-gradient(to right, #787057, #404845)',
    'linear-gradient(to right, #cfbcdd, #786ae4)',
    'linear-gradient(to right, #e4ac70, #eeae98)',
    'linear-gradient(to right, #000000, #bfb8b5)'
  ]
})

const toPlay =(item) =>{
  if (this.typeID === 24372) {
    this.$router.push({
      path: `/short_video/play`,
      query: { id: this.id, sort: 0, detailId: item.id, typeTxt: '推荐' }
    })
    return
  }

  if (item.videoType === 1) {
    this.$router.push(`/play/${item.id}`)
  } else if (item.videoType === 2) {
    this.$router.push(`/short_video/play?id=${this.id}&detailId=${item.id}&typeTxt=推荐`)
  }
}
</script>

<style lang="scss" scoped>
.big-list {
  padding-bottom: 0;
  border-radius: 0.05rem;
  color: $cardTitle;
  padding: 0 0.12rem;
  @include flexbox($jc: flex-start, $ai: flex-start, $fd: row, $fw: wrap);

  &-item {
    margin-bottom: 0.3rem;
    width: 100%;
    .item-bg {
      width: 100%;
      height: 100%;
      position: relative;
      border-radius: 0.12rem;
      .bg-position {
        width: 100%;
        padding-top: 57%;
        position: relative;
      }
      .bg-position-img {
        position: absolute;
        top: 0;
        width: 100%;
        height: 100%;
      }
      :deep()  {
        .warpNoPadding {
          border-radius: 0.12rem;
        }
      }
      .video-type {
        position: absolute;
        top: 0;
        left: 0;
        color: $mainTxtColor1;
        font-size: 0.26rem;
        font-weight: 600;
        &-vip {
          width: 0.64rem;
          height: 0.29rem;
          border-bottom-right-radius: 0.12rem;
          border-top-left-radius: 0.12rem;
          text-align: center;
          line-height: 0.29rem;
          background: linear-gradient(to right, #fd9c3a, #fc342d);
        }
        &-gold {
          min-width: 0.68rem;
          height: 0.29rem;
          border-bottom-right-radius: 0.12rem;
          border-top-left-radius: 0.12rem;
          text-align: center;
          line-height: 0.29rem;
          background: linear-gradient(to right, #493afd, #752dfc);
          img {
            width: 0.19rem;
            height: 0.19rem;
            margin-right: 0.02rem;
          }
        }
        &-free {
          width: 0.64rem;
          height: 0.29rem;
          border-bottom-right-radius: 0.4rem;
          border-top-left-radius: 0.12rem;
          text-align: center;
          line-height: 0.29rem;
          background: linear-gradient(to right, #00cd01, #06ac04);
        }
      }
    }
    // 详情标签
    .vide-detail-type {
      position: absolute;
      top: 0;
      right: 0;
      img {
        width: 0.25rem;
        height: 0.25rem;
        margin-top: 0.06rem;
      }
      img:first-child {
        margin-top: 0;
      }
    }
    // 底部时间
    .video-time {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      color: $mainTxtColor1;
      padding-left: 0.16rem;
      font-size: 0.24rem;
      background: rgba($color: #000000, $alpha: 0.6);
      border-bottom-left-radius: 0.12rem;
      border-bottom-right-radius: 0.12rem;
      img {
        width: 0.2rem;
        margin-right: 0.02rem;
      }
    }
    .item-desc {
      @include textoverflow(2);
      font-size: 0.26rem;
      margin-top: 0.1rem;
    }
  }
}
@media screen and (min-width: 750px) {
  .big-list {
    &-item {
      cursor: pointer;
      width: 25%;
      padding: 0 0.1rem;
      .item-bg {
        .video-type {
          font-size: 12px;
          &-vip {
            width: 0.84rem;
            height: 0.38rem;
            line-height: 0.38rem;
          }
          &-gold {
            width: 0.84rem;
            height: 0.38rem;
            line-height: 0.38rem;
            img {
              width: 0.19rem;
              height: 0.19rem;
            }
          }
          &-free {
            width: 0.84rem;
            height: 0.38rem;
            line-height: 0.38rem;
          }
        }
      }
    }
  }
}
</style>
