<template>
  <div class="no-data">
       <img src="@/assets/imgs/search/noData.svg" alt="" />
       {{text}}
  </div>
</template>

<script setup>
const props = defineProps({
  text: {
    type: String,
    default: ""
  }
})

</script>

<style lang="scss" scoped>
.no-data {
  @include flexbox($jc: center, $ai: center, $fd: column, $fw: nowrap);
  font-size: 0.28rem;
  color: #939496;
  min-height: 50vh;
  img {
    width: 3.62rem;
    height: 3.42rem;
    margin-bottom: 1.14rem;
  }
}
</style>
