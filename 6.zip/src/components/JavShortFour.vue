<template>
  <div class="short-four" v-if="state.newList && state.newList.length > 0">
    <div class="short-four-item" v-for="(item, index) in state.newList" :key="index" @click="toPlay(item, index, list)">
      <div class="item-bg">
        <div
          style="
            position: absolute;
            width: 92%;
            top: -0.14rem;
            padding-top: 120%;
            border-radius: 0.16rem;
            overflow: hidden;
            left: 0;
            right: 0;
            margin: auto;
          "
          :style="{
            background: index > 5 ? state.color[index % 6] : state.color[index]
          }"
        ></div>
        <div class="bg-position">
          <DecryptImg :imgURL="item.coverImg" :needPadding="false" class="bg-position-img">
            <!-- 视频分类标签 -->
            <div class="video-type">
              <div class="video-type-vip" v-if="item.payType === 1">VIP</div>
              <div class="video-type-gold" v-if="item.payType === 2">
                <img src="@/assets/imgs/index/gold.png" alt="" />
                {{ changeGold(item.price) }}
              </div>
              <div class="video-type-free" v-if="item.payType === 0">免费</div>
            </div>
            <!-- 视频详情标签 -->
            <div class="vide-detail-type">
              <img v-if="item.showTags === '无码'" src="@/assets/imgs/index/video-ma.svg" alt="" />
              <img v-if="item.showTags === '中文'" src="@/assets/imgs/index/video-zhong.svg" alt="" />
            </div>
            <!-- 短视频标题 -->
            <div class="video-item-desc" v-if="item.videoType === 2">{{ item.title }}</div>

            <div @click.stop="checkItem(item)" v-if="showMask" class="sel-wrap">
              <img v-if="!item.clickMask" src="@/assets/imgs/mine/sel-default.png" alt="" />
              <img v-else src="@/assets/imgs/mine/sel-active.png" alt="" />
            </div>
          </DecryptImg>
        </div>
        <!-- 影片描述 -->
        <div class="item-desc" v-if="item.videoType !== 2">{{ item.title }}</div>
      </div>
    </div>
  </div>
</template>
<script setup>
import { changeGold } from '@/utils/filter'
const emits = defineEmits(["clickItem"])
const router = useRouter()
import { useStore } from 'vuex'
const store = useStore()
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const props = defineProps({
  list: {
    type: Array,
    default: [],
  },
  isLike: {
    type: Boolean,
    default: false
  },
  showMask: {
    type: Boolean,
    default: false
  },
  id: {
    type:Number,
    default: 0
  },
  sort: {
    type:Number,
    default: 0
  },
  typeTxt: {
    type:String,
    default: ''
  },
  tag: {
    type:String,
    default: ''
  },
  coded: {
    type:Number,
    default: 0
  },
  coverType: {
    type:Number,
    default: 0
  }

})

const state = reactive({
  spliceList: [],
  newList: [],
  color: [
    'linear-gradient(to right, #de8498, #f86b8b)',
    'linear-gradient(to right, #75b49969, #6bf8c7)',
    'linear-gradient(to right, #787057, #404845)',
    'linear-gradient(to right, #cfbcdd, #786ae4)',
    'linear-gradient(to right, #e4ac70, #eeae98)',
    'linear-gradient(to right, #000000, #bfb8b5)'
  ]
})

const toPlay = (item, index, list) => {
  if (props.isLike) {
    return router.replace(`/play/${item.id}`)
  }
  // 如果是小视频 则这个列表的数据和id index 都存入vuex
  if (item.videoType === 2) {
    if (props.typeTxt === '观看记录') {
      store.commit('SET_VIDEOLIST', JSON.stringify(list))
      router.push({ path: `/short_video/play`, query: { detailId: item.id, typeTxt: props.typeTxt } })
    } else {
      router.push({
        path: `/short_video/play`,
        query: {
          id: props.id,
          sort: props.sort,
          detailId: item.id,
          typeTxt: props.typeTxt,
          tag: props.tag,
          coded: props.coded,
          coverType: props.coverType
        }
      })
    }
  } else {
    router.push(`/play/${item.id}`)
  }
}
const checkItem = (item) => {
  item.clickMask = !item.clickMask
  if (item.clickMask) {
    if (state.spliceList.length > 0) {
      state.spliceList.map((sItem, index, arr) => {
        if (item.id === sItem.id) {
          arr.splice(index, 1, item.id)
        }
      })
      state.spliceList.push(item.id)
    } else {
      state.spliceList.push(item.id)
    }
  } else {
    state.spliceList.map((sItem, index) => {
      if (item.id === sItem.id) {
        state.spliceList.splice(index, 1)
      }
    })
  }
  emits("clickItem",state.spliceList)
}
watch(() => props.list, (n) => {
  state.newList = JSON.parse(JSON.stringify(n))
},{ immediate: true })

</script>
<style lang="scss" scoped>
.short-four {
  padding: 0 0.12rem;
  padding-top: 0.3rem;
  border-radius: 0.05rem;
  margin-bottom: 0.3rem;
  margin: 0 !important;
  color: #f4ce4e;
  @include flexbox($jc: flex-start, $ai: flex-start, $fd: row, $fw: wrap);
  &-item {   
    width: 50%;
    padding: 0 0.1rem;
    margin-bottom: 0.3rem;
    position: relative;
    .item-bg {
      width: 100%;
      height: 100%;
      position: relative;
      border-radius: 0.12rem;

      .bg-position {
        width: 100%;
        padding-top: 143%;

        position: relative;
      }
      .bg-position-img {
        position: absolute;
        top: 0;
        width: 100%;
        height: 100%;
      }
      :deep()  {
        .warpNoPadding {
          border-radius: 0.12rem;
        }
      }
      .video-type {
        position: absolute;
        top: 0;
        left: 0;
        color: $mainTxtColor1;
        font-size: 0.16rem;
        font-weight: 600;
        &-vip {
          width: 0.64rem;
          height: 0.29rem;
          border-bottom-right-radius: 0.12rem;
          border-top-left-radius: 0.12rem;
          text-align: center;
          line-height: 0.29rem;
          background: linear-gradient(to right, #fd9c3a, #fc342d);
        }
        &-gold {
          min-width: 0.68rem;
          height: 0.29rem;
          border-bottom-right-radius: 0.12rem;
          border-top-left-radius: 0.12rem;
          text-align: center;
          line-height: 0.29rem;
          background: linear-gradient(to right, #493afd, #752dfc);
          @include flexbox($jc: center, $ai: center, $fd: row, $fw: wrap);
          img {
            width: 0.19rem;
            height: 0.19rem;
            margin: 0 0.1rem 0 0;
          }
        }
        &-free {
          width: 0.64rem;
          height: 0.29rem;
          border-bottom-right-radius: 0.12rem;
          border-top-left-radius: 0.12rem;
          text-align: center;
          line-height: 0.29rem;
          background: linear-gradient(to right, #00cd01, #06ac04);
        }
      }
    }
    // 详情标签
    .vide-detail-type {
      position: absolute;
      top: 0;
      right: 0;
      img {
        width: 0.25rem;
        height: 0.25rem;
        margin-top: 0.06rem;
      }
      img:first-child {
        margin-top: 0;
      }
    }
    .video-item-desc {
      position: absolute;
      bottom: 0rem;
      left: 0;
      width: 100%;
      @include textoverflow();
      font-size: 0.2rem;
      color: $cardTitle;
      padding-left: 0.1rem;
      color: $cardTitle;
      background: #302828;
      height: 0.5rem;
      line-height: 0.5rem;
      border-radius: 0 0 0.12rem 0.12rem;
    }
    // 底部时间
    .video-time {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 0.33rem;
      color: $mainTxtColor1;
      line-height: 0.33rem;
      padding-left: 0.16rem;
      font-size: 0.24rem;
      background: rgba($color: #000000, $alpha: 0.6);
      border-bottom-right-radius: 0.12rem;
      border-bottom-left-radius: 0.12rem;
      img {
        width: 0.2rem;
        margin-right: 0.02rem;
      }
    }
    .item-desc {
      color: $mainTxtColor1;
      @include textoverflow(2);
      font-size: 0.26rem;
      margin-top: 0.1rem;
    }
  }
  @media screen and (min-width: 960px) {
    .short-four-item:hover {
      cursor: pointer;
      .item-desc {
        color: #fcca35;
      }
    }
  }  
}
.short-video-time {
  padding-right: 0.16rem;
  @include flexbox($jc: space-between, $ai: center, $fd: row, $fw: nowrap);
  .right-time {
    @include flexbox($jc: flex-end, $ai: center, $fd: row, $fw: nowrap);
    img {
      margin-right: 0.1rem;
    }
  }
}

// 选择视频
.sel-wrap {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  z-index: 9;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: flex-end;
  border-radius: 0.12rem;
  img {
    width: 0.4rem;
    height: 0.4rem;
  }
}

@media screen and (min-width: 750px) {
  .short-four {
    &-item {
      width: 16.666666%;
      .item-bg {
        .video-type {
          font-size: 14px;
          &-vip {
            width: 0.84rem;
            height: 0.38rem;
            line-height: 0.38rem;
          }
          &-gold {
            min-width: 0.68rem;
            height: 0.38rem;
            line-height: 0.38rem;
            img {
              width: 0.19rem;
              height: 0.19rem;
            }
          }
          &-free {
            width: 0.84rem;
            height: 0.38rem;
            line-height: 0.38rem;
          }
        }
      }
    }
  }
}
</style>
