<template>
  <div class="short-six" v-if="list && list.length > 0">
    <template v-for="(item, index) in list">
      <div
        v-if="item.id"
        class="short-six-item"
        style="position: relative"
        :key="'short-six-item' + item.id + '-c' + index"
        @click="toPlay(item, index, list)"
      >
        <div class="item-bg">
          <div
            style="
              position: absolute;
              width: 90%;
              top: -0.1rem;
              padding-top: 120%;
              border-radius: 0.16rem;
              overflow: hidden;
              left: 0;
              right: 0;
              margin: auto;
            "
            :style="{
              background: index > 5 ? state.color[index % 6] : state.color[index]
            }"
          ></div>
          <div class="bg-position">
            <DecryptImg :imgURL="item.coverImg" :needPadding="false" class="bg-position-img">
              <!-- 视频分类标签 -->
              <div class="video-type">
                <div class="video-type-vip" v-if="item.payType === 1">VIP</div>
                <div class="video-type-gold" v-if="item.payType === 2">
                  <img src="@/assets/imgs/index/gold.png" alt="" />
                  {{ changeGold(item.price) }}
                </div>
                <div class="video-type-free" v-if="item.payType === 0">免费</div>
              </div>
              <!-- 视频详情标签 -->
              <div class="vide-detail-type">
                <img v-if="item.showTags === '无码'" src="@/assets/imgs/index/video-ma.svg" alt="" />
                <img v-if="item.showTags === '中文'" src="@/assets/imgs/index/video-zhong.svg" alt="" />
              </div>
              <!-- 时间  -->
              <div class="video-time" v-if="item.watchTimes > 1000">
                <van-icon :name="'fire'" color="#ee0a24" />
                {{numberFilter(item.watchTimes)}}
              </div>
            </DecryptImg>
          </div>
          <!-- 影片描述 -->
          <div class="item-desc">{{ item.title }}</div>
        </div>
      </div>
    </template>
  </div>
</template>
<script setup>
import { defineProps,reactive} from "vue";
import { numberFilter,changeGold } from '@/utils/filter'
import DecryptImg from "@/components/DecryptImg/index.vue"
import { useRouter } from "vue-router";
const router = useRouter()
const props = defineProps({
  list: {
    type: Array,
    default: []
  },
  id: {
    type: Number,
    default() {
      return 0
    }
  },  
  sort: {
    type: Number,
    default() {
      return 0
    }
  },   
  typeTxt: {
    type: String,
    default() {
      return ''
    }
  },  
  typeID: {
    type: Number,
    default() {
      return 0
    }
  }  
});
const state = reactive({
  color: [
    'linear-gradient(to right, #000000, #bfb8b5)',
    'linear-gradient(to right, #000000, #bfb8b5)',
    'linear-gradient(to right, #000000, #bfb8b5)',
    'linear-gradient(to right, #000000, #bfb8b5)',
    'linear-gradient(to right, #000000, #bfb8b5)',
    'linear-gradient(to right, #000000, #bfb8b5)'
  ]
})
const toPlay = async (item, index, list) => {
  if (props.typeID === 24372) {
    router.push({
      path: `/short_video/play`,
      query: { id: props.id, sort: props.sort, detailId: item.id, typeTxt: props.typeTxt }
    })
  }
  // 如果是小视频 则这个列表的数据和id index 都存入vuex
  if (item.videoType === 2) {
    router.push({
      path: `/short_video/play`,
      query: { id: props.id, sort: props.sort, detailId: item.id, typeTxt: props.typeTxt }
    })
  } else {
    router.push(`/play/${item.id}`)
  }  
};


</script>

<style lang="scss" scoped>
.short-six {
  padding: 0.3rem 0.05rem 0 0.05rem;
  border-radius: 0.05rem;
  color: $videoTxtColor;
  box-sizing: border-box;
  @include flexbox($jc: flex-start, $ai: flex-start, $fd: row, $fw: wrap);
  &-item {
    margin-bottom: 0.3rem;
    width: 33.3333%;
    padding: 0 0.06rem;
    .item-bg {
      width: 100%;
      height: 100%;
      position: relative;
      border-radius: 0.12rem;
      .bg-position {
        width: 100%;
        padding-top: 143%;
        position: relative;
      }
      .bg-position-img {
        position: absolute;
        top: 0;
        width: 100%;
        height: 100%;
      }
      :deep()  {
        .warpNoPadding {
          border-radius: 0.12rem;
          img {
            object-position: 100% 50% !important;
          }
        }
      }
      .video-type {
        position: absolute;
        top: -0.03rem;
        left: -0.06rem;
        color: $mainTxtColor1;
        font-size: 0.18rem;
        font-weight: 600;
        transform: scale(0.8);
        &-vip {
          width: 0.64rem;
          height: 0.29rem;
          border-bottom-right-radius: 0.12rem;
          border-top-left-radius: 0.12rem;
          text-align: center;
          line-height: 0.29rem;
          background: linear-gradient(to right, #fd9c3a, #fc342d);
        }
        &-gold {
          min-width: 0.68rem;
          height: 0.29rem;
          line-height: 0.29rem;
          border-bottom-right-radius: 0.12rem;
          border-top-left-radius: 0.12rem;
          text-align: center;
          line-height: 0.29rem;
          background: linear-gradient(to right, #493afd, #752dfc);
          @include flexbox($jc: center, $ai: center, $fd: row, $fw: wrap);
          img {
            width: 0.19rem;
            height: 0.19rem;
            margin: 0 0.1rem 0 0;
          }
        }
        &-free {
          width: 0.64rem;
          height: 0.29rem;
          border-bottom-right-radius: 0.12rem;
          border-top-left-radius: 0.12rem;
          text-align: center;
          line-height: 0.29rem;
          background: linear-gradient(to right, #00cd01, #06ac04);
        }
      }
    }

    // 详情标签
    .vide-detail-type {
      position: absolute;
      top: 0;
      right: 0;
      img {
        width: 0.25rem;
        height: 0.25rem;
        margin-top: 0.06rem;
      }
      img:first-child {
        margin-top: 0;
      }
    }
    // 底部时间
    .video-time {
      position: absolute;
      top: 0;
      right: 0;
      width: 0.82rem;
      height: 0.285rem;
      color: $mainTxtColor1;
      line-height: 0.285rem;
      padding: 0 0.05rem;
      font-weight: 800;
      font-size: 0.16rem;
      text-align: center;
      background: rgba($color: #22232899, $alpha: 0.6);
      border-bottom-left-radius: 0.12rem;
      color: #fcca35;
    }
    .item-desc {
      @include textoverflow(2);
      font-size: 0.22rem;
      margin-top: 0.02rem;
    }
  }
}
@media screen and (min-width: 960px) {
  .short-six {
    padding: 0.3rem 0.2rem 0 0.2rem;
    &-item {
      width: 16.6666%;
      padding: 0 0.1rem;
      .item-bg {
        .video-type {
          font-size: 14px;
          &-vip {
            width: 0.84rem;
            height: 0.38rem;
            line-height: 0.38rem;
          }
          &-gold {
            min-width: 0.68rem;
            height: 0.38rem;
            line-height: 0.38rem;
            img {
              width: 0.19rem;
              height: 0.19rem;
            }
          }
          &-free {
            width: 0.84rem;
            height: 0.38rem;
            line-height: 0.38rem;
          }
        }
      }
      .item-desc {
        font-size: 0.26rem;
      }
    }
    // 底部时间
    .video-time {
      width: auto;
      height: 0.38rem;
      line-height: 0.38rem;
    }
  }
  .short-six-item:hover {
    cursor: pointer;
    .item-desc {
      color: #fcca35;
    }
  }  
}
</style>
