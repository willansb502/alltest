<template>
<div class="popup-box">
  <van-popup
    v-model:show="state.childShowBuy"
    round
    :position="position"
    :style="{ width:width }"
    get-container="#app"
    @closed="closed"
  >
    <div class="title">{{ title }}</div>
    <div class="price">
      {{ price }}
      <img src="@/assets/imgs/index/gold.png" alt="" />
    </div>
    <div class="btn" @click="shoudBuy">{{ price > state.myBalance ? '前往充值' : '确认购买' }}</div>
  </van-popup>
</div>

</template>

<script setup>
import { useStore } from 'vuex'
const store = useStore()
const router = useRouter()
const emits = defineEmits(["shoudBuy","closed"])

const props = defineProps({
  title: {
    type: String,
    default() {
      return '购买此楼凤信息'
    }
  },
  position: {
    type: String,
    default() {
      return 'bottom'
    }
  },
  price: {
    type: Number,
    default() {
      return 0
    }
  },
  showBuy: {
    type: Boolean,
    default() {
      return false
    }
  },

  width: {
    type: String,
    default() {
      return '100%'
    }
  }
})
const state = reactive({
  childShowBuy: false,
  // 获取个人余额
  myBalance:computed(() => store.getters['getUserInfo'].balance / 100)
})
// 购买按钮
const shoudBuy =() =>{
  if (props.price > state.myBalance) {
    router.push('/mine/my-wallet')
  } else {
    emits("shoudBuy")
  }
}
// 关闭弹窗按钮
const closed =() =>{
  emits("closed",false)
}

watch(() => props.showBuy, (n) => {
  state.childShowBuy = n
},{ immediate: true })

</script>

<style lang="scss" scoped>
:deep()  {
  .van-popup {
    background: linear-gradient(to bottom, #e7e3fe, #d6e7fc, #ffffff);
    font-size: 0.32rem;
    text-align: center;
    padding: 0.3rem 0;
  }
  .title{
    color: $mainTxtColor2;
  }
  .price {
    font-size: 0.52rem;
    margin-top: 0.43rem;
    color: #9e1f5a;
    img {
      width: 0.35rem;
      height: 0.35rem;
    }
  }
  .btn {
    border-radius: 0.05rem;
    width: 3.3rem;
    height: 0.74rem;
    background: $btnBg;
    box-shadow: $shadow;
    margin: 0.3rem auto 0 auto;
    line-height: 0.74rem;
  }  
}


</style>
