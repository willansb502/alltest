<template>
  <div class="row-card">
    <div class="short-title">精选短视频</div>

    <div style="overflow: auto; vertical-align: top; overflow-y: hidden" class="home-card-list-scroll">
      <div
        style="font-size: 0.12rem; line-height: 1.2; position: relative; color: #fff; height: auto"
        :style="{
          width: list && list.length * 4.8 + 'rem'
        }"
      >
        <div
          v-for="(shortItem, key) in list"
          :key="'list' + key"
          style="
            position: relative;
            width: 4.8rem;
            padding: 0.02rem 0.12rem;
            display: inline-block;
            vertical-align: top;
            cursor: pointer;
          "
        >
          <div style="padding-top: 137.68%; position: relative">
            <div
              style="
                position: absolute;
                z-index: 1;
                top: 0;
                width: 100%;
                height: 100%;
                display: flex;
                flex-flow: row wrap;
                border-radius: 0.06rem;
                overflow: hidden;
              "
            >
              <template v-if="shortItem">
                <div class="home-pos-w100" @click="() => $router.push(`/short_video/play?detailId=${shortItem.id}`)">
                  <DecryptImg :imgURL="shortItem.coverImg" :needPadding="false" class="item-bg">
                    <HomeVideoTypeTag :payType="shortItem.payType" :price="shortItem.price"></HomeVideoTypeTag>
                    <div class="msg-wrap">
                      <div class="msg-title van-ellipsis">{{ shortItem.title }}</div>
                      <div class="card-play">
                        <img src="@/assets/imgs/index/card-play.svg" alt="" />
                        播放量：{{ numberFilter(shortItem.watchTimes) }}
                      </div>
                    </div>
                  </DecryptImg>
                </div>
              </template>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { numberFilter } from '@/utils/filter'
const HomeVideoTypeTag = defineAsyncComponent(() => import('@/components/Home/videoTypeTag.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const props = defineProps({
  typeTxt: {
    type: String,
    default() {
      return ''
    }
  },
  id: {
    type: Number,
    default() {
      return 0
    }
  },
  list: {
    type: Array,
    default() {
      return []
    }
  },
  titleText: {
    type: String,
    default() {
      return '精选短视频'
    }
  },
  length: {
    type: Number,
    default() {
      return 0
    }
  }
})
const state = reactive({
  width: 0
})


onMounted(() => {
  if (innerWidth < 750) {
    // 计算出轮播图的等分， UI上是横排分成五分，每一项占他的2倍
    state.width = (innerWidth / 4.5) * 2 + 15 * props.length
  } else {
    state.width = (750 / 4.5) * 2 + 15 * props.length
  }
}) 
</script>

<style lang="scss" scoped>
.row-card {
  background: #202123;
  padding: 0.2rem 0.25rem;
  :deep()  {
    .item-bg {
      height: 100%;
    }
  }

  .short-title {
    font-size: 0.28rem;
    color: $mainTxtColor1;
    padding-bottom: 0.2rem;
    font-weight: 600;
  }
  .msg-wrap {
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 1rem;
    padding-top: 0.2rem;
    background-image: linear-gradient(0deg, rgba(0, 0, 0, 0.9), transparent);
    font-size: 0.2rem;
    color: $mainTxtColor1;
    .msg-title {
      width: 90%;
      margin: 0 auto;
    }
    .card-play {
      display: flex;
      align-items: center;
      font-size: 0.2rem;
      padding-left: 0.15rem;
      img {
        width: 0.2rem;
        margin-right: 0.1rem;
      }
    }
  }
  .home-pos-w100 {
    position: absolute;
    top: 0;
    width: 100%;
    height: 100%;
  }
}
</style>
