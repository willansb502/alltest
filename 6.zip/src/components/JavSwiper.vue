<template>
  <div>
    <van-swipe class="my-swipe" :style="{height:height}" ref="cardSwiper" :stop-propagation="true" indicator-color="white" :autoplay="autoplay">
      <van-swipe-item class="item" :class="{ radius: !radius }" v-for="item in imgs" :key="item.id">
        <div class="swiper-slide-inner">
          <DecryptImg
            :hasLazy=false
            :needPadding="false"
            class="resetImg"
            :imgURL="item.cover || item"
            @clickImg="clickImg(item)"
            ref="refImg"
          >
            <div class="sm-video" v-if="shoudPlay">
              <van-icon name="play" color="#fff" size="60" />
            </div>
          </DecryptImg>
        </div>
      </van-swipe-item>
    </van-swipe>
    <!-- <ComPlayVideo ref="playVideo" /> -->
  </div>
</template>

<script setup>
import { handleParamsRouteJump, handleURlParams } from '@/utils/utils_tools'
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
// const ComPlayVideo = defineAsyncComponent(() => import('@/components/Community/video.vue'))
// 向组件传递方法
let refImg = ref(null)
const emits = defineEmits(["clickImg"])
const props = defineProps({
  imgs: {
    type: Array,
    default() {
      return []
    }
  },
  hasSuperiorClick: {
    type: Boolean,
    default() {
      return false
    }
  },    
  height: {
    type: String,
    default() {
      return '3.8rem'
    }
  },
  autoplay: {
    type: Number,
    default() {
      return 1500
    }
  },
  shoudPlay: {
    type: String,
    default() {
      return ''
    }
  },
  radius: {
    type: Boolean,
    default() {
      return true
    }
  }  
})


const clickImg = (item) =>{
  if(props.hasSuperiorClick){
    return emits("clickImg");
  }
  if (props.shoudPlay) {
    const code = handleURlParams(props.shoudPlay)
    handleParamsRouteJump(code)
  } else {
    const code = handleURlParams(item.href)
    handleParamsRouteJump(code)
  }
}

defineExpose({
  refImg
})
</script>

<style lang="scss" scoped>
.my-swipe {
  .item {
    width: 100%;
    padding-top: 11.5%;
    position: relative;
    .swiper-slide-inner {
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      align-items: center;
      display: flex;      
      .resetImg {
        width: 100%;
        position: relative;
        object-fit: contain !important;
        .warp {
          width: auto;
        }
      }
    }
  }
  .radius {
    :deep()  {
      .warp {
        border-radius: 0;
        img {
          object-fit: contain;
          border-radius: 0;
        }
      }
    }
  }
}
.sm-video {
  position: absolute;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  top: 0;
  left: 0;
  background: rgba($color: #000000, $alpha: 0.5);
}
</style>
