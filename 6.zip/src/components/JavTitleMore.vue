<template>
  <div class="look-more" @click="lookMore">
    <div class="left">
      <!-- title -->
      <div class="title">{{ title }}</div>
      <!-- desc -->
      <p class="desc">{{ desc }}</p>
    </div>

    <!-- more -->
    <div class="right">
      <!-- 合集购买按钮 -->
      <div class="price-btn" v-if="price" @click.stop="buyCollection">
        <div class="price">
          {{ changeGold(price) }}
          <img src="@/assets/imgs/index/gold.png" alt="" />
        </div>
        <div class="btn">
          <img
            :src="
              state.detailIsBuy ? getAssetsFile('index/row-suo.svg') : getAssetsFile('index/row-suo-back.svg')
            "
            alt=""
          />
          {{ !state.detailIsBuy ? '解锁' : '已解锁' }}
        </div>
      </div>
      {{ more }}
      <van-icon name="arrow" />
    </div>
    <JavShowBuy
      :title="'购买此合集需支付'"
      :showBuy="state.showBuy"
      :width="'80%'"
      :position="'center'"
      @shoudBuy="shoudBuy"
      @closed="closed"
      :price="changeGold(price)"
    />
  </div>
</template>

<script setup>
import { getAssetsFile } from '@/utils/utils_tools'
import { showToast } from 'vant';
import { changeGold } from '@/utils/filter'
import { gather_buy } from '@/api/home'
import  JavShowBuy from '@/components/JavShowBuy.vue'
const emits = defineEmits(["lookMore"])
const props = defineProps({
  title: {
    type: String,
    default() {
      return '会员专区'
    }
  },
  desc: {
    type: String,
    default() {
      return ''
    }
  },
  price: {
    type: Number,
    default() {
      return 0
    }
  },
  isBuy: {
    type: Boolean,
    default() {
      return false
    }
  },
  noMore: {
    type: Boolean,
    default() {
      return false
    }
  },
  id: {
    type: Number,
    default() {
      return 0
    }
  },
  more: {
    type: String,
    default() {
      return '更多'
    }
  }
})

const state = reactive({
  showBuy: false,
  detailIsBuy: false
})

const lookMore = async () =>{
  emits("lookMore")
}
// 合集购买
const buyCollection = async () =>{
  if (!state.detailIsBuy) {
    state.showBuy = true
  } else {
    emits("lookMore")
  }
}
// 购买弹窗关闭事件
const closed = async (close) =>{
  state.showBuy = close
}

const shoudBuy = async () =>{
  try {
    const res = await gather_buy({
      id: props.id
    })
    if (res.code === 200) {
      state.detailIsBuy = true
      state.showBuy = false
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    return showToast('请求错误，请稍后再试！')
  }
}

onMounted(() => {
  state.detailIsBuy = props.isBuy
})
</script>

<style lang="scss" scoped>
.look-more {
  padding: 0.2rem 0;
  @include flexbox();
  .left {
    display: flex;
    align-items: center;
    font-size: 0.32rem;
    max-width: 90%;

    .title {
      max-width: 100%;
      text-align: center;
      line-height: 0.56rem;
      margin-right: 0.25rem;
      font-weight: 600;
      // border-radius: 0.29rem;
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
      color: transparent;
      background: $txtActive;
      -webkit-background-clip: text;
    }
    .desc {
      font-size: 0.24rem;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      max-width: 3rem;
      margin-right: 0.15rem;
      margin: 0;
      color: #939496;
    }
  }
  .right {
    font-size: 0.25rem;
    min-width: 1rem;
    display: flex;
    align-items: center;
  }
}
.price-btn {
  display: flex;
  align-items: center;
  font-size: 0.25rem;
  margin-right: 0.14rem;
  .price,
  .btn {
    display: flex;
    align-items: center;
    justify-content: center;
    border: 0.01rem solid #9e1f5a;
    padding: 0.05rem 0.12rem;
    white-space: nowrap;
  }

  .price {
    color: #9e1f5a;
    font-weight: 600;
    border-right: none;
    img {
      width: 0.24rem;
      height: 0.24rem;
      margin-left: 0.04rem;
    }
  }
  .btn {
    color: $mainTxtColor1;
    background: linear-gradient(to right, #e13177, #550d3b);
    border-left: none;
    img {
      width: 0.18rem;
      margin-right: 0.03rem;
    }
  }
}
</style>
