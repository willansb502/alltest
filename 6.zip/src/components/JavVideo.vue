<template>
  <div class="md-video-play">
    <div style="padding-top: 57%; position: relative; width: 100%">
      <div id="dplayer" ref="dplayer"></div>
    </div>
    <transition name="van-fade">
      <div v-if="!hasPreview" class="play-tip" @click="skipPreview">跳過預覽</div>
    </transition>
    <slot></slot>
  </div>
</template>
<script setup>
const baseApi = import.meta.env.VITE_APP_baseApi
import HlsJsPlayer from "xgplayer-hls.js";
import $device from "current-device";
const emits = defineEmits(["skipPreview"])
const props = defineProps({
  videoInfo: {
    type: Object,
    default() {
      return {}
    }
  },
  // 预览
  path1: {
    type: String,
    default() {
      return '/api/app/media/m3u8/'
    }
  },
  // 正片
  path2: {
    type: String,
    default() {
      return '/api/app/media/m3u8ex/'
    }
  },
  // 是否可以观看
  hasPreview: {
    type: Boolean,
    default() {
      return false
    }
  }
})

const state = reactive({
  lstTime: 0,
  dp: null,
  newVideoInfo: {},
  token:computed(() => store.state.user.token),
  imgCDN:computed(() => store.getters['cdn']),
  // 播放视频url 如果有预览地址则播放预览地址，没有就播放
  url:computed(() => {
    if (props.hasPreview) {
      return baseApi + props.path2 + state.newVideoInfo.id
    } else {
      return state.newVideoInfo.preVideoUrl
        ? baseApi + props.path1 + state.newVideoInfo.preVideoUrl
        : baseApi + props.path1 + state.newVideoInfo.videoUrl
    }
  })

})

const skipPreview =() =>{
  state.dp.pause()
  emits("skipPreview",!props.hasPreview)
}

const skipVideoPlay =() =>{
  if (!state.dp) {
    state.dp.start(baseApi + props.path2 + state.newVideoInfo.id + `?token=${state.token}`)
  } else {
    state.dp.src = baseApi + props.path2 + state.newVideoInfo.id + `?token=${state.token}`
  }
  state.dp.play()
}

watch(() => props.videoInfo, (n, o) => {
  state.newVideoInfo = n
  if (n && o && n.id !== o.id) {
    state.dp.currentTime = 0
    state.dp.src = state.url + `?token=${state.token}`
  }
},{ immediate: true })

onMounted(async () => {
  if (state.newVideoInfo.id) {
    if (state.dp) {
      state.dp.destroy(true)
      state.dp = null
    }
    state.dp = new HlsJsPlayer({
      id: 'dplayer', //容器ID
      lang: 'zh-cn',
      width: '100%',
      height: '100%',
      // autoplayMuted: true,
      autoplay: true, // 是否自动播放
      volume: 0.3, // 音量
      loop: false, // 循环
      pic: true, // 画中画
      miniplayer: false, // 迷你播放
      controls: true,
      cssFullscreen: false,
      videoInit: true, // 初始化视频首帧
      playbackRate: [0.5, 0.75, 1, 1.5, 2], // 倍速
      lastPlayTime: 0, // 记忆播放，从多少多少秒开始
      lastPlayTimeHideDelay: 5, //提示文字展示时长（单位：秒）
      rotateFullscreen: false, // 使得视频全屏幕时 横屏
      download: false, //设置download控件显示
      airplay: true,
      playsinline: true,
      // isLive: true, //直播场景设置为true
      // useHls: true,
      preloadTime: 10,
      closeVideoClick: false,
      closeVideoDblclick: true,
      // url: "https://admin.yejjhsd.com/api/web/media/m3u8/av/cu/61/vb/ku/0b81c5ce442e41f3b7c0aa9ef50ec72a.m3u8",
      url: state.url + `?token=${state.token}`,
      // 开启弹幕
      danmu: {
        closeDefaultBtn: true
      },
      execBeforePluginsCall: [
        () => {
          console.log('Execute before plugins call')
        }
      ],

      'x5-video-player-type': 'h5', //微信同层播放：
      'x5-video-player-fullscreen': 'true', //微信全屏播放：
      'x5-video-orientation': 'landscape' //微信横竖屏控制
    })
    // 如果预览时长为0，则直接提示
    // state.dp.on('play', () => {
    //   if (danmakuList && danmakuList.length) {
    //     state.dp.danmu.play()
    //     if (!props.hasPreview && !state.newVideoInfo.preVideoUrl) {
    //       if (state.newVideoInfo.preTime === 0) {
    //         state.dp.pause()
    //         emits("skipPreview",!props.hasPreview)
    //       }
    //     }
    //   }
    // })
    // 如果是预告片播放结束给出购买提示
    state.dp.on('ended', () => {
      // 当不可播放完整视频时，如果播放时长大于等于预览市场，给出购买提示
      if (!props.hasPreview && state.newVideoInfo.preVideoUrl) {
        emits("skipPreview",!props.hasPreview)
      }
    })

    // 获取当前视频播放时间
    state.dp.on('timeupdate', () => {
      // 当不可播放完整视频时，如果播放时长大于等于预览市场，给出购买提示
      if (!props.hasPreview && !state.newVideoInfo.preVideoUrl) {
        const curTime = state.dp.currentTime
        if (state.newVideoInfo.preTime !== 0 && curTime >= state.newVideoInfo.preTime) {
          state.dp.currentTime = 0
          state.dp.pause()
          emits("skipPreview",!props.hasPreview)
        }
      }
    })
  }
})
onUnmounted (() => {
  if (state.newVideoInfo.id) {
    if (state.dp) {
      if (state.dp.hls) {
        state.dp.hls.destroy()
      }
      state.dp.src = ''
      state.dp.destroy()
    }
  }
})
</script>

<style lang="scss" scoped>
.md-video-play {
  position: absolute;
  top: 0.9rem;
  left: 50%;
  width: 100%;
  z-index: 1;
  @include transformCenter(-50%, 0);
  #dplayer {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    max-width: $pcMaxWidth;
    background-color: #000;
    left: 50%;
    @include transformCenter(-50%, 0);
  }
  video {
    z-index: 999;
    position: absolute;
    width: 100%;
    height: 100%;
  }
  .play-tip {
    position: absolute;
    right: 0.2rem;
    bottom: 0.5rem;
    width: 1.5rem;
    text-align: center;
    height: 0.5rem;
    line-height: 0.5rem;
    border-radius: 0.2rem;
    background-color: rgb(36, 34, 34);
    color: $mainTxtColor1;
    font-size: 0.22rem;
    z-index: 999;
  }

  :deep()  {
    /**.dplayer-hide {
        .dplayer-controller {
          display: none;
        }
      }**/
    .dplayer-full-in-icon:first-child {
      display: none !important;
    }
    .xgplayer-enter-spinner {
      height: 1rem !important;
      width: 1rem !important;
    }
    .dplayer-full-icon:first-child {
      display: none !important;
    }

    .dplayer-mobile-play {
      display: block !important;
    }
  }
}

@media screen and (min-width: 750px) {
  .play-tip {
    right: 50%;
    bottom: 50%;
  }
}
</style>
