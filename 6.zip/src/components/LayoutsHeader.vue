<template>
  <div class="LayoutsHeader">
    <van-nav-bar
      :fixed="true"
      :title="title"
      @click-left="onClickLeft"
      @click-right="onClickRight"
      left-text=""
      left-arrow
    >
      <template #title>
        <div class="header-title">{{title}}</div>
      </template>

      <template #right>
        <slot name="right"></slot>
      </template>
    </van-nav-bar>
  </div>

<!-- <van-nav-bar
  title="标题"
  right-text="按钮"
  left-arrow
  @click-left="onClickLeft"
  @click-right="onClickRight"
/> -->

</template>

<script setup>
const logoName = import.meta.env.VITE_APP_logoName
const baseUrl = import.meta.env.VITE_APP_baseUrl
const router = useRouter()
const emits = defineEmits(["goBack","onClickRight"])
const props = defineProps({
  hasSuperiorClick: {
    type: Boolean,
    default() {
      return false
    }
  },
  title: {
    type: String,
    default() {
      return ''
    }
  },
  color: {
    type: String,
    default() {
      return '#fff'
    }
  }
})

const clickLogo =() =>{
  router.push('/')
}

const onClickLeft =() =>{
  if (props.hasSuperiorClick) {
    emits("goBack")
  } else {
    router.go(-1)
  }
}

const onClickRight =() =>{
  emits("onClickRight")
}
</script>

<style lang="scss" scoped>
.LayoutsHeader {
  .logo-mini {
    display: none;
  }
  .header-title{
    font-weight: 500;
  }
  :deep()  {
    .van-nav-bar {
      background: $mainBgDeepColor;
      height: 1rem;
      z-index: 11;
      .van-nav-bar__left {
        left: -0.2rem !important;
        .van-icon {
          font-size: 25px;
          color: $mainTxtColor1;
        }
      }
    }
    .van-nav-bar--fixed {
      left: 50%;
      top: 0;
      transform: translateX(-50%);
      //max-width: $pcMaxWidth;
    }
    .van-hairline--bottom::after {
      display: none;
    }
    .van-nav-bar__title {
      color: $mainTxtColor1;
    }
    .van-nav-bar__right {
      color: $mainTxtColor1;
    }
  }
}
@media screen and (min-width: 750px) {
  .LayoutsHeader {
    :deep()  {
      .van-nav-bar {
        // background: transparent;
      }
    }
  }
  .logo-mini {
    display: block !important;
    width: 2rem;
    height: 0.5rem;
    font-size: 0;
    margin-right: 0.3rem;
    img {
      width: 100%;
      height: 100%;
    }
  }
}
</style>
