<template>
  <div class="home-card-list-scroll" style="padding-bottom: 0.1rem">
    <div class="home-card-body-base">
      <div
        v-for="(comicItem, key) in 4"
        :key="'mcItem' + key"
        class="mcItem"
        style="position: relative; display: inline-block; vertical-align: top"
      >
        <p class="name" style="">
          {{ list[key] && list[key].name }}
        </p>
        <div
          v-for="(cmCitem, index) in 4"
          :key="'cmCitem' + index"
          style="
            position: relative;
            padding: 0.12rem 0;
            margin-bottom: 0.13rem;
            width: 100%;
            padding-top: 56.8%;
            border-radius: 0.06rem;
            overflow: hidden;
          "
          :style="{
            background: index > 5 ? color2[index % 6] : color2[index]
          }"
          @click="() => handelVideoPalyerPath(1, list[key]['mediaList'][index])"
        >
          <template v-if="list[key]">
            <div class="home-pos-w100" style="cursor: pointer">
              <div style="width: 50%; height: 100%; display: inline-block">
                <DecryptImg
                  :imgURL="list[key] && list[key].mediaList[index] && list[key].mediaList[index].coverImg"
                  :needPadding="false"
                  class="item-bg"
                >
                </DecryptImg>
              </div>
              <div style="width: 50%; display: inline-block; vertical-align: top; padding: 0.33rem 0.2rem">
                <div class="van-multi-ellipsis--l2 van-hairline--bottom title" style="text-align: center">
                  {{ list[key] && list[key].mediaList[index] && list[key].mediaList[index].title }}
                </div>
                <div
                  class="desc"
                  style="
                    color: #ccc;
                    margin: 0.1rem 0;
                    text-indent: 2em;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    display: -webkit-box;
                    -webkit-line-clamp: 6;
                    -webkit-box-orient: vertical;
                  "
                >
                  {{ list[key] && list[key].mediaList[index] && list[key].mediaList[index].desc }}
                </div>
              </div>
            </div>
          </template>
        </div>
        <div style="text-align: center">
          <van-button
            plain
            hairline
            type="success"
            @click="
              () => {
                $router.push(
                  `/media_detail/${list[key]['id']}?title=${list[key].name}&showType=${list[key].showType}&price=${list[key].price}`
                )
              }
            "
            size="mini"
            style="background-color: transparent"
            >-进入[<span style="color: #f4ce4e; font-size: 0.24rem; font-weight: 600">{{
              list[key] && list[key].name
            }}</span
            >]主题-</van-button
          >
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
const router = useRouter()
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const props = defineProps({
  list: {
    type: Array,
    default: []
  },
  color2: {
    type: Array,
    default: () => [
      'linear-gradient(to right, #0f0b0c, #0f0b0c)',
      'linear-gradient(to right, #0f0b0c, #0f0b0c)',
      'linear-gradient(to right, #0f0b0c, #0f0b0c)',
      'linear-gradient(to right, #0f0b0c, #0f0b0c)',
      'linear-gradient(to right, #0f0b0c, #0f0b0c)',
      'linear-gradient(to right, #000000, #0f0b0c)'
    ]
  }
})

// 处理视频播放类型
const handelVideoPalyerPath =(type, v) =>{
  if (v.id)
    if (type === 1 || type === 2) {
      router.push(`/play/${v.id}`)
    }
}

</script>

<style lang="scss" scoped>
.home-card-list-scroll {
  overflow-x: scroll;
  overflow-y: hidden;
  vertical-align: top;
}
.home-card-body-base {
  width: calc(4 * 4.6rem);
  font-size: 0.22rem;
  line-height: 1.2;
  position: relative;
  color: #fff;
  height: auto;
}
.mcItem {
  padding: 0 0.12rem;
  width: 4.6rem;
  .name {
    padding: 0.2rem 0;
    margin: 0 0;
    font-size: 0.24rem;
    font-weight: 600;
    text-align: center;
  }
}
.home-pos-w100 {
  position: absolute;
  top: 0;
  width: 100%;
  height: 100%;
}
.title {
  font-size: 0.28rem;
}
.desc {
  font-size: 0.2rem;
}
@media screen and (min-width: 750px) {
  .mcItem {
    .name {
      font-size: 0.28rem;
    }
  }
  .desc {
    font-size: 0.26rem;
  }
  .title {
    margin: 0.2rem 0;
    font-size: 0.29rem;
  }
  .home-card-list-scroll {
    overflow: hidden;
  }
  .home-card-body-base {
    width: auto;
  }
  .mcItem {
    width: 25%;
  }
}
</style>