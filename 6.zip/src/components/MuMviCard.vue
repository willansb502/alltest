<template>
  <div class="home-card-list-scroll" style="margin-bottom: 0.2rem">
    <div class="home-card-body-base">
      <div
        v-for="(comicItem, key) in 6"
        :key="'mcItem' + key"
        class="mcItem"
        style="position: relative; display: inline-block; vertical-align: top"
      >
        <p style="padding: 0.2rem 0; margin: 0 0; font-size: 0.32rem; font-weight: 600; text-align: center">
          <!-- {{ list[key] && list[key].name }} -->
        </p>
        <div
          v-for="(cmCitem, index) in 3"
          :key="'cmCitem' + index"
          class="cmCitem"
          style="
            position: relative;
            padding: 0.1rem 0;
            margin-bottom: 0.13rem;
            width: 100%;
            padding-top: 106.8%;
            border-radius: 0.06rem;
            overflow: hidden;
            cursor: pointer;
          "
          :style="{
            background: index > 5 ? color2[index % 6] : color2[index]
          }"
          @click="() => handelVideoPalyerPath('comics', key, index)"
        >
          <template v-if="list[key]">
            <div class="home-pos-w100">
              <div style="width: 100%; height: 100%; display: inline-block">
                <DecryptImg
                  :imgURL="list[key] && list[key].comicsList[index] && list[key].comicsList[index].coverImg"
                  :needPadding="false"
                  class="item-bg"
                >
                </DecryptImg>
              </div>
              <div
                style="
                  position: absolute;
                  bottom: 0;
                  left: 0;
                  z-index: 2;
                  width: 100%;
                  display: inline-block;
                  vertical-align: top;
                  background-color: #000000cf;
                "
              >
                <div class="van-ellipsis van-hairline--bottom title" style="text-align: center">
                  {{ list[key] && list[key].comicsList[index] && list[key].comicsList[index].title }}
                </div>
                <div
                  class="desc"
                  style="
                    color: #ccc;
                    margin: 0.1rem 0;
                    text-indent: 2em;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    display: -webkit-box;
                    -webkit-line-clamp: 2;
                    -webkit-box-orient: vertical;
                  "
                >
                  {{ list[key] && list[key].comicsList[index] && list[key].comicsList[index].desc }}
                </div>
              </div>
            </div>
          </template>
        </div>
        <div style="text-align: center">
          <!-- <van-button
            plain
            hairline
            type="success"
            @click="
              () => {
                $router.push(`/comics/more?id=${list[key].id}&name=${comicItem.name}`)
              }
            "
            size="mini"
            style="background-color: transparent"
            >-进入[<span style="color: #f4ce4e; font-size: 0.24rem; font-weight: 600">{{
              list[key] && list[key].name
            }}</span
            >]主题-</van-button
          > -->
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
const router = useRouter()
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const props = defineProps({
  list: {
    type: Array,
    default: []
  },
  color2: {
    type: Array,
    default: () => [
      'linear-gradient(to right, #000, #0f0b0c)',
      'linear-gradient(to right, #000, #0f0b0c)',
      'linear-gradient(to right, #000, #0f0b0c)',
      'linear-gradient(to right, #000, #0f0b0c)',
      'linear-gradient(to right, #000, #0f0b0c)',
      'linear-gradient(to right, #000, #0f0b0c)'
    ]
  }
})

// 处理视频播放类型
const handelVideoPalyerPath =(type, key, index) =>{
  let item = props.list[key]['comicsList'][index]
  if (item) {
    if (type === 'comics') {
      router.push(`/comics/decial/${item.id}`)
    }
  }
}
</script>

<style lang="scss" scoped>
.home-card-list-scroll {
  overflow-x: scroll;
  overflow-y: hidden;
  vertical-align: top;
}
.home-card-body-base {
  width: calc(4 * 3.6rem);
  font-size: 0.22rem;
  line-height: 1.2;
  position: relative;
  color: #fff;
  height: auto;
}
.mcItem {
  padding: 0 0.12rem;
  width: 3.6rem;
  :deep()  {
    .warpNoPadding {
      border-radius: 0.12rem;
    }
  }
}
.home-pos-w100 {
  position: absolute;
  top: 0;
  width: 100%;
  height: 100%;
}
.cmCitem:hover {
  cursor: pointer;
}
.title {
  font-size: 0.24rem;
}
.desc {
  font-size: 0.2rem;
}
@media screen and (min-width: 750px) {
  .desc {
    font-size: 0.24rem !important;
  }
  .title {
    margin: 0.1rem 0;
    font-size: 0.32rem !important;
  }
  .home-card-list-scroll {
    overflow: hidden;
  }
  .home-card-body-base {
    width: auto;
  }
  .mcItem {
    width: 16.6666%;
  }
}
</style>