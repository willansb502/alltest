<template>
  <div class="home-card-list-scroll">
    <div class="home-six-card-text">
      <div
        v-for="(gcItem, key) in 6"
        :key="'gcItem' + key"
        class="gcItem"
        style="position: relative; display: inline-block; vertical-align: top"
      >
        <div style="text-align: center; margin: 0.2rem 0">
          <van-button
            plain
            hairline
            class="tit-btn van-ellipsis"
            type="success"
            @click="
              () => {
                $router.push(
                  `/media_detail/${list[key].id}?title=${list[key].name}&showType=${list[key].showType}&price=${list[key].price}`
                );
              }
            "
            size="mini"
            style="background-color: transparent; padding: 0.28rem 0.3rem"
            :style="{
              background: key > 5 ? color3[key % 6] : color3[key],
            }"
            >-点击进入【
            <span
              style="color: #f4ce4e; font-size: 0.28rem; font-weight: 600"
              >{{ list[key] && list[key].name ? list[key].name : "" }}</span
            >
            】-</van-button
          >
        </div>
        <div
          v-for="(gcCitem, index) in 5"
          :key="'gcCitem' + index"
          style="
            position: relative;
            margin: 0.12rem 0;
            width: 100%;
            padding-top: 35.8%;
            border-radius: 0.15rem;
            cursor: pointer;
          "
          :style="{
            background: key > 5 ? color3[key % 6] : color3[key],
          }"
        >
          <template v-if="list[key]">
            <div
              class="home-pos-w100"
              @click="
                handelVideoPalyerPath(
                  list[key]['showType'],
                  list[key]['mediaList'][index]
                )
              "
            >
              <div
                style="
                  width: 60%;
                  height: 100%;
                  display: inline-block;
                  position: relative;
                "
              >
                <DecryptImg
                  :imgURL="
                    list[key]['mediaList'][index] &&
                    list[key]['mediaList'][index].coverImg
                  "
                  :needPadding="false"
                  class="bg-position-img"
                >
                </DecryptImg>
              </div>
              <div
                style="
                  position: relative;
                  width: 40%;
                  height: 100%;
                  display: inline-block;
                  vertical-align: top;
                  padding: 0.15rem 0.1rem;
                "
              >
                <div
                  class="van-multi-ellipsis--l2"
                  style="font-size: 0.26rem; padding: 0 0.1rem; color: #fff;font-weight: 600;}"
                >
                  {{
                    list[key]["mediaList"][index] &&
                    list[key]["mediaList"][index].title
                  }}
                </div>
                <div
                  style="padding: 0.05rem 0"
                  v-if="list[key]['mediaList'][index]"
                >
                  <van-tag
                    v-if="list[key]['mediaList'][index].payType === 2"
                    plain
                    style="
                      margin: 0 0.05rem;
                      background: transparent;
                      font-size: 0.14rem;
                    "
                    color="red"
                    >热销</van-tag
                  >
                  <van-tag
                    plain
                    style="
                      margin: 0 0.05rem;
                      background: transparent;
                      font-size: 0.14rem;
                    "
                    v-for="tag in list[key]['mediaList'][index].tags"
                    :key="'t' + tag"
                    color="#f5e311"
                    >{{ tag }}</van-tag
                  >

                  <van-tag
                    plain
                    v-if="
                      list[key]['mediaList'][index] &&
                      list[key]['mediaList'][index].payType === 2
                    "
                    style="
                      margin: 0 0.05rem;
                      background: transparent;
                      font-size: 0.14rem;
                    "
                    >付费观看</van-tag
                  >
                  <van-tag
                    plain
                    v-if="
                      list[key]['mediaList'][index] &&
                      list[key]['mediaList'][index].payType === 1
                    "
                    style="
                      margin: 0 0.05rem;
                      background: transparent;
                      font-size: 0.14rem;
                    "
                    >会员免费</van-tag
                  >
                  <van-tag
                    plain
                    v-if="
                      list[key]['mediaList'][index] &&
                      list[key]['mediaList'][index].payType === 0
                    "
                    style="
                      margin: 0 0.05rem;
                      background: transparent;
                      font-size: 0.14rem;
                    "
                    >免费观看</van-tag
                  >
                </div>
                <div
                  style="
                    position: absolute;
                    bottom: 0.12rem;
                    width: 100%;
                    display: flex;
                    flex-flow: row wrap-reverse;
                    padding: 0.05rem 0.1rem;
                  "
                >
                  <div
                    class=""
                    style="font-size: 0.2rem; flex: 2; color: #ee0957"
                    v-if="list[key]['mediaList'][index]"
                  >
                    <van-icon name="fire-o" color="#ee0957" />{{
                      numberFilter(list[key]["mediaList"][index].likes)
                    }}
                  </div>
                  <div
                    style="flex: 2; font-size: 0.2rem"
                    v-if="list[key]['mediaList'][index]"
                  >
                    <van-icon name="eye-o" />{{
                      numberFilter(list[key]["mediaList"][index].watchTimes)
                    }}
                  </div>
                  <div
                    style="
                      flex: 1;
                      background: red;
                      text-align: center;
                      border-radius: 0.25rem 0 0 0.25rem;
                      padding: 0.02rem 0;
                      font-weight: 600;
                    "
                    :style="{
                      background:
                        index > 5
                          ? color2[color3.length - 1]
                          : color2[list[key].mediaList.length - index - 1],
                    }"
                  >
                    <div
                      v-if="
                        list[key]['mediaList'][index] &&
                        list[key]['mediaList'][index].payType === 1
                      "
                      style="color: #f4ce4e"
                    >
                      VIP
                    </div>
                    <template
                      v-if="
                        list[key]['mediaList'][index] &&
                        list[key]['mediaList'][index].payType === 2
                      "
                    >
                      <van-icon name="gold-coin" color="#f4ce4e" />
                      {{ list[key]["mediaList"][index].price / 100 }}
                    </template>
                    <div
                      v-if="
                        list[key]['mediaList'][index] &&
                        list[key]['mediaList'][index].payType === 0
                      "
                    >
                      免费
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { defineProps } from "vue";
import { numberFilter } from "@/utils/filter"
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const router = useRouter()
const props = defineProps({
  list: {
    type: Array,
    default: [],
  },
  color3: {
    type: Array,
    default: () => [
      "linear-gradient(to right, #000000, #3c3134)",
      "linear-gradient(to right, #000000, #5b6252)",
      "linear-gradient(to right, #000000, #794c57)",
      "linear-gradient(to right, #000000, #1e486bd6)",
      "linear-gradient(to right, #000000, #533c21)",
      "linear-gradient(to right, #000000, #df3962)",
    ],
  },
  color2: {
    type: Array,
    default: () => [
      "linear-gradient(to right, #de8498, #0f0b0c)",
      "linear-gradient(to right, #75b49969, #0f0b0c)",
      "linear-gradient(to right, #787057, #0f0b0c)",
      "linear-gradient(to right, #cfbcdd, #0f0b0c)",
      "linear-gradient(to right, #e4ac70, #0f0b0c)",
      "linear-gradient(to right, #000000, #0f0b0c)",
    ],
  },
});

// 处理视频播放类型
const handelVideoPalyerPath = async (type, v) => {
  if (type === "comics") {
    router.push(`/comics/decial/${v.id}`);
    return;
  }
  if (type === 1 || type === 2) {
    router.push(`/play/${v.id}`);
  }
};
</script>

<style lang="scss" scoped>
.home-card-list-scroll {
  overflow-x: scroll;
  overflow-y: hidden;
  vertical-align: top;
}
.bg-position-img {
  position: absolute;
  top: 0;
  width: 100%;
  height: 100%;
  div {
    position: absolute;
    top: 0;
    left: 0;
    z-index: 0;
    padding: 0.05rem 0.12rem;
    font-size: 0.22rem;
    border-radius: 0 0 0.12rem 0;
  }
}
.home-six-card-text {
  width: calc(6 * 6.2rem);
  font-size: 0.16rem;
  position: relative;
  color: #fff;
  height: auto;
}
.tit-btn {
  width: 5.2rem;
}
.gcItem {
  padding: 0.12rem 0.12rem;
  width: 6.2rem;
}
.home-pos-w100 {
  position: absolute;
  top: 0;
  width: 100%;
  height: 100%;
}
:deep()  {
  .imgNoPadding {
    object-fit: contain !important;
  }
}
@media screen and (min-width: 750px) {
  .home-six-card-text {
    width: calc(4 * 6.2rem);
  }
  .home-six-card-text {
    width: auto;
  }
  .home-card-list-scroll {
    overflow: hidden;
  }
  .gcItem {
    width: 33.333%;
  }
  .tit-btn {
    width: auto;
  }
  .gcItem:nth-of-type(4) {
    display: none !important;
  }
  .gcItem:nth-of-type(5) {
    display: none !important;
  }
  .gcItem:nth-of-type(6) {
    display: none !important;
  }
  .bg-position-img {
    div {
      padding: 0.05rem 0.2rem;
      font-size: 0.42rem;
      border-radius: 0 0 0.12rem 0;
    }
  }
}
</style>