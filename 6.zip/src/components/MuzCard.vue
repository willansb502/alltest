<template>
  <div class="home-card-list-scroll">
    <div class="home-card-body-base"
      :style="{
        width: 'calc('+itemNumber+' * 6rem)'
      }">
      <div
        v-for="(remItem, key) in itemNumber"
        :key="'remItem' + key"
        class="remItem"
        style="position: relative; display: inline-block; vertical-align: top; top: 0.14rem"
      >
        <div
          class="home-card-body-bg"
          :style="{
            background: key > 5 ? color[key % 6] : color[key]
          }"
        ></div>
        <div style="padding-top: 90%; position: relative">
          <div
            class="home-card-body-content"
            style="border-width: 2px; border-style: solid"
            :style="{
              borderColor: key > 5 ? textColor[key % 6] : textColor[key]
            }"
          >
            <template v-if="list[key] && list[key].mediaList">
              <div
                v-for="(item, index) in 6"
                :key="'item' + index"
                style="position: relative; border: 1px #f4ce4e solid"
                :style="{
                  borderColor: key > 5 ? cardColor[key % 6] : cardColor[key],
                  width: compCardType2(list[key]['showType']),
                  paddingTop: compCardType1(list[key]['showType'])
                }"
                @click="handleJump(list[key], list[key]['mediaList'][index], list[key].id)"
              >
                <div
                  class="home-pos-w100"
                  v-if="list[key]['mediaList'][index] && list[key]['mediaList'][index].coverImg"
                >
                  <DecryptImg :imgURL="list[key]['mediaList'][index].coverImg" :needPadding="false" class="item-bg">
                  </DecryptImg>
                </div>
              </div>
            </template>
          </div>
        </div>
        <div
          style="
            margin: 0.2rem 0;
            text-align: center;
            display: flex;
            flex-flow: row nowrap;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            font-size: 0.24rem;
          "
          v-if="list[key]"
          @click="
            () =>
              $router.push(
                `/media_detail/${list[key]['id']}?title=${list[key].name}&showType=${list[key].showType}&price=${list[key].price}`
              )
          "
        >
          <div
            style="width: 80%; display: inline-block; opacity: 100%"
            class="van-ellipsis"
            :style="{ color: key > 5 ? textColor[key % 6] : textColor[key] }"
          >
            {{ list[key] && list[key].desc ? list[key].desc : `站长推荐片单（${key + 1}）` }}
          </div>
          <div style="width: 20%; display: inline-block">
            <van-tag
              plain
              mark
              style="color: #ffe1e1; background: transparent"
              :color="key > 5 ? textColor[key % 6] : textColor[key]"
              >进入</van-tag
            >
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const emits = defineEmits(["clickJumpURL"])
const props = defineProps({
  itemNumber: {
    type: Number,
    default: 6
  },    
  list: {
    type: Array,
    default: []
  },
  cardColor: {
    type: Array,
    default: () => ['#de849842', '#75b49969', '#67614d70', '#cfbcdd42', '#000000', '#cfbcdd42']
  },
  textColor: {
    type: Array,
    default: () => ['#dcb68c', '#74a997', '#787057', '#cfbcdd', '#e4ac70', '#bfb8b5']
  },
  color: {
    type: Array,
    default: () => [
      'linear-gradient(to right, #dcb68c, #e6dca8)',
      'linear-gradient(to right, #75b49969, #74a997)',
      'linear-gradient(to right, #787057, #404845)',
      'linear-gradient(to right, #cfbcdd, #151518)',
      'linear-gradient(to right, #e4ac70, #eeae98)',
      'linear-gradient(to right, #000000, #bfb8b5)'
    ]
  }
})

// 展示方式  1:横版(三排两列)长视频大横排 2:横版(大列表) 3:竖版(两排三列)短视频四宫格 4:竖版(三排两列)短视频六宫格
const compCardType1 =(showType) =>{
  switch (+showType) {
    case 1:
      return '29.9%'
    case 2:
      return '29.9%'
    case 3:
      return '45%'
    case 4:
      return '45%'
    default:
      return '45%'
  }
}

const compCardType2 =(showType) =>{
  switch (+showType) {
    case 1:
      return '50%'
    case 2:
      return '50%'
    case 3:
      return '33.3333%'
    case 4:
      return '33.3333%'
    default:
      return '33.3333%'
  }
}

const handleJump =(key, i, id) =>{
  emits("clickJumpURL",{ i, id })
}

</script>

<style lang="scss" scoped>
.home-card-list-scroll {
  overflow-x: scroll;
  overflow-y: hidden;
  vertical-align: top;
}
.remItem {
  width: 6rem;
  padding: 0.02rem 0.12rem;
}
.home-pos-w100 {
  position: absolute;
  top: 0;
  width: 100%;
  height: 100%;
}
.home-card-body-base {
  width: calc(6 * 6rem);
  font-size: 0.22rem;
  line-height: 1.2;
  position: relative;
  color: #fff;
  height: auto;
}
.home-card-body-bg {
  position: absolute;
  width: 89%;
  top: -0.08rem;
  padding-top: 90%;
  border-radius: 0.16rem;
  overflow: hidden;
  left: 0;
  right: 0;
  margin: auto;
}
.home-card-body-content {
  position: absolute;
  z-index: 1;
  top: 0;
  width: 100%;
  display: flex;
  flex-flow: row wrap;
  border-radius: 0.16rem;
  overflow: hidden;
}

.home-card-body-content:hover {
  cursor: pointer !important;
}

@media screen and (min-width: 750px) {
  .home-card-body-base {
    width: auto !important;
  }
  .home-card-list-scroll {
    overflow: hidden;
  }
  .remItem {
    width: 25%;
  }

  .remItem:nth-of-type(5) {
    display: none !important;
  }
  .remItem:nth-of-type(6) {
    display: none !important;
  }
}
</style>