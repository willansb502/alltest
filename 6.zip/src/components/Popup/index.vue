<template>
  <div class="popup-list">
    <van-popup 
    @click-overlay="fn_close"  
    class="popup-round" 
    v-model:show="state.popupMsg.show" 
    get-container="body" 
    :position="state.popupMsg.position" round>
      <!--small-text 提示-->
      <div class="small-text"  v-if="state.popupMsg.type=='small-text'">
        <div class="title">{{state.popupMsg.title}}</div>
        <div class="text">
          {{state.popupMsg.content}}
        </div>
        <div class="btn-wrap">
          <div @click="fn_close" >取消</div>
          <div   @click="fn_ok(true)">确定</div>
        </div>
      </div>      
      <!--text 余额不足 -->
      <div class="item-text"  v-if="state.popupMsg.type=='text'">
        <div class="title">{{state.popupMsg.title}}</div>
        <div class="content">{{state.popupMsg.content}}</div>
        <div class="btn-wrap">
          <div class="ok" @click="fn_ok(true)" v-if="state.popupMsg.ok">{{state.popupMsg.ok}}</div>
          <div class="cancel" @click="fn_close" v-if="state.popupMsg.cancel">{{state.popupMsg.cancel}}</div>
        </div>
      </div>
      <!--coin 金币 -->
      <div class="item-text"  v-if="state.popupMsg.type=='coin'">
        <div class="title">{{state.popupMsg.title}}</div>
        <div class="content coin">
          <img src="@/assets/imgs/index/gold.png" alt="">{{state.popupMsg.content}}
        </div>
        <div class="btn-wrap">
          <div class="ok" @click="fn_ok(true)" v-if="state.popupMsg.ok">{{state.popupMsg.ok}}</div>
          <div class="cancel" @click="fn_close" v-if="state.popupMsg.cancel">{{state.popupMsg.cancel}}</div>
        </div>
      </div>      
    </van-popup>      
  </div>
</template>

<script setup>
const emits = defineEmits(["closePopup"])
const props = defineProps({
  list: {
    type: Array,
    default: [],
  },
  title: {
    type: String,
    default: "标题"
  }
})

const state = reactive({
  popupMsg: {
    show:false,
    title:'',
    content:'',
    type:'text',
    cancel:'',
    ok:'',   
    position:'bottom',
    cb:null  
  }
})

//取消、关闭
const fn_close = () => {
  state.popupMsg.show=false;
  setTimeout(()=>{
    emits("closePopup")
  },500);
}
//确定
const fn_ok = (status) => {
  state.popupMsg.cb(status);
}

</script>

<style lang="scss" scoped>
  .popup-round{
    background-color: $mainBgColor;
    max-width: $pcMaxWidth;
    left: auto;
    border-top-left-radius: 0.8rem;
    border-top-right-radius: 0.8rem;
  }
  .small-text{
      text-align: center;
      background: #f7f6fa;
      width: 3.7rem;
      display: flex;
      justify-content: space-between;
      flex-direction: column;
      .title{
        padding: 0.2rem 0;
      }
      .text{
        box-shadow: 0 0.06rem 0.1rem rgba($color: #000, $alpha: 0.1) inset;
        padding: 0.2rem;
        padding-bottom: 0.2rem;
        opacity: 0.7;
        color: #6a6a6a;
      }
      .btn-wrap{
        padding: 0.2rem 0;
        display: flex;
        justify-content: center;
        box-shadow: 0.06rem 0 0.1rem rgba($color: #000, $alpha: 0.1);
        div{
          border-radius: 0.1rem;
          border:1px solid $mainTxtColor1;
          background: $mainBgColor;
          @include box-shadow-all;
          color: #f09035;
          padding: 0.05rem 0.1rem;
          &:first-child{
            background: transparent;
            border:1px solid #eee;
            margin-right: 0.2rem;
          }
        }
      }
  }
  .item-text{
    padding: 0.5rem 0.35rem;
    text-align: center;
    .title{
      font-size: 0.36rem;
      color: #e02020;
    }
    .content{
      font-size: 0.28rem;
      font-size: #6a6a6a;
      padding:0.4rem 0 ;
      &.coin{
        @include flex-center;
        font-size: 0.5rem;
        img{
          width: 0.4rem;
          height: 0.4rem;
          margin-right: 0.1rem;
        }
      }
    }
    .btn-wrap{
      display: flex;
      div{
        height: 0.78rem;
        line-height: 0.78rem;
        border-radius: 0.39rem;
        font-size: 0.32rem;
        color: $mainTxtColor1;
        flex: 1;
      }
      .ok{
        background: $btnBg;
      }
      .cancel{
        margin-left: 0.2rem;
        background: #777777;
      }    
    }    
  }  
</style>
