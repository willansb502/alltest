<template>
  <div class="pull-container">
    <van-pull-refresh
      ref="backup"
      v-model="childRefreshing"
      @refresh="onRefresh"
      :disabled="$route.meta.isCloseRefresh || disabled"
    >
      <slot name="top"></slot>
      <van-list
        v-model:loading="childLoading"
        :finished="finished"
        :finished-text="finishedText"
        @load="onLoad"
        :immediate-check="false"
        v-if="skeleton"
      >
        <slot></slot>
      </van-list>
    </van-pull-refresh>
  </div>
</template>
<script setup>
const emits = defineEmits(["moreData","refreshData"])
const props = defineProps({
  finishedText: {
    Type: String,
    default() {
      return '没有更多了'
    }
  },    
  loading: {
    Type: Boolean,
    default() {
      return false
    }
  },
  refreshing: {
    Type: Boolean,
    default() {
      return false
    }
  },
  finished: {
    Type: Boolean,
    default() {
      return false
    }
  },
  skeleton: {
    Type: Boolean,
    default() {
      return true
    }
  }
})

const state = reactive({
  isShowGoback: false,
  scrollTop: 0,
  childLoading: false,
  childRefreshing: false,
  disabled: false
})
const onLoad =() =>{
  emit('moreData', state.childLoading)
}
const onRefresh =() =>{
  // 重新加载数据
  emit('refreshData', state.childRefreshing)
}


watch(() => props.loading, (n, o) => {
  state.childLoading = n
},{ immediate: true })

watch(() => props.refreshing, (n, o) => {
  state.childRefreshing = n
},{ immediate: true })

</script>

<style scoped lang="scss">
.pull-container {
  position: relative;
}
</style>
