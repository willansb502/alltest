<template>
  <div class="sort-play" :class="{ 'home-page-video-style': homeSvParams.nowPosit == '首页短视频' }">
    <LayoutsHeader v-if="homeSvParams.nowPosit != '首页短视频'" :title="''" />
    <!-- 购买弹窗 -->
    <div class="buy-porp" v-if="state.buyPorp">
      <!-- 非vip -->
      <div class="no-times" v-if="state.showTypeNum === 1">
        <p>免费观看次数已用完</p>
        <p class="sub-txt">您今日的观看次数已经全部用完,开通会员可以无限畅看</p>
        <div class="btn">
          <span @click.stop="$router.push('/vip')">开通会员</span>
          <span @click.stop="state.buyPorp = false">忍着不看</span>
        </div>
        <div class="tip-txt">
          分享成功可以免费获得3天会员哦 <i @click.stop="$router.push('/mine/share')">去分享 -</i>
        </div>
      </div>
      <!-- 付费观看 -->
      <div class="no-times coin-wrap" v-show="state.showTypeNum === 2&&state.code != 6018">
        <p> 
          影片《{{ state.itemVideoInfo.title }}》<br>需要支付<strong style="color: red; padding: 0 0.2rem">{{
            changeGold(state.itemVideoInfo.price) 
          }}</strong
          >金币观看
        </p>
        <div class="btn" >
          <span @click="payBtnFn">确认支付</span>
          <span @click.stop="state.buyPorp = false">忍着不看</span>
        </div>
      </div>
      <!-- 支付确认 -->
      <div class="no-times" v-show="state.code === 6018">
        <p>您的余额不足以支付本片</p>
        <div class="btn">
          <span @click.stop="$router.push('/mine/my-wallet')">去充值</span>
          <span @click.stop="state.buyPorp = false">忍着不看</span>
        </div>
      </div>
    </div>
    <!-- 视频轮播  :stop-propagation="false"-->
    <van-swipe
      vertical
      ref="swipe"
      style="width: 100%"
      :style="{ height: state.height + 'px' }"
      :touchable="true"
      class="my-swipe"
      :loop="state.hasChanngeSwiper"
      :duration="600"
      indicator-color="white"
      @change="swiperChage"
      :initial-swipe="0"
      :show-indicators="false"
      :stop-propagation="false"
    >


      <van-swipe-item
        class="A"
        style="width: 100%; position: relative"
      >
        <div class="play-circle-warp"
          @touchmove="e => touchmove(e, 0, 'stop')"
          @touchend="e => touchend(e, 0)"        
        >
          <van-icon
            v-if="!state.videoElObject['xgPlayerA']['play'] && state.videoElObject['xgPlayerA']['canplay']"
            name="play-circle-o"
            class="play-circle-o"
            color="#fff"
          />
        </div>
        <video
          :autoplay="state.isFirst"
          volume="0.65"
          ref="xgPlayerA"
          class="video"
          playsinline="true"
          webkit-playsinline="true"
          x5-playsinline="true"
          x5-video-player-type="h5"
          x5-video-player-fullscreen="true"
          x5-video-orientation="landscape"
          airplay="true"
          webkit-airplay="true"
          preload="auto"
          x-webkit-airplay="allow"
          controlsList="nofullscreen nodownload noremoteplayback noplaybackrate"
          disablepictureinpicture
          :poster="state.ABase64 ? state.ABase64 : undefined"
        ></video>
        <div v-show="state.videoElObject['xgPlayerA']['playing']&&!(!state.videoElObject['xgPlayerA']['play'] && state.videoElObject['xgPlayerA']['canplay'])" class="xgplayer-loading">
        </div>
        <div class="right-icon"              

              >
          <div class="right-icon-header">
            <DecryptImg
              @click="clickImg(state.AData)"
              v-if="state.AData && state.AData.publisher !== undefined"
              :imgURL="state.AData && state.AData.publisher !== undefined ? state.AData.publisher.avatar : ''"
            >
            </DecryptImg>
            <img
              class="add-icon"
              src="@/assets/imgs/short-video/addCare.png"
              alt=""
              v-if="state.AData && state.AData.publisher !== undefined && !state.AData.publisher.isFollow"
              @click.stop="careUser(state.AData.publisher)"
            />
          </div>
          <div class="right-icon-likes" v-if="state.AData">
            <van-icon @click.stop="addLike(state.AData)" size="30" :color="state.AData.isLike ? 'red' : '#ffffff'" :name="'like'" />
            <span>{{ numberFilter(state.AData.likes) }}</span>
          </div>
          <div @click.stop="showComment(state.AData)" class="right-icon-comment" v-if="state.AData">
            <van-icon color="#fff" size="30" :name="getAssetsFile('vertical.png')" />
            <span> {{ numberFilter(state.AData.comments) }}</span>
          </div>
          <div class="right-icon-share" @click.stop="clickShare(2)">
            <van-icon name="share" size="30" color="#fff" />
            <span>分享</span>
          </div>
        </div>
        <div class="video-info">
          <!-- 标签 -->
          <div class="tags-list">
            <template v-if="state.AData && state.AData.tags">
              <span @click.stop="toTagList(sitem)" v-for="sitem in state.AData.tags" :key="sitem">#{{ sitem }}</span>
            </template>
          </div>
          <!-- 付费按钮 -->
          <div class="video-title" v-if="state.AData && state.AData.title">{{ state.AData.title }}</div>
          <div class="publisher-info" v-if="state.showTypeNum">
            <div class="pay-btn"  @click.stop="showBuyPorp()">
              <span v-if="state.AData.price !== 0" class="price">
                {{ changeGold(state.AData.price) }}
                <img src="@/assets/imgs/index/gold.png" alt="" />
                观看完整视频
              </span>
              <span v-else> VIP观看完整视频</span>
            </div>
          </div>
        </div>
      </van-swipe-item>
      <van-swipe-item
        class="B"
        style="width: 100%; position: relative"
      >
        <div
          class="play-circle-warp"
          @touchmove="e => touchmove(e, 1, 'stop')"
          @touchend="e => touchend(e, 1)"          
        >
          <van-icon
            v-if="!state.videoElObject['xgPlayerB']['play'] && state.videoElObject['xgPlayerB']['canplay']"
            name="play-circle-o"
            class="play-circle-o"
            color="#fff"
          />
        </div>
        <video
          volume="0.65"
          class="video"
          ref="xgPlayerB"
          playsinline="true"
          webkit-playsinline="true"
          x5-playsinline="true"
          x5-video-player-type="h5"
          x5-video-player-fullscreen="true"
          x5-video-orientation="landscape"
          airplay="true"
          webkit-airplay="true"
          preload="auto"
          x-webkit-airplay="allow"
          controlsList="nofullscreen nodownload noremoteplayback noplaybackrate"
          disablepictureinpicture
          :poster="state.BBase64 ? state.BBase64 : undefined"
        ></video>
        <div v-show="state.videoElObject['xgPlayerB']['playing'] &&!(!state.videoElObject['xgPlayerB']['play'] && state.videoElObject['xgPlayerB']['canplay'])" class="xgplayer-loading">
        </div>        
        <div class="right-icon"
              >
          <div class="right-icon-header">
            <DecryptImg
              @click="clickImg(state.BData)"
              v-if="state.BData && state.BData.publisher !== undefined"
              :imgURL="state.BData && state.BData.publisher !== undefined ? state.BData.publisher.avatar : ''"
            >
            </DecryptImg>
            <img
              class="add-icon"
              src="@/assets/imgs/short-video/addCare.png"
              alt=""
              v-if="state.BData && state.BData.publisher !== undefined && !state.BData.publisher.isFollow"
              @click.stop="careUser(state.BData.publisher)"
            />
          </div>
          <div class="right-icon-likes" v-if="state.BData">
            <van-icon @click.stop="addLike(state.BData)" size="30" :color="state.BData.isLike ? 'red' : '#ffffff'" :name="'like'" />
            <span>{{ state.BData.likes  }}</span>
          </div>
          <div @click.stop="showComment(state.BData)" class="right-icon-comment" v-if="state.BData">
            <van-icon color="#fff" size="30" :name="getAssetsFile('vertical.png')" />
            <span> {{ numberFilter(state.BData.comments) }}</span>
          </div>
          <div class="right-icon-share" @click.stop="clickShare(2)">
            <van-icon name="share" size="30" color="#fff" />
            <span>分享</span>
          </div>
        </div>
        <div class="video-info">
          <!-- 标签 -->
          <div class="tags-list">
            <template v-if="state.BData && state.BData.tags">
              <span @click.stop="toTagList(sitem)" v-for="sitem in state.BData.tags" :key="sitem">#{{ sitem }}</span>
            </template>
          </div>
          <div class="video-title" v-if="state.BData && state.BData.title">{{ state.BData.title }}</div>
          <!-- 付费按钮 -->
          <div class="publisher-info" v-if="state.showTypeNum">
            <div class="pay-btn"  @click.stop="showBuyPorp()">
              <div v-if="state.BData.price !== 0" class="price">
                {{ changeGold(state.BData.price) }}
                <img src="@/assets/imgs/index/gold.png" alt="" />
                观看完整视频
              </div>
              <span v-else> VIP观看完整视频</span>
            </div>
          </div>
        </div>
      </van-swipe-item>
      <van-swipe-item
        class="C"
        style="width: 100%; position: relative"
      >
        <div
          class="play-circle-warp"
          @touchmove="e => touchmove(e, 2, 'stop')"
          @touchend="e => touchend(e, 2)"          
        >
          <van-icon
            v-if="!state.videoElObject['xgPlayerC']['play'] && state.videoElObject['xgPlayerC']['canplay']"
            name="play-circle-o"
            class="play-circle-o"
            color="#fff"
          />
        </div>
        <!-- :src="isSafari ? '/api/app/media/m3u8/' + state.CData.videoUrl : undefined" -->
        <video
          volume="0.65"
          class="video"
          ref="xgPlayerC"
          playsinline="true"
          webkit-playsinline="true"
          x5-playsinline="true"
          x5-video-player-type="h5"
          x5-video-player-fullscreen="true"
          x5-video-orientation="landscape"
          airplay="true"
          webkit-airplay="true"
          preload="auto"
          x-webkit-airplay="allow"
          controlsList="nofullscreen nodownload noremoteplayback noplaybackrate"
          disablepictureinpicture
          :poster="state.CBase64 ? state.CBase64 : undefined"
        ></video>
        <div v-show="state.videoElObject['xgPlayerC']['playing']&&!(!state.videoElObject['xgPlayerC']['play'] && state.videoElObject['xgPlayerC']['canplay'])" class="xgplayer-loading">
        </div>     
        <div class="right-icon"              
              >
          <div class="right-icon-header">
            <DecryptImg
              @click="clickImg(state.CData)"
              v-if="state.CData && state.CData.publisher !== undefined"
              :imgURL="state.CData && state.CData.publisher !== undefined ? state.CData.publisher.avatar : ''"
            >
            </DecryptImg>
            <!-- -->
            <img
              class="add-icon"
              src="@/assets/imgs/short-video/addCare.png"
              alt=""
              v-if="state.CData && state.CData.publisher !== undefined && !state.CData.publisher.isFollow"
              @click.stop="careUser(state.CData.publisher)"
            />
          </div>
          <div class="right-icon-likes" v-if="state.CData">
            <van-icon @click.stop="addLike(state.CData)" size="30" :color="state.CData.isLike ? 'red' : '#ffffff'" :name="'like'" />
            <span>{{ numberFilter(state.CData.likes) }}</span>
          </div>
          <div @click.stop="showComment(state.CData)" class="right-icon-comment" v-if="state.CData">
            <van-icon color="#fff" size="30" :name="getAssetsFile('vertical.png')" />
            <span> {{ numberFilter(state.CData.comments) }}</span>
          </div>
          <div class="right-icon-share" @click.stop="clickShare(2)">
            <van-icon name="share" size="30" color="#fff" />
            <span>分享</span>
          </div>
        </div>
        <div class="video-info">
          <!-- 标签 -->
          <div class="tags-list">
            <template v-if="state.CData && state.CData.tags">
              <span @click.stop="toTagList(sitem)" v-for="sitem in state.CData.tags" :key="sitem">#{{ sitem }}</span>
            </template>

          </div>

          <div class="video-title" v-if="state.CData && state.CData.title">{{ state.CData.title }}</div>
          <!-- 付费按钮 -->
          <div class="publisher-info" v-if="state.showTypeNum">
            <div class="pay-btn"  @click.stop="showBuyPorp()">
              <div v-if="state.CData.price !== 0" class="price">
                {{ changeGold(state.CData.price) }}
                <img src="@/assets/imgs/index/gold.png" alt="" />
                观看完整视频
              </div>
              <span v-else> VIP观看完整视频</span>
            </div>
          </div>
        </div>
      </van-swipe-item>
      <van-swipe-item
        class="D"
        style="width: 100%; position: relative"
      >
        <div
          class="play-circle-warp"
          @touchmove="e => touchmove(e, 3, 'stop')"
          @touchend="e => touchend(e, 3)"          
        >
          <van-icon
            v-if="!state.videoElObject['xgPlayerD']['play'] && state.videoElObject['xgPlayerD']['canplay']"
            name="play-circle-o"
            class="play-circle-o"
            color="#fff"
          />
        </div>
        <video
          class="video"
          ref="xgPlayerD"
          volume="0.65"
          playsinline="true"
          webkit-playsinline="true"
          x5-playsinline="true"
          x5-video-player-type="h5"
          x5-video-player-fullscreen="true"
          x5-video-orientation="landscape"
          airplay="true"
          webkit-airplay="true"
          preload="auto"
          x-webkit-airplay="allow"
          controlsList="nofullscreen nodownload noremoteplayback noplaybackrate"
          disablepictureinpicture
          :poster="state.DBase64 ? state.DBase64 : undefined"
        ></video>
        <div v-show="state.videoElObject['xgPlayerD']['playing'] &&!(!state.videoElObject['xgPlayerD']['play'] && state.videoElObject['xgPlayerD']['canplay'])" class="xgplayer-loading">
        </div>  
        <div class="right-icon"              
              >
          <div class="right-icon-header">
            <DecryptImg
              @click="clickImg(state.DData)"
              v-if="state.DData && state.DData.publisher !== undefined"
              :imgURL="state.DData && state.DData.publisher !== undefined ? state.DData.publisher.avatar : ''"
            >
            </DecryptImg>
            <!-- -->
            <img
              class="add-icon"
              src="@/assets/imgs/short-video/addCare.png"
              alt=""
              v-if="state.DData && state.DData.publisher !== undefined && !state.DData.publisher.isFollow"
              @click.stop="careUser(state.DData.publisher)"
            />
          </div>
          <div class="right-icon-likes" v-if="state.DData">
            <van-icon @click.stop="addLike(state.DData)" size="30" :color="state.DData.isLike ? 'red' : '#ffffff'" :name="'like'" />
            <span>{{ numberFilter(state.DData.likes)  }}</span>
          </div>
          <div @click.stop="showComment(state.DData)" class="right-icon-comment" v-if="state.DData">
            <van-icon color="#fff" size="30" :name="getAssetsFile('vertical.png')" />
            <span> {{ numberFilter(state.DData.comments) }}</span>
          </div>
          <div class="right-icon-share" @click.stop="clickShare(2)">
            <van-icon name="share" size="30" color="#fff" />
            <span>分享</span>
          </div>
        </div>
        <div class="video-info">
          <!-- 标签 -->
          <div class="tags-list">
            <template v-if="state.DData && state.DData.tags">
              <span @click.stop="toTagList(sitem)" v-for="sitem in state.DData.tags" :key="sitem">#{{ sitem }}</span>
            </template>

          </div>

          <div class="video-title" v-if="state.DData && state.DData.title">{{ state.DData.title }}</div>
          <!-- 付费按钮 -->
          <div class="publisher-info" v-if="state.showTypeNum">
            <div class="pay-btn"  @click.stop="showBuyPorp()">
              <div v-if="state.DData.price !== 0" class="price">
                {{ changeGold(state.DData.price) }}
                <img src="@/assets/imgs/index/gold.png" alt="" />
                观看完整视频
              </div>
              <span v-else> VIP观看完整视频</span>
            </div>
          </div>
        </div>
      </van-swipe-item>
    </van-swipe>
    <BlShare
      :isShow="state.showShare"
      @select="shareBtn"
      @cancel="
        e => {
          state.showShare = e
        }
      "
    />
    <JavComment
      :showComment="state.show"
      :objectype="1"
      @close="close"
      @addComment="addComment"
      :publisher="state.itemVideoInfo.publisher.id"
      :objectId="state.itemVideoInfo.id"
    />
  </div>
</template>
<script setup>
import useClipboard from 'vue-clipboard3'
const { toClipboard } = useClipboard()
import { getAssetsFile } from '@/utils/utils_tools'
import { showToast,showNotify } from 'vant'
import { useStore } from 'vuex'
const store = useStore()
const router = useRouter()
const route = useRoute()
let swipe = ref(null)
let xgPlayerA = ref(null)
let xgPlayerB = ref(null)
let xgPlayerC = ref(null)
let xgPlayerD = ref(null)


const baseApi = import.meta.env.VITE_APP_baseApi
import { video_play, video_pay } from '@/api/play'
import { collect, care_add, homeRecommendList, homeFocusList } from '@/api/home'
import { media_details, index_home } from '@/api/home' // topic详情列表
import { collect_list } from '@/api/user' // 收藏记录列表
import { pay_history } from '@/api/user' // 购买记录列表
import { user_media } from '@/api/community' // up小视频列表
import { search, tag_detail } from '@/api/search' // 搜索视频列表// 分类标签列表
import { handleVerAutoImg } from '@/utils/utils_tools'
import { numberFilter ,changeGold} from '@/utils/filter'
import { nextTick } from 'vue'
const JavComment = defineAsyncComponent(() => import('@/components/JavComment.vue'))
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const BlShare = defineAsyncComponent(() => import('@/components/BlShare/index.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))

const props = defineProps({
  homeSvParams: {
    type: Object,
    default() {
      return {
        nowPosit: ''
      }
    }
  }
})
let isClick = true;
const state = reactive({
  // 第一次点击屏幕
  isFirstClickSwiper: true,
  // 是否存在改变swiper index
  hasChanngeSwiper: false,
  // 是否是第一次
  isFirst: true,
  // swiper height
  height: null,
  // 用于管理视频的数据对象
  videoElObject: {
    xgPlayerA: {
      play: false,
      canplay: false,
      playing: true
    },
    xgPlayerB: {
      play: false,
      canplay: false,
      playing: true
    },
    xgPlayerC: {
      play: false,
      canplay: false,
      playing: true
    },
    xgPlayerD: {
      play: false,
      canplay: false,
      playing: true
    }
  },
  // HLS对象
  xgObject: {
    xgPlayerA: null,
    xgPlayerB: null,
    xgPlayerC: null,
    xgPlayerD: null
  },
  swipeDirection: null,
  isSupported: false,
  pageNum: 1,
  pageSize: 100,
  list: [],
  code: 0, // 视频code
  swiperIndex: 0,
  dataIndex: 0,
  hasPre: false,
  buyPorp: false, // 购买弹窗
  showTypeNum:0,//当前显示类型1.vip 2.金币 0.免费 
  itemVideoInfo: {
    publisher: {}
  }, //当前播放视频信息
  show: false, // 评论弹窗控制
  showShare: false, //分享弹窗
  ABase64: '',
  BBase64: '',
  CBase64: '',
  DBase64: '',
  AData: {},
  BData: {},
  CData: {},
  DData: {},
  isMobile_pc:computed(() => {
    let flag = navigator.userAgent.match(
      /(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i
    )
    return flag
  }),
  isSafari:computed(() => /Safari/.test(navigator.userAgent) && !/Chrome/.test(navigator.userAgent)),
  cdn:computed(() => store.getters['cdn']),
  user:computed(() => store.getters['getUserInfo']),
  isMember:computed(() => store.getters['isMember']),
  //暂存视频(推荐)
  shortVideoRemInfo:computed(() => store.getters['getShortVideoRemInfo']),
  //暂存视频(关注)
  shortVideoFocusInfo:computed(() => store.getters['getShortVideoFocusInfo'])
})

const addVideoEventListeners = (video, key) => {
  video.removeEventListener('pause', ev => {})
  video.removeEventListener('play', ev => {})
  video.removeEventListener('canplay', ev => {})
  video.removeEventListener('canplaythrough', ev => {})
  video.removeEventListener('playing', ev => handleVideoEvent(ev, key))
  video.removeEventListener('timeupdate', ev => {})
  
  video.addEventListener('pause', ev => handleVideoEvent(ev, key))
  video.addEventListener('play', ev => handleVideoEvent(ev, key))
  video.addEventListener('canplay', ev => handleVideoEvent(ev, key))
  video.addEventListener('canplaythrough', ev => handleVideoEvent(ev, key))
  video.addEventListener('playing', ev => handleVideoEvent(ev, key))
  video.addEventListener('timeupdate', ev => handleVideoEvent(ev, key))
} 

const handleVideoEvent = (evt, key) => {
  switch (evt.type) {
    case 'durationchange':
      break
    case 'resize':
      break
    case 'loadedmetadata':
      break
    case 'loadeddata':
      break
    // 可以播放状态，每个视频调用一次
    case 'canplay':
      break
    case 'timeupdate':
      // 12月5日打开这个注释
      if (getReallyRef(key) && getReallyRef(key).currentTime >= 10) {
        showBuyPorp();
        if(state.showTypeNum){
          getReallyRef(key).pause()
          getReallyRef(key).currentTime = 0
        }

      }
      break
    //完全可以播放
    case 'canplaythrough':
      state.videoElObject[key].canplay=true;
      break
    case 'ended':
      break
    case 'seeking':
      break
    case 'seeked':
      break
    // 正在播放
    case 'play':
      state.videoElObject[key].play=true;           
      break
    case 'playing':
      state.videoElObject[key].playing=false;         
      break
    case 'pause':
      state.videoElObject[key].play=false;     
      break
    case 'waiting':
      // state.videoElObject[key].canplay=false; 
      break
    case 'stalled':
      break
    case 'error':
      break
    default:
      break
  }
}
const handleSwiperNext =async (swiperIndex, dataIndex, status) => {
  //先播放
  state.itemVideoInfo = state.list[state.dataIndex]; 
  //检测是否会员
  fn_showTypeNum();
  //返回数据再次检测
  getVideoInfo(state.list[state.dataIndex].id);
  //保存记录
  saveLastHistory();
  for (const key in state.videoElObject) {
    state.videoElObject[key].playing=true;
  }
  // console.log(state.videoElObject)          
  if (status === 'zroe') {
    let base64 = await getImgBase64Data(state.list[dataIndex].coverImg)
    switch (swiperIndex) {
      case 0:
        state.CBase64 = null
        clearSwiperNextHlsAndVideoPause('xgPlayerC', 'xgPlayerD', 'xgPlayerA')
        if (state.hasPre) {
          state.hasPre = false
        } else {
          state.BData = state.list[0]
          getStream('xgPlayerB', 0)
        }
        state.ABase64 = base64
        break
      case 1:
        state.DBase64 = null
        clearSwiperNextHlsAndVideoPause('xgPlayerD', 'xgPlayerA', 'xgPlayerB')
        if (state.hasPre) {
          state.hasPre = false
        } else {
          state.CData = state.list[0]
          getStream('xgPlayerC', 0)
        }
        state.BBase64 = base64
        break
      case 2:
        state.ABase64 = null
        clearSwiperNextHlsAndVideoPause('xgPlayerA', 'xgPlayerB', 'xgPlayerC')
        if (state.hasPre) {
          state.hasPre = false
        } else {
          state.DData = state.list[0]
          getStream('xgPlayerD', 0)
        }
        state.CBase64 = base64
        break
      case 3:
        state.BBase64 = null
        clearSwiperNextHlsAndVideoPause('xgPlayerB', 'xgPlayerC', 'xgPlayerD')
        if (state.hasPre) {
          state.hasPre = false
        } else {
          state.AData = state.list[0]
          getStream('xgPlayerA', 0)
        }
        state.DBase64 = base64
        break
    }
  } else {
    let base64 = await getImgBase64Data(state.list[dataIndex].coverImg)
    switch (swiperIndex) {
      case 0:
        state.CBase64 = null
        clearSwiperNextHlsAndVideoPause('xgPlayerC', 'xgPlayerD', 'xgPlayerA')
        if (state.hasPre) {
          state.hasPre = false
        } else {
          state.BData = state.list[dataIndex + 1]
          getStream('xgPlayerB', dataIndex + 1)
        }
        state.ABase64 = base64
        break
      case 1:
        state.DBase64 = null
        clearSwiperNextHlsAndVideoPause('xgPlayerD', 'xgPlayerA', 'xgPlayerB')
        if (state.hasPre) {
          state.hasPre = false
        } else {
          state.CData = state.list[dataIndex + 1]
          getStream('xgPlayerC', dataIndex + 1)
        }
        state.BBase64 = base64
        break
      case 2:
        clearSwiperNextHlsAndVideoPause('xgPlayerA', 'xgPlayerB', 'xgPlayerC')
        if (state.hasPre) {
          state.hasPre = false
        } else {
          state.DData = state.list[dataIndex + 1]
          getStream('xgPlayerD', dataIndex + 1)
        }
        state.CBase64 = base64
        state.ABase64 = null
        break
      case 3:
        clearSwiperNextHlsAndVideoPause('xgPlayerB', 'xgPlayerC', 'xgPlayerD')
        if (state.hasPre) {
          state.hasPre = false
        } else {
          state.AData = state.list[dataIndex + 1]
          getStream('xgPlayerA', dataIndex + 1)
        }
        state.DBase64 = base64
        state.BBase64 = null
        break
    }
  }  
}
const handleSwiperPre =async (swiperIndex, dataIndex, status) => {
  state.itemVideoInfo = state.list[state.dataIndex]; 
  fn_showTypeNum();
  getVideoInfo(state.list[state.dataIndex].id);
  saveLastHistory();
  for (const key in state.videoElObject) {
    state.videoElObject[key].playing=true;
  }
  // console.log(state.videoElObject)         
  if (status === 'zroe') {
    let base64 = await getImgBase64Data(state.list[dataIndex].coverImg)
    switch (swiperIndex) {
      case 0:
        clearSwiperNextHlsAndVideoPause('xgPlayerC', 'xgPlayerB', 'xgPlayerA')
        state.DData = state.list[dataIndex]
        getStream('xgPlayerD', dataIndex)
        state.DBase64 = base64
        state.CBase64 = null
        break
      case 1:
        state.DBase64 = null
        clearSwiperNextHlsAndVideoPause('xgPlayerD', 'xgPlayerC', 'xgPlayerB')
        state.AData = state.list[dataIndex]
        getStream('xgPlayerA', dataIndex)
        state.ABase64 = base64

        break
      case 2:
        state.ABase64 = null
        clearSwiperNextHlsAndVideoPause('xgPlayerA', 'xgPlayerD', 'xgPlayerC')
        state.BData = state.list[dataIndex]
        getStream('xgPlayerB', dataIndex)
        state.BBase64 = base64

        break
      case 3:
        state.BBase64 = null
        clearSwiperNextHlsAndVideoPause('xgPlayerB', 'xgPlayerA', 'xgPlayerD')
        state.CData = state.list[dataIndex]
        getStream('xgPlayerC', dataIndex)
        state.CBase64 = base64

        break
    }
  } else {
    let base64 = await getImgBase64Data(state.list[dataIndex - 1].coverImg)
    switch (swiperIndex) {
      case 0:
        state.CBase64 = null
        clearSwiperNextHlsAndVideoPause('xgPlayerC', 'xgPlayerB', 'xgPlayerA')
        state.DData = state.list[dataIndex - 1]
        getStream('xgPlayerD', dataIndex - 1)
        state.DBase64 = base64
        break
      case 1:
        state.DBase64 = null
        clearSwiperNextHlsAndVideoPause('xgPlayerD', 'xgPlayerC', 'xgPlayerB')
        state.AData = state.list[dataIndex - 1]
        getStream('xgPlayerA', dataIndex - 1)
        state.ABase64 = base64
        break
      case 2:
        state.ABase64 = null
        clearSwiperNextHlsAndVideoPause('xgPlayerA', 'xgPlayerD', 'xgPlayerC')
        state.BData = state.list[dataIndex - 1]
        getStream('xgPlayerB', dataIndex - 1)
        state.BBase64 = base64
        break
      case 3:
        state.BBase64 = null
        clearSwiperNextHlsAndVideoPause('xgPlayerB', 'xgPlayerA', 'xgPlayerD')
        state.CData = state.list[dataIndex - 1]
        getStream('xgPlayerC', dataIndex - 1)
        state.CBase64 = base64
        break
    }
  }   
}
const touchmove = (event, index, state) => {
  isClick = false
}
const touchend = (event, index) => {
  if (isClick) clickSwiper(index)
  isClick = true
}
const clickSwiper = (index) => {
  if (state.isFirstClickSwiper) {
    if (state.videoElObject.canplay) getReallyRef('xgPlayerA').play()
    if (state.videoElObject.canplay) getReallyRef('xgPlayerB').play()
    if (state.videoElObject.canplay) getReallyRef('xgPlayerC').play()
    if (state.videoElObject.canplay) getReallyRef('xgPlayerD').play()
    setTimeout(() => {
      switch (index) {
        case 0:
          getReallyRef('xgPlayerB').pause()
          getReallyRef('xgPlayerC').pause()
          getReallyRef('xgPlayerD').pause()
          break
        case 1:
          getReallyRef('xgPlayerA').pause()
          getReallyRef('xgPlayerC').pause()
          getReallyRef('xgPlayerD').pause()
          break
        case 2:
          getReallyRef('xgPlayerA').pause()
          getReallyRef('xgPlayerB').pause()
          getReallyRef('xgPlayerD').pause()
          break
        case 3:
          getReallyRef('xgPlayerA').pause()
          getReallyRef('xgPlayerB').pause()
          getReallyRef('xgPlayerC').pause()
          break
      }
      state.isFirstClickSwiper = false
    })
  }
  switch (index) {
    case 0:
      if (getReallyRef('xgPlayerA').paused) {
        getReallyRef('xgPlayerA').play()
      } else {
        getReallyRef('xgPlayerA').pause()
      }
      break
    case 1:
      if (getReallyRef('xgPlayerB').paused) {
        getReallyRef('xgPlayerB').play()
      } else {
        getReallyRef('xgPlayerB').pause()
      }
      break
    case 2:
      if (getReallyRef('xgPlayerC').paused) {
        getReallyRef('xgPlayerC').play()
      } else {
        getReallyRef('xgPlayerC').pause()
      }
      break
    case 3:
      if (getReallyRef('xgPlayerD').paused) {
        getReallyRef('xgPlayerD').play()
      } else {
        getReallyRef('xgPlayerD').pause()
      }
  }
}
// 清除swiper next动作后的hls 与 video dom的一些状态
const clearSwiperNextHlsAndVideoPause = (hlsKey, elKey, loadKey) => {
  // 销毁这个hls 对象内存
  if (state.xgObject[hlsKey]) {
    state.xgObject[hlsKey].stopLoad()
    state.xgObject[hlsKey].detachMedia()
    state.xgObject[hlsKey].destroy()
    // state.xgObject[hlsKey] = null
  }
  // 这个节点停止http流量加载
  if (state.xgObject[elKey]) {
    state.xgObject[elKey].stopLoad()
  }
  if (getReallyRef(elKey)) {
    getReallyRef(elKey).pause()
  }
  // 这个节点开始http流量加载
  if (state.xgObject[loadKey]) {
    state.xgObject[loadKey].startLoad()
  }
}
const swiperChage = (index) => {
  state.isFirst = false
  state.swiperIndex = index
  nextTick(() => {
    state.hasChanngeSwiper = true
    if (state.swipeDirection === 'next') {
      if (state.dataIndex === state.list.length - 1) {
        state.dataIndex = 0
      } else {
        state.dataIndex += 1
      }
      if (state.hasPre === true) {
        state.hasPre = false
      }
      if (state.dataIndex < state.list.length - 1) {
        handleSwiperNext(index, state.dataIndex)
      } else if (state.dataIndex === state.list.length - 1) {
        handleSwiperNext(index, state.dataIndex, 'zroe')
        state.dataIndex = -1
      }
      if (state.dataIndex + 2 === state.list.length) {
        state.pageNum += 1
        if (props.homeSvParams.nowPosit == '首页短视频') {
          getHomeRecommendList()
        } else {
          getTypeTxtQuest(route.query.typeTxt)
        }
      }
    } else if (state.swipeDirection === 'pre') {
      if (state.dataIndex === 0) {
        state.dataIndex = state.list.length
      } else if (state.dataIndex === -1) {
        state.dataIndex = state.list.length - 1
      }
      state.dataIndex -= 1
      if (state.dataIndex >= 1) {
        handleSwiperPre(index, state.dataIndex)
      } else if (state.dataIndex === 0) {
        handleSwiperPre(index, 9, 'zroe')
      }
      state.hasPre = true
    }
    setTimeout(() => {
      switch (index) {
        case 0:
          if (getReallyRef('xgPlayerA')) getReallyRef('xgPlayerA').play()
          break
        case 1:
          if (getReallyRef('xgPlayerB')) getReallyRef('xgPlayerB').play()
          break
        case 2:
          if (getReallyRef('xgPlayerC')) getReallyRef('xgPlayerC').play()
          break
        case 3:
          if (getReallyRef('xgPlayerD')) getReallyRef('xgPlayerD').play()
          break
      }
    })
  })
}
// 解密并获取base64图片地址
const getImgBase64Data =async (imgURL) => {
  if (!imgURL) return
  const baseUri = await handleVerAutoImg(`${state.cdn}${imgURL}`)
  if (baseUri && baseUri.length) {
    return baseUri
  } else {
    return '/cover.png'
  }
}
// 首页推荐小视频
const getHomeRecommendList =async () => {
  try {
    let res = {}
    if (props.homeSvParams.name == '关注') {
      res = await homeFocusList({
        pageNum: state.pageNum,
        pageSize: state.pageSize
      })
    }else{
      res = await homeRecommendList({
        pageNum: state.pageNum,
        pageSize: state.pageSize
      })       
    }
    if (res.code === 200) {
      if (res.data.shortList && res.data.shortList.length) {
        state.list = [...state.list, ...res.data.shortList]
      } else {
        state.list = [...state.list, ...res.data.mediaList]
      }
    } else {
      showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    showToast('请求失败，请稍后再试！')
  }
}
// 短视频详情列表 首页推荐+推荐页详情跳转 参数 id, sort 默认0
const getTopicDetails =async () => {
  try {
    const res = await media_details({
      id: +route.query.id,
      sort: +route.query.sort || 0,
      pageNum: state.pageNum,
      pageSize: 300
    })
    if (res.code === 200) {
      state.list = [...state.list, ...res.data.mediaList]
    } else {
      showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    showToast('请求失败，请稍后再试！')
  }
}
// 获取首页默认短视频列表数据
const getHomePage =async () => {
  try {
    const res = await index_home({
      id: +route.query.id,
      sort: +route.query.sort || 0,
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      if (res.data.shortList && res.data.shortList.length) {
        res.data.shortList.forEach(async item => {
          let base64 = await handleVerAutoImg(`${state.cdn}${item.coverImg}`)
          item.base64 = base64
        })

        state.list = [...state.list, ...res.data.shortList]
      } else {
        res.data.mediaList.forEach(async item => {
          let base64 = await handleVerAutoImg(`${state.cdn}${item.coverImg}`)
          item.base64 = base64
        })
        state.list = [...state.list, ...res.data.mediaList]
      }
    } else {
      showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    showToast('请求失败，请稍后再试！')
  }
}
//去重
const remove_repeat = (oldlist, newlist) => {
  let newShortArr = []
  newlist.forEach(newEle => {
    let status = false
    oldlist.forEach(oldEle => {
      if (newEle.id == oldEle.id) {
        status = true
      }
    })
    if (!status) newShortArr.push(newEle)
  })
  newShortArr = [...oldlist, ...newShortArr]
  return newShortArr
}   
// 获取历史记录短视频列表
const getHistoryList = () => {
  state.list = JSON.parse(store.getters['getShortVideoList'])
}
// 获取收藏短视频列表
const getCollect =async () => {
  try {
    const res = await collect_list({
      type: 2,
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      res.data.mediaList.forEach(async item => {
        let base64 = await handleVerAutoImg(`${state.cdn}${item.coverImg}`)
        item.base64 = base64
      })
      state.list = [...state.list, ...res.data.mediaList]
    } else {
      showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    showToast('请求错误，请稍后再试！')
  }
}
// 购买记录短视频列表
const getPayList =async () => {
  try {
    const res = await pay_history({
      type: 2,
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      state.list = [...state.list, ...res.data.mediaList]
    } else {
      showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    showToast('请求错误，请稍后再试！')
  }
}
// 搜索短视频列表   
const getSearchList =async () => {
  try {
    const res = await search({
      content: route.query.id,
      type: 2,
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      state.list = [...state.list, ...res.data.mediaList]
    } else {
      showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    showToast('请求错误，请稍后再试！')
  }
}
// up主短视频列表
const getUpList =async () => {
  try {
    const res = await user_media({
      userId: +route.query.id,
      pageSize: state.pageSize,
      pageNum: state.pageNum
    })
    if (res.code === 200) {
      state.list = [...state.list, ...res.data.mediaList]
    } else {
      showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    showToast('请求错误，请稍后再试！')
  }
}    
// 分类短视频列表
const getTagList =async () => {
  try {
    const res = await tag_detail({
      coverType: +route.query.coverType,
      sort: +route.query.sort,
      coded: +route.query.coded,
      location: +route.query.id,
      pageNum: state.pageNum,
      pageSize: state.pageSize,
      tag: route.query.tag
    })
    if (res.code === 200) {
      res.data.mediaList.forEach(async item => {
        let base64 = await handleVerAutoImg(`${state.cdn}${item.coverImg}`)
        item.base64 = base64
      })
      state.list = [...state.list, ...res.data.mediaList]
    } else {
      showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    showToast('请求错误，请稍后再试！')
  }
}
//保存最后视频
const saveLastHistory = () => {
  //vuex当前保存视频
  if(props.homeSvParams.name == '推荐') store.commit('setShortVideoRemInfo', state.list[state.dataIndex]);
  if(props.homeSvParams.name == '关注') store.commit('setShortVideoFocusInfo', state.list[state.dataIndex]);
}
//判断当前类型
const fn_showTypeNum = () => {
  //1.vip 2.金币 0.免费
  if(!state.isMember&&state.list[state.dataIndex].payType==1){
    state.showTypeNum=1;
  }else if(!state.list[state.dataIndex].isBuy&&state.list[state.dataIndex].payType==2&&state.list[state.dataIndex].price){
    state.showTypeNum=2;
  }else{
    state.showTypeNum=0;
  }
}
// 点击观看完整视频
const showBuyPorp =() => {
  fn_showTypeNum();
  if(state.showTypeNum) state.buyPorp = true;
}   
// up主跳转 头像
const clickImg =(item) => {
  if (item.publisher && item.publisher.id) {
    router.push(`/up/index/${item.publisher.id}`)
  } else {
    showToast('发布者id不存在！')
  }
}       

// 评论弹窗关闭控制
const close =(showType) => {
  state.show = showType
}      

// 评论发布成功
const addComment =(success) => {
  if (success) {
    state.itemVideoInfo.comments += 1
  }
}   
// 剪贴板  
const doCopy =async (text) => {
  await toClipboard(text)
  showToast('复制剪贴板成功')
} 
// 点击分享按钮
const shareBtn =(options, index) => {
  switch (index) {
    case 0:
      let str = window.location.href.slice(0, window.location.href.indexOf('/short-video'))
      this.doCopy(str)
      break
    default:
      router.push({ path: '/mine/share' })
      break
  }
}
// 视频购买成功
const payBtnFn =async () => {
  // 先判断当前余额
  if (state.user.balance < state.list[state.dataIndex].price) {
    state.code = 6018
    return
  }
  try {
    const res = await video_pay({
      id: state.list[state.dataIndex].id,
      payType: 1
    })
    if (res.data.code === 200) {
      showToast('购买成功,点击播放即可');
      state.code = 200;
      state.list[state.dataIndex].isBuy=true;
      state.itemVideoInfo.isBuy=true;
      fn_showTypeNum();
      state.buyPorp = false;
    } else {
      state.code = 6018
      showToast(res.data.msg||res.tip)
    }
    
  } catch (error) {
    console.log(error)
    state.buyPorp = false
    showToast('请求错误，请稍后再试！')
  }
}
// 关注，取消关注按钮
const careUser =async (info) => {
  // 关注用户
  try {
    const res = await care_add({
      id: info.id,
      add: !info.isFollow
    })
    if (res.code === 200) {
      info.isFollow = !info.isFollow
      if (info.isFollow) {
        return showToast('关注成功')
      } else {
        return showToast('取消关注')
      }
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    return showToast('请求失败，请稍后再试')
  }
}
// 视频标签跳转
const toTagList = (item) => {
  router.push({
    path: `/tag/detail/${2}`,
    query: { name: item }
  })
}
const getStream = (refKey, index) => {
  let videoInfo = state.list[index]
  if (state.isSupported) {
    if (state.xgObject[refKey]) {
      state.xgObject[refKey].detachMedia()
      state.xgObject[refKey].destroy()
      state.xgObject[refKey] = null
    }
    state.xgObject[refKey] = new Hls()
    state.xgObject[refKey].attachMedia(getReallyRef(refKey))
    state.xgObject[refKey].loadSource(baseApi + '/api/app/media/m3u8/' + videoInfo.videoUrl)
    state.xgObject[refKey].on(Hls.Events.MEDIA_ATTACHED, () => {     
      state.xgObject[refKey].on(Hls.Events.MANIFEST_PARSED, () => {})
      state.xgObject[refKey].on(Hls.Events.ERROR, (event, data) => {
        // 监听出错事件
        // console.log(event, data)
        //showToast('视频加载失败，请切换下一个')
      })
    })      

  } else {
    getReallyRef(refKey).src = baseApi+'/api/app/media/m3u8/' + videoInfo.videoUrl;
  }
}

const loadVideo = () => {
  nextTick(() => {
    getStream('xgPlayerA', 0)
    addVideoEventListeners(getReallyRef('xgPlayerA'), 'xgPlayerA')
    getStream('xgPlayerB', 1)
    addVideoEventListeners(getReallyRef('xgPlayerB'), 'xgPlayerB')
    getReallyRef('xgPlayerB').pause()
    getStream('xgPlayerC', 2)
    addVideoEventListeners(getReallyRef('xgPlayerC'), 'xgPlayerC')
    getReallyRef('xgPlayerC').pause()
    getStream('xgPlayerD', 3)
    addVideoEventListeners(getReallyRef('xgPlayerD'), 'xgPlayerD')
    getReallyRef('xgPlayerD').pause()
  })
}

// 根据传入typeTXT判断请求哪个列表
const getTypeTxtQuest =async (typeTxt) => {
  switch (typeTxt) {
    case '推荐': //小视频首页列表+小视频更多：传tab栏id，
    case '详情':
      await getTopicDetails()
      break
    case '默认': //传tab栏id，sort(排序非必须)，
      await getHomePage()
      break
    case '观看记录':
      await getHistoryList()
      break
    case '收藏记录':
      await getCollect()
      break
    case '购买记录':
      await getPayList()
      break
    case 'up':
      await getUpList()
      break
    case '搜索':
      await getSearchList()
      break
    case '分类':
      await getTagList()
      break
    default:
      break
  }
}
// 评论弹窗
const showComment = () => {
  state.show = true
}
// 请求视频播放信息
const getVideoInfo =async (id,ifFirst) => {
  if(state.list.length&&state.list[state.dataIndex].haveUpdate) return;
  try {
    const res = await video_play({
      id
    })
    if (res.code === 200) {
      // 第一次
      if(ifFirst) state.ABase64 = await handleVerAutoImg(`${state.cdn}${res.data.mediaInfo.coverImg}`);
      res.data.mediaInfo.haveUpdate=true;
      //第二次更新
      state.itemVideoInfo = res.data.mediaInfo;
      state.list[state.dataIndex]=res.data.mediaInfo;
      //返回后判断是否需要购买
      fn_showTypeNum();
      saveLastHistory();
    } else {
      showNotify('视频已下架或播放错误，请选择其他视频观看!')
    }
  } catch (error) {
    console.log(error)
    showNotify('视频已下架或播放错误，请选择其他视频观看!')
  }
}
// 收藏，喜欢视频
const addLike =async (item) => {
  const res = await collect({
    flag: !item.isLike,
    object_id: item.id,
    collect_type: item.videoType
  })
  if (res.code === 200) {
    if (!item.isLike) {
      item.isLike = true
      item.likes += 1
      return showToast('收藏成功')
    } else {
      item.isLike = false
      item.likes -= 1
      return showToast('取消收藏')
    }
  } else {
    return showToast('操作失败')
  }
}
// 分享按钮
const clickShare = () => {
  state.showShare = true
}  
//获取哪个ref
const getReallyRef = (refName) => {
  if(refName=="xgPlayerA") return xgPlayerA.value;
  if(refName=="xgPlayerB") return xgPlayerB.value;
  if(refName=="xgPlayerC") return xgPlayerC.value;
  if(refName=="xgPlayerD") return xgPlayerD.value;
}

watch(() => state.swiperIndex, (n, o) => {
  if (o === 0 && n === 1) {
    state.swipeDirection = 'next'
  } else if (o === 1 && n === 2) {
    state.swipeDirection = 'next'
  } else if (o === 2 && n === 3) {
    state.swipeDirection = 'next'
  } else if (o === 3 && n === 0) {
    state.swipeDirection = 'next'
  } else if (o === 0 && n === 3) {
    state.swipeDirection = 'pre'
  } else if (o === 3 && n === 2) {
    state.swipeDirection = 'pre'
  } else if (o === 2 && n === 1) {
    state.swipeDirection = 'pre'
  } else if (o === 1 && n === 0) {
    state.swipeDirection = 'pre'
  }
},{ immediate: true })

onUnmounted(() => {
  state.xgObject['xgPlayerA'].destroy()
  state.xgObject['xgPlayerA'] = null
  state.xgObject['xgPlayerB'].destroy()
  state.xgObject['xgPlayerB'] = null
  state.xgObject['xgPlayerC'].destroy()
  state.xgObject['xgPlayerC'] = null
  state.xgObject['xgPlayerD'].destroy()
  state.xgObject['xgPlayerD'] = null
})

onMounted(async () => {
  state.height = window.innerHeight
  state.isSupported = Hls.isSupported()
  //首页短视频（等待接口返回再操作）
  if (props.homeSvParams.nowPosit == '首页短视频') {
    await getHomeRecommendList()
    //查找上次播放视频，存在则unshift前置
    if(state.shortVideoRemInfo&&props.homeSvParams.name == '推荐') state.list.unshift(state.shortVideoRemInfo)
    if(state.shortVideoFocusInfo&&props.homeSvParams.name == '关注') state.list.unshift(state.shortVideoFocusInfo)
    if (state.list.length === 0) {
      return showToast('您关注的up主暂无视频')
    };      
    state.dataIndex = 0   
    //先更新第一次
    state.itemVideoInfo = state.list[state.dataIndex]        
    getVideoInfo(state.list[state.dataIndex].id,'first')
  } else {
    //其他地方短视频
    state.dataIndex = 0
    await getVideoInfo(+route.query.detailId,'first')
    if(route.query.typeTxt){
      await getTypeTxtQuest(route.query.typeTxt)
    }else{
      //轮播直接点进来，单个视频
      await getHomeRecommendList()
    }
  }
  if (state.list[0]) state.AData = state.list[0]
  if (state.list[1]) state.BData = state.list[1]
  if (state.list[2]) state.CData = state.list[2]
  if (state.list[3]) state.DData = state.list[3]
  loadVideo()
  //swipe滑动更新
  nextTick(() => {
    swipe.value.resize()
  })
}) 

</script>


<style lang="scss" scoped>

.xgplayer-loading{
  left: 50%;
  pointer-events: none;
  position: absolute;
  top: 50%;
  transform: translate(-50%,-50%);
  z-index: 10;
  animation: Sr905S5u 1s steps(60,start) infinite;
  background-image: url("../../assets/imgs/s-loading.png");
  background-size: 48px;
  display: inline-block;
  font-size: 0;
  height: 48px;
  transform: scale(.7);
  margin-top: -24px;
  margin-left: -24px;
  width: 48px;
}
@keyframes Sr905S5u {
	to {
		background-position-y: -2880px
	}
}



.sort-play {
  max-width: $pcMaxWidth;
  width: 100%;
  max-height: 100%;
  overflow: hidden;
  padding: 0;
  box-sizing: border-box;
  position: relative;
  margin: 0 auto;
  .play-box {
    z-index: 2;
  }
  .play-box,
  video {
    position: absolute;
    top: 0;
    left: 0;
    width: 100% !important;
    height: 100% !important;
    object-fit: contain;
    z-index: 2;

    // outline: none;
    // -webkit-user-select: none;
    // -moz-user-select: none;
    // user-select: none;
    //  -ms-user-select: none;

    background-repeat: no-repeat;
  }

  :deep()  {
    .LayoutsHeader {
      .van-nav-bar,
      .van-nav-bar__content {
        z-index: 10;
        background: transparent;
        border: none !important;
        .van-icon,
        .van-nav-bar__title {
          color: #fff !important;
        }
      }
    }
  }
}

.swiper-slide {
  max-width: $pcMaxWidth;
  margin: 0 auto;
  position: relative;
  width: 100%;
  height: 100%;
  text-align: center;
  font-size: 0.18rem;
  color: #fff;
  background: #000;
}

.volume-tip {
  position: absolute;
  display: flex;
  align-items: center;
  z-index: 99999;
  left: 0.2rem;
  top: 2rem;
  padding: 0 0.15rem;
  height: 0.5rem;
  line-height: 0.5rem;
  border-radius: 0.2rem;
  background-color: rgba($color: #dbd1d1, $alpha: 0.65);
  color: rgb(121, 23, 23);
  font-size: 0.22rem;
}
:deep()  {
  #ShortVideoPage {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 1;
    width: 100%;
    height: 100%;
  }
}
.play-circle-warp {
  position: absolute;
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 3;
}
.play-circle-o {
  cursor: pointer;
  font-size: 1.2rem;
  z-index: 9;
  opacity: 0.4;
}
// 右侧三个图标
.right-icon {
  display: flex;
  align-items: center;
  flex-direction: column;
  position: absolute;
  right: 0.2rem;
  top: 40%;
  z-index: 999;
  font-size: 0.24rem;
  &-header {
    @include flexbox($jc: center, $ai: center, $fd: column, $fw: nowrap);
    margin-bottom: 0.6rem;
    position: relative;
    :deep()  {
      .warp {
        border-radius: 50%;
        width: 0.7rem;
      }
      img {
        border-radius: 50%;
      }
    }
    .add-icon {
      position: absolute;
      width: 0.25rem;
      height: 0.33rem;
      bottom: -0.1rem;
      left: 50%;
      transform: translate(-50%, 0);
    }
  }

  &-comment,
  &-share,
  &-likes {
    display: flex;
    align-items: center;
    flex-direction: column;
    justify-content: center;
    margin-bottom: 0.4rem;
  }
}

// 短视频描述
.video-info {
  width: 100%;
  position: absolute;
  padding: 0 0 0.2rem 0.2rem;
  left: 0;
  bottom: calc(constant(safe-area-inset-bottom));
  bottom: calc(env(safe-area-inset-bottom));
  display: flex;
  flex-direction: column;
  font-size: 0.24rem;
  z-index: 5;
  background: linear-gradient(to bottom, rgba(#000, 0), rgba(#000, 0.5));
  .publisher-info {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    .pay-btn {
      min-width: 90%;
      cursor: pointer;
      margin-left: 0.1rem;
      background: rgba($color: rgb(237, 24, 24), $alpha: 0.63);
      color: #ffbb12;
      border-radius: 0.2rem;
      display: flex;
      align-items: center;
      justify-content: center;
      white-space: nowrap;
      font-size: 0.28rem;
      font-weight: 600;
      margin: 0 auto;
      border: 1px solid #ffbb12;
      margin-bottom: 0.1rem;
      .price {
        display: flex;
        align-items: center;
        img {
          width: 0.24rem;
          height: 0.24rem;
          margin: 0 0.1rem;
        }
      }
      div,
      span {
        padding: 0.14rem 0.25rem;
      }
    }
  }
  .video-title {
    text-align: left;
    padding: 0  0.2rem 0.15rem 0.2rem;
  }
  .tags-list {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    span {
      cursor: pointer;
      padding: 0.02rem 0.13rem;
      background: rgba($color: #fff, $alpha: 0.2);

      margin: 0.15rem 0.15rem;
      display: inline-block;
      border-radius: 0.08rem;
    }
  }
}
.desc {
  font-size: 0.28rem;
}
// 购买提示框
.buy-porp {
  height: 100%;
  width: 100%;
  position: fixed;
  top: 0;
  z-index: 1000;
  max-width: $pcMaxWidth;
  background: rgba($color: #000, $alpha: 0.8);
  @include flexbox($jc: center, $ai: center, $fd: column, $fw: nowrap);
  color: #fff;
  font-size: 0.32rem;
  .no-times {
    text-align: center;
    .btn {
      cursor: pointer;
      @include flexbox($jc: space-between, $ai: center, $fd: row, $fw: nowrap);
      max-width: 4rem;
      margin: 0 auto;
    }
    span:first-child {
      background: $btnBg;
      color: $mainTxtColor1;
      margin-right: 0.2rem;
    }
    span {
      width: 1.8rem;
      line-height: 0.56rem;
      height: 0.56rem;
      font-size: 0.28rem;
      border-radius: 0.32rem;
    }
    span:last-child {
      margin-left: 0.2rem;
      border: solid 0.02rem #fff;
    }
    .sub-txt {
      font-size: 0.24rem;
      margin: 0.3rem 0;
    }
    .tip-txt {
      font-size: 0.2rem;
      margin-top: 0.2rem;
      i {
        margin-left: 0.1rem;
        color: #ffbb12;
        display: inline-block;
        font-style: normal;
      }
    }
    &.coin-wrap{
      width: 80%;
    }
  }
}
@media screen and (min-width: 750px) {
  .video-info {
    position: absolute;
    left: 0.2rem;
    bottom: calc(constant(safe-area-inset-bottom));
    bottom: calc(env(safe-area-inset-bottom));
  }
}
</style>
