<template>
  <div class="ad-warp">
    <div class="swiper-container">
      <div class="swiper-wrapper">
        <div class="swiper-slide" v-for="(item, index) in imgList" :key="index + 'swiper'">
          <div class="swiper-slide-inner">
            <DecryptImg :hasLazy="false" @click="clickImg(item)" :needPadding="false" class="md-img" :imgRadius="'0.12rem'" :imgURL="item.cover" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script  setup>
import {defineProps,onMounted,reactive,onUnmounted} from "vue"
import { handleParamsRouteJump, handleURlParams,handleVerAutoImg } from '@/utils/utils_tools' 
import { useStore } from 'vuex'
import DecryptImg from '@/components/DecryptImg/index.vue'
const store = useStore()       
const props = defineProps({
  imgList: {
    type: Array,
    default() {
      return []
    }
  },
  height: {
    type: String,
    default() {
      return '3.44rem'
    }
  }
})
const state = reactive({
  newList: [],
  swiper: null,
  imgCDN:store.getters['cdn']  
})
// 活动跳转
const clickImg = async (item) =>{
  if (item.href) {
    const code = handleURlParams(item.href)
    console.log(code)
    handleParamsRouteJump(code)
  } else {
    return
  }
}
// 初始化轮播
const initSwiper = async (item) =>{
  state.swiper = new Swiper({
    el: '.swiper-container',
    loop: true,
    initialSlide: state.newList.length > 3 ? 3 : 0,
    spaceBetween: 10,
    slidesPerView: 1.12,
    centeredSlides: true,
    grabCursor: true,
    autoplay: {
      delay: 3000 //1秒切换一次
    },
    breakpoints: {
      //当swiper宽度大于等于768
      768: {
        slidesPerView: 1.12,
        spaceBetween: 10
      },
      768: {
        slidesPerView: 3,
        spaceBetween: 20
      },
      1540: {
        slidesPerView: 3,
        spaceBetween: 20
      }
    },
    on: {
      slideChangeTransitionStart: function () {
      }
    }
  })
}

onMounted(async () => {
  state.newList = props.imgList
  initSwiper()
})
onUnmounted(async () => {
  if (state.swiper) {
    state.swiper = null
  }      
})
</script>

<style lang="scss" scoped>
.ad-warp {
  width: 100%;
  margin: 0.3rem 0;
  overflow: hidden;
  position: relative;
}
:deep()  {
  // vip
  .swiper-container {
    width: 100%;
    height: 100%;
    .swiper-slide {
      padding-top: 48%;
      position: relative;
      .swiper-slide-inner {
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 0;
        .md-img{
          height: 100%;
        }
        img {
          width: 100%;
          height: 100%;
          border-radius: 0.14rem;
        }
      }
    }
  }
}

@media screen and (min-width: 750px) {
  .swiper-container {
    .swiper-slide {
      padding-top: 20% !important;
    }
  }
}
</style>
