<template>
  <van-tabbar
    class="footer-bar"
    :class="{
      isIphonex:state.isIphonex,
      isStandalone:state.isStandalone
    }"
    route
    active-color="#c38c4a"
    v-model="state.active"
    @change="handleChange"
  >
    <van-tabbar-item v-for="(item, index) in data" :to="item.to" :dot="index === 4" :key="index">
      {{ item.title }}
      <template #icon="props">
        <img :src="props.active ? item.icon.active : item.icon.defaultAcitve" />
      </template>
    </van-tabbar-item>
  </van-tabbar>
</template>
<script setup>
import { isIphonex } from '@/utils/utils_tools'
const emits = defineEmits(["change"])
const props = defineProps({
  defaultActive: {
    type: Number,
    default: 0
  },
  data: {
    type: Array,
    default: () => {
      return []
    }
  }
})

const state = reactive({
  active: props.defaultActive,
  isIphonex: false,
  isStandalone: false
})

const handleChange =(value) =>{
  emits("change",value)
}

onMounted(() => {
  state.isStandalone = navigator.standalone
  state.isIphonex = isIphonex()
}) 

</script>

<style lang="scss" scoped>
.footer-bar {
  transform: translate(-50%, 0);
  width: calc(100% - 0.5rem);
  left: 50%;
  border-radius: 0.12rem;
  border: none;
  box-shadow: $shadow;
  .van-tabbar-item:first-child {
    border-radius: 0.13rem;
  }
  .van-tabbar-item:last-child {
    border-radius: 0.13rem;
  }
  .van-tabbar-item--active {
    background: transparent;
    font-weight: 600;
  }
  .van-tabbar-item {
    font-size: .26rem;
    color: #c2c9d0;
    font-weight: 500;
    .van-tabbar-item__icon {
      img {
        height: 34px;
      }
    }    
  }
}
.isIphonex {
  padding-bottom: 0.24rem;
}
.van-hairline--top-bottom::after {
  display: none !important;
  border: none !important;
  border-width: 0 !important;
}
@media screen and (min-width: 750px) {
  .footer-bar {
    display: none;
  }
}
</style>
