<template>
  <div class="upload-img-box">
    <DecryptImg
      class="img-item"
      v-for="(item, index) in state.upLoadImgs"
      :key="index"
      :imgURL="item"
      ref="refImg"
      :needPadding="false"
      @click="imagePreview(index)"
    >
      <van-icon class="colse" @click.stop="colse(index)" size="18" color="#fff" name="clear" />
    </DecryptImg>
    <van-uploader class="uploadImg-wrap" :after-read="onReadImg" multiple accept="image/*">
      <div class="upload-img-item img-item">
        <img src="@/assets/imgs/dating/upload.png" alt="" />
      </div>
    </van-uploader>
  </div>
</template>

<script setup>
import { showToast , showLoadingToast } from 'vant';
import { showImagePreview } from 'vant'
import { imgsCompress } from '@/utils/utils_tools'
import { uploadImgs } from '@/api/home'
let refImg = ref(null);
const emits = defineEmits(["result"])
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const props = defineProps({
  imgs: { 
    type: Array,
    default() {
      return []
    }
  }
})
const state = reactive({
  upLoadImgs: [] 
})
// 图片预览
const imagePreview = (indexImg) => {
  const imgArr = []
  const domArr = refImg.value
  domArr.forEach(item => {
    imgArr.push(item.realUrl)
  })
  showImagePreview({
    images: imgArr, // 需要预览的图片 URL 数组
    showIndex: true, // 是否显示页码
    loop: true, // 是否开启循环播放
    startPosition: indexImg // 图片预览起始位置索引
  })
}
// 上传多图
const onReadImg =async (file) => {
  if (state.upLoadImgs && state.upLoadImgs.length >= 8) return showToast('最多传8张')
  // 组合
  let formData = new FormData()
  let newBlobList = []
  if (!file.length) {
    newBlobList = await imgsCompress([file])
  } else {
    newBlobList = await imgsCompress(file)
  }
  for (let index = 0; index < newBlobList.length; index++) {
    console.log(newBlobList[index])
    formData.append('upload[]', newBlobList[index])
  }
  // 上传
  showLoadingToast({ duration: 0, message: '图片上传中请稍后' })
  const res = await uploadImgs(formData)
  if (res.code === 200) {
    showToast('上传成功')
    if(!state.upLoadImgs) state.upLoadImgs=[];
    state.upLoadImgs.push(...res.data.paths)
    emits("result",state.upLoadImgs)
    console.log(state.upLoadImgs)    
  } else {
    showToast(res.tip || res.msg)
  }
}
// 获取上传文件信息，并调上传接口
const tirggerFile =async (file) => {
  // 获取当前选中的文件
  if (event.target.files[0]) {
    const file = event.target.files[0]
    const imgMasSize = 1024 * 1024 * 4 // 10MB
    // 检查文件类型
    if (['jpeg', 'png', 'gif', 'jpg'].indexOf(file.type.split('/')[1]) < 0) {
      // 自定义报错方式
      showToast('文件类型仅支持 jpeg/png/gif！')
      return
    }
    // 文件大小限制
    if (file.size > imgMasSize) {
      // 文件大小自定义限制
      showToast('文件大小不能超过4MB！')
      return
    }
    const formData = new FormData()
    // 自定义formData中的内容
    // type
    formData.append('type', file.type)
    // size
    formData.append('size', file.size || 'image/jpeg')
    // name
    formData.append('name', file.name)
    // lastModifiedDate
    formData.append('lastModifiedDate', file.lastModifiedDate)
    // append 文件
    formData.append('upload', file)
    // 已上传图片
    const res = await uploadImgs(formData)
    if (res.code === 200) {
      if (state.upLoadImgs) {
        state.upLoadImgs.map((item, index) => {
          if (item === res.data.path) {
            state.upLoadImgs.splice(index, 1)
          }
        })
      }
      state.upLoadImgs.push(res.data.path)
      emits("result",state.upLoadImgs)      
    } else {
      showToast('上传失败')
    }
  }
}
// 取消上传
const colse = (index) => {
  state.upLoadImgs.splice(index, 1)
}
    
watch(() => props.imgs, (newValue, oldValue) => {
  state.upLoadImgs = props.imgs
},{ immediate: true })

</script>

<style lang="scss" scoped>
.upload-img-box {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  .img-item {
    width: 2.14rem;
    height: 2.14rem;
    position: relative;
    margin-right: 0.2rem;
    margin-top: 0.2rem;
    .colse {
      position: absolute;
      top: 0rem;
      right: 0rem;
    }
  }
  .upload-img-item {
    width: 2.14rem;
    height: 2.14rem;
    background: #f0f0f0;
    text-align: center;

    line-height: 2rem;

    img {
      width: 0.48rem;
      height: 0.48rem;
    }
  }

}
</style>
