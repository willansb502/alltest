<template>
  <Uploader
    :options="options"
    @file-success="onSuccess"
    @file-progress="onProgress"
    @file-added="onFileAdd"
    @file-error="onError">
    <UploaderUnsupport></UploaderUnsupport>
    <uploader-btn :attrs="state.attrs" class="border-none w-full p-0">
      <slot name="view"></slot>
    </uploader-btn>
     <!-- v-if="hasCustomView" -->
    <!-- <uploader-btn  :attrs="state.attrs" class="border-none">
      <div class="bg-[#EEE] rounded-[4px]">选择文件</div>
    </uploader-btn> -->
  </Uploader>
</template>
<script setup>
import { useStore } from 'vuex'
const store = useStore()
const router = useRouter()
import SparkMD5 from 'spark-md5'
import vueSimpleUploader from 'vue-simple-uploader'
const Uploader=vueSimpleUploader.Uploader
const UploaderBtn=vueSimpleUploader.UploaderBtn
const UploaderUnsupport=vueSimpleUploader.UploaderUnsupport
const baseApi = import.meta.env.VITE_APP_baseApi
// console.log(Uploader)

import $device from "current-device"
import UAParser from "ua-parser-js"
import { showToast } from 'vant';
const emits = defineEmits(["upload-progress","uploaded","upload-fail"])

const props = defineProps({
  maxSize: { // 影片最大限制(bytes)
    type: Number,
    default() {
      return 1024 * 1024 * 100
    }
  }
})
const state = reactive({
  // 视频校验唯一码
  trackId: '',
  chunks: 0,
  fileChunkList: [],
  duration: 0,
  attrs: {
    accept: 'video/*'
  }
})

const uploadQuery = (file, chunk) => {
  return {
    id: String(state.trackId),
    pos: Number(chunk.offset + 1),
    totalPos: Number(state.chunks),
    data: state.fileChunkList[chunk.offset]
  }
}
const onProgress =async (rootFile, file, chunk) => {
  const params = {
    pos: chunk.offset + 1,
    totalPos: state.chunks,
    progress: file.progress(),
    id: String(state.trackId)
  }
  emits("upload-progress",params)
}

const onSuccess =async (rootFile, file, message) => {
  const res = JSON.parse(message)
  console.log('onSuccess:', res)
  if (res.code === 200) {
    const data = {
      id: res.data.id,
      videoUri: res.data.videoUri,
      md5: state.trackId
    }
    emits("uploaded",data)
    showToast("上传完成")
  } else {
    emits("upload-fail")
    showToast(res.tip || res.msg)
  }
}

const onFileAdd =async (file) => {
  state.fileChunkList = []
  if (props.maxSize && file.file.size > props.maxSize) {
    return showToast(`视频不能大于${props.maxSize / 1024 / 1024}M`)
  }
  emits("file-added",file.file)
  emits("uploading")
  file.pause() // 暂停上传
  const { md5, chunks } = await computeMD5(file)
  state.trackId = md5
  console.log(file)
  state.chunks = chunks
  file.resume() // 通过验证 开始上传
}

const onError =(rootFile, file, message) => {
  console.error('onError:', message)
  emits("upload-fail")
}

const computeMD5 =(file) => {
  const fileReader = new FileReader()
  const blobSlice = File.prototype.slice || File.prototype.mozSlice || File.prototype.webkitSlice
  let currentChunk = 0
  const chunkSize = options.value.chunkSize
  const chunks = Math.ceil(file.file.size / chunkSize)
  console.log(chunks)
  const spark = new SparkMD5()

  loadNext()

  return new Promise((resolve, reject) => {
    fileReader.onload = (e) => {
      state.fileChunkList.push(e.target.result.split('base64,')[1])
      spark.append(e.target.result)

      if (currentChunk < chunks) {
        currentChunk++
        loadNext()
      } else {
        const md5 = spark.end()
        // md5计算完毕
        resolve({ md5, file, chunks })
      }
    }

    fileReader.onerror = function() {
      console.error(`文件${file.name}读取出错，请检查该文件`)
      reject()
    }
  })

  function loadNext() {
    const start = currentChunk * chunkSize
    const end = start + chunkSize >= file.file.size ? file.file.size : start + chunkSize
    fileReader.readAsDataURL(blobSlice.call(file.file, start, end))
  }
}
const getUAParser =() => {
  // 设置x-user-agent
  const obj = new UAParser(navigator.userAgent)
  const results = obj.getResult()
  const DevType = results.device.vendor + ' ' + results.device.model + ' ' + results.device.type
  const BuildID = results.browser.name + ' ' + results.browser.version
  const Ver = '1.0.1+27'
  let SysType = ''
  if ($device.desktop()) {
    SysType = 'h5_pc'
  }
  if ($device.android()) {
    SysType = 'h5_android'
  }
  if ($device.ios()) {
    SysType = 'h5_ios'
  }
  return `DevType=${DevType};SysType=${SysType};Ver=${Ver};BuildID=${BuildID}`
}
const options = computed(() => {
  return {
    target: baseApi+'/api/app/vid/upload',
    chunkSize: 2 * 1024 * 1024,
    fileParameterName: 'file',
    testChunks: false,
    forceChunkSize: true,
    maxChunkRetries: 3,
    singleFile: true,
    simultaneousUploads: 1,
    query: uploadQuery,
    headers: {
      'Authorization': store.getters['getToken'],
      'X-User-Agent': getUAParser()
    }
  }
})
</script>
