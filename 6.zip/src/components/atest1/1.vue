<template>
  <div>{{list}}{{title}}{{user}}{{homecategoryV2}}</div>

  <div>
    {{foo}} {{foo2}}
  </div>
  <div>{{name_customRef}}</div>
</template>

<!-- 使用方式，需要在 <script> 代码块上添加 setup -->
<script setup>
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
import { useStore } from 'vuex'
const store = useStore()
const router = useRouter()
const emits = defineEmits(["addNum2"])
emits("addNum2",123)
let spanBox = ref(null)

const props = defineProps({
  list: {
    type: Array,
    default: [],
  },
  title: {
    type: String,
    default: "标题"
  }
})

const state = reactive({
  isMobile: "手机",
  name: 'lisa',
  imgCDN:computed(() => store.getters['cdn']),
  // 播放视频url 如果有预览地址则播放预览地址，没有就播放
  url:computed(() => {
  })
})


const aaa =() =>{

}
watch(() => router.currentRoute.value.path, (newValue, oldValue) => {

},{ immediate: true })

onMounted(async () => {

}) 


// Toast
import { showToast } from 'vant';
import 'vant/es/toast/style';

// Dialog
import { showDialog } from 'vant';
import 'vant/es/dialog/style';

// Notify
import { showNotify } from 'vant';
import 'vant/es/notify/style';

// showImagePreview
import { showImagePreview } from 'vant';
import 'vant/es/image-preview/style';
  // 直接引入组件即可，因为使用了setup，他会自动注册；
  // import anotherPage from "./components/AnotherPage.vue" 
  // 使用 defineExpose,defineEmits,defineProps 。都不用import
  import {ref,toRef,unref,isRef,customRef,shallowRef,triggerRef,reactive,watch,defineEmits,getCurrentInstance,computed} from "vue";
  import { useStore } from 'vuex'
  const store = useStore()    
  const {proxy} = getCurrentInstance()

  console.log(proxy)  
  // 组件传值

   // 定义变量
  const number = ref('1001')

  // 定义方法
  const addNum = () => {
    number.value++;
    user.age = 11;
  }


  // watch(nums, (newValue, oldValue) => {
  //   console.log('watch 已触发', newValue)
  // })
  // 监听demo对象的name属性
  watch(() => user.age, (newValue, oldValue) => {
    console.log('watch 已触发', newValue)
  })

  // 向父组件传递方法
  emits("addNum2",123)


  onMounted(async () => {})

  const homecategoryV2 = computed(() => {
    return store.getters['homecategoryV2']
  })
  console.log(homecategoryV2.value)
  setTimeout(() => {
    store.commit("SET_tes888","改动了")
    console.log(8888)
  }, 2000);
 

    const state = reactive({
      foo: 1,
      bar: 2
    })
    const foo = toRef(state, 'foo')
    const foo2 = ref(state.foo)
    console.log("~~~~~~~~~~~~~~~~~~~~~~")
    const update = () => {
      //必须是reactive const 不行，原始数据必须是响应式对象，数据更新，视图更新
      state.foo++ 
      foo.value++
      // foo和state中的数据不会更新 
      foo2.value++  
    }
    update()
    // 如果参数是一个ref，则返回内部值，否则返回参数本身。这是 val = isRef(val) ? val.value : val 的语法糖函数。
    console.log(unref(10))
    console.log(unref(ref(10)))
    console.log(isRef(10)); // true
    console.log(isRef(ref(2))); // false

    function myRef(value){
      return customRef((track, trigger)=>{
        return {
          get(){
            track();
            console.log(0.12)
            return value
          },
          set(newVal){
            trigger();
            console.log(0.13)
            value = newVal
          }
        }
      })
    }
    let name_customRef = myRef('lcy');
    const changeName = ()=>{
      name_customRef.value='lcy666'
    }
    changeName()


  // 将组件属性和方法暴露出去，供父组件使用
  defineExpose({
    number,  // 暴露属性
    user,  // 暴露属性
    addNum, // 暴露方法
  })
</script>

