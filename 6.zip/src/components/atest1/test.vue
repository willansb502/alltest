<!-- home -->
<template>
  <div>
    <Default @addNum2=addNum2 :list=[1,2,3,4] title="父级传下的标题" ref="child" />
    <button @click="addNum2">点击</button>
  </div>
</template>
<script setup>
  // reactive 用于声明引用数据类型的值，可以使用toRefs来解构成ref值使用。
  import { onMounted,ref,reactive } from 'vue'
  import Default from '@/components/test1/1.vue'
  let child = ref(null)
  onMounted(() => {
    console.log(child.value.number); // Child Components
    child.value.addNum()
  })  
  const addNum2 = (val) => {
    console.log(val)
  }
</script>
<style lang="scss" scoped>
.index-container {
  padding: 0.8rem 0 1rem 0;
  min-height: $minHeight;
  max-width: $pcMaxWidth;
  margin: 0 auto;
  :deep()  {
    .imgNoPadding {
      object-fit: cover;
    }
    .item-bg {
      height: 100%;
    }
  }
  .container-tab {
    :deep()  {
      .van-sticky {
        margin-bottom: 0.2rem;
        background: $mainBgDeepColor;
        position: fixed;
        top: 1.3rem;
        @include transformCenter();
      }
    }
  }
}
.home-card-warp {
  background: #4641413d;
  backdrop-filter: blur(5px);
  margin: 0 0.1rem;
  border-radius: 0.08rem;
  margin-bottom: 0.2rem;
}
.home-card-title {
  font-size: 0.28rem;
  padding: 0.12rem 0.1rem;
  margin: 0 0;
}
.home-card-sub-title {
  font-size: 0.26rem;
  margin: 0.12rem 0.1rem;

  color: #aba9a9;
}
.home-card-list-scroll {
  overflow-x: scroll;
  overflow-y: hidden;
  vertical-align: top;
}
.home-card-body-base {
  font-size: 0.16rem;
  line-height: 1.2;
  position: relative;
  color: #fff;
  height: auto;
}
.home-six-card-text {
  font-size: 0.16rem;
  position: relative;
  color: #fff;
  height: auto;
}

.home-card-body-width {
  position: relative;
  width: 1.4rem;
  margin: 0.02rem 0.12rem;
  display: inline-block;
  vertical-align: top;
  top: 0.08rem;
}
// 约炮
.merchantcard-list {
  @include flexbox($jc: flex-start, $ai: flex-start, $fd: row, $fw: nowrap);
  overflow-x: scroll;
  &-item {
    width: 25%;
    min-width: 5.6rem;
    margin: 0.2rem 0.2rem 0.3rem 0;
    border-radius: 0.05rem;
    box-shadow: $shadow;
  }
  :deep()  {
    .merchant-card {
      width: 100%;
    }
  }  
}
.merchantcard-list::-webkit-scrollbar {
  /*滚动条整体样式*/
  width: 10px; /*高宽分别对应横竖滚动条的尺寸*/
  height: 10px;
}
.merchantcard-list::-webkit-scrollbar-thumb {
  /*滚动条里面小方块*/
  border-radius: 10px;
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  background: #83807e;
}
.merchantcard-list::-webkit-scrollbar-track {
  /*滚动条里面轨道*/
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  border-radius: 10px;
}
// 名优馆推荐
.home-card-body-width-ac {
  position: relative;
  width: 2.5rem;
  margin: 0.02rem 0.12rem;
  display: inline-block;
  vertical-align: top;
  top: 0.14rem;
}

.home-card-body-bg {
  position: absolute;
  width: 89%;
  top: -0.08rem;
  padding-top: 90%;
  border-radius: 0.16rem;
  overflow: hidden;
  left: 0;
  right: 0;
  margin: auto;
}
.home-card-body-content {
  position: absolute;
  z-index: 1;
  top: 0;
  width: 100%;
  display: flex;
  flex-flow: row wrap;
  border-radius: 0.16rem;
  overflow: hidden;
}

.home-pos-w100 {
  position: absolute;
  top: 0;
  width: 100%;
  height: 100%;
}

.account-img-pop {
  background-color: transparent;
  min-height: 7.78rem;
  overflow-y: visible;
}
.account-img {
  width: 80vw;
  height: 100%;
  background: linear-gradient(to top, #0a0707, #303030);
  background-size: 100% 100%;
  background-repeat: no-repeat;
  padding: 0.3rem 0.2rem 0.2rem 0.2rem;
  text-align: center;
  border-radius: 15px;
  :deep()  {
    .van-icon {
      cursor: pointer;
      @include transformCenter(-50%, 0);
      position: absolute;
      right: -0.1rem;
      top: 0.2rem;
    }
  }
  .title-img {
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.36rem;
    margin-bottom: 0.4rem;
    span {
      color: rgb(233, 202, 63);
      margin: 0 0.1rem;
    }
    img {
      width: 1.4rem;
    }
  }
  p {
    margin: 0 0 0.2rem 0;
    font-size: 0.4rem;
    color: #eb3876;
  }

  .desc {
    max-height: 2rem;
    overflow: auto;
    text-align: left;
    font-size: 0.26rem;
    white-space: pre-line;
    color: #f5db73;
    margin: 0.3rem 0 0.45rem 0;
  }
  .btn {
    background: $btnBg;
    color: $mainTxtColor1;
    font-size: 0.3rem;
    border-radius: 0.36rem;
    width: 3.12rem;
    height: 0.7rem;
    line-height: 0.7rem;
    margin: 0 auto;
    color: #f5db73;
  }
  .btn:hover {
    cursor: pointer;
  }
}
.activity-img-pop {
  background-color: transparent;
  min-height: 7.78rem;
  overflow-y: visible;
  .activity-img {
    width: 6rem;
    height: 100%;
    :deep()  {
      .van-icon {
        cursor: pointer;
        @include transformCenter(-50%, 0);
        position: absolute;
        right: 0rem;
        top: 0.2rem;
      }
    }
  }
}

.home-card-list-scroll::-webkit-scrollbar {
  /*滚动条整体样式*/
  width: 10px; /*高宽分别对应横竖滚动条的尺寸*/
  height: 10px;
}
.home-card-list-scroll::-webkit-scrollbar-thumb {
  /*滚动条里面小方块*/
  border-radius: 10px;
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  background: #83807e;
}
.home-card-list-scroll::-webkit-scrollbar-track {
  /*滚动条里面轨道*/
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  border-radius: 10px;
  background: #241e1e;
}
.animate-tabs {
  width: auto;
  margin-bottom: 1px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 0.24rem;
  height: 0.68rem;
  line-height: 0.68rem;
  position: relative;
  top: 0.04rem;
  z-index: 9;
  div {
    overflow: hidden;
    cursor: pointer;
    border: 1px solid #f4ce4e4d;
    text-align: center;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    width: 100px;
  }
  div:first-child {
    border-radius: 0.22rem 0 0 0;
  }
  div:last-child {
    border-radius: 0 0.22rem 0 0;
  }
  .animate-tab-active {
    border-bottom-color: #151313;
    color: #f4ce4e;
  }
}

.icon {
  cursor: pointer;
}
.iconTrans {
  transform: rotate(720deg);
  -webkit-transition: transform 0.25s linear;
  -moz-transition: transform 0.25s linear;
  -o-transition: transform 0.25s linear;
  transition: transform 0.25s linear;
}
.iconTrans2 {
  transform: rotate(-720deg);
  -webkit-transition: transform 0.25s linear;
  -moz-transition: transform 0.25s linear;
  -o-transition: transform 0.25s linear;
  transition: transform 0.25s linear;
}
.app-down{
  .app-dl-dialog{
    position: relative;
    text-align: center;
    padding: 0.2rem 0.4rem 0.4rem 0.4rem;
    font-size: 0.26rem;
    background: url("https://jinmantiankong.com/attachment/section-1-bg.jpeg") $mainTxtColor2;
    background-size:cover ;
    &::before{
      content: '';
      position: absolute;
      left: 0;
      right: 0;
      bottom: 0;
      top: 0;
      background-color: rgba(0,0,0, .7);
      backdrop-filter: blur(1px);
      z-index: 1;
    }
    li{
      position: relative;
      z-index: 2;      
      // white-space: nowrap;
    }
    .title{
      padding: 0.2rem 0;
      font-size: 0.3rem;
    }
    .domain{
      text-align: center;
    }
  }
}

@media screen and (min-width: 750px) {
  .account-img,
  .activity-img {
    width: 8rem !important;
  }
  .animate-tabs {
    font-size: 0.3rem;
    padding: 0.2rem 0.1rem;
    div {
      width: 220px;
    }
  }
  :deep()  {
    .long-four {
      &-item:nth-of-type(6) {
        display: none !important;
      }
    }
  }
}
</style>

