import { createApp } from 'vue'
import router from './router';
import store from './store/index'
import App from './App.vue'
import { Lazyload } from 'vant';
// 引入全局样式
import '@/assets/scss/constant.scss'

import 'vant/es/toast/style';
import 'vant/es/dialog/style';
import 'vant/es/image-preview/style';
import 'vant/es/notify/style';

// 引入创建indexDb文件
import '@/plugins/indexDB.client'

const app = createApp(App);
app.config.errorHandler = (err, vm, info) => {
  console.log(err, vm, info)
}

app.use(router);
app.use(store);
app.use(Lazyload, {
  lazyComponent: true,
  attempt: 1,
  observer: true,
  observerOptions: {
    rootMargin: '0px',
    threshold: 0.1
  },
  listenEvents: ['scroll'],
  adapter: {
    loaded({ bindType, el, naturalHeight, naturalWidth, $parent, src, loading, error, Init }) {
      // do something here
      // example for call LoadedHandler
      console.log('loaded')
    },
    loading(listender, Init) {
      console.log('loading')
    },
    error(listender, Init) {
      console.log('error')
    }
  }  
});
app.mount('#app')

