import { createRouter, createWebHashHistory } from 'vue-router';
import routes from 'virtual:generated-pages';
import store from '@/store/index'
console.log(routes);
routes.push({
  path: '/',
  redirect: '/home',
});

//导入生成的路由数据
const router = createRouter({
  history: createWebHashHistory(),
  routes 
});


router.beforeEach(async (_to, _from, next) => {
  next();
  //记录上个来源位置
  store.state.config.keepAliveList.forEach((element,index) => {
    if(element.pagePath==_from.path){
      store.commit("setAliveList",{
        index,
        scrollTop:document.documentElement.scrollTop
      })
    }
  });
  //滚动当前页面
  store.state.config.keepAliveList.forEach((element) => {
    if(element.pagePath==_to.path){
      document.documentElement.scrollTop=element.scrollTop
    }
  });
});

router.afterEach((_to) => {
  // console.log(document.documentElement.scrollTop)
});



export default router;
