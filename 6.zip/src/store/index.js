import { createStore } from 'vuex'
import config from './modules/config'
import history from './modules/history'
import shortVideo from './modules/shortVideo'
import user from './modules/user'

import createPersistedState from 'vuex-persistedstate'
// 存到local的数据
// const dataLocal =
// 存到session的数据
// const dataSession =


export default createStore({
  modules: {
    config,
    history,
    shortVideo,
    user
  },
  plugins: [createPersistedState({
    storage: window.localStorage,
    key: 'vueX',
    reducer(val) {
      return {
        // 只存储state中的userState
        history: val.history,
        user: val.user
      }
    }
  })]
})





