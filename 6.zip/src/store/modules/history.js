const state = {
  // 搜索历史列表
  saerchlist: [],
  // 长视频列表
  avList: [],
  // 短视频列表
  shortList: [],
  // 动漫视频列表
  cartoonList: [],
  // av分类默认index
  avIndex:0,
  // 小视频分类默认index
  shortVideoIndex:0,
  // 动漫分类默认index
  cartoonIndex:0,
  // 社区分类默认index
  communityIndex:0,

  //书架
  bookshelfList:[
    {id:'默认分组',name:'默认分组',list:[] }
  ], 
  //个人中心-漫画浏览历史
  comicsHisList:[],  
  //漫画当前章节保存
  comicChapterObj:{},
}
const getters = {
  getSaerchlist(state) {
    return state.saerchlist
  },
  avList(state) {
    return state.avList
  },
  shortList(state) {
    return state.shortList
  },
  cartoonList(state) {
    return state.cartoonList
  },
  avIndex(state) {
    return state.avIndex
  },
  shortVideoIndex(state) {
    return state.shortVideoIndex
  },
  cartoonIndex(state) {
    return state.cartoonIndex
  },
  communityIndex(state){
    return state.communityIndex
  }
}

const mutations = {
  //设置书架默认分组最多100个
  setBookshelf(state, list){
    state.bookshelfList=list;  
  },
  //漫画收藏
  setComicsHisList(state, obj){
    if (obj.type == "add") {
      let status = state.comicsHisList.some((item) => { return item.id == obj.item.id });
      if (!status) {
        if (state.comicsHisList.length > 50) {
          state.comicsHisList = state.comicsHisList.splice(0, 50);
        };
        state.comicsHisList.unshift(obj.item);
      }
    } else if (obj.type == "delOne") {
      state.comicsHisList.splice(obj.index, 1);
    } else if (obj.type == "delAll") {
      state.comicsHisList = [];
    }    
  }, 
  //漫画当前章节保存
  setComicChapterObj(state, obj){
    state.comicChapterObj=obj;
  },   
  SET_SEARCHLIST(state, item) {
    if (item.type === 'add') {
      if (state.saerchlist.length > 0) {
        state.saerchlist.map((sItme, sIndex) => {
          if (sItme === item.value) {
            state.saerchlist.splice(sIndex, 1)
          }
        })
        state.saerchlist.push(item.value)
      } else {
        state.saerchlist.push(item.value)
      }
    } else if (item.type === 'del') {
      state.saerchlist.splice(item.value, 1)
    } else {
      state.saerchlist = item.value
    }
  },
  // av视频
  SET_AVLIST(state, item) {
    if (item.type === 'add') {
      item.item.clickMask = false
      if (state.avList && state.avList.length > 0) {
        state.avList.map((sItme, sIndex) => {
          if (sItme.id === item.item.id) {
            state.avList.splice(sIndex, 1)
          }
        })
        state.avList.push(item.item)
      } else {
        state.avList.push(item.item)
      }
    } else if (item.type === 'del') {
      state.avList = state.avList.filter((o) => {
        return !item.arr.includes(o.id)
      });
    } else {
      state.avList = [...item.item]
    }
  },
  // 短视频
  SET_SHORTLIST(state, item) {
    if (item.type === 'add') {
      item.item.clickMask = false
      if (state.shortList && state.shortList.length > 0) {
        state.shortList.map((sItme, sIndex) => {
          if (sItme.id === item.item.id) {
            state.shortList.splice(sIndex, 1)
          }
        })
        state.shortList.push(item.item)
      } else {
        state.shortList.push(item.item)
      }
    } else if (item.type === 'del') {
      state.shortList = state.shortList.filter((o) => {
        return !item.arr.includes(o.id)
      });
    } else {
      state.shortList = [...item.item]
    }
  },
  // 动漫
  SET_CARTOON(state, item) {
    if (item.type === 'add') {
      item.item.clickMask = false
      if (state.cartoonList && state.cartoonList.length > 0) {
        state.cartoonList.map((sItme, sIndex) => {
          if (sItme.id === item.item.id) {
            state.cartoonList.splice(sIndex, 1)
          }
        })
        state.cartoonList.push(item.item)
      } else {
        state.cartoonList.push(item.item)
      }
    } else if (item.type === 'del') {
      state.cartoonList = state.cartoonList.filter((o) => {
        return !item.arr.includes(o.id)
      });
    } else {
      state.cartoonList = [...item.item]
    }
  },
  SET_AVINDEX(state,id){
    state.avIndex = id
  },
  SET_SHORTVIDEOINDEX(state,id){
    state.shortVideoIndex = id
  },
  SET_CARTOONINDEX(state,id){
    state.cartoonIndex = id
  },
  SET_COMMUNITYINDEX(state,id){
    state.communityIndex = id
  },
}
const actions = {
  setAvList({ commit }, item) {
    commit('SET_AVLIST', item)
  },
  setShortList({ commit }, item) {
    commit('SET_SHORTLIST', item)
  },
  setSaerchlist({ commit }, item) {
    commit('SET_SEARCHLIST', item)
  },
  setCartoonList({ commit }, item) {
    commit('SET_CARTOON', item)
  },
  setAvIndex({ commit }, item){
    commit('SET_AVINDEX', item)
  },

}
export default {
  state,
  mutations,
  actions,
  getters
}
