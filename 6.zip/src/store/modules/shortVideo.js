const state = {
  // 播放数据
  list: [],
  // 当前短视频播放的列表的索引
  historyShortVideoIndex: 0,
  // 当前短视频播放的列表的索引(推荐)
  shortVideoRemInfo: null,  
  // 当前短视频播放的列表的索引(关注)
  shortVideoFocusInfo: null,    
}
const getters = {
  getShortVideoList(state) {
    return state.list
  },
  getHistoryShortVideoIndex(state){
    return state.historyShortVideoIndex
  },
  // (推荐)
  getShortVideoRemInfo(state) {
    return state.shortVideoRemInfo
  },  
  // (关注)
  getShortVideoFocusInfo(state) {
    return state.shortVideoFocusInfo
  },   
}
const mutations = {
  // (推荐)
  setShortVideoRemInfo(state, item) {
    state.shortVideoRemInfo = item
  }, 
  // (关注) 
  setShortVideoFocusInfo(state, item) {
    state.shortVideoFocusInfo = item
  },   
  SET_VIDEOLIST(state, list) {
    state.list = list
  },
  SET_SHORT_VIDEO_INDEX(state, index) {
    state.historyShortVideoIndex = index
  },
}
export default {
  state,
  mutations,
  getters
}
