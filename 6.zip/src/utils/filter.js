// 数字转换
export function numberFilter(v) {
  if (!v) {
    return 0
  }
  if (v < 10000) {
    return v
  }
  const value = v / 10000
  return Number.isInteger(value) ? value + '万' : value.toFixed(1) + '万'
}

// 金额单位转换  分转元(默认保留0位小数)
export function changeGold(v,fixedNum) {
  if (v) {
    if(fixedNum) return (v / 100).toFixed(fixedNum)
    if(!fixedNum) return (v / 100).toFixed(0)
  } else {
    return 0
  }
}

// 秒转化成 时分秒
export function secondToDate(v) {
  const date = new Date(v)
  var h = Math.floor(date / 3600 % 24);
  var m = Math.floor((date / 60 % 60))
  var s = Math.floor((date % 60))
  if (h < 10) {
    h = '0' + h
  }
  if (m < 10) {
    m = '0' + m
  }
  if (s < 10) {
    s = '0' + s
  }
  v = h + ':' + m + ':' + s
  return v
}

// 时间差转换
export function timeDiff(v) {
  let result = ''
  const date = Date.parse(v)
  const minute = 1000 * 60
  const hour = minute * 60
  const day = hour * 24
  const month = day * 30
  const now = new Date().getTime()
  const diffValue = now - date
  if (diffValue < 0) { return }
  const monthC = diffValue / month
  const weekC = diffValue / (7 * day)
  const dayC = diffValue / day
  const hourC = diffValue / hour
  const minC = diffValue / minute
  if (monthC >= 1) {
    result = '' + parseInt(monthC) + '月前'
  } else if (weekC >= 1) {
    result = '' + parseInt(weekC) + '周前'
  } else if (dayC >= 1) {
    result = '' + parseInt(dayC) + '天前'
  } else if (hourC >= 1) {
    result = '' + parseInt(hourC) + '小时前'
  } else if (minC >= 1) {
    result = '' + parseInt(minC) + '分钟前'
  } else { result = '剛剛' }
  return result
}

// 返回时间格式为: yy-mm-dd
export function formatDate(v) {
  const date = new Date(v)
  const Y = date.getFullYear() + '-'
  const M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-'
  const D = date.getDate() + ' '
  const h = date.getHours() + ':'
  const m = date.getMinutes() + ':'
  const s = date.getSeconds()
  return (Y + M + D + h + m + s)
}

// 返回时间格式为: yy-mm-dd
export function timeYmd(v) {
  const date = new Date(v)

  const Y = date.getFullYear() + '-'
  const M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-'
  const D = date.getDate() + ' '

  return (Y + M + D)
}

// 罩杯转换
export function fillterCup(v) {
  const cupData = [
    { id: 1, name: 'B罩杯' },
    { id: 2, name: 'C罩杯' },
    { id: 3, name: 'D罩杯' },
    { id: 4, name: 'E罩杯' },
    { id: 5, name: 'F罩杯' },
    { id: 6, name: 'G罩杯' },
    { id: 7, name: 'H罩杯' },
    { id: 8, name: 'I罩杯' },
    { id: 9, name: 'J罩杯' },
    { id: 10, name: 'K罩杯' },
    { id: 11, name: 'L罩杯' }
  ]
  const res = cupData.filter((item) => {
    return item.id === v
  })
  if (res && res[0]) {
    return res[0].name
  } else {
    return ''
  }
}

// 聊天时间
export function filterTime(string) {
  let hour = parseInt(string.substring(0, 2))
  hour + 8 > 23 ? (hour = hour + 8 - 24) : (hour = hour + 8)
  let minutes = string.substring(3, 8)
  return hour + ':' + minutes
}