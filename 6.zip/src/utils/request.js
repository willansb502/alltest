import axios from 'axios'
import store from '@/store/index'
import router from '@/router'
import { showToast , showDialog} from 'vant';

let havegetYkInfo=false;
import { decodeDataToHttpResponse, decodeParamToHttpRequest } from '@/utils/utils_tools'
// // 根据环境不同引入不同api地址
const baseApi='https://app.stgx1w.com/'
import { ykInfo } from '@/api/user'
import UAParser from "ua-parser-js"
import $device from "current-device"

// create an axios instance
const service = axios.create({
  baseURL: baseApi, // url = base api url + request url
  withCredentials: false, // send cookies when cross-domain requests
  timeout: 600000, // request timeout
  headers: {
    'Content-Type': 'application/json'
  }
})
service.setToken = (token) => {
  service.defaults.headers['Authorization'] = token
  store.dispatch('setToken', token)
}
// 是否正在刷新的标记
let isRefreshing = false
// 重试队列，每一项将是一个待执行的函数形式
let requests = []
// request拦截器 request interceptor
service.interceptors.request.use(
  config => {
    // 设置x-user-agent
    const userAgent = config.headers['user-agent']
    const obj = new UAParser(userAgent)
    const results = obj.getResult()

    let DevType = results.device.vendor + ' ' + results.device.model + ' ' + results.device.type
    if (!results.device.vendor || !results.device.model || !results.device.type) {
      DevType = 'Apple iPhone mobile'
    }

    const BuildID = results.browser.name + ' ' + results.browser.version
    config.headers.serect = 'kaFttDJRcahRMTI7' // kaFttDJRcahRMTI7  fkf34lKD9344s6F8
    const Ver = store.state.config.ver;
    let SysType = '';
    if ($device.desktop()){ //pc端
      SysType = 'h5_pc';
    }else if ($device.android()) {//安卓
      if (router.history&&router.history.current.query.dec) {
        store.dispatch('setPhoneDevice', router.history.current.query.dec)
      }
      if (store.getters['getUserDevice']) {
        SysType = 'android'
      } else {
        SysType = 'h5_android'
      }
    }else if ($device.ios()) { //ios端
      navigator.standalone ? SysType = 'ios' : SysType = 'h5_ios' 
    }
    //保存设备信息
    store.dispatch('setIsAnIosPhone', SysType); 
    //提前存贮用户pc dc
    getChannel();

    config.headers['X-User-Agent'] = 'DevType=' +
      DevType +
      ';' +
      'SysType=' +
      SysType +
      ';' +
      'Ver=' +
      Ver +
      ';' +
      'BuildID=' +
      BuildID
    // 配置加密信息
    const XUserAgent = config.headers['X-User-Agent']
    const token = store.getters['getToken']
    const apiPath = config.url
    const serect = config.headers.serect
    config.headers['x-api-key'] = decodeParamToHttpRequest({ token, apiPath, XUserAgent, serect })
    config.headers.Authorization = token
    if (process.env.NODE_ENV !== 'production') {
      console.log('Making request to ' + config.url)
    }
    if(config.url=='/api/app/upload/images'){
      config.headers['Content-Type']='multipart/form-data'
    }else{
      config.headers['Content-Type']='application/json'
    }
    return config
  },
  error => {
    // do something with request error
    console.log(error) // for debug
    return Promise.reject(error)
  }
)
// respone拦截器
service.interceptors.response.use(
  async response => {
    const res = response.data
    if (res.code && res.code === 200) {
      if (response.headers && response.headers['refresh-authorization'] && response.headers['refresh-authorization'] !== '') {
        store.dispatch('setToken', response.headers['refresh-authorization'])
      }
    }
    // 调用游客生成方法
    if (res.code === 1000 || res.code === 1015) {
      // if(router.history.current.path!="/") await newUser(res.code, response.config)
      const config = response.config
      if (!isRefreshing) {
        isRefreshing = true
        if (!store.getters['getUid']) {
          const hasUID = Number(Math.random().toString().substr(2, 8) + Date.now()).toString(36)
          await store.dispatch('setUid', hasUID)
        }
        await store.dispatch('clearInfo')        
        return ykInfo({
          affCode: getChannel() ? JSON.stringify(store.getters['getChannel']) : '{}',
          devID: store.getters['getUid']
        }).then(res => {
          const { token } = res.data
          service.setToken(token)
          config.headers['Authorization'] = token
          requests.forEach(cb => cb(token))
          requests = []
          config.baseURL = baseApi
          return service(config)
        }).catch(res => {
          console.error('refreshtoken error =>', res)
          window.location.href = '/'
        }).finally(() => {
          isRefreshing = false
        })
      } else {
        // 正在刷新token，将返回一个未执行resolve的promise
        return new Promise((resolve) => {
          // 将resolve放进队列，用一个函数形式来保存，等token刷新后直接执行
          requests.push((token) => {
            config.baseURL = baseApi
            config.headers['Authorization'] = token
            resolve(service(config))
          })
        })
      }
    }
    return decodeDataToHttpResponse(res)
  },
  async error => {
    console.log(error)
    const res = error.response.data
    // 调用游客生成方法
    if (res.code === 1000 || res.code === 1015) {
      if(router.history.current.path!="/") await newUser(res.code, error.response.config)
    } else {
      console.log('err' + error) // for debug
      return Promise.reject(error)
    }
  }
)
// code码，错误的请求参数
async function newUser(params, config) {
  if(havegetYkInfo) return;
  havegetYkInfo=true; 
  if (params === 1000) {
    await store.dispatch('clearInfo')
    // 刷新token操作
    if (!store.getters['getUid']) {
      const hasUID = Number(Math.random().toString().substr(2, 8) + Date.now()).toString(36)
      await store.dispatch('setUid', hasUID)
    } 
    if (!store.getters['getToken']) {
      const res = await ykInfo({
        affCode: getChannel() ? JSON.stringify(store.getters['getChannel']) : '{}',
        devID: store.getters['getUid']
      })
      if (res && res.code === 200) {
        await store.dispatch('setUserInfo', res.data)
        await store.dispatch('setToken', res.data.token)
      } else {
        showToast(res.tip)
      }
    } else {
      await store.dispatch('setToken', store.getters['getToken'])
    }
    // 替换错误请求的token
    config.headers.Authorization = store.getters['getToken']
    return location.reload()


  } else if (params === 1015) {
    await store.dispatch('clearInfo')
    showDialog.confirm({
      title: '友情提示',
      message: '账号不能同时在两个客户端登录！',
      confirmButtonText: '重新登陆',
      cancelButtonText: '游客进入'
    }).then(async () => {
      await store.dispatch('clearUid')
      router.push('/mine/login')
    }).catch(() => {
      //  替换错误请求的token
      config.headers.Authorization = store.getters['getToken']
      return location.reload()
    })
  }
}
// 获取渠道参数
function getChannel() {
  let hasDC = ""
  let hasPC = ""
  //计费方式/#/home?dc=LWEU2LVQ&billingType=cps
  const billingType = router.currentRoute.value.query && router.currentRoute.value.query.billingType
  if(store.getters['getIsAnIosPhone']=='android'&&DemaxiyaClipboardManager){
    let copied = DemaxiyaClipboardManager.getStringFromClipboard()
    if(copied&&copied.includes('dc')) hasDC = JSON.parse(copied).dc
    if(copied&&copied.includes('pc')) hasPC = JSON.parse(copied).pc
  }else{
    hasDC = router.currentRoute.value.query && router.currentRoute.value.query.dc
    hasPC = router.currentRoute.value.query && router.currentRoute.value.query.pc
  }

  //先贮存，下载轻量版需要用
  if (hasDC) {
    store.dispatch('setParams', {
      key: 'dc',
      data: hasDC
    })
  }
  if (hasPC) {
    store.dispatch('setParams', {
      key: 'pc',
      data: hasPC
    })
  }
  //h5计费方式是cps或者app端存在则记录
  if (hasDC&&store.getters['getIsAnIosPhone'].includes('h5')&&billingType=='cps'
      ||hasDC&&store.getters['getIsAnIosPhone']=='android'
      ||hasDC&&store.getters['getIsAnIosPhone']=='ios') {
    return 'dc'
  }
  //app端才计算pc，客户邀请用
  if (hasPC&&store.getters['getIsAnIosPhone']=='android'
      ||hasPC&&store.getters['getIsAnIosPhone']=='ios') {
    return 'pc'
  }
}
export default service
