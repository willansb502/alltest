import CryptoJS from 'crypto-js'
import $device from "current-device"
const baseData= import.meta.env
import router from '@/router'
import { showToast } from 'vant';
import axios from 'axios'
import store from '@/store/index'
import useClipboard from 'vue-clipboard3'
const { toClipboard } = useClipboard()



import { IMAGE_DB_CONFIG, IMAGE_DB_KEY, SAVE_COUNT_MAX_KEY, START_IMAGE_DB_KEY } from '../config/imgConfig'
import { decodeHttpResponseData } from './decodeResponceData'
import { decryptImage } from './imgCode'

//漫画api
import { comicsPay, comicsChapterIsLook, comicsChapterPics } from '@/api/comics' //api列表

const {
  store_name,
  table_name,
  db_option
} = IMAGE_DB_CONFIG

/**
 * 解密图片
 * @param {string} [KEY] - 图片解密密钥【主要是使用密钥的长度】
 */

import { Buffer } from 'buffer'
const KEY = Buffer.from('2019ysapp7527')

// 图片解密加自动保存
export function handleVerAutoImg(linkImg) {
  return new Promise(async (resolve, reject) => {
    if (!linkImg || !linkImg.length || !linkImg.includes('.')) resolve(false)
    const linkArray = linkImg.split('.')
    try {
      // 判断是否使用本地储存 还是使用网络请求

      if (!IMAGE_DB_CONFIG[START_IMAGE_DB_KEY]) {
        const originBase64 = await getImgBuffer()
        resolve(originBase64)
      } else {
        const ImageDB = IMAGE_DB_CONFIG[IMAGE_DB_KEY]
        if (!window.indexedDB || !ImageDB || ImageDB === undefined) {
          const originBase64 = await getImgBuffer()
          resolve(originBase64)
        }
        // 获取图片存储对象 并检测本地是否存储
        const transaction = ImageDB.transaction(store_name, db_option)
        const objectStore = transaction.objectStore(store_name)
        const index = objectStore.index(table_name)
        const response = index.get(linkImg)
        // 本地图片检测失败
        response.onerror = async function (event) {
          const originBase64 = await getImgBuffer()
          resolve(originBase64)
        }
        response.onsuccess = async function (event) {
          // 检测到本地存储有图片直接返回图片base64
          if (response.result !== undefined && response.result) {
            const { imgData } = response.result
            resolve(imgData)
          } else { // 本地没有缓存图片 下载后 压缩图片并直接存储 base64
            const base64Image = await getImgBuffer()
            const transaction = ImageDB.transaction(store_name, db_option)
            const objectStore = transaction.objectStore(store_name)
            const saveRes = objectStore.put({ src: linkImg, imgData: base64Image })
            saveRes.onsuccess = function () {
              // 判断存储是否已经达到上限 到达上限循环写入
              const saveIsMax = IMAGE_DB_CONFIG[SAVE_COUNT_MAX_KEY]
              if (!saveIsMax) return
              // 获取数据库第一个存储对象删除
              const keyRangeValue = IDBKeyRange.lowerBound(1)
              objectStore.openCursor(keyRangeValue).onsuccess = function (event) {
                const cursor = event.target.result
                if (cursor) cursor.delete()
              }
            }
            resolve(base64Image)
          }
        }
      }
    } catch (e) {
      reject(e)
    }
    function getBase64(result) {
      const bufArr = window.btoa(result)
      const baseImage = bufArr.substring(bufArr.indexOf(',') + 1)
      const realBase64 = 'data:image/'.concat(linkArray[linkArray.length - 1], ';base64,').concat(baseImage)
      return realBase64
    }

    function getImgBuffer() {
      return new Promise((resolve, reject) => {
        axios.get(linkImg, { responseType: 'arraybuffer', timeout: 100000 }).then((res) => {
          const data = res.data
          let binary = ''
          const bytes = new Uint8Array(data)
          const decryptBytes = decryptImage(bytes)

          const len = decryptBytes.byteLength
          for (let i = 0; i < len; i++) {
            binary += String.fromCharCode(decryptBytes[i])
          }
          resolve(getBase64(binary))
        }).catch((e) => reject(e))
      })
    }
  })
}

/**
 * 单图解密图片主方法【被动调用方法】
 * @param {string} [linkImg] - 图片地址
 */
export function handleVerImg(linkImg) {
  return new Promise((resolve) => {
    axios
      .get(linkImg, { responseType: 'arraybuffer', timeout: 100000 })
      .then((res) => {
        const data = res.data
        const bytes = new Uint8Array(data)
        for (let i = 0; i < 100; i++) {
          bytes[i] ^= KEY[i % KEY.length]
        }
        // const type = 'data:image/png;base64'
        // const imgBase64 = type + transformArrayBufferToBase64(bytes);
        resolve(bytes)
        // resolve((window.URL) ? window.URL.createObjectURL(new Blob([bytes])) : window.webkitURL.createObjectURL(new Blob([bytes])))
      }).catch(err => {
        console.log(err);
      })
  })
}
export function handleVideoURL(linkImg) {
  return new Promise((resolve) => {
    axios
      .get(linkImg)
      .then((res) => {
        const bytes = new Uint8Array(res.data)
        resolve((window.URL) ? window.URL.createObjectURL(new Blob([bytes])) : window.webkitURL.createObjectURL(new Blob([bytes])))
      }).catch(err => {
        console.log(err);
      })
  })
}
// 请求参数加密
export function decodeParamToHttpRequest(params) {
  const { token, apiPath, XUserAgent, serect } = params
  const timestamp = parseInt(new Date(new Date().toUTCString()).getTime() / 1000)
  const nonce = getUuid()
  const signSting = token + '&' + apiPath + '&' + XUserAgent + '&' + timestamp.toString() + '&' + nonce
  // console.log('计算内容',signSting, 'token====+',token, 'apiPath====+',apiPath, 'XUserAgent====+',XUserAgent, 'serect====+',serect)

  const Sha1Encrypt = CryptoJS.HmacSHA1(signSting, serect)
  // console.log('计算结果', Sha1Encrypt)
  return `timestamp=${timestamp};sign=${Sha1Encrypt};nonce=${nonce}`
  function getUuid() {
    const s = []
    const hexDigits = '0123456789abcdef'
    for (let i = 0; i < 36; i++) {
      s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1)
    }
    s[14] = '4'
    s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1)
    s[8] = s[13] = s[18] = s[23] = '-'

    return s.join('')
  }
}
// 返回数据解密
export function decodeDataToHttpResponse(params) {
  if (params.code === 200 && params.hash) {
    const data = params.data
    params.data = JSON.parse(decodeHttpResponseData(data))
    return params
  } else {
    return params
  }
}

export function isUcOrBaiduOrShougouBrowser(params) {
  if (process.client) {
    const ua =
      navigator.userAgent.toLowerCase() ||
      window.navigator.userAgent.toLowerCase() ||
      ''
    const isUC = /UCBrowser|ucbrowser|UCWEB/.test(ua)
    const isBAIDU = /baidu|baiduboxapp|BAIDUBrowser|baidubrowser|baidumobilebrowser/.test(
      ua
    )
    const isSG = /sogoumobilebrowser|SE|MetaSr/.test(ua)
    const isWEIBO = /Weibo|weibo/.test(ua)
    return {
      isUC,
      isBAIDU,
      isSG,
      isWEIBO
    }
  }
}
export function getParams(url) {
  if (url === 'yinseinner://hq_wallet' || url === 'yinseinner://hq_home_hookup' || url === 'yinseinner://hq_sign_in_page' || url === 'yinseinner://hq_share_promotion') {
    const resultes = {
      urlParent: url
    }
    return resultes
  }
  if (url) {
    const str = url.split('?')
    const resultes = {
      urlParent: str[0]
    }
    if (str.length && str.length > 1) {
      const q = str[1].split('&')
      for (let i = 0; i < q.length; i++) {
        resultes[q[i].split('=')[0]] = unescape(q[i].split('=')[1])
      }
      return resultes
    }

    return resultes
  }
}
/**
 *
 * @param
 * typeCode:
 * @returns
 * // 视频 yinseinner://hq_video?id=
// 短视频 yinseinner://hq_player_list?id=
// 漫画 yinseinner://hq_comics?id=

/comics/decial/21752
// 钱包 yinseinner://hq_wallet
// vip yinseinner://hq_vip?tab=
// 演员 yinseinner://hq_user_center?id=
// 分享 yinseinner://hq_share_promotion
// 更多 专题 yinseinner://hq_topic?id=&title=
// 女优 yinseinner://hq_actress_detail_page?id=
// 厂商 yinseinner://hq_vendor_detail_page?id=
// 帖子详情 yinseinner://hq_post_detail_page?id=
// 商家详情 yinseinner://hq_bosses_detail?id=
// 活动详情 yinseinner://hq_activity_detail_page?name=
//  yinseinner://hq_sign_in_page 签到活动页
// 游戏充值yinseinner://hq_game_recharger_page
// 直接播放yinseinner://hq_simple_player_page?url=/sp/av/3a4exxx.m3u8&w=1920&h=1080
// 全名代理页面     yinseinner://hq_member_agent_page
  对应底部 tabbar   yinseinner://hq_home?tab=4
 */
export function handleURlParams(url) {
  const params = getParams(url)
  const paramsTyep = {
    ...params,
    typeCode: ''
  }
  if (params) {
    if (params.hasOwnProperty('urlParent')) {
      switch (params.urlParent) {
        // 视频
        case 'yinseinner://hq_video':
          // 存在视频id 则跳往播放页面
          if (params.hasOwnProperty('id')) {
            paramsTyep.typeCode = 1
            return paramsTyep
          }
          break
        // 短视频
        case 'yinseinner://hq_player_list':
          // 存在短视频id 则跳往短视频播放页面
          if (params.hasOwnProperty('id')) {
            paramsTyep.typeCode = 2
            return paramsTyep
          }
          break
        // 钱包
        case 'yinseinner://hq_wallet':
          // 直接跳转钱包页
          paramsTyep.typeCode = 3
          return paramsTyep

        // 活动
        case 'yinseinner://hq_activity_detail_page':
          // 存在活动name 则跳往活动页面
          if (params.hasOwnProperty('name')) {
            paramsTyep.typeCode = 4
            return paramsTyep
          }
          break
        // vip
        case 'yinseinner://hq_vip':
          // 存在tab 则代表是跳vip
          if (params.hasOwnProperty('tab')) {
            paramsTyep.typeCode = 5
            return paramsTyep
          }
          break
        // 演员
        case 'yinseinner://hq_user_center':
          // 存在演员id 则跳往演员详情
          if (params.hasOwnProperty('id')) {
            paramsTyep.typeCode = 6
            return paramsTyep
          }
          break
        // 帖子
        case 'yinseinner://hq_post_detail_page':
          // 存在帖子id 则跳往帖子详情
          if (params.hasOwnProperty('id')) {
            paramsTyep.typeCode = 7
            return paramsTyep
          }
          break
        // 女优
        case 'yinseinner://hq_actress_detail_page':
          if (params.hasOwnProperty('id')) {
            paramsTyep.typeCode = 8
            return paramsTyep
          }
          break
        // 厂商
        case 'yinseinner://hq_vendor_detail_page':
          if (params.hasOwnProperty('id')) {
            paramsTyep.typeCode = 9
            return paramsTyep
          }
          break
        // 分享
        case 'yinseinner://hq_share_promotion':
          // 跳往分享
          paramsTyep.typeCode = 10
          return paramsTyep
        // 全民代理
        case 'yinseinner://hq_member_agent_page':
          // 全民代理
          paramsTyep.typeCode = 11
          return paramsTyep
        // 直接播放
        case 'yinseinner://hq_simple_player_page':
          if (params.hasOwnProperty('url')) {
            paramsTyep.typeCode = 13
            return paramsTyep
          }
          break
        // 更多专题
        case 'yinseinner://hq_topic':
          if (params.hasOwnProperty('id')) {
            paramsTyep.typeCode = 14
            return paramsTyep
          }
          break
        // 签到活动页
        case "yinseinner://hq_sign_in_page":
          paramsTyep.typeCode = 15
          return paramsTyep

        // 更多专题
        case 'yinseinner://hq_home':
          if (params.hasOwnProperty('tab')) {
            paramsTyep.typeCode = 16
            return paramsTyep
          }
          break
        case 'yinseinner://hq_home_hookup':
        // 嫩模发布体验
          paramsTyep.typeCode = 21
          return paramsTyep
        // 漫画
        case 'yinseinner://hq_comics':
          if (params.hasOwnProperty('id')) {
            paramsTyep.typeCode = 22
            return paramsTyep
          }
          break
        // 约炮商家详情
        case 'yinseinner://hq_bosses_detail':
          if (params.hasOwnProperty('id')) {
            paramsTyep.typeCode = 23
            return paramsTyep
          }
          break
        default:
          return url
      }
    }
  } else {
    return paramsTyep
  }
}

// 判断type code 处理相关逻辑
export async function handleParamsRouteJump(type) {
  if (type.typeCode) {
    switch (type.typeCode) {
      case 1:
        // 跳到播放页
        router.push('/play/' + Number(type.id))
        break
      // 跳到短视频播放页
      case 2:
        router.push({ path: `/short_video/play`, query: { detailId: type.id } })
        break
      case 3:
        // 跳到钱包
        router.push('/mine/my-wallet')
        break
      case 4:
        // 跳到活动详情
        router.push(`/activity/detail/${type.name}`)
        break
      case 5:
        // 跳到会员卡页面
        router.push('/vip')
        break
      case 6:
        // 跳到演员详情
        router.push('/actor/detail/' + Number(type.id))
        break
      case 7:
        // 跳到帖子详情
        router.push('/community/detail/' + Number(type.id))
        break
      case 8:
        router.push('/actor-detail/' + Number(type.id))
        break
      case 9:
        router.push('/actor-detail/' + Number(type.id))
        break
      case 10:
        // 分享页面
        router.push('/mine/share')
        break
      case 11:
        router.push('/mine/agent')
        break
      case 13:
        // ref.fn_playVideo(type.url)
        break
      case 14:
        // 专题
        router.push('/media_detail/' + Number(type.id) + '?title=' + type.title)
        break
      case 15:
        // 签到
        router.push('/signIn')
        break
      // 页面内跳转
      case 16:
        if (type.tab == 0) {
          return router.push('/')
        }
        if (type.tab == 1) {
          return router.push('/home')
        }
        if (type.tab == 2) {
          return router.push('/comics')
        }
        if (type.tab == 3) {
          return router.push('/community')
        }
        if (type.tab == 4) {
          return router.push('/vip')
        }
        if (type.tab == 5) {
          return router.push('/mine')
        }
        break
      case 21:
        router.push('/dating')
        break
      case 22:
        router.push('/comics/decial/' + Number(type.id))
        break
      case 23:
        router.push('/bosses/detail/' + Number(type.id))
        break
      // 直接跳转
      default:
        window.open(type.urlParent)
    }
  } else {
    window.open(type)
  }


}

// 中间件下载图片转blob
export function dataURItoBlob(base64Data) {
  var byteString
  if (base64Data.split(',')[0].indexOf('base64') >= 0) {
    byteString = window.atob(base64Data.split(',')[1])
  } else {
    // base64 解码
    byteString = unescape(base64Data.split(',')[1])
  }
  var mimeString = base64Data.split(',')[0].split(':')[1].split(';')[0] // mime类型 -- image/png

  // var arrayBuffer = new ArrayBuffer(byteString.length); //创建缓冲数组
  // var ia = new Uint8Array(arrayBuffer);//创建视图
  var ia = new Uint8Array(byteString.length) // 创建视图
  for (var i = 0; i < byteString.length; i++) {
    ia[i] = byteString.charCodeAt(i)
  }
  var blob = new Blob([ia], {
    type: mimeString
  })
  return blob
}

//  根据所需金币判断当前用户是否有足够金币购买  price 所需金币
export function canBuy(store, price) {
  if (store.state.user.info.balance / 100 < price / 100) {
    return false
  } else {
    return true
  }
}


// 单图、多图压缩
export function imgsCompress(fileList) {
  const promises = fileList.map((element) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.readAsDataURL(element.file)
      reader.onload = e => {
        const image = new Image()
        image.src = e.target.result
        image.onload = function () {
          // 默认压缩后图片规格
          const quality = 0.5
          const w = this.width
          const h = this.height
          const canvas = document.createElement('canvas')
          const context = canvas.getContext('2d')
          canvas.width = w
          canvas.height = h
          context.drawImage(image, 0, 0, w, h)
          canvas.toBlob(
            blob => {
              const strName = element.file.name.split('.')[0] + '.jpeg'
              const obj = new File([blob], strName, { type: 'image/jpeg', lastModified: new Date() })
              resolve(obj)
            },
            'image/jpeg',
            quality
          )
        }
      }
    })
  })
  return Promise.all(promises)
}

// fn是我们需要包装的事件回调, delay是时间间隔的阈值
export function throttle(fn, delay) {
  // last为上一次触发回调的时间, timer是定时器
  let last = 0,
    timer = null;
  // 将throttle处理结果当作函数返回
  return function () {

    // 保留调用时的this上下文
    let context = this;
    // 保留调用时传入的参数
    let args = arguments;
    // 记录本次触发回调的时间
    let now = +new Date();
    // 判断上次触发的时间和本次触发的时间差是否小于时间间隔的阈值
    if (now - last < delay) {
      // 如果时间间隔小于我们设定的时间间隔阈值，则为本次触发操作设立一个新的定时器
      clearTimeout(timer);
      timer = setTimeout(function () {
        last = now;
        fn.apply(context, args);
      }, delay);
    } else {
      // 如果时间间隔超出了我们设定的时间间隔阈值，那就不等了，无论如何要反馈给用户一次响应
      last = now;
      fn.apply(context, args);
    }
  };
}

export function isIphonex() { // 判断是不是X类型手机
  // X XS, XS Max, XR，11， 11pro，11pro max，12mini，12， 12 pro，12 pro max
  const xSeriesConfig = [
    {
      devicePixelRatio: 3,
      width: 375,
      height: 812,
    },
    {
      devicePixelRatio: 3,
      width: 414,
      height: 896,
    },
    {
      devicePixelRatio: 2,
      width: 414,
      height: 896,
    },
    {
      devicePixelRatio: 3,
      width: 315,
      height: 812,
    },
    {
      devicePixelRatio: 3,
      width: 390,
      height: 844,
    },
    {
      devicePixelRatio: 3,
      width: 428,
      height: 926,
    }
  ];
  // h5
  if (typeof window !== 'undefined' && window) {
    const isIOS = /iphone/gi.test(window.navigator.userAgent);
    if (!isIOS) return false;
    const { devicePixelRatio, screen } = window;
    const { width, height } = screen;
    return xSeriesConfig.some(item => item.devicePixelRatio === devicePixelRatio && item.width === width && item.height === height);
  }
  return false;
}

//章节权限跳转  this 和章节id
export async function picViewRightTo(picsId) {
  let popupMsg = ref(null)
  let routeObj = { id: "", nowPage: "" };
  //漫画预览页
  if (router.currentRoute.value.path.includes("/comics/pic-view/")) {
    routeObj.id = +router.currentRoute.value.query.parentId;
    routeObj.nowPage = "pic-view";
  }
  //漫画介绍页
  if (router.currentRoute.value.path.includes("/comics/decial/")) {
    routeObj.id = +router.currentRoute.value.params.id;
    routeObj.nowPage = "decial";
  }
  const resOne = await comicsChapterIsLook({
    id: picsId,
  });
  // console.log(resOne.data)
  if (resOne.data.code == 200 && !resOne.data.playable) return showToast("请开通会员或购买章节");;
  //需要开通会员接口1
  if (resOne.data.code == 6094) {
    popupMsg.popupMsg = {
      show: true,
      title: '温馨提示',
      content: '您目前尚未成为vip，可立即前往成为VIP',
      type: 'text',
      ok: '立即前往',
      cancel: '',
      position: 'bottom',
      cb: async (returnData) => {
        router.push('/vip');
      }
    };
    return;
  } else if (resOne.data.code == 6095) {
    popupMsg.popupMsg = {
      show: true,
      title: '温馨提示',
      content: '付费即可观看本漫画',
      type: 'text',
      ok: '立即购买',
      cancel: '',
      position: 'bottom',
      cb: async (returnData) => {
        const res = await comicsPay({
          id: routeObj.id
        })
        if (res.code === 200) {
          popupMsg.popupMsg.show = false;
          showToast('购买成功');
        } else {
          router.push('/mine/my-wallet');
          return showToast(res.tip);
        }

      }
    };
    return;
  }

  //需要开通会员接口2
  showToast("加载章节中...");
  const res = await comicsChapterPics({
    id: picsId,
  });
  if (res.data && res.code === 200) {
    store.commit('setComicChapterObj', res.data);
    if (routeObj.nowPage == "pic-view") {
      router.replace({
        path: `/comics/pic-view/` + picsId,
        query: {
          parentId: router.currentRoute.value.query.parentId
        }
      })
    } else {
      router.push({
        path: `/comics/pic-view/` + picsId,
        query: {
          parentId: router.currentRoute.value.params.id
        }
      })
    }
    return 200;
  } else {
    //需要开通会员
    if (res.data.code == 6032 || res.data.code == 6101) {
      popupMsg.popupMsg = {
        show: true,
        title: '温馨提示',
        content: '您目前尚未成为vip，可立即前往成为VIP',
        type: 'text',
        ok: '立即前往',
        cancel: '',
        position: 'bottom',
        cb: async (returnData) => {
          router.push('/mine/vip-center');
        }
      };
    } else if (res.data.code == 6100) {
      popupMsg.popupMsg = {
        show: true,
        title: '温馨提示',
        content: '付费即可观看本漫画',
        type: 'text',
        ok: '立即购买',
        cancel: '',
        position: 'bottom',
        cb: async (returnData) => {
          const res = await comicsPay({
            id: routeObj.id
          })
          if (res.code === 200) {
            popupMsg.popupMsg.show = false;
            showToast('购买成功');
          } else {
            router.push('/mine/wallet');
            return showToast(res.tip);
          }

        }
      };
    } else {
      showToast(res.data.msg || res.tip);
    }
    return res.data.code;
  }
}

//app下载 公共下载
export async function publicDownload(delay) {
  let downloadIos=function(){
    let param = '';
    if(store.getters['getChannel']&&store.getters['getChannel'].dc){
      param='?dc='+store.getters['getChannel'].dc
    };
    if(store.getters['getChannel']&&store.getters['getChannel'].pc){
      param='?pc='+store.getters['getChannel'].pc
    };       
    const eleLink = document.createElement('a')
    // eleLink.download = 'descriptionFile.mobileconfig'
    eleLink.href = baseData.VITE_APP_iosDownURL + param
    document.body.appendChild(eleLink)
    eleLink.click()
    document.body.removeChild(eleLink)
  }
  if ($device.android()) {
    let androidChannel={}
    if(store.getters['getChannel']&&store.getters['getChannel'].dc){
      androidChannel={
        'dc':store.getters['getChannel'].dc
      }
    }
    if(store.getters['getChannel']&&store.getters['getChannel'].pc){
      androidChannel={
        'pc':store.getters['getChannel'].pc
      }
    }
    await toClipboard(JSON.stringify(androidChannel))
    showToast('复制渠道号成功')           

    const eleLink = document.createElement('a')
    eleLink.href = baseData.VITE_APP_androidDownURL
    document.body.appendChild(eleLink)
    eleLink.click()
    document.body.removeChild(eleLink)
  } else if($device.ios()) {
    let isSafari = /Safari/.test(navigator.userAgent) && /Version/.test(navigator.userAgent);
    if (isSafari) {
      if(delay){
        router.push({
          path: `/download/ios`
        })            
        setTimeout(() => {
          downloadIos();             
        }, 3000);              
      }else{
        downloadIos();        
      }
        
    } else {
      alert('请用Safari打开本应用才能正确下载！')
    }
  }        
}



// 获取assets静态资源
export function getAssetsFile (url) {
  return new URL(`../assets/imgs/${url}`, import.meta.url).href;
};


