<template>
  <div class="activity-detail">
    <LayoutsHeader :title="state.activityObj.title ? state.activityObj.title : '新手活动列表'" />
    <div class="activity-detail-main" v-if="$route.params.name !== 'xinshourenwu'">
      <div v-if="state.activityObj.nodeList && state.activityObj.nodeList.length>0">
         <DecryptImg class="sItemImg" @clickImg="clickImg(sItem)" v-for="(sItem,index) in state.activityObj.nodeList" :key="index" :imgURL="sItem.cover" :needPadding="false" />

      </div>
      <div v-else>
           <DecryptImg class="cover" @clickImg="clickImg(state.activityObj)" :imgURL="state.activityObj.coverDetail" :needPadding="false" />
      <div class="desc">
        <p>活动说明:</p>
        {{ state.activityObj.describe }}
      </div>
      <div class="desc">
        <p>注意事项:</p>
        {{ state.activityObj.note }}
      </div>
      </div>
    </div>
    <div class="word-detail-main" v-else>
      <div class="bg-img">
        <img class="" src="@/assets/imgs/activity/xs_activity.png" alt="" />
      </div>
      <div class="word-main">
        <!-- 标题 -->
        <ul class="list">
          <li class="item" v-for="item in state.list" :key="item.id">
            <div class="title">
              <img src="@/assets/imgs/activity/star.svg" alt="" />
              {{ item.title }}
              <span v-if="item.param1">({{ `${item.currParam1}/${item.param1}` }})</span>
            </div>
            <span class="desc">{{ item.desc }}</span>
            <div
              class="btn"
              v-if="item.status !== 1 || item.status !== 0"
              :class="item.status === 1 ? 'active' : item.status === 2 ? 'receiveBtn' : ''"
              @click="receiveBtn(item)"
            >
              {{ item.status === 0 ? '去完成' : item.status === 1 ? '领取' : '已领取' }}
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script setup>
import { showToast } from 'vant'
const route = useRoute()
import { handleParamsRouteJump, handleURlParams } from '@/utils/utils_tools'
import { activity_detail, xs_activity_list, advertise_click } from '@/api/activity'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))

const state = reactive({
  activityObj: {},
  list: [],
  receive: true
})

// 活动跳转
const clickImg =(item) =>{
  const code = handleURlParams(item.jumpUrl)
  handleParamsRouteJump(code)
}

// 领取奖励 item.status ===1 可领取
const receiveBtn =async (item) =>{
  if (item.status === 1) {
    const res = await advertise_click({
      id: item.id
    })
    if (res.code === 200) {
      item.status = 2
      return showToast('领取成功')
    } else {
      return showToast(res.tip)
    }
  } else if (item.status === 0) {
    // 去完成跳转
    if (item.goTo) {
      const code = handleURlParams(item.goTo)
      handleParamsRouteJump(code)
    }
  }
}
    
onMounted(async () => {
  if (route.params.name !== 'xinshourenwu') {
    try {
      const res = await activity_detail({
        name: route.params.name
      })

      if (res.code === 200) {
        state.activityObj = res.data
      } else {
        return showToast(res.tip)
      }
    } catch (error) {
      console.log(error)
      return showToast('请求错误,请稍后再试！')
    }
  } else {
    try {
      const res = await xs_activity_list()
      if (res.code === 200) {
        state.list = res.data.list
      } else {
        return showToast(res.tip)
      }
    } catch (error) {
      console.log(error)
      return showToast('请求错误,请稍后再试！')
    }
  }
}) 

</script>

<style lang="scss" scoped>
.activity-detail {
  min-height: 100vh;
  padding-top: 1rem;
  &-main {
    padding: 0.3rem;
    .desc {
      font-size: 0.28rem;
      padding: 0.3rem;
      margin-bottom: 0.3rem;

      white-space: pre-line;
      p {
        margin: 0.2rem 0;
      }
    }
  }
}

.word-detail-main {
  background: $mainBgColor;
  padding: 0.3rem;
  min-height: calc(100vh - 1rem);
  box-sizing: border-box;
  width: 100%;
  position: relative;
}
.bg-img {
  position: absolute;
  width: 100%;
  max-width: $pcMaxWidth;
  left: 0;
  top: 0;
  img {
    border-radius: 0.1rem;
    height: 4.14rem;
    width: 100%;
  }
}
.word-main {
  background: $mainBgColor;
  padding: 0.3rem;
  font-size: 0.24rem;
  color: #000;
  position: absolute;
  width: 7rem;
  border-radius: 0.1rem;
  left: 50%;
  @include transformCenter(-50%, 0);
  top: 3.2rem;
  .list {
    .item {
      @include flexbox($jc: space-between, $ai: center, $fd: row, $fw: nowrap);
      margin-top: 0.37rem;
      img {
        width: 0.25rem;
        height: 0.25rem;
        margin-right: 0.12rem;
      }
      .title {
        margin-right: 0.15rem;
        white-space: nowrap;
        @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
        max-width: 2rem;
        img {
          width: 0.5rem;
          height: 0.5rem;
        }
      }
      .desc {
        white-space: nowrap;
        max-width: 1.2rem;
      }
      .btn {
        width: 1.52rem;
        height: 0.52rem;
        text-align: center;
        line-height: 0.52rem;
        border-radius: 0.52rem;
        border: 0.02rem solid #757381;
        text-align: center;
        font-size: 0.26rem;
        color: #757381;
      }
    }
    .item:first-child {
      margin-top: 0;
    }
    .active {
      background-image: linear-gradient(#fd9c3a, #fc342d);
      color: $mainTxtColor1;
    }
    .receiveBtn {
      background: #ffe7df;
      color: #333b4d;
      width: 1.4rem;
      height: 0.52rem;
      text-align: center;
      line-height: 0.52rem;
      border-radius: 0.52rem;
      font-size: 0.26rem;
    }
    .item:last-child {
      border-top: 0.04rem solid #868591;
      padding-top: 0.2rem;
      .title {
        font-size: 0.28rem;
        font-weight: 600;
      }
    }
  }
}
.sItemImg{
  width: 100%;
}
</style>
