<template>
  <div class="activity">
    <LayoutsHeader :title="'活动专区'" />
    <div class="activity-content-wrap">
      <PullUp
        @refreshData="refreshData"
        @moreData="moreData"
        :finished="state.finished"
        :loading="state.loading"
        :refreshing="state.refreshing"
        :skeleton="state.skeleton"
      >
        <DecryptImg
          @clickImg="$router.push(`/activity/detail/${item.name}`)"
          class="activity-bg"
          :imgURL="item.cover"
          :needPadding="false"
          v-for="item in state.activityList"
          :key="item.cover"
        />
      </PullUp>
    </div>
  </div>
</template>

<script setup>
import { showToast } from 'vant'
import { activity_list } from '@/api/activity'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const state = reactive({
  refreshing: false,
  loading: false,
  finished: false,
  pageNum: 1,
  pageSize: 10,
  skeleton: false,
  activityList: []
})

const refreshData =(refreshing) =>{
  state.refreshing = refreshing
  state.loading = true
  state.finished = false
  state.pageNum = 1
  state.activityList = []
  state.skeleton = true
  getActivity()
}
const moreData =() =>{
  state.pageNum += 1
  getActivity()
}
// 获取活动列表
const getActivity =async () =>{
  try {
    const res = await activity_list({
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      state.loading = false
      state.refreshing = false
      state.activityList = [...state.activityList, ...res.data.list]
      if (res.data.list.length < state.pageSize || !res.data.list) {
        state.finished = true
      }
    } else {
      state.loading = false
      state.refreshing = false
      state.finished = true
      return showToast(res.tip)
    }
  } catch (error) {
    state.loading = false
    state.refreshing = false
    state.finished = true
    return showToast('请求出错，请稍后再试！')
  }
}
  
onMounted(() => {
  refreshData()
}) 
</script>

<style lang="scss" scoped>
.activity {
  max-width: 640px;
  margin: 0 auto;
  min-height: 100vh;
  padding-top: 1.4rem;
  padding-bottom: 1.4rem;
  .activity-content-wrap {
    padding: 0 0.4rem;
  }
  .activity-bg {
    width: 100%;
    height: 3.44rem;
    border-radius: 0.2rem;
    margin-bottom: 0.2rem;
    box-shadow: $shadow;
    :deep()  {
      .warpNoPadding {
        border-radius: 0.2rem;
        img {
          border-radius: 0.2rem;
        }
      }
    }
  }
}
</style>
