<template>
  <div class="actor-detail">
    <LayoutsHeader :title="'女优作品'" />
    <div class="detail-main">
      <div class="top">
        <div class="top-left">
          <DecryptImg :imgURL="state.detailData.avatar" />
          <div class="counts">
            <div class="name">{{ state.detailData.name }}</div>
            <div class="counts-detail">
              <div class="video-num">
                <img src="@/assets/imgs/index/videos.svg" alt="" />
                {{ numberFilter(state.detailData.movieCount)}}
              </div>
              <div class="line"></div>
              <div class="watchs-num">
                <img src="@/assets/imgs/index/watchs.svg" alt="" />
                {{ numberFilter(state.detailData.watchCount) }}
              </div>
            </div>
          </div>
        </div>
        <div class="top-right" @click="addLike(state.detailData)">
          <img src="@/assets/imgs/blank-path.svg" alt="" />
          {{ state.detailData.isCollect ? '取消收藏' : '收藏' }}
        </div>
      </div>
      <!-- 视频列表 -->
      <div class="media-list">
        <div class="cover-type">
          <div @click="changeCoverType()" :class="state.coverType === 1 ? 'coverType1' : 'coverType2'"></div>
        </div>
        <ul class="sort-title">
          <li
            v-for="item in state.childCategory"
            @click="navChange(item.id)"
            :class="state.sort === item.id ? 'active' : ''"
            :key="item.id"
          >
            {{ item.name }}
          </li>
        </ul>
        <PullUp
          @refreshData="refreshData"
          @moreData="moreData"
          :finished="state.finished"
          :loading="state.loading"
          :refreshing="state.refreshing"
        >
          <JavFourCard v-if="state.coverType === 2" :list="state.mediatList" />
          <JavShortFour :list="state.mediatList" v-if="state.coverType === 1" />
        </PullUp>
      </div>
    </div>
  </div>
</template>

<script setup>
import { showToast } from 'vant'
import { media_actor_info, media_actor_details } from '@/api/home'
import { numberFilter } from '@/utils/filter'
import { collect } from '@/api/home'
const route = useRoute()
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const JavFourCard = defineAsyncComponent(() => import('@/components/JavFourCard.vue'))
const JavShortFour = defineAsyncComponent(() => import('@/components/JavShortFour.vue'))
const JavBgNav = defineAsyncComponent(() => import('@/components/JavBgNav.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))

const state = reactive({
  childCategory: [
    { id: 0, name: '最新发布' },
    { id: 1, name: '最热观看' },
    { id: 2, name: '最受好评' }
  ],
  detailData: {},
  mediatList: [],
  pageNum: 1,
  pageSize: 10,
  sort: 0,
  coverType: 1,
  refreshing: false, // 下拉刷新开关
  loading: false, // 上拉加载
  finished: false // 上拉加载开关
})

const changeCoverType =() =>{
  state.coverType === 1 ? (state.coverType = 2) : (state.coverType = 1)
  refreshData()
}
const navChange =(index) =>{
  if (index === state.sort) return
  state.sort = index
  refreshData()
}
// 添加喜欢
const addLike =async (item) =>{
  // 收藏信息
  try {
    const res = await collect({
      flag: !item.isCollect,
      object_id: item.id,
      collect_type: 7
    })
    if (res.code === 200) {
      item.isCollect = !item.isCollect
      if (item.isCollect) {
        return showToast('收藏成功')
      } else {
        return showToast('取消收藏')
      }
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    return showToast('请求失败，请稍后再试')
  }
}

// 请求视频信息
const getMediaList =async (item) =>{
  try {
    const res = await media_actor_details({
      id: +route.params.id,
      pageNum: state.pageNum,
      pageSize: state.pageSize,
      sort: state.sort,
      coverType: state.coverType
    })
    if (res.code === 200) {
      state.refreshing = false
      state.loading = false
      state.mediatList = [...state.mediatList, ...res.data.mediaList]
      if (res.data.mediaList.length < state.pageSize || !res.data.mediaList) {
        state.finished = true
      }
    } else {
      state.loading = false
      state.refreshing = false
      state.finished = true
      return showToast(res.tip)
    }
  } catch (error) {
    state.loading = false
    state.refreshing = false
    state.finished = true
    console.log(error)
  }
}
// 下拉刷新
const refreshData = (refreshing) =>{
  state.refreshing = refreshing
  state.pageNum = 1
  state.finished = false
  state.loading = true
  state.mediatList = []
  getMediaList()
}

// 上拉加载
const moreData = (loading) =>{
  state.loading = loading
  state.pageNum += 1
  getMediaList()
}

// 请求女优详情
const getActorDetail =async () =>{
  try {
    const res = await media_actor_info({
      id: +route.params.id
    })
    if (res.code === 200) {
      state.detailData = res.data
    } else {
      showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    showToast('请求错误，请稍后再试！')
  }
}

onMounted(async () => {
  getActorDetail()
  refreshData()
}) 
</script>

<style lang="scss" scoped>
.actor-detail {
  padding-top: 1rem;
  max-width: $pcMaxWidth;
  margin: 0 auto;
  .detail-main {
    padding: 0.3rem 0.25rem;
  }
}
.top {
  @include flexbox();
  font-size: 0.32rem;
  padding: 0.25rem;
  .top-left {
    @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
    .default {
      width: 1.2rem;
      margin-right: 0.3rem;
      :deep()  {
        .warp {
          border-radius: 50%;
        }
      }
    }
  }
  .counts {
    .name {
      font-size: 0.32rem;
      font-weight: 600;
      margin-bottom: 0.1rem;
      @include textoverflow();
    }
    .counts-detail {
      @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);

      .line {
        width: 0.03rem;
        height: 0.21rem;
        background: #848494;
        margin: 0 0.4rem;
      }
      .video-num,
      .watchs-num {
        display: flex;
        align-items: center;
        font-size: 0.2rem;
        img {
          width: 0.21rem;
          height: 0.16rem;
          margin-right: 0.08rem;
        }
      }
    }
  }

  .top-right {
    padding: 0.05rem 0.07rem;
    background: $btnBg;
    box-shadow: $shadow;
    border-radius: 0.025rem;
    img {
      width: 0.26rem;
      height: 0.23rem;
    }
  }
}
.media-list {
  box-shadow: $shadow;
  margin-top: 0.4rem;
  .sort-title {
    font-size: 0.28rem;
    color: #ccc;
    @include flexbox($jc: space-around, $ai: center, $fd: row, $fw: nowrap);
    margin-top: 0.5rem;
  }
  .active {
    color: #ceba62;
    font-weight: 600;
    position: relative;
  }
  .active::after {
    position: absolute;
    top: 0.5rem;
    left: 50%;
    @include transformCenter(-50%, 0);
    content: '';
    width: 0.38rem;
    height: 0.1rem;
    background: #333b4d;
    border-radius: 0.05rem;
  }
}
.cover-type {
  div {
    width: 100%;
    height: 0.847rem;
  }
}
.coverType1 {
  background: url('../../assets/imgs/search/covertype1.svg') no-repeat;
  background-size: 100% 100%;
}
.coverType2 {
  background: url('../../assets/imgs/search/covertype2.svg') no-repeat;
  background-size: 100% 100%;
}
</style>
