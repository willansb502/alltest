<template>
  <div class="application">
    <LayoutsHeader title="应用中心" />
    <PullUp
      @refreshData="refreshData"
      @moreData="moreData"
      :finished="state.finished"
      :loading="state.loading"
      :refreshing="state.refreshing"
      :skeleton="state.skeleton"
    >
      <div class="app-item" v-for="item in appsList" :key="item.id">
        <div class="info-box">
          <DecryptImg class="avatar" :imgURL="item.avatar" />
          <div class="info">
            <div class="title">
              {{ item.name }}
              <span>推荐</span>
            </div>
            <div class="desc">
              {{ item.desc }}
            </div>
          </div>
        </div>
        <!-- btn -->
        <div class="btn" @click="down(item.download_url)">立即前往</div>
      </div>
    </PullUp>
  </div>
</template>

<script setup>
import { showToast } from 'vant'
import { apps_list } from '@/api/home'
import { handleParamsRouteJump, handleURlParams } from '@/utils/utils_tools'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const state = reactive({
  refreshing: false,
  loading: false,
  finished: false,
  pageNum: 1,
  pageSize: 10,
  skeleton: false,
  appsList: []
})

const refreshData =(refreshing) =>{
  state.refreshing = refreshing
  state.loading = true
  state.finished = false
  state.pageNum = 1
  state.appsList = []
  state.skeleton = true
  getApps()
}

const moreData =() =>{
  state.pageNum += 1
  getApps()
}
// 获取应用列表
const getApps =async () =>{
  try {
    const res = await apps_list({
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      state.loading = false
      state.refreshing = false
      state.appsList = [...state.appsList, ...res.data.list]
      if (res.data.list.length < state.pageSize || !res.data.list) {
        state.finished = true
      }
    } else {
      state.loading = false
      state.refreshing = false
      state.finished = true
      return showToast(res.tip)
    }
  } catch (error) {
    state.loading = false
    state.refreshing = false
    state.finished = true
    console.log(error)
  }
}

// 活动跳转
const down =(item) =>{
  const code = handleURlParams(item)
  handleParamsRouteJump(code)
}

onMounted(() => {
  refreshData()
}) 

</script>

<style lang="scss" scoped>
.application {
  max-width: 640px;
  margin: 0 auto;
  min-height: 100vh;
  padding-top: 0.9rem;
}
.app-item {
  padding: 0 0.25rem;
  box-shadow: $shadow;
  border-radius: 0.05rem;
  @include flexbox($jc: space-between, $ai: center, $fd: row, $fw: nowrap);
  margin-top: 0.3rem;
  padding: 0.3rem 0.25rem;
  .info-box {
    @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
  }
  .avatar {
    width: 1.1rem;
    border-radius: 0.06rem;
    flex-shrink: 0;
    :deep()  {
      .warp {
        border-radius: 0.06rem;
        img {
          border-radius: 0.06rem;
        }
      }
    }
  }
  .info {
    font-size: 0.24rem;
    margin: 0 0.6rem 0 0.29rem;
    .title {
      font-size: 0.3rem;
      font-weight: 600;
      padding: 0.1rem;
      @include flexbox($jc: flex-start, $ai: flex-end, $fd: row, $fw: nowrap);
      border-bottom: 0.01rem solid #848494;
      span {
        padding: 0.02rem 0.12rem;
        border: 0.02rem solid #ff7eaf;
        border-radius: 0.08rem;
        color: #ff7eaf;
        font-size: 0.22rem;
        margin-left: 0.17rem;
      }
    }
    .desc {
      color: #878796;
      margin-top: 0.12rem;
    }
  }
  .btn {
    width: 1.6rem;
    height: 0.6rem;
    border-radius: 0.37rem;
    background: $btnBg;
    text-align: center;
    line-height: 0.6rem;
    flex-shrink: 0;
    font-size: 0.26rem;
  }
}
</style>
