<template>
  <div class="bookshelf-wrap">
    <LayoutsHeader title="书架" />
    <!-- 右上下拉列表 -->
    <div class="toggle-nav-wrap">
      <div @click.stop="state.menuObj.showSetting = !state.menuObj.showSetting">管理</div>
    </div>
    <!-- 书籍分组 -->
    <main class="main-list">
      <div class="item-wrap" v-for="(itemGroup, indexGroup) in state.newBookshelfList" :key="indexGroup">
        <div class="title-wrap">
          <div class="left">
            <div>
              {{ itemGroup.name }}
              <span>(共{{ itemGroup.list.length }}本)</span>
            </div>
            <div @click.stop="fn_showRename(itemGroup)">重命名</div>
            <div
              v-show="itemGroup.id != '默认分组'"
              @click.stop="fn_deleteGroup(itemGroup, indexGroup)"
              v-if="state.menuObj.showSetting && itemGroup.name != '默认分组'"
            >
              删除
            </div>
          </div>
          <div class="right" @click="fn_toggle(itemGroup)">
            <div :class="{ toggle: itemGroup.id != state.toggle }"></div>
          </div>
        </div>
        <ul v-if="itemGroup.id == state.toggle">
          <template v-if="itemGroup.list.length">
            <li v-for="(item, index) in itemGroup.list" :key="index" :class="{ selPadding: !state.menuObj.showSetting }">
              <div class="radio" @click.stop="fn_bookSel(item)">
                <img v-if="item.select" src="@/assets/imgs/comics/bookshelf/radio-active.png" alt="" />
                <img v-else src="@/assets/imgs/comics/bookshelf/radio.png" alt="" />
              </div>
              <div @click="toGoPath(item)" class="book-img">
                <div class="md-img-bg1"></div>
                <div class="md-img-bg2"></div>
                <DecryptImg
                  :needPadding="false"
                  :imgRadius="'0.06rem'"
                  class="md-img"
                  :imgURL="item.coverImg"
                ></DecryptImg>
              </div>
              <div @click="toGoPath(item)" class="book-title">
                <div class="title">{{ item.title }}</div>
                <div class="hasView">已看到：{{ item.hasViewNum ? item.hasViewNum : 0 }}章</div>
                <div class="new">最新：{{ item.hasViewCount || item.newChapter }}章</div>
              </div>
            </li>
          </template>
          <div v-else class="public-noData">暂无更多数据</div>
        </ul>
      </div>
    </main>
    <!-- 下面设置列表  -->
    <transition name="van-fade">
      <div class="footer-wrap" v-if="state.menuObj.showSetting">
        <div class="wrap">
          <ul>
            <li @click="fn_top" class="footer-item top">
              <div class="ico">
                <img v-if="state.selBookNumber != 1" src="@/assets/imgs/comics/bookshelf/top-default.png" alt="" />
                <img v-else src="@/assets/imgs/comics/bookshelf/top-active.png" alt="" />
              </div>
              <div class="text">顶置</div>
            </li>
            <li class="footer-item group">
              <div class="ico" @click.stop="fn_setGroup">
                <img src="@/assets/imgs/comics/bookshelf/group.png" alt="" />
              </div>
              <div class="text" @click.stop="fn_setGroup">移动分组</div>
            </li>
            <li class="footer-item del">
              <div class="ico">
                <img src="@/assets/imgs/comics/bookshelf/delete.png" alt="" />
              </div>
              <div class="text" @click="fn_delBook">删除</div>
            </li>
          </ul>
        </div>
      </div>
    </transition>
    <div class="group-wrap-mask" @click="state.menuObj.show = !state.menuObj.show" v-if="state.menuObj.show"></div>
    <div class="group-wrap" v-if="state.menuObj.show">
      <div @click="fn_moveBook(item)" class="item" v-for="(item, index) in state.newBookshelfList" :key="index">
        {{ item.name }}
      </div>
      <div class="item" @click="fn_newGroup">新建分组</div>
    </div>
    <!-- 修改分组名称 -->
    <van-popup v-model:show="state.showRename" position="center" class="showRename" round>
      <div class="title">新建分组名称为</div>
      <div class="text">
        <input
          v-model="state.renameTxt"
          maxlength="10"
          :placeholder="state.selParentItem && state.selParentItem.name ? state.selParentItem.name : '最多不超过10个字'"
          type="text"
        />
      </div>
      <div class="btn-wrap">
        <div @click=";(state.showRename = false), (state.renameTxt = '')">取消</div>
        <div @click="sure_rename()">确定</div>
      </div>
    </van-popup>
    <DmPopup ref="popupMsg"></DmPopup>
  </div>
</template>
<script setup>
import { useStore } from 'vuex'
const store = useStore()
import { showToast } from 'vant'
import { onUnmounted } from 'vue'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const DmPopup = defineAsyncComponent(() => import('@/components/Popup/index.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
let popupMsg = ref(null)
const state = reactive({
  //重命名
  renameTxt: '',
  showRename: false,
  //右上下拉列表
  menuObj: {
    show: false,
    showSetting: false
  },
  //下拉
  toggle: '',
  //store书架
  newBookshelfList: [],
  //目前选中几本书
  selBookNumber: 0,
  //当前分组数据
  selParentItem: {
    list: []
  },
  bookshelfList:computed(() => store.state.history.bookshelfList)
})


const toGoPath =(item) =>{
  store.commit('setBookshelf', state.newBookshelfList)
  router.push(`/comics/decial/${item.id}`)
}
//移动书籍
const fn_moveBook =(item) =>{
  if (!state.selBookNumber) return showToast('请选择书籍后再操作！！！')
  let lastArr = state.selParentItem.list.filter((ele, index) => {
    return !ele.select
  })
  let pushArr = state.selParentItem.list.filter((ele, index) => {
    return ele.select
  })
  state.selParentItem.list = lastArr
  item.list = [...item.list, ...pushArr]
  state.menuObj.show = false
  showToast('移动分组成功')
}

//新建分组
const fn_newGroup =() =>{
  if (state.newBookshelfList.length > 9) return showToast('最多10个分组')
  state.newBookshelfList.push({ id: '分组' + state.newBookshelfList.length, name: '新分组未分类', list: [] })
  showToast('新建分组成功！！！')
}
//移动分组
const fn_setGroup =() =>{
  state.menuObj.show = true
}
//顶置
const fn_top =() =>{
  if (state.selParentItem.list.length < 2) return
  if (state.selBookNumber != 1) return showToast('请只选中一本书籍顶置！！！')
  let item = {}
  //删除
  state.selParentItem.list.forEach((element, index) => {
    if (element.select) {
      element.select = false
      item = element
      state.selParentItem.list.splice(index, 1)
    }
  })
  //加入头部
  state.selParentItem.list.unshift(item)
  //还原
  state.selBookNumber = 0
}

//删除收藏书籍
const fn_delBook =() =>{
  let newArr = state.selParentItem.list.filter((ele, index) => {
    return !ele.select
  })
  state.selParentItem.list = newArr
  fn_resetSelbook()
}
// 删除一个分组
const fn_deleteGroup =(itemGroup, indexGroup) =>{
  if (itemGroup.id == '默认分组') return
    popupMsg.value.popupMsg = {
    show: true,
    title: '确定删除',
    content: `确定删除${itemGroup.name}吗？删除后将不可恢复`,
    type: 'small-text',
    ok: '',
    cancel: '',
    position: 'center',
    cb: async returnData => {
      state.newBookshelfList.splice(indexGroup, 1)
      popupMsg.value.popupMsg.show = false
    }
  }
}
//重命名  
const fn_showRename =(item) =>{
  state.selParentItem = item
  state.showRename = true
}

const sure_rename =() =>{
  state.showRename = false
  state.selParentItem.name = state.renameTxt
  state.renameTxt = ''
}

//书籍选择
const fn_bookSel =(item) =>{
  item.select = !item.select
  // 计算目前选中个数
  let selBookNumber = 0
  state.newBookshelfList.forEach(element1 => {
    element1.list.forEach(element2 => {
      if (element2.select) {
        selBookNumber++
      }
    })
  })
  state.selBookNumber = selBookNumber
}
// 展开
const fn_toggle =(itemGroup) =>{
  if (state.selParentItem.id == itemGroup.id) {
    if (state.toggle == '') {
      state.toggle = itemGroup.id
    } else {
      state.toggle = ''
    }
  } else {
    //还原选中信息，只支持一个分组操作
    fn_resetSelbook()
    state.toggle = itemGroup.id
    state.selParentItem = itemGroup
  }
}
//重置书本选中
const fn_resetSelbook =() =>{
  state.newBookshelfList.forEach(element => {
    element.list.forEach(sElement => {
      sElement.select = false
    })
  })
  state.selBookNumber = 0
}

onMounted(() => {
  let newBookshelfList = JSON.parse(JSON.stringify(state.bookshelfList))
  //初始化书本选中移动
  newBookshelfList.forEach(element => {
    element.list.forEach(sElement => {
      sElement.select = false
    })
  })
  //默认第一项有书本则展开
  if (newBookshelfList[0].list.length) state.toggle = newBookshelfList[0].id
  // console.log(newBookshelfList);
  state.newBookshelfList = newBookshelfList
  state.selParentItem = state.newBookshelfList[0]
}) 

onUnmounted(() => {
  store.commit('setBookshelf', state.newBookshelfList)
})
</script>

<style lang="scss" scoped>
.bookshelf-wrap {
  max-width: 750px;
  margin: 0 auto;
  min-height: 100vh;
  padding-top: 0.92rem;
  padding-bottom: 1.66rem;
  color: #6a6a6a;
  font-size: 0.24rem;
  .toggle-nav-wrap {
    position: fixed;
    top: 0.23rem;
    z-index: 999;
    right: 0.37rem;
    font-size: 0.32rem;
  }
  //书籍列表
  .main-list {
    .item-wrap {
      // box-shadow: 0 0.06rem 0.1rem rgba($color: #000, $alpha: 0.1) inset;
      padding: 0.2rem 0;
      .title-wrap {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 0.37rem;
        .left {
          display: flex;
          align-items: center;
          div {
            &:nth-child(1) {
              font-size: 0.32rem;
              color: $mainTxtColor1;
              span {
                font-size: 0.24rem;
                opacity: 0.5;
              }
            }
            &:nth-child(2) {
              padding: 0 0.24rem;
            }
            &:nth-child(2),
            &:nth-child(3) {
              color: #da5751;
              text-decoration: underline;
            }
          }
        }
        .right {
          display: flex;
          align-items: center;
          div {
            width: 0;
            height: 0;
            border-width: 0.18rem;
            border-style: solid;
            border-color: #6a6a6a transparent transparent transparent;
            &.toggle {
              border-color: transparent #6a6a6a transparent transparent;
            }
          }
        }
      }
    }
    ul {
      max-height: 7.72rem;
      overflow-y: auto;
      animation: fadeIn 0.5s;
      @keyframes fadeIn {
        from {
          opacity: 0;
        }
        to {
          opacity: 1;
        }
      }
      li {
        display: flex;
        align-items: center;
        .radio {
          padding-left: 0.37rem;
          padding-right: 0.3rem;
          img {
            width: 0.39rem;
            height: 0.39rem;
          }
        }
        .book-img {
          position: relative;
          display: flex;
          flex-direction: column;
          width: 1.12rem;
          margin-top: 0.4rem;
          z-index: 2;
          .md-img-bg1 {
            display: inline-block;
            background: #741348;
            opacity: 0.15;
            width: 90%;
            height: 0.4rem;
            top: -0.1rem;
            border-top-left-radius: 0.1rem;
            border-top-right-radius: 0.1rem;
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
          }
          .md-img-bg2 {
            content: '';
            display: inline-block;
            background: #741348;
            opacity: 0.1;
            width: 80%;
            height: 0.4rem;
            top: -0.2rem;
            border-top-left-radius: 0.1rem;
            border-top-right-radius: 0.1rem;
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
          }

          .md-img {
            position: relative;
            height: 1.53rem;
          }
        }
        .book-title {
          padding-left: 0.35rem;
          div {
            &.title {
              max-width: 4.25rem;
              overflow: hidden;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 1;
              white-space: normal;
              font-size: 0.32rem;
              color: $mainTxtColor1;
            }
            &.hasView {
              font-size: 0.24rem;
              color: $mainTxtColor1;
              opacity: 0.7;
              padding: 0.05rem 0;
            }
            &.new {
              color: #da5751;
            }
          }
        }
        &.selPadding {
          padding-left: 0.37rem;
          .radio {
            display: none;
          }
        }
      }
    }
  }
  //底部导航
  .footer-wrap {
    position: fixed;
    bottom: 0;
    width: 100%;
    max-width: $pcMaxWidth;
    z-index: 999;
    background: transparent;
    height: 1.47rem;
    .wrap {
      width: 6.8rem;
      height: 100%;
      margin: 0 auto;
      background: transparent;
      border-top-left-radius: 0.6rem;
      border-top-right-radius: 0.6rem;
      ul {
        background: $mainBgColor;
        width: 100%;
        height: 1.17rem;
        display: flex;
        border-radius: 0.6rem;
        // box-shadow: 0.1rem 0.1rem 0.3rem #ccc;
        .footer-item {
          padding-top: 0.25rem;
          text-align: center;
          position: relative;
          flex: 1;
          font-size: 0.2rem;
          .ico-act {
            position: absolute;
          }
          .ico {
            z-index: 10;
          }
          .ico,
          .ico-act {
            img {
              width: 100%;
              height: 100%;
            }
          }
          .text {
            margin-top: 0.06rem;
          }
        }
        //图片大小,位置
        li {
          &.top {
            .ico {
              img {
                width: 0.6rem;
              }
            }
          }
          &.group {
            .ico {
              img {
                width: 0.42rem;
              }
            }
          }
          &.del {
            .ico {
              img {
                width: 0.37rem;
              }
            }
          }
          .ico {
            width: 100%;
            text-align: center;
          }
        }
      }
    }
  }
  //操作-组
  .group-wrap {
    z-index: 1002;
    display: flex;
    flex-direction: column;
    color: #6a6a6a;
    background: $mainBgColor;
    position: fixed;
    left: 50%;
    transform: translateX(-50%);
    bottom: 1.5rem;
    border-radius: 0.15rem;
    .item {
      // box-shadow: 0 0.01rem 0.2rem rgba($color: #000, $alpha: 0.1) inset;
      text-align: center;
      border-bottom: 1px solid #eee;
      padding: 0.1rem 0.2rem;
      &:first-child {
        border-top-left-radius: 0.15rem;
        border-top-right-radius: 0.15rem;
      }
      &:last-child {
        border-bottom: 0;
        border-bottom-left-radius: 0.15rem;
        border-bottom-right-radius: 0.15rem;
      }
      &.active {
        color: #ff8b00;
      }
    }
    animation: fadeInGroup 0.5s;
    @keyframes fadeInGroup {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }
  }
  .group-wrap-mask {
    z-index: 1000;
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba($color: #000000, $alpha: 0.2);
  }
  //重命名输入框
  .showRename {
    text-align: center;
    background: #f7f6fa;
    width: 50%;
    height: 2.5rem;
    display: flex;
    justify-content: space-between;
    flex-direction: column;
    .title {
      padding: 0.2rem 0;
    }
    .text {
      @include placeholder-color;
      input {
        text-indent: 0.2rem;
        height: 0.5rem;
        text-align: center;
        width: 100%;
        padding: 0;
        padding-right: 0.12rem;
        border: 0;
        outline: 0;
      }
    }
    .btn-wrap {
      padding: 0.2rem 0;
      display: flex;
      justify-content: center;
      div {
        border-radius: 0.1rem;
        border: 1px solid $mainTxtColor1;
        background: $btnBg;
        // @include box-shadow-all;
        color: #f09035;
        padding: 0.05rem 0.1rem;
        &:first-child {
          background: transparent;
          border: 1px solid #eee;
          margin-right: 0.2rem;
        }
      }
    }
  }
  .public-noData {
    color: #ccc;
    font-size: 0.24rem;
    display: flex;
    align-items: center;
    justify-content: center;
  }
}
</style>
