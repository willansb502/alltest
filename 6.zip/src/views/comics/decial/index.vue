<template>
  <!-- 更多专题更多列表,一行3个 -->
  <div class="home-comic-decial" v-if="state.showPage">
    <LayoutsHeader :title="state.comicsData.title"></LayoutsHeader>
    <template v-if="state.comicsData.id">
      <div class="home-comic-top">
        <div class="left-wrap">
          <DecryptImg :needPadding="false" class="md-img" :imgRadius="'0.12rem'" :imgURL="state.comicsData.coverImg" />
          <div class="btn-wrap">
            <div style="opacity: 0.7" v-if="state.isLike" @click="setFavour">已收藏</div>
            <div v-else @click="setFavour">+加入书架</div>
          </div>
        </div>
        <div class="right-wrap">
          <div class="wrap">
            <div class="title">{{ state.comicsData.title }}</div>
            <div class="author">
              <div class="t">作者：</div>
              <li
                v-for="(item, index) in state.comicsData.author"
                @click="
                  $router.push({
                    path: `/comics/author`,
                    query: {
                      name: item
                    }
                  })
                "
                :key="index"
                style="cursor: pointer"
              >
                {{ item }}
              </li>
            </div>
            <div class="author tag">
              <div class="t">标签：</div>
              <li
                @click="
                  $router.push({
                    path: `/comics/tag-type-one`,
                    query: {
                      name: item.name,
                      id: item.id
                    }
                  })
                "
                v-for="(item, index) in state.comicsData.tags"
                :key="index"
                style="cursor: pointer"
              >
                {{ item.name }}
              </li>
            </div>
            <div class="btn-wrap">
              <!-- vip且我不是vip -->
              <div @click="fn_buy" class="vip" v-if="state.shoudBuy === 1">
                <div>VIP免费观看</div>
              </div>
              <!-- 有价钱未购买 -->
              <div @click="fn_buy" class="buy" v-else-if="state.shoudBuy === 2">
                <div class="coin">
                  <img src="@/assets/imgs/index/gold.png" alt="" />
                  <span> {{ changeGold(state.comicsData.price) }} 购买观看 </span>
                </div>
              </div>
              <!-- 其他情况 -->
              <div v-else @click="fn_buy">
                <div class="vip" v-if="state.shoudBuy === 7">VIP观看</div>
                <div class="vip" v-else-if="state.shoudBuy === 8">已购观看</div>
                <div class="vip free" v-else-if="state.shoudBuy === 9">免费观看</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <main class="home-comic-bottom">
        <ul class="nav-wrap">
          <li :class="{ active: state.tab == '漫画详情' }" @click="fn_tab('漫画详情')">漫画详情</li>
          <li class="comments" :class="{ active: state.tab == '评论' }" @click="fn_tab('评论')">
            评论({{ state.comicsData.comments }})
          </li>
          <li class="watchTimes">
            <img src="@/assets/imgs/comics/fire.png" alt="" />
            观看次数：{{ numberFilter(state.comicsData.watchTimes) }}
          </li>
        </ul>
        <template>
          <van-list
            v-show="state.tab == '漫画详情'"
            v-model:loading="state.loading"
            :finished="state.finished"
            finished-text="暂时没有更多数据！"
            @load="onLoad"
            :immediate-check="false"
            error-text="请求失败，点击重新加载"
          >
            <div class="chapter-wrap">
              <!-- <div class="tip">您有{{state.comicsData.newChapter}}章更新尚未观看</div> -->
              <div class="desc" v-if="state.comicsData.desc">
                {{ state.comicsData.desc }}
              </div>
              <ul class="chapter" v-if="state.chapterList.length">
                <CatalogueItem v-for="(item, index) in state.chapterList" :item="item" :key="index"></CatalogueItem>
              </ul>
              <!-- v-if="state.chapterList.length>20"  <div v-if="state.chapterList.length > 20" class="more" @click="$refs['ComicCatalogue'].initDatas()">
                查看目录
              </div>-->
            </div>
            <div class="look-again">
              <div class="title">看了又看</div>
              <ul>
                <DmComicCard v-for="(item, index) in state.comicsList" :item="item" :key="index"></DmComicCard>
              </ul>
            </div>
          </van-list>
        </template>
        <template>
          <Comment
            v-show="state.tab == '评论'"
            class="comment-box"
            :publisher="state.comicsData"
            :objectId="+$route.params.id"
            :objectype="3"
            :disabledPull="true"
            @addComments="addComments"
          />
        </template>
      </main>
      <ComicCatalogue ref="ComicCatalogue" :catalogueObj="state.catalogueObj"></ComicCatalogue>
      <DmPopup ref="popupMsg"></DmPopup>
    </template>
  </div>
</template>
<script setup>
import { showToast } from 'vant'
import { numberFilter , changeGold} from '@/utils/filter'
import { comicsDetail } from '@/api/comics' //api列表
import { picViewRightTo } from '@/utils/utils_tools'
import { onUnmounted } from 'vue'
const router = useRouter()
const route = useRoute()
import { useStore } from 'vuex'
const store = useStore()
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const DmPopup = defineAsyncComponent(() => import('@/components/Popup/index.vue'))
const DmComicCard = defineAsyncComponent(() => import('@/components/Comic/oneCard/index.vue'))
const Comment = defineAsyncComponent(() => import('@/components/Comment/index.vue'))
const ComicCatalogue = defineAsyncComponent(() => import('@/components/Comic/comic/catalogue/index.vue'))
const CatalogueItem = defineAsyncComponent(() => import('@/components/Comic/comic/catalogue/item.vue'))
const state = reactive({
  //展示页面
  showPage: true,
  catalogueObj: {
    list: [],
    show: false
  },
  tab: '漫画详情',
  //漫画详情
  comicsData: {},
  chapterList: [],
  //收藏
  isLike: false,
  comicsList: [],
  //加载刷新
  pageNum: 1,
  pageSize: 9,
  refreshing: false,
  loading: false,
  finished: false,
  isVipMember:computed(() => store.getters['isMember']),
  bookshelfList:computed(() => store.state.history.bookshelfList),
  //判断是否能看
  shoudBuy:computed(() => {
    if (state.comicsData.isVip && !state.isVipMember) {
      return 1
    } else if (state.comicsData.price && !state.comicsData.isBuy) {
      return 2
    } else {
      if (state.comicsData.isVip) {
        return 7 //VIP观看
      } else if (state.comicsData.isBuy) {
        return 8 //已购观看
      } else {
        return 9 //免费
      }
    }
  })
})
//传递评论
const addComments =() =>{
  state.comicsData.comments++
}
// 设置历史
const setHistory =() =>{
  let comicsData = JSON.parse(JSON.stringify(state.comicsData))
  store.commit('setComicsHisList', { type: 'add', item: comicsData })
}
// 看漫画章节
const toWatch =() =>{
  if (!state.chapterList.length) {
    return showToast('当前漫画无章节！！！')
  }
  router.push({
    path: `/comics/pic-view/` + state.chapterList[0].id,
    query: {
      parentId: route.params.id
    }
  })
}
//本地收藏
const setFavour = () =>{
  let itemIndex = 0
  let newBookshelfList = JSON.parse(JSON.stringify(state.bookshelfList))
  if (newBookshelfList[0].list.length > 100) {
    return showToast('您收藏的漫画超过100个，请收藏夹删除再操作')
  }
  newBookshelfList[0].list.forEach((element, index) => {
    if (element.id == state.comicsData.id) {
      itemIndex = index
    }
  })
  // 取消收藏
  if (state.isLike) {
    newBookshelfList[0].list.splice(itemIndex, 1)
    store.commit('setBookshelf', newBookshelfList)
    state.isLike = false
    showToast('取消收藏成功！')
  } else {
    let comicsSave = JSON.parse(JSON.stringify(state.comicsData))
    delete comicsSave.author
    delete comicsSave.lookComics
    delete comicsSave.tags
    newBookshelfList[0].list.unshift(comicsSave)
    store.commit('setBookshelf', newBookshelfList)
    state.isLike = true
    showToast('收藏成功！')
  }
}
//收藏位置
const findIndex = () =>{
  let status = false
  state.bookshelfList.forEach(element1 => {
    element1.list.forEach(element2 => {
      if (element2.id == +route.params.id) {
        status = true
      }
    })
  })
  if (!status) {
    state.isLike = false
  } else {
    state.isLike = true
  }
}
//获取漫画详情
const comicsDetail =async (type) =>{
  const res = await comicsDetail({
    id: +route.params.id,
    pageNum: state.pageNum,
    pageSize: state.pageSize
  })
  if (res.code === 200 && res.data) {
    state.showPage = true
    state.chapterList = res.data.chapterList
    state.catalogueObj.list = res.data.chapterList
    state.comicsData = res.data.comicsData
    findIndex()
    state.chapterList.forEach((item, index) => {
      item.indexName = index + 1
    })
    state.refreshing = false
    state.loading = false
    if (
      !res.data ||
      !res.data.comicsData ||
      !res.data.comicsData.lookComics ||
      res.data.comicsData.lookComics.length < state.pageSize
    ) {
      state.finished = true
    }
    if (type == 'pull') state.comicsList = []
    if (res.data.comicsData && res.data.comicsData.lookComics)
      state.comicsList = [...state.comicsList, ...res.data.comicsData.lookComics]
  } else {
    state.showPage = true
    state.finished = true
    state.refreshing = false
    state.loading = false
    return showToast(res.tip)
  }
}
//切换
const fn_tab =(name) =>{
  state.tab = name
}
//购买
const fn_buy =() =>{
  if (!state.chapterList.length) {
    return showToast('当前漫画无章节！！！')
  }
  picViewRightTo(state.chapterList[0].id)
}
//上拉加载更多
const onLoad =() =>{
  state.pageNum += 1
  comicsDetail()
}
// 刷新
const onRefresh =() =>{
  state.pageNum = 1
  state.finished = false
  state.loading = true
  comicsDetail('pull')
}

onMounted(() => {
  comicsDetail()
}) 

onUnmounted(() => {
  setHistory()
})


watch(() => router.currentRoute.value.path, () => {
  state.showPage = false
  comicsDetail('pull')
},{ immediate: true })


</script>

<style lang="scss" scoped>
.home-comic-decial {
  min-height: 100vh;
  padding-top: 0.92rem;
  padding-bottom: 0.1rem;
  transform: translate3d(0, 0, 0);
  margin: 0 auto;

  .home-comic-top {
    padding: 0.27rem 0.37rem;
    display: flex;
    .left-wrap {
      .md-img {
        width: 3.4rem;
        height: 4.6rem;
      }
      .btn-wrap {
        padding-top: 0.2rem;
        display: flex;
        cursor: pointer;
        div {
          padding: 0 0.12rem;
          background: $btnBg;
          height: 0.46rem;
          border-radius: 0.12rem;
          color: #fff;
          font-size: 0.24rem;
          @include flex-center;
          @include box-shadow-all;
          white-space: nowrap;
        }
      }
    }
    .right-wrap {
      font-size: 0.24rem;
      padding-left: 0.2rem;
      color: #fff;
      .wrap {
        padding-bottom: 0.7rem;
        position: relative;
        min-height: 3.3rem;
        .title {
          font-size: 0.32rem;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
          white-space: normal;
        }
        .author {
          display: flex;
          align-items: center;
          flex-wrap: wrap;
          padding: 0.15rem 0;
          .t {
            font-size: 0.28rem;
            color: #fff;
          }
          li {
            margin-bottom: 0.1rem;
            margin-right: 0.1rem;
            padding: 0.05rem 0.25rem;
            @include flex-center;
            @include box-shadow-all;
            border-radius: 999px;
            font-size: 0.18rem;
            color: #ece0e0;
            background: linear-gradient(to right, #242323, #363a61);
          }
          &.tag {
            padding: 0;
            //max-height: 1rem;
            overflow: auto;
            @include scrollbar-hide;
            li {
              padding: 0.05rem 0.1rem;
            }
          }
        }
        .btn-wrap {
          cursor: pointer;
          position: absolute;
          bottom: 0;
          display: flex;
          .vip {
            background: #ff8b00;
            padding: 0.1rem 0.34rem;
            font-size: 0.26rem;
            border-radius: 0.14rem;
            color: $mainTxtColor1;
            @include flex-center;
            @include box-shadow-all;
          }
          .buy {
            .coin {
              white-space: nowrap;
              color: $mainTxtColor1;
              padding: 0.1rem 0.34rem;
              background: #e65551;
              display: flex;
              align-items: center;
              justify-content: center;
              border-radius: 0.14rem;
              font-size: 0.24rem;
              img {
                width: 0.24rem;
                margin-right: 0.05rem;
              }
              span {
              }
            }
          }
          .free {
            background: #4e982e;
          }
        }
      }
    }
  }
  .home-comic-bottom {
    min-height: calc(100vh - 6.72rem);
    position: relative;
    background: $mainBgColor;
    border-top-left-radius: 0.44rem;
    border-top-right-radius: 0.44rem;
    // &::before{
    //   content: "";
    //   position: absolute;
    //   top: 0;
    //   left: 50%;
    //   transform: translateX(-50%);
    //   width: 0;
    //   height: 0;
    //   border-width: 0.18rem;
    //   border-style: solid;
    //   border-color: #ff8b00 transparent transparent transparent;
    // }
    .nav-wrap {
      text-align: center;
      padding: 0.5rem 0.37rem 0.2rem 0.37rem;
      font-size: 0.32rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      color: #b8b0b0;
      li.active {
        color: #ff8b00;
      }
      .watchTimes {
        font-size: 0.24rem;
        display: flex;
        align-items: center;
        img {
          width: 0.24rem;
          margin-right: 0.05rem;
        }
      }
    }
    .chapter-wrap {
      position: relative;
      box-shadow: 0 0.06rem 0.1rem rgba($color: #000, $alpha: 0.1) inset;
      .tip {
        top: 0.2rem;
        left: 50%;
        transform: translateX(-50%);
        position: absolute;
        border-radius: 0.22rem;
        background: #ff7777;
        padding: 0.05rem 0.2rem;
        color: $mainTxtColor1;
      }
      .desc {
        font-size: 0.24rem;
        padding: 0.2rem 0.2rem 0 0.2rem;
        opacity: 0.7;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 4;
        white-space: normal;
        margin-bottom: 0.2rem;
      }
      .chapter {
        max-height: 4.3rem;
        display: flex;
        flex-wrap: wrap;
        overflow-y: hidden;
        padding: 0.2rem 0.66rem 0 0.66rem;
      }
      .more {
        font-size: 0.32rem;
        margin: 0 auto;
        border-radius: 0.2rem;
        color: #ff7777;
        width: 2.68rem;
        height: 0.78rem;
        background: $mainBgColor;
        @include flex-center;
        @include box-shadow-all;
        margin-top: 0.2rem;
        margin-bottom: 0.2rem;
      }
    }
    .look-again {
      box-shadow: 0 0.06rem 0.1rem rgba($color: #000, $alpha: 0.1) inset;
      padding: 0.2rem 0.37rem;
      .title {
        color: #ccc;
        font-size: 0.28rem;
      }
      ul {
        display: flex;
        flex-wrap: wrap;
        justify-content: flex-start;

        li {
          display: flex;
          flex-direction: column;
          //width: 2.1rem;
          margin-bottom: 0.2rem;
          .md-img {
            height: 2.86rem;
          }
          .decial-wrap {
            width: 100%;
            border-radius: 0.12rem;
            .decial {
              display: flex;
              flex-direction: column;
              div {
                &:first-child {
                  padding-top: 0.12rem;
                  font-size: 0.28rem;
                  color: #6a6a6a;
                }
                &:last-child {
                  font-size: 0.18rem;
                  color: #a0a0a0;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  display: -webkit-box;
                  -webkit-box-orient: vertical;
                  -webkit-line-clamp: 2;
                  white-space: normal;
                }
              }
            }
          }
        }
      }
    }
  }
}
//评论框
.comment-box {
  :deep() {
    .header {
      display: none;
    }
    .content-main-wrap {
      height: auto;
    }
  }
}

@media screen and (min-width: 960px) {
  .home-comic-decial {
    padding: 1rem 1.52rem;
    .home-comic-top {
      .left-wrap {
        .md-img {
          width: 5.1rem;
          height: 6.9rem;
        }
        .btn-wrap {
          div {
            height: 0.8rem;
            width: 5.2rem;
          }
          div:hover {
            background: rgb(156, 143, 106);
          }
        }
      }
      .right-wrap {
        .wrap {
          .title {
            font-size: 24px;
          }

          .author.tag li {
            padding: 0.1rem 0.4rem;
          }
        }
      }
    }
    .home-comic-bottom {
      .look-again {
        ul {
          padding: 0 1.53rem;
        }
      }
    }
  }
}
</style>
