<template>
  <div class="comics-main">
    <SwiperShow class="home-swiper" :imgList="state.cartongAD" v-if="state.cartongAD && state.cartongAD.length" />

    <MuBtnList :tags="[]" style="margin: 0.25rem 0"></MuBtnList>

    <!--切换面板 -->
    <JavTab
      class="container-tab"
      @change="change"
      :sticky="true"
      :titles="state.comicsCategory"
      :active="state.type ? state.type : state.comicsCategory && state.comicsCategory[0] ? state.comicsCategory[0].id : 0"
      :animated="false"
      :needBack="true"
    >
      <template v-slot:default="scope">
        <div class="tab-main">
          <component :nowTabItem="scope.item" :is="compComponent(scope)"></component>
        </div>
      </template>
    </JavTab>
  </div>
</template>

<script setup name="comicsPage">
import { useStore } from 'vuex'
const store = useStore()
const SwiperShow = defineAsyncComponent(() => import('@/components/Swiper/index.vue'))
const MuBtnList = defineAsyncComponent(() => import('@/components/Home/MuBtnList.vue'))
const JavTab = defineAsyncComponent(() => import('@/components/JavTab.vue'))
const ComicsDefault = defineAsyncComponent(() => import('@/components/Comic/default.vue'))
const ComicsList = defineAsyncComponent(() => import('@/components/Comic/list/index.vue'))

const state = reactive({
  type: 0,
  cartongAD:computed(() => store.getters['cartongAD']),
  comicsCategory:computed(() => store.getters['comicsCategory'])  
})

const change = (index) =>{
  state.type = index
  store.commit('SET_CARTOONINDEX', state.type)
}

const compComponent = (data) =>{
  switch (data.data) {
    case 7:
      return ComicsList
    default:
      return ComicsDefault
  }
}
</script>
<style lang="scss" scoped>
.comics-main {
  padding: 1.9rem 0 1.3rem 0;
  min-height: $minHeight;
  max-width: $pcMaxWidth;
  margin: 0 auto;
  .container-tab {
    :deep()  {
      .van-sticky {
        margin-bottom: 2rem;
        background: $mainBgDeepColor;
        position: fixed;
        top: 1.3rem;
        @include transformCenter();
      }
      .van-tabs__content {
        height: 100%;
      }
    }
  }
}
</style>
