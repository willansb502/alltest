<template>
  <!-- 更多专题更多列表,一行3个 -->
  <div class="home-comic-more">
    <LayoutsHeader :title="$route.query.name" />
    <van-pull-refresh v-model="state.refreshing" @refresh="onRefresh">
      <van-list
        v-model:loading="state.loading"
        :finished="state.finished"
        finished-text="暂时没有更多数据！"
        @load="onLoad"
        :immediate-check="false"
        error-text="请求失败，点击重新加载"
      >
        <div class="list-wrap">
          <ul>
            <DmComicCard v-for="(item, index) in comicsList" :item="item" :key="index"></DmComicCard>
          </ul>
        </div>
      </van-list>
    </van-pull-refresh>
  </div>
</template>
<script setup>
import { showToast } from 'vant'
import { comicsTopicList } from '@/api/comics' //api列表
const route = useRoute()
const DmComicCard = defineAsyncComponent(() => import('@/components/Comic/oneCard/index.vue'))
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const state = reactive({
  //加载刷新
  pageNum: 1,
  pageSize: 9,
  refreshing: false,
  loading: false,
  finished: false,
  comicsList: []
})

const comicsAuthor =async (type) =>{
  const res = await comicsTopicList({
    id: +route.query.id,
    pageNum: state.pageNum,
    pageSize: state.pageSize,
    sort: 0
  })
  if (res.code === 200 && res.data) {
    state.refreshing = false
    state.loading = false
    if (!res.data || !res.data.list || res.data.list.length < state.pageSize) {
      state.finished = true
    }
    if (type == 'pull') state.comicsList = []
    if (res.data.list) state.comicsList = [...state.comicsList, ...res.data.list]
  } else {
    state.finished = true
    state.refreshing = false
    state.loading = false
    return showToast(res.tip)
  }
}
//上拉加载更多
const onLoad = () =>{
  state.pageNum += 1
  comicsAuthor()
}

// 刷新
const onRefresh = () =>{
  state.pageNum = 1
  state.finished = false
  state.loading = true
  comicsAuthor('pull')
}

onMounted(() => {
  onRefresh()
}) 

</script>

<style lang="scss" scoped>
.home-comic-more {
  min-height: 100vh;
  padding-top: 0.92rem;
  padding-bottom: 0.1rem;
  max-width: $pcMaxWidth;
  margin: 0 auto;
  .list-wrap {
    padding: 0 0.37rem;
    ul {
      display: flex;
      flex-wrap: wrap;
      justify-content: flex-start;
    }
  }
}
</style>
