<template>
  <div class="home-pic-view" :class="{ navHeight0: !state.clickShow }">
    <div class="click-show" v-show="state.clickShow">
      <LayoutsHeader :title="state.datasObj.title"></LayoutsHeader>
      <div @click.stop="setFavour" class="add-store" v-if="!state.isLike">加入书架</div>
      <div class="progress-wrap">
        <div class="progress-top">
          <div class="left-wrap">
            <div>{{ state.datasObj.title }}</div>
            <div>作者：{{ state.datasObj.author.toString() }}</div>
          </div>
          <div class="right-wrap">
            <!-- <div>详情</div> -->
            <div class="ml" @click.stop="open_ml">目录</div>
          </div>
        </div>
        <div class="progress-bot">
          <div class="up-page" @click="fn_upPage">上一章</div>
          <van-slider v-model="state.pageValue" :min="1" :max="state.pageMax" @change="onChange" />
          <div class="down-page" @click="fn_downPage">下一章</div>
        </div>
      </div>
    </div>
    <div class="view-chapter" v-show="!state.clickShow">
      第{{ state.chapterName }}话 <span>{{ state.pageValue }} / {{ state.pageMax }}</span>
    </div>
    <van-index-bar ref="viewIndexBar" class="view-index-bar" @change="change" :index-list="state.indexList">
      <ul class="view-wrap" @click="state.clickShow = !state.clickShow">
        <li
          v-for="(item, index) in state.datasObj.chapter"
          :key="index"
          :style="{ height: item.reset_high ? item.reset_high + 'px' : 'auto' }"
        >
          <!-- 章节定位器 -->
          <van-index-anchor :index="index + 1" />
          <DecryptImg :needPadding="false" class="dm-img" :imgURL="item.comicsPic" />
        </li>
      </ul>
    </van-index-bar>
    <ComicCatalogue ref="refComicCatalogue" :catalogueObj="state.catalogueObj"></ComicCatalogue>
    <DmPopup ref="popupMsg"></DmPopup>
  </div>
</template>
<script setup>
import { showToast } from 'vant'
import { picViewRightTo } from '@/utils/utils_tools'
import { comicsDetail } from '@/api/comics' //api列表
import { onUnmounted } from 'vue'
import { useStore } from 'vuex'
const emits = defineEmits(["ComicCatalogue","setBookshelf"])
const store = useStore()
const router = useRouter()
const route = useRoute()
const DmPopup = defineAsyncComponent(() => import('@/components/Popup/index.vue'))
const ComicCatalogue = defineAsyncComponent(() => import('@/components/Comic/comic/catalogue/index.vue'))
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
let refComicCatalogue = ref(null)
let viewIndexBar = ref(null)
const state = reactive({
  //引导条
  indexList: [],
  catalogueObj: {
    list: [],
    show: false
  },
  isLike: true,
  //点击
  clickShow: false,
  //章节控制
  pageMax: 50,
  pageValue: 1,
  chapterName: '',
  //加载刷新
  datasObj: {
    author: [],
    chapter: [],
    chapterInfos: []
  },
  pageItem: {},
  //窗口宽度
  clientWidth: 0,
  bookshelfList:computed(() => store.state.history.bookshelfList),
})

//滚动事件
const scrollHandle =() =>{
  if (state.datasObj.chapter.length < 3) return
  if (state.pageValue >= state.datasObj.chapter.length - 3) {
    let marginBot = 0
    if (document.documentElement.scrollTop) {
      marginBot =
        document.documentElement.scrollHeight -
        (document.documentElement.scrollTop + document.body.scrollTop) -
        document.documentElement.clientHeight
    } else {
      marginBot = document.body.scrollHeight - document.body.scrollTop - document.body.clientHeight
    }
    if (marginBot <= 0) {
      fn_downPage()
    }
  }
}

//初始化图片高度
const get_viewPicHeight =(item) =>{
  //没有数据默认auto
  if (!item.high || !item.width) return
  if (!state.clientWidth) {
    state.clientWidth = document.querySelector('.home-pic-view').clientWidth
  }
  item.reset_width = document.querySelector('.home-pic-view').clientWidth
  item.reset_high = (state.clientWidth * item.high) / item.width
  if (!Number.isInteger(item.reset_high)) {
    item.reset_high = +item.reset_high.toFixed(3)
  }
}

//上一章
const fn_upPage =async () =>{
  if (state.catalogueObj.list.length <= 1) return showToast('当前只有一章')
  if (state.chapterName - 1 === 0) return showToast('当前第一章')
  state.catalogueObj.list.forEach(async (item, index) => {
    if (+route.params.id == item.id) {
      state.pageItem = state.catalogueObj.list[index - 1]
      showToast('正在加载第' + (state.chapterName - 1) + '话')
      let code = await picViewRightTo(+state.pageItem.id)
    }
  })
}
//下一章
const fn_downPage =async () =>{
  if (state.chapterName - 1 === state.catalogueObj.list.length) return showToast('当前最后一章')
  state.catalogueObj.list.forEach(async (item, index) => {
    if (+route.params.id == item.id) {
      if (state.catalogueObj.list.length - 1 != index) {
        state.pageItem = state.catalogueObj.list[index + 1]
        showToast('正在加载第' + (state.chapterName + 1) + '话')
        let code = await picViewRightTo(+state.pageItem.id)
      } else {
        return showToast('当前最后一章')
      }
    }
  })
}
//打开目录
const open_ml =() =>{
  state.clickShow = false
  refComicCatalogue.value.initDatas()
}

//slider滑动跳页，跳页不能开启-van字符查找改变
const onChange =(value) =>{
  viewIndexBar.value.scrollTo(value.toString())
}

//van字符查找改变,正在滑动不调用
const change =(index) =>{
  state.pageValue = index
}

//获取章节信息
const comicsChapterPics =(datasObj) =>{
  state.datasObj = datasObj
  state.pageMax = datasObj.chapter.length
  datasObj.chapter.forEach((item, index) => {
    //引导条
    state.indexList.push(index + 1)
    //计算初始化高度
    get_viewPicHeight(item)
  })

  datasObj.chapterInfos.forEach((item, index) => {
    item.indexName = index + 1
    if (+route.params.id == item.id) {
      state.chapterName = index + 1
    }
  })
  state.catalogueObj.list = datasObj.chapterInfos
} 
//收藏位置
const findIndex =(datasObj) =>{
  let status = false
  let newBookshelfList = JSON.parse(JSON.stringify(state.bookshelfList))
  newBookshelfList.forEach(element1 => {
    element1.list.forEach(element2 => {
      if (element2.id == +route.query.parentId) {
        status = true
        //大于才更新
        if (!element2.hasViewNum) {
          element2.hasViewNum = state.datasObj.Num
        } else {
          if (state.datasObj.Num > element2.hasViewNum) element2.hasViewNum = state.datasObj.Num
        }
        element2.hasViewCount = state.datasObj.Count
        emits("setBookshelf",newBookshelfList)
      }
    })
  })
  if (!status) {
    state.isLike = false
  } else {
    state.isLike = true
  }
}
//本地收藏
const setFavour =async () =>{
  const res = await comicsDetail({
    id: +route.query.parentId
  })
  if (res.code === 200 && res.data) {
    let newBookshelfList = JSON.parse(JSON.stringify(state.bookshelfList))
    if (newBookshelfList[0].list.length > 100) {
      return showToast('您收藏的漫画超过100个，请收藏夹删除再操作')
    }
    let comicsSave = JSON.parse(JSON.stringify(res.data.comicsData))
    delete comicsSave.author
    delete comicsSave.lookComics
    delete comicsSave.tags
    newBookshelfList[0].list.unshift(comicsSave)
    store.commit('setBookshelf', newBookshelfList)
    state.isLike = true
    showToast('收藏成功！')
  } else {
    return showToast(res.tip)
  }
}

onMounted(() => {
  //获取数据
  let datasObj = JSON.parse(JSON.stringify(store.state.history.comicChapterObj))
  //初始化
  comicsChapterPics(datasObj)
  //查找是否已收藏 更新书架当前已看到的位置
  findIndex()
  //监控到底加载
  window.addEventListener('scroll', scrollHandle)
}) 
onUnmounted(() => {
  window.removeEventListener('scroll', scrollHandle)
})
</script>

<style lang="scss" scoped>
.home-pic-view {
  max-width: 876px;
  margin: 0 auto;
  padding-top: 0.92rem;
  margin-bottom: 3rem;
  width: 100%;
  &.navHeight0 {
    padding-top: 0;
  }
  .click-show {
    .add-store {
      position: fixed;
      text-align: center;
      right: 0;
      top: 20vh;
      width: 1.69rem;
      height: 0.53rem;
      line-height: 0.53rem;
      border-top-left-radius: 0.27rem;
      border-bottom-left-radius: 0.27rem;
      background: $mainBgColor;
      font-size: 0.28rem;
      color: #ff7777;
      z-index: 99;
    }
    .progress-wrap {
      max-width: 876px;
      position: fixed;
      bottom: 0;
      width: 100%;
      z-index: 99;
      border-top-left-radius: 0.8rem;
      border-top-right-radius: 0.8rem;
      background: $mainBgColor;
      @include box-shadow-all;
      padding: 0.3rem 0.66rem;
      .progress-top {
        padding-bottom: 0.45rem;
        display: flex;
        justify-content: space-between;
        .left-wrap {
          div {
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            max-width: 4rem;
            &:first-child {
              color: #ff8b00;
              font-size: 0.28rem;
            }
            &:last-child {
              font-size: 0.24rem;
              color: rgba($color: #ff8b00, $alpha: 0.8);
            }
          }
        }
        .right-wrap {
          align-items: center;
          display: flex;
          div {
            font-size: 0.28rem;
            width: 1.5rem;
            height: 0.68rem;
            line-height: 0.68rem;
            @include box-shadow-all;
            border-radius: 0.24rem;
            text-align: center;
            margin-left: 0.1rem;
            color: #ff7777;
            &.ml {
              color: #ff8b00;
            }
          }
        }
      }
      .progress-bot {
        width: 6.2rem;
        margin: 0 auto;
        display: flex;
        align-items: center;
        .up-page,
        .down-page {
          white-space: nowrap;
          font-size: 0.28rem;
          color: #ff8b00;
        }
        .up-page {
          padding-right: 0.3rem;
        }
        .down-page {
          padding-left: 0.3rem;
        }
        :deep()  {
          .van-slider__button {
            width: 0.32rem;
            height: 0.32rem;
            background-color: #ec8f35;
          }
          .van-slider__bar {
            background-color: #ec8f35;
          }
        }
      }
    }
  }
  .view-chapter {
    z-index: 999;
    position: fixed;
    bottom: 0.8rem;
    right: 0.2rem;
    background: rgba(#000, 0.6);
    border-radius: 0.2rem;
    padding: 0.05rem 0.2rem;
    text-align: center;
    color: $mainTxtColor1;
    font-size: 0.24rem;
  }
  .view-wrap {
    li {
      font-size: 0;
      width: 100%;
      min-height: 4rem;
      .dm-img {
        width: 100%;
      }
    }
  }
  //定位器
  :deep()  {
    .view-index-bar {
      .van-index-bar__sidebar,
      .van-index-anchor {
        display: none;
      }
    }
  }
}
</style>
