<template>
  <div class="community-detail">
    <LayoutsHeader :title="'详情'" />
    <PullUp
      @refreshData="refreshData"
      @moreData="moreData"
      :finished="state.finished"
      :loading="state.loading"
      :refreshing="state.refreshing"
    >
      <PostItem :isDetail="true" :itemData="state.detailInfo" />
      <!-- 评论列表 -->
      <div class="comment-list">
        <div class="content-main" v-for="item in state.commentList" :key="item.id">
          <DecryptImg class="user-header" :imgURL="item.userAvatar" />
          <!-- 第一层用户 -->
          <div class="comment-user">
            <div class="first-comment">
              <div class="comment-user-name">
                {{ item.userName }}
                <span v-if="item.userId === state.detailInfo.base.userId" class="zuoze">作者</span>
              </div>
              <div class="text">
                <p class="comment-user-text">
                  {{ item.text }}
                </p>
                <!-- 回复按钮，时间 -->
                <div class="comment-user-res">
                  <p class="comment-user-time">
                    {{ timeDiff(item.createdAt) }}
                  </p>
                  <!-- 回复 -->
                  <div class="resTxt" @click.stop="clickRespondText(item)">回复</div>
                </div>
              </div>
              <!-- 展开 -->
              <div class="comment-user-open" v-if="item.commentCount && item.id !== state.activeIndex">
                <div class="comment-user-open-right" @click="openSon(item)">
                  <span>展开 {{ item.commentCount }} 条回复</span>
                </div>
              </div>
              <!-- 第二层用户评论 -->
              <template v-if="item.id === state.activeIndex">
                <div class="second-comment" v-for="sItem in state.secondList" :key="sItem.id">
                  <DecryptImg class="user-header" :imgURL="sItem.userAvatar" />
                  <div class="second-comment-main">
                    <div class="comment-user-name">
                      {{ sItem.userName }}
                      <span v-if="sItem.userId === state.detailInfo.base.userId" class="zuoze">作者</span>
                      <span class="color">回复</span> {{ item.userName }} <span class="color">的评论</span>
                    </div>
                    <div class="text">
                      <div class="comment-user-text">
                        {{ sItem.text }}
                      </div>
                      <!-- 回复按钮，时间 -->
                      <div class="comment-user-res">
                        <p class="comment-user-time">
                          {{ timeDiff(sItem.createdAt) }}
                        </p>
                        <!-- 回复 -->
                        <div class="resTxt" @click.stop="clickRespondText(item)">回复</div>
                      </div>
                    </div>
                  </div>
                </div>
              </template>
            </div>
          </div>
        </div>
      </div>
    </PullUp>
    <!-- 评论 -->
    <div class="submit-box">
      <!-- 是否为会员 -->
      <div class="submit-btn" @click="$router.push('/vip')" v-if="!state.isMember">开通VIP 立即评论</div>
      <div class="submit-input" v-else>
        <van-field v-model="state.text" :placeholder="state.placeholder" />
        <span class="submit-txt" @click="addComment">发送</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { showToast } from 'vant'
import { community_detail } from '@/api/community'
import { comment_list, comment_add } from '@/api/home'
import { timeDiff } from '@/utils/filter'
import { useStore } from 'vuex'
const store = useStore()
const route = useRoute()
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const PostItem = defineAsyncComponent(() => import('@/components/Community/default.vue'))

const state = reactive({
  detailInfo: {
    nodes: [],
    base: {}
  },
  finished: false,
  loading: false,
  refreshing: false,
  activeIndex: 0, // 展开的id
  commentList: [], // 一级评论列表
  pageNum: 1,
  pageSize: 10,
  text: '', // 评论
  placeholder: '喜欢就给个评论支持一下～',
  parentsId: 0, // 父级id
  secondList: [], // 二级评论列表  
  isMember:computed(() => store.getters['isMember'])
})


// 获取详情信息
const getDetail =async () =>{
  try {
    const res = await community_detail({
      id: +route.query.id
    })
    if (res.code === 200) {
      state.detailInfo = res.data
    } else {
      showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    showToast('请求错误，请稍后再试！')
  }
}

// 触发评论列表刷新
const refreshData = (refreshing) =>{
  state.refreshing = refreshing
  state.finished = false
  state.loading = true
  state.commentList = []
  state.secondList = []
  state.activeIndex = 0
  getCommentList({
    objectId: state.detailInfo.base.id,
    objectType: 2,
    pageNum: 1,
    pageSize: 10,
    parentsId: null
  })
}

// 触发onload
const moreData = (loading) =>{
  state.loading = loading
  state.pageNum += 1
  getCommentList({
    objectId: state.detailInfo.base.id,
    objectType: 2,
    pageNum: state.pageNum,
    pageSize: state.pageSize,
    parentsId: state.parentsId
  })
}

// 获取评论列表
const getCommentList =async (data) =>{
  try {
    const res = await comment_list(data)
    if (res.code === 200) {
      // 有parentsId 为二级列表请求
      state.loading = false
      state.refreshing = false
      if (data.parentsId) {
        state.secondList = [...state.secondList, ...res.data.list]
        if (!res.data.list || (res.data && res.data.list.length < state.pageSize)) {
          state.parentsId = null
        }
      } else {
        state.commentList = [...state.commentList, ...res.data.list]
        if (!res.data.list || (res.data && res.data.list.length < state.pageSize)) {
          state.finished = true
        }
      }
    } else {
      state.loading = false
      state.refreshing = false
      state.finished = true
      return showToast(res.tip || res.data.msg)
    }
  } catch (error) {
    state.loading = false
    state.refreshing = false
    state.finished = true
    console.log(error)
    showToast('请求错误，请稍后再试！')
  }
}

// 点击回复按钮
const clickRespondText = (item) =>{
  if (!state.isMember) {
    return showToast('会员才参与可以评论!')
  }
  state.placeholder = `回复 ${item.userName}`
  state.parentsId = item.id
  state.replyId = item.userId
}

// 打开二级评论列表
const openSon = (item) =>{
  state.activeIndex = item.id
  state.pageNum = 1
  state.finished = false
  state.parentsId = item.id
  state.secondList = []
  const data = {
    objectId: state.detailInfo.base.id,
    objectType: 2,
    pageNum: state.pageNum,
    pageSize: state.pageSize,
    parentsId: state.parentsId
  }
  getCommentList(data)
}

// 发布评论
const addComment =async () =>{
  if (!state.text) {
    return showToast('请输入评论内容!')
  }
  const res = await comment_add({
    objectId: state.detailInfo.base.id,
    objectType: 2, // 对象类型
    parentsId: state.parentsId, // 上级id
    replyId: state.replyId, // 回复id
    // score: state.score, // 评分 没有为0
    text: state.text
  })
  state.activeIndex = 0
  if (res.code === 200) {
    state.commentList = []
    state.secondList = []
    state.text = ''
    const data = {
      objectId: state.detailInfo.base.id,
      objectType: 2,
      pageNum: 1,
      pageSize: 10,
      parentsId: null
    }
    getCommentList(data)
    return showToast('评论成功')
  } else {
    state.loading = false
    state.isLoading = false
    state.finished = true
    return showToast(res.tip || res.data)
  }
}

onMounted(async () => {
  await getDetail()
  await refreshData()
}) 

</script>

<style lang="scss" scoped>
.community-detail {
  // padding-top: 1.1rem;
  // padding-bottom: 1.1rem;
  padding: 1.1rem 0.25rem;
  border-radius: 0.12rem;
  box-shadow: $shadow;
  min-height: 100vh;
  max-width: 540px;
  margin: 0 auto;
    
}
//  评论主体内容
.content-main {
  display: flex;
  padding: 0.3rem;
  box-sizing: border-box;
  max-width: 100%;
  border-bottom: 0.02rem solid #eee;
  .user-header {
    width: 0.5rem;
    height: 0.5rem;
    border-radius: 50%;
    margin-right: 0.2rem;
    :deep()  {
      .warp {
        font-size: 0;
        border-radius: 50%;
      }
      .img {
        border-radius: 50%;
        width: 0.5rem;
        height: 0.5rem;
      }
    }
  }
  .comment-user {
    max-width: 100%;
    .first-comment,
    .second-comment {
      font-size: 0.22rem;
      color: $mainTxtColor1;
      margin-top: 0.1rem;
      .zuoze {
        display: inline-block;
        width: 0.65rem;
        height: 0.37rem;
        background: #999999;
        font-size: 0.24rem;
        color: $mainTxtColor1;
        text-align: center;
        line-height: 0.37rem;
        border-radius: 0.05rem;
        margin-left: 0.2rem;
      }
      .comment-user-name {
        font-size: 0.26rem;
        color: $mainTxtColor1;
      }
      .comment-user-time {
        font-size: 0.18rem;
        color: #999999;
        margin: 0;
        margin-right: 0.3rem;
      }
      .comment-user-text {
        max-width: 100%;
        font-size: 0.18rem;
        word-break: break-all;
        word-wrap: break-word;
        margin: 0;
        color: $mainTxtColor2;
        margin: 0.1rem 0;
        font-size: 0.28rem;
      }
    }
  }
}
// 回复文本样式
.resTxt {
  @include flexbox;
  color: #999999;
  img {
    width: 0.35rem;
    margin-right: 0.1rem;
  }
}
.second-comment {
  display: flex;
  .user-header {
    width: 0.5rem;
    height: 0.5rem;
    border-radius: 50%;
    margin-right: 0.2rem;
  }
}
.comment-user-res {
  @include flexbox;
}
// 展开回复
.comment-user-open {
  &-right {
    color: #3a84f6;
  }
}
// 提交按钮
.submit-box {
  position: fixed;
  width: 100%;
  max-width: $pcMaxWidth;
  background: $mainBgColor;
  bottom: 0;
  left: 50%;
  @include transformCenter(-50%, 0);
  font-size: 0.3rem;
  z-index: 10;
  // 评论发送按钮
  .submit-input {
    @include flexbox;
    margin: 0.3rem auto;
    font-size: 0.26rem;
    padding: 0 0.3rem;
    .submit-txt {
      width: 1.2rem;
      height: 0.6rem;
      display: inline-block;
      background: $btnBg;
      border-radius: 0.3rem;
      text-align: center;
      line-height: 0.6rem;
    }
    :deep()  {
      .van-cell {
        background-color: #f4f4f4;
        border-radius: 0.3rem;
        margin-right: 0.3rem;
        padding: 0.1rem 0.2rem;
      }
    }
  }

  // 开通会员提示按钮
  .submit-btn {
    text-align: center;
    background: $btnBg;
    height: 1rem;
    border-radius: 0.12rem;
    line-height: 1rem;
  }
}
.color {
  color: #333;
}
</style>
