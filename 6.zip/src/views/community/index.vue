<!-- home -->
<template>
  <div class="index-container">
    <!-- <JavSwiper class="dating-swiper" :imgs="commityAD" /> -->
    <!--切换面板 -->
    <JavTab
      :addClass="'bgTab'"
      class="community-tab"
      @change="change"
      :titles="postCategory"
      :active="state.indexActive"
      :animated="false"
    >
      <!-- 列表 -->
      <PullUp
        @refreshData="refreshData"
        @moreData="moreData"
        :finished="state.finished"
        :loading="state.loading"
        :refreshing="state.refreshing"
      >
        <!-- 热门推荐 -->
        <div class="hot-recommend" v-if="state.hotLits && state.hotLits.length > 0">
          <div class="top">
            <img src="@/assets/imgs/community/hot.svg" alt="" />
            热门推荐
          </div>
          <ul class="bot-list" @touchmove.stop>
            <li v-for="item in state.hotLits" :key="item.id" @click="$router.push(`/up/index/${item.id}`)">
              <DecryptImg class="acavtar" :imgURL="item.avatar" />
              <p class="title">{{ item.name }}</p>
            </li>
          </ul>
        </div>
        
        <CommunityDefault v-for="(item,index) in state.list" :key="index" :itemData="item" />
      </PullUp>
    </JavTab>
    <!-- 发布按钮 -->
    <div class="public" @click="toPublic">
      <img src="@/assets/imgs/community/public.svg" alt="" />
    </div>    
    <!-- 发布按钮弹窗 -->
    <van-popup class="bottom-pop" v-model:show="state.showPublic" :position="'bottom'">
      <div class="title">请选择发布类型</div>
      <div class="dynamic" @click="$router.push('/community/public?type=1')">
        <img src="@/assets/imgs/community/img.svg" alt="" />
        动态
      </div>
      <div class="video"  @click="$router.push('/community/public?type=2')">
        <img src="@/assets/imgs/community/video.svg" alt="" />
        视频
      </div>
      <div class="btn" @click="state.showPublic = false">取消</div>
    </van-popup>
  </div>
</template>

<script setup name="communityPage">
import { showToast } from 'vant'
import { community_list } from '@/api/community'
import { useStore } from 'vuex'
const store = useStore()

const state = reactive({
  indexActive:0,
  loading: false,
  finished: false,
  refreshing: false,
  list: [],
  showPublic: false, // 发布弹窗控制
  pageSize: 10,
  pageNum: 1,
  hotLits: [], // 热门推荐列表
})

const JavTab = defineAsyncComponent(() => import('@/components/JavTab.vue'))
const JavSwiper = defineAsyncComponent(() => import('@/components/JavSwiper.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const CommunityDefault = defineAsyncComponent(() => import('@/components/Community/default.vue'))


// 获取首页顶部视频分类导航列表
const postCategory = computed(() => {
  return store.getters['postCategory']
})  
// 获取轮播广告
const commityAD = computed(() => {
  return store.getters['commityAD']
})  
const isMember = computed(() => {
  return store.getters['isMember']
})  

const change = (v,item) =>{
  state.indexActive=v;
  refreshData()
}
const refreshData = (refreshing) =>{
  state.refreshing = refreshing
  state.loading = true
  state.finished = false
  state.pageNum = 1
  state.list = []
  getPostList()
}
const moreData = (loading) =>{
  state.loading = loading
  state.pageNum += 1
  getPostList()
}
// 获取帖子列表
const getPostList =async () =>{
  try {
    const res = await community_list({
      id: state.indexActive,
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      state.loading = false
      state.refreshing = false
      if (state.pageNum === 1) {
        state.hotLits = res.data.publishList
      } else {
        res.data.publishList ? (state.hotLits = res.data.publishList) : ''
      }
      state.list = [...state.list, ...res.data.list]
      //  图片超出8张只显示8张
      state.list.map(item => {
        if (item.node && item.node.imgs &&item.node.imgs.length && item.node.imgs.length > 6) {
          item.node.imgs = item.node.imgs.splice(0, 6)
        }
      })
      if (!res.data.list || res.data.list.length < state.pageSize) {
        state.finished = true
      }
    } else {
      state.loading = false
      state.refreshing = false
      state.finished = true
      showToast(res.tip)
    }
  } catch (error) {
    state.loading = false
    state.refreshing = false
    state.finished = true
    console.log(error)
    showToast('请求错误，请稍后再试')
  }
}

const toPublic = () =>{
  if (isMember) {
    state.showPublic = true
  } else {
    return showToast('会员才可以发布哦！')
  }
}

onMounted(async () => {
}) 

</script>
<style lang="scss" scoped>
.index-container {
  min-height: $minHeight;
  background: $mainBgColor;
  position: relative;
  padding-top: 0.4rem;
  max-width: 960px;
  margin: 0 auto;
  // 轮播图
  .dating-swiper {
    width: 100%;
    :deep()  {
      .van-swipe__track {
        width: 100% !important;
        .van-swipe-item {
          width: 100% !important;
        }
      }
    }
  }
  .community-tab {
    margin-top: 0.3rem;
    padding: 0.3rem  0.3rem 1.3rem 0.3rem;
    :deep()  {
      .van-tabs__nav {
        padding: 0 0.3rem;
   
      }
      .van-tab:first-child {
        margin-left: 0.1rem !important;
      }
    }
  }
  // 热门推荐
  .hot-recommend {
    padding-top: 0.2rem;
    .top {
      @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
      font-weight: 600;
      font-size: 0.24rem;
      margin-bottom: 0.1rem;
      color: transparent;
      background: $txtActive;
      -webkit-background-clip: text;
      img {
        width: 0.32rem;
        height: 0.32rem;
        margin-right: 0.2rem;
      }
    }
    .bot-list {
      @include flexbox($jc: flex-start, $ai: flex-start, $fd: row, $fw: nowrap);
      background: $mainBgColor;
      box-shadow: $shadow;
      padding: 0.3rem 0.25rem;
      overflow-y: scroll;
      border-radius: 0.12rem;
      margin-bottom: 0.2rem;
      li {
        margin-right: 0.35rem;
        .acavtar {
          width: 1rem;
          border-radius: 50%;
          :deep()  {
            .warp {
              border-radius: 50%;
            }
          }
        }
        .title {
          margin: 0.15rem 0 0 0;
          font-size: 0.22rem;
          color: #939496;
          @include textoverflow();
        }
      }
      li:last-child {
        margin-right: 0;
      }
    }
  }
}
// 发布按钮
.public {
  width: 0.8rem;
  height: 0.8rem;
  background: linear-gradient(to right, #fd9c3a, #fc342d);
  border-radius: 50%;
  position: fixed;
  right: 0.7rem;
  bottom: 10%;
  z-index: 10;
  text-align: center;
  line-height: 0.6rem;
  img {
    width: 0.42rem;
    height: 0.48rem;
  }
}
// 发布弹窗
:deep(.bottom-pop){
  max-width: 960px;
  margin: 0 auto;
  left: auto;
  background: $btnBg;
  font-size: 0.32rem;
  padding-top: 0.3rem;
  text-align: center;

  border-radius: 0.2rem;
  .dynamic,
  .video {
    @include flexbox($jc: center, $ai: center, $fd: row, $fw: nowrap);
    padding: 0.3rem 0;
    font-size: 0.36rem;
    img {
      width: 0.37rem;
      height: 0.34rem;
      margin-right: 0.53rem;
    }
  }
  .dynamic {
    border-top: 0.02rem solid #ddd;
    border-bottom: 0.02rem solid #ddd;
    margin-top: 0.3rem;
  }
  .video {
    border-bottom: 0.02rem solid #adadb7;
  }
  .btn {
    padding: 0.3rem 0;
    background: $btnBg;
  }
}
</style>
