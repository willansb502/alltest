<template>
  <div class="release">
    <LayoutsHeader :title="+$route.query.type === 1 ? '动态' : '视频'"></LayoutsHeader>
    <div class="release-main">
      <!-- 描述信息 -->
      <p class="desc-title">描述信息</p>
      <van-field v-model="state.text" rows="4" autosize required type="textarea" :placeholder="`请填写需要发布的${+$route.query.type === 1 ? '动态' : '视频'}介绍`" />
      <!-- 上传图片 -->
      <p class="upload-img-title" v-if="+$route.query.type === 1">最多可选择9张图片</p>
      <UploadImg class="upload-img" v-if="+$route.query.type === 1" @result="result" :imgs="state.images"  />
      <span class="upload-img-title" v-if="+$route.query.type === 2">视频大小不超过100M</span>
      <SimpleUpload
        v-if="+$route.query.type === 2"
        class="w-full"
        @file-added="onVideoFileAdded"
        @uploading="onVideoUploading"
        @uploaded="onVideoUploadSuccess"
        @upload-progress="onVideoUploadProgress"
        @upload-fail="onVideoUploadFail">
        <template #view>
          <div v-if="state.previewVideoSrc">
            <video class="cover-image rounded-[5px] object-cover">
              <source :src="state.previewVideoSrc">
            </video>
          </div>
          <div v-else class="cover-default-image">
            <span>+</span>
          </div>
          <div class="cover-notice">视频大小不超过100M</div>
        </template>
      </SimpleUpload>
      <van-field
        v-model.number="state.price"
        name="age"
        label="帖子价格"
        placeholder="输入帖子价格(只能是整数)"
        :label-width="'1.5rem'"
        :rules="[{ required: true, message: '请输入价格(只能是整数)' }]"
      />
      <!-- 提示语 -->
      <ul class="waring" v-if="+$route.query.type === 1">
        <li>动态发布规则</li>
        <li>1.图片模糊不清，不通过</li>
        <li>2.有非本APP的网址，水印，联系方式的，不通过</li>
      </ul>
      <!-- 提示语 -->
      <ul class="waring" v-if="+$route.query.type === 2">
        <li>视频发布规则</li>
        <li>1.发布视频资源可设置价格，审核通过后，将在社区页展示</li>
        <li>2.发布成功，解锁可获得40%的解锁收益</li>
        <li>3.小于30秒的视频，不通过</li>
        <li>4.清晰度低于640的视频，不通过</li>
        <li>5.有非本APP的网址，水印，联系方式的，不通过</li>
        <li>6.设置更高的金额，请联系在线客服</li>
      </ul>
    </div>
    <!-- 提交验证 -->
    <div class="submit" @click="submit">发布</div>
  </div>
</template>

<script setup>
import { showToast , showLoadingToast } from 'vant';
import { community_publish } from '@/api/community'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const UploadImg = defineAsyncComponent(() => import('@/components/UploadImg/index.vue'))
const SimpleUpload = defineAsyncComponent(() => import('@/components/UploadVideo/simple-upload.vue'))
const state = reactive({
  text: '',
  price: 0,
  taskID: '',
  video: '',
  images: [],
  previewVideoSrc: null
})
const result = (res) => {
  state.images = res
}
const videoResult = (data) => {
  state.video = data.videoUri
  state.taskID = data.id
}
const submit =async () => {
  if (!state.text || state.text.length < 8) {
    return showToast('描述信息字数不可少于8个字')
  }
  if (!state.video&&!state.images || !state.video&&state.images.length === 0) {
    return showToast('请上传图片!')
  }
  if (state.images.length > 9) {
    return showToast('图片不能大于9张')
  }
  try {
    state.price = state.price * 100
    const res = await community_publish({
      imgs: state.images,
      text: state.text,
      price: state.price,
      taskID: state.taskID,
      video: state.video
    })
    if (res.code === 200) {
      state.images = null
      state.text = null
      state.price = null
      state.taskID = null
      state.video = null
      showToast('提交成功，请等待审核')
    } else {
      return showToast(res.tip || res.data.msg || '上传失败')
    }
  } catch (error) {
    console.log(error)
    return showToast('请求错误，请稍后再试！')
  }
}
const onVideoFileAdded = (file) => {
  if(state.previewVideoSrc) return;
  state.previewVideoSrc = URL.createObjectURL(file)
}
const onVideoUploading = () => {
  showLoadingToast({
    type: 'loading',
    message: '视频上传中',
    forbidClick: true,
    duration: 0
  })
}
const onVideoUploadFail = () => {
  showToast('视频上传失败')
}
const onVideoUploadProgress = (data) => {
  showLoadingToast({
    type: 'loading',
    message: `视频上传 ${Math.ceil(data.progress * 100)}%`,
    forbidClick: true,
    duration: 0
  })
}
const onVideoUploadSuccess = (data) => {
  console.log('onVideoUploadSuccess:', data)
  showToast('上传成功')
  state.video = data.videoUri
  state.taskID = data.id
}

</script>

<style lang="scss" scoped>
.release {
  min-height: 100vh;
  padding-top: 1rem;
  &-main {
    padding: 0.3rem;
    .desc-title {
      margin: 0;
      font-size: 0.26rem;
    }
    .van-cell {
      margin-top: 0.2rem;
      background: $mainBgColor;
      color: #000;
      :deep() {
        .field-placeholder-text-color {
          color: #9493b1;
        }
        .van-field__control {
          color: #666;
          font-size: 0.2rem;
        }
      }
    }
    .van-cell::after {
      display: none;
    }
    .upload-img{
      :deep(){
        .img-item:nth-child(3n){
          margin-right: 0;
        }
      }
    }
    // 图片上传
    .upload-img-title {
      color: #9493b1;
      margin: 0;
      font-size: 0.26rem;
    }
    .upload-img-box {
      .img-item:nth-child(3n) {
        margin-right: 0;
      }
    }
  }
  .viode-upload {
    :deep() {
      .uploader-btn {
        width: 2.5rem;
        height: 2.5rem;
      }
    }
  }
  .title {
    p {
      margin: 0;
      font-size: 0.32rem;
    }
  }
  // 表单提交
  :deep() {
    .van-field {
      color: #666;
      margin-bottom: 0.2rem;
      border-radius: 0.1rem;
      box-shadow: $shadow;
      .van-field__label {
        font-weight: 600;
        span::after {
          content: '|';
          margin-left: 0.2rem;
        }
      }
    }
  }
  // 提示语
  .waring {
    font-size: 0.24rem;
    color: #9493b1;
  }
}
// 提交审核
.submit {
  position: fixed;
  bottom: 0rem;
  width: 95%;
  max-width: $pcMaxWidth;
  height: 0.8rem;
  background: $btnBg;
  font-size: 0.3rem;
  text-align: center;
  line-height: 0.8rem;
  left: 50%;
  transform: translate(-50%, 0);
  border-radius: 0.4rem;
}

.cover-image {
  width: 100%;
  height: 2rem;
}

.cover-default-image {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  background-color: #D9D9D9;
  width: 50%;
  height: 2rem;

  img {
    width: 0.9rem;
  }

  span {
    padding-top: 4px;
    font-size: 14px;
    font-weight: 500;
    color: #666;
  }
}
.cover-notice {
  font-size: 12px;
  font-weight: 400;
  color: rgba(#FFF, 0.5);
  padding-top: 4px;
}
</style>
