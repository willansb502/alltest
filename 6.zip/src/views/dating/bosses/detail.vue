<template>
  <div class="bosses-detail">
    <LayoutsHeader  :class="color ? 'color' : ''" />
    <div class="detail-main">
      <!-- 经纪人信息 -->
      <div class="top-warp">
        <div class="avatar-bg">
          <div class="avatar-child">
            <DecryptImg class="avatar" :imgURL="bossInfo.avatar" />
            <div class="avatar-right">
              <div class="avatar-right-top">
                <p class="name">{{ bossInfo.name }}</p>
                <p class="recommend" v-if="bossInfo.recommend">推荐</p>
              </div>
              <!-- 商家信息 -->
                 <div class="boss-info">
            <div>认证妹子 {{ bossInfo.girls }}</div>
            <div>成交 {{ bossInfo.orders }}</div>
            <div>数量 {{ numberFilter(bossInfo.fans) }}</div>
          </div>
            </div>
          </div>
        </div>
        <div class="bot-info">
          <!-- 经纪人描述 -->
          <div class="desc">{{ bossInfo.desc }}</div>
          <!-- 排序查询 -->
          <div class="sort-box">
            妹子列表
            <div class="sort-type">
              <div class="sort-box" @click="showSort = !showSort" :class="{ up: showSort }">
                <span style="color:#333;">{{ sortList[sort].name }}</span>
                <van-icon name="arrow"  />
              </div>
              <div class="sort-list">
                <ul v-if="showSort">
                  <li
                    v-for="item in sortList"
                    :key="item.id"
                    class="sort-type-item"
                    @click="selectType(item.id)"
                    :class="{ activeSort: sort === item.id }"
                  >
                    {{ item.name }}
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <PullUp
        @refreshData="refreshData"
        @moreData="moreData"
        :finished="finished"
        :loading="loading"
        :refreshing="refreshing"
        class="list-main"
      >
        <Smcard :list="modelList"></Smcard>
      </PullUp>
    </div>
  </div>
</template>

<script setup>
import { showToast } from 'vant'
import { bosses_detail } from '@/api/dating'
import { numberFilter } from '@/utils/filter'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const Smcard = defineAsyncComponent(() => import('@/components/Dating/Sm_card.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))


export default {
  components: {
    LayoutsHeader: () => import('@/components/LayoutsHeader.vue'),
    DecryptImg: () => import('@/components/DecryptImg/index.vue'),
    Smcard: () => import('@/components/Dating/Sm_card.vue'),
    PullUp: () => import('@/components/PullUp.vue')
  },
  data() {
    return {
      pageNum: 1,
      pageSize: 10,
      color: false,
      loading: false,
      refreshing: false,
      finished: false, // 终止请求
      modelList: [], // 妹子列表
      bossInfo: {}, // 经纪人详情信息
      sort: 0, // 排序方式
      showSort: false, // 下拉框显示按钮
      sortList: [
        {
          id: 0,
          name: '创建时间'
        },
        {
          id: 1,
          name: '观看数量'
        },
        {
          id: 2,
          name: '购买数量'
        },
        {
          id: 3,
          name: '收藏数量'
        }
      ]
    }
  },
  async mounted() {
    await this.refreshData()
    window.addEventListener('scroll', this.scrollHandle) // 绑定页面滚动事件
  },
  methods: {
    // 监听滚动高度
    scrollHandle(e) {
      const top = e.srcElement.scrollingElement.scrollTop // 获取页面滚动高度
      if (top >= 300) {
        this.color = true
      } else {
        this.color = false
      }
    },
    moreData(loading) {
      this.loading = loading
      this.pageNum += 1
      this.getDatingBossesDetail()
    },
    // 选择排序方式
    selectType(id) {
      this.sort = id
      this.showSort = false
      this.refreshData()
    },
    // 上拉刷新
    refreshData(refreshing) {
      this.refreshing = refreshing
      this.modelList = []
      this.finished = false
      this.loading = true
      this.pageNum = 1
      this.getDatingBossesDetail()
    },
    // 请求商家详情信息
    async getDatingBossesDetail() {
      try {
        const res = await bosses_detail({
          id: +this.$route.params.id,
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          sort: this.sort
        })
        if (res.code === 200) {
          this.loading = false
          this.refreshing = false
          if (this.pageNum === 1) {
            this.bossInfo = res.data.bossInfo
          } else {
            res.data.bossInfo ? (this.bossInfo = res.data.bossInfo) : (this.bossInfo = this.bossInfo)
          }
          if (res.data.modelList < this.pageSize || !res.data.modelList) {
            this.finished = true
          }
          this.modelList = [...this.modelList, ...res.data.modelList]
        } else {
          this.loading = false
          this.refreshing = false
          this.finished = true
          return showToast(res.tip)
        }
      } catch (error) {
        this.loading = false
        this.refreshing = false
        this.finished = true
        console.log(error)
      }
    }
  },
  beforeDestroy() {
    window.removeEventListener('scroll', this.scrollHandle)
  }
}
</script>

<style lang="scss" scoped>
.bosses-detail {
  min-height: 100vh;
  :deep()  {
    .van-nav-bar {
      background: transparent !important;
      border: none !important;
    }
       .van-icon-arrow-left ,.van-nav-bar__title,.van-nav-bar__content{
      color: $mainTxtColor1 !important;
    }
  }
}
.color {
  :deep()  {
    .van-nav-bar {
      background: transparent !important;
    }
    .van-icon-arrow-left ,.van-nav-bar__title,.van-nav-bar__content{
      color: #000 !important;
    }
  }
}
// 头部商家信息
.top-warp {
  font-size: 0.28rem;
  .avatar-bg {
    padding-top: 30%;
    min-height: 3rem;
    width: 100%;
    position: relative;
    background: url('../../../assets/imgs/dating/boss-bg.jpg') no-repeat;
    background-size: 100% 100%;
  }
  // 商家名称
  .avatar-child {
    position: absolute;
    bottom: 0rem;
    right: -0.3rem;
    width: 100%;
    box-sizing: content-box;
    padding-bottom: 0.38rem;
    display: flex;
    align-items: center;
    .avatar {
      width: 1rem;
      border-radius: 50%;
      margin-right: 0.3rem;
      :deep()  {
        .warp {
          border-radius: 50%;
        }
      }
    }
    .avatar-right {
      width: 60%;
    }
    .avatar-right-top {
      display: flex;
      align-items: center;
      margin-bottom: 0.09rem;
      font-weight: 600;
      font-size: 0.36rem;

      p {
        margin: 0;
      }
      .name {
        margin-right: 0.2rem;
        color: $mainTxtColor1;
      }
    }
  }
  // 商家信息
  .boss-info {
      @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
       color: $mainTxtColor1;
      font-size: 0.24rem;
      div {
        margin-right: 0.42rem;
      }
      div:last-child {
        margin-right: 0;
      }
    }
  .recommend {
    background-image: linear-gradient(to bottom, #fd9c3a, #fc342d);
    color: $mainTxtColor1;
    width: 0.7rem;
    height: 0.32rem;
    line-height: 0.32rem;
    font-size: 0.22rem;
    border-radius: 0.1rem;
    text-align: center;
  }
}
// 经纪人底部描述
.bot-info {
  padding: 0.25rem 0.3rem;

  color: #666666;
  font-size: 0.26rem;
  margin-bottom: 0.2rem;
  .desc {
    color: #bfc0c3;
    margin-bottom: 0.37rem;
  }
  .sort-box {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 0.32rem;
    font-weight: 600;
    color: #bfc0c3;
  }
  // 排序列表
  .sort-type {
    position: relative;
    .sort-box {
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.24rem;
      background-color: #f2f2f2;
      width: 1.6rem;
      height: 0.42rem;
      border-radius: 0.21rem;
      img {
        width: 0.17rem;
        height: 0.12rem;
        margin-left: 0.12rem;
      }
    }
    .up {
      img {
        transform: rotate(180deg);
      }
    }
  }
  .sort-list {
    position: absolute;
    top: 0.6rem;
    left: 50%;
    transform: translate(-50%, 0);
    width: 100%;
    color: $mainTxtColor1;
    font-size: 0.22rem;
    z-index: 10;
    ul {
      position: relative;
      background: #2b2b3d;
      border: 0.02rem solid #2b2b3d;
      border-radius: 0.06rem;
      li {
        border-bottom: 0.02rem solid #666666;
        text-align: center;
        padding: 0.04rem 0;
        box-sizing: content-box;
      }
      .activeSort {
        color: #3a84f6;
      }
    }
    ul::after,
    ul::before {
      position: absolute;
      bottom: 100%;
      left: calc(93% - 14px);
      border: solid transparent;
      content: '';
      height: 0;
      width: 0;
      pointer-events: none;
    }

    ul::after {
      border-color: transparent;
      border-bottom-color: #2b2b3d;
      border-width: 0.12rem;
      margin-left: -0.12rem;
    }
    ul::before {
      border-color: transparent;
      border-bottom-color: #2b2b3d;
      border-width: 0.15rem;
      margin-left: -0.15rem;
    }
  }
}
.list-main {
  padding: 0 0.25rem;
}
</style>
