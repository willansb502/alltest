<template>
  <div class="bosses-detail">
    <LayoutsHeader :title="'商家列表'" />

      <PullUp
        @refreshData="refreshData"
        @moreData="moreData"
        :finished="state.finished"
        :loading="state.loading"
        :refreshing="state.refreshing"
        class="list-main"
      >
        <SjCard :list="state.bossList"></SjCard>
      </PullUp>

  </div>
</template>

<script setup>
import { dating_bosses } from '@/api/dating'
import { showToast } from 'vant'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const SjCard = defineAsyncComponent(() => import('@/components/Dating/Sj_card.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const state = reactive({
  pageNum: 1,
  pageSize: 10,
  finished: false,
  loading: false,
  refreshing: false,
  bossList: []
})

const moreData =(loading) =>{
  state.loading = loading
  state.pageNum += 1
  getDatingBossesList()
}


// 上拉刷新
const refreshData =(refreshing) =>{
  state.refreshing = refreshing
  state.bossList = []
  state.finished = false
  state.loading = true
  state.pageNum = 1
  getDatingBossesList()
}


// 请求商家详情信息
const getDatingBossesList =async () =>{
  try {
    const res = await dating_bosses({
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      state.loading = false
      state.refreshing = false

      if (res.data.bossList < state.pageSize || !res.data.bossList) {
        state.finished = true
      }
      state.bossList = [...state.bossList, ...res.data.bossList]
    } else {
      state.loading = false
      state.refreshing = false
      state.finished = true
      return showToast(res.tip)
    }
  } catch (error) {
    state.loading = false
    state.refreshing = false
    state.finished = true
    console.log(error)
  }
}

onMounted(() => {
  refreshData()
}) 

</script>

<style lang="scss" scoped>
.bosses-detail {
  min-height: 100vh;
  padding: 1.3rem 0 0 0;
  .sj-card{
  margin: 0 0.3rem;
}
}

</style>
