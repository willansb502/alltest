<template>
  <div class="city-list">
    <LayoutsHeader :title="'切换城市'" :hasSuperiorClick="true" @goBack="goBack" />
    <div class="city-main">
      <div class="search-clickbox-box">
        <van-search v-model="state.value" @input="change(state.value)" placeholder="请输入搜索关键词" />
      </div>

      <div class="main-box">
        <!-- 当前城市 -->
        <div class="now-city">
          <van-icon name="location-o" />
          <span class="city-type">当前城市</span>
          <span class="city"> {{ state.city }}</span>
        </div>
        <!-- 热门城市 -->
        <div class="hot-city">
          <div class="top-title">
            <img src="@/assets/imgs/search/search-hot.svg" alt="" />
            热门城市
          </div>
          <ul class="hot-city-list">
            <li
              class="hot-city-list-item"
              v-for="(item, index) in state.hotList"
              :key="index"
              @click="checkCity(item)"
              :class="{ lastChild: index === state.hotList.length - 1 }"
            >
              {{ item.name }}
            </li>
            <li></li>
          </ul>
        </div>
        <!-- 全国 -->
        <p class="all" @click="checkCity({ name: '全国', id: 0 })">全国</p>
      </div>
    </div>

    <!-- 索引 -->
    <van-index-bar :sticky-offset-top="276">
      <template v-for="(citys, key) in state.newAlphabet">
        <van-index-anchor v-if="citys.length" :index="key" :key="'anchor' + key" />
        <template v-for="(city, idx) in citys" :key="idx">
          <van-cell @click="checkCity(city)" :title="city.name" />
        </template>
      </template>
    </van-index-bar>
  </div>
</template>

<script setup>
import { city_list } from '@/api/dating'
import cnchar from 'cnchar'
import { showToast } from 'vant'
const router = useRouter()
const route = useRoute()
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const state = reactive({
  // 显示地址选择
  showCity: false,
  item: {},
  value: '',
  // 当前城市
  city: '全国',
  hotList: [],
  // 类型，外围还是楼凤
  type: +route.params.type,
  alphabet: {
    A: [],
    B: [],
    C: [],
    D: [],
    E: [],
    F: [],
    G: [],
    H: [],
    I: [],
    J: [],
    K: [],
    L: [],
    M: [],
    N: [],
    O: [],
    P: [],
    Q: [],
    R: [],
    S: [],
    T: [],
    U: [],
    V: [],
    W: [],
    X: [],
    Y: [],
    Z: []
  },
  newAlphabet: {
    A: [],
    B: [],
    C: [],
    D: [],
    E: [],
    F: [],
    G: [],
    H: [],
    I: [],
    J: [],
    K: [],
    L: [],
    M: [],
    N: [],
    O: [],
    P: [],
    Q: [],
    R: [],
    S: [],
    T: [],
    U: [],
    V: [],
    W: [],
    X: [],
    Y: [],
    Z: []
  }
})

const goBack =() =>{
  router.replace('/dating');  
}
// 获取城市列表并进行分类
const getCityList =async () =>{
  const res = await city_list({})
  if (res.code === 200) {
    state.hotList = res.data.hotList
    res.data.list.forEach(item => {
      const s = item.name.spell()[0]
      Object.getOwnPropertyNames(state.alphabet).forEach(key => {
        if (key === s) {
          state.alphabet[key].push(item)
          state.newAlphabet[key].push(item)
        }
      })
    })
  } else {
    return showToast(res.tip)
  }
}

const checkCity =(item) =>{
  router.replace(`/dating?cityName=${item.name}&cityId=${item.id}&type=${route.query.type}`)  
}

// 模糊查询
const change =(matchStr) =>{
  for (const key in state.alphabet) {
    if (state.alphabet.hasOwnProperty.call(state.alphabet, key)) {
      const element = state.alphabet[key]
      const newArr = []
      element.filter((ele, index) => {
        if (ele.name.includes(matchStr)) {
          newArr.push(ele)
        }
      })
      state.newAlphabet[key] = newArr
    }
  } 
}

onMounted(() => {
  state.city = route.params.cityId
  getCityList()
}) 
</script>
<style lang="scss" scoped>
.city-list {
  position: absolute;
  top: 0;
  width: 100%;
  max-width: $pcMaxWidth;
  z-index: 999;
  min-height: 100vh;
  padding-top: 1rem;
  color: #666666;

  :deep()  {
    .header-nav {
      z-index: 100;
    }
  }
}
.city-main {
  position: fixed;
  background: #000;
  width: 100%;
  max-width: $pcMaxWidth;
  z-index: 2;
  // 搜索框
  .search-clickbox-box {
    background: #000;
    position: relative;
    width: 100%;
    max-width: $pcMaxWidth;
    z-index: 2;
    :deep()  {
      .van-search {
        background: #000;
      }
      .van-search__content {
        padding-left: 0;
      }
      .van-field__control{
        color: #fff;
      }
    }
    .search-clickbox {
      margin: 0 auto;
      width: 92%;
      height: 0.7rem;
      border-radius: 0.56rem;
      background: #212125;
      color: #999;
      font-size: 0.3rem;
      display: flex;
      align-items: center;
      :deep()  {
        .van-field__control {
          text-indent: 0.5rem;
        }
      }
    }
    img {
      position: absolute;
      left: 0.3rem;
      top: 50%;
      transform: translate3d(0, -50%, 0);
      margin-left: 0.3rem;
      margin-right: 0.2rem;
      width: 0.356rem;
      height: 0.356rem;
    }
  }

  // 当前城市
  .now-city {
    display: flex;
    align-items: center;
    font-size: 0.24rem;
    color: #eee;
    span {
      margin: 0.2rem 0.2rem 0.2rem 0;
    }
    .city {
      color: #009cff;
      font-weight: 600;
    }
  }
  // 热门城市
  .hot-city {
    .top-title {
      color: #939496;
      display: flex;
      align-items: center;
      font-size: 0.26rem;
      font-weight: 600;
      margin-bottom: 0.3rem;
      img {
        width: 0.28rem;
        height: 0.32rem;
        margin-right: 0.1rem;
      }
    }
    .hot-city-list {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      margin: 0.3rem 0;
      .hot-city-list-item {
        width: 32%;
        text-align: center;
        padding: 0.11rem 0;
        margin-top: 0.1rem;
        color: #eee;
        font-size: 0.24rem;
        background: $mainBgColor;
        border-radius: 0.1rem;
        &.lastChild{
          margin-left: 0.12rem;
        }
      }
    }

    .hot-city-list::after {
      content: '';
      flex: auto;
      margin-right: 0.1rem;
    }
  }
  .all {
    font-size: 0.3rem;
    margin: 0;
    margin-bottom: 0.1rem;
    font-weight: 600;
    color: #939496;
  }
}
// 索引
:deep()  {
  .van-index-bar {
    padding-top: 6rem;
    .van-cell{
      color: #ddd;
    }
  }
}

.title {
  background: $mainBgColor;
  margin: 0;
  padding-left: 0.2rem;
}
:deep()  {
  .van-index-bar__sidebar {
    margin-top: 2.2rem;
  }
  .van-index-anchor {
    padding: 0 0.25rem;
    color: #505d71;
  }
  .van-cell {
    color: #666666;
    background-color: $mainBgColor !important;
  }      
}

.main-box {
  padding: 0 0.24rem;
}
</style>
