<template>
  <div class="release">
    <LayoutsHeader :title="'举报'"></LayoutsHeader>
    <div class="release-main">
      <!-- 描述信息 -->
      <p class="desc-title">描述信息</p>
      <van-field v-model="state.text" rows="4" autosize required type="textarea" placeholder="请填写要举报的内容" />
      <!-- 上传图片 -->
      <p class="upload-img-title">上传图片</p>
      <UploadImg @result="result" />
      <!-- line -->
      <ul class="line-box">
        <li></li>
        <li>体检报告要求</li>
        <li></li>
      </ul>
      <!-- 提示语 -->
      <ul class="waring">
        <li v-for="item in state.textList" :key="item">{{ item }}</li>
      </ul>
    </div>
    <!-- 提交验证 -->
    <div class="submit" @click="submit">提交举报</div>
  </div>
</template>

<script setup>
import { dating_complaint } from '@/api/dating'
import { showToast } from 'vant'
const route = useRoute()
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const UploadImg = defineAsyncComponent(() => import('@/components/UploadImg/index.vue'))
const state = reactive({
  text: '',
  textList: [
    '1.每一条楼凤只能举报一次不能重复举报',
    '2.楼凤举报有截图证明的合适以后可享受楼凤退款',
    '3.购买楼凤后超过7天再进行举报则视为常规举报，不享受退款处理'
  ],
  images: []
})

const result =(res) =>{
  state.images = res
}
const submit =async () =>{
  if (!state.text || state.text.length < 8) {
    return showToast('描述信息字数不可少于8个字')
  }
  if (state.images.length < 4) {
    return showToast('图片不能少于4张')
  }
  try {
    const res = await dating_complaint({
      images: state.images,
      text: state.text,
      type: +route.query.type,
      objectId: +route.params.id
    })
    if (res.code === 200) {
      router.go('-1')
      return showToast('举报成功，请等待审核')
    } else if (res.code === 6059) {
      return showToast('举报失败，重复上传')
    } else if (res.code === 6054) {
      return showToast('举报失败，您还没有购买此信息！')
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    return showToast('请求错误，请稍后再试！')
  }
}
</script>

<style lang="scss" scoped>
.release {
  min-height: 100vh;
  padding-top: 1rem;
  &-main {
    padding: 0.3rem;
    .desc-title {
      margin: 0;
      font-size: 0.26rem;
    }
    .van-cell {
      margin-top: 0.2rem;
      background: $mainBgColor;
      color: #000;
      :deep()  {
        .field-placeholder-text-color {
          color: #9493b1;
        }
        .van-field__control {
          color: #666;
          font-size: 0.2rem;
        }
      }
    }
    .van-cell::after {
      display: none;
    }
    // 图片上传
    .upload-img-title {
      margin: 0.2rem 0;
      font-size: 0.26rem;
    }
  }
  // 分割线
  .line-box {
    display: flex;
    align-items: center;
    color: #9493b1;
    margin: 0.48rem 0;
    li:first-child,
    li:last-child {
      background: #9493b1;
      height: 0.02rem;
      width: 2.33rem;
    }
    li:nth-child(2) {
      font-size: 0.3rem;
      margin: 0 0.2rem;
    }
  }
  // 提示语
  .waring {
    font-size: 0.24rem;
    color: #9493b1;
  }
}
// 提交审核
.submit {
  position: fixed;
  bottom: 0rem;
  width: 95%;
  max-width: $pcMaxWidth;
  height: 0.8rem;
  background: $btnBg;
  font-size: 0.3rem;
  text-align: center;
  line-height: 0.8rem;
  left: 50%;
  transform: translate(-50%, 0);
  border-radius: 0.4rem;
}
</style>
