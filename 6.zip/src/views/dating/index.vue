<template>
  <div class="dating-index">
    <!-- 顶部返回导航 -->
    <LayoutsHeader :title="'约炮'" @onClickRight="onClickRight">
      <template v-slot:right>
        <div class="right-btn">
          <van-icon size="16" name="location" />
          {{ state.cityName }}
        </div>
      </template>        
    </LayoutsHeader>

    <!-- 首页 推荐轮播 -->
    <!-- <SwiperShow class="dating-swiper" v-if="datingAD.length > 0" :imgList="datingAD" /> -->

    <!-- 主体内容 -->
    <div class="dating-main">
      <!-- 推荐商家 -->
      <div class="tj-merchantcard">
        <JavTitleMore :title="'推荐商家'" :more="'更多'" @lookMore="lookMore" />
        <div class="merchantcard-list">
          <div class="merchantcard-list-item" @click="toBossDetail(item)" v-for="item in state.BossList" :key="item.id">
            <Merchantcard :item="item" />
          </div>
        </div>
      </div>

      <!--切换面板 -->
      <JavTab
        :addClass="'bgTab'"
        class="dating-tab"
        @change="change"
        :titles="state.category"
        :active="state.nowItem.index"
        :animated="false"
        :needBack="false"
      >
        <template v-slot:default="scope">
          <!-- 列表 -->
          <PullUp
            @refreshData="refreshData"
            @moreData="moreData"
            :finished="state.finished"
            :loading="state.loading"
            :refreshing="state.refreshing"
            :skeleton="state.skeleton"
            :finishedText="'商家招募中..'"
          >
         
            <component :list="state.list" :is="compComponent(scope.data)"></component>
          </PullUp>
        </template>
      </JavTab>
    </div>
    <!-- 发布上门按钮 -->
    <div class="public-btn" @click="toPublic">
      <van-icon class="btn-icon" name="add" size="20" />
      发布上门
    </div>
  </div>
</template>

<script setup name="daitngPage">
import { useStore } from 'vuex'
const store = useStore()
const router = useRouter()
const route = useRoute()
import { dating_bosses, dating_category } from '@/api/dating'
import { showToast } from 'vant'

const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const JavTab = defineAsyncComponent(() => import('@/components/JavTab.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const Merchantcard = defineAsyncComponent(() => import('@/components/Dating/Merchantcard.vue'))
const JavTitleMore = defineAsyncComponent(() => import('@/components/JavTitleMore.vue'))
const SwiperShow = defineAsyncComponent(() => import('@/components/Swiper/index.vue'))
const LfCard = defineAsyncComponent(() => import('@/components/Dating/Lf_card.vue'))
const SjCard = defineAsyncComponent(() => import('@/components/Dating/Sj_card.vue'))
const SmCard = defineAsyncComponent(() => import('@/components/Dating/Sm_card.vue'))

const state = reactive({
  list: [], // 楼凤 上门 商家 列表
  BossList: [], // 推荐商家列表
  category: [
    // { showType: 1, name: '楼凤' },
    { index:0,showType: 2,name: '上门' },
    { index:1,showType: 3,name: '商家' }
  ],
  nowItem:{},
  refreshing: false,
  loading: false,
  finished: false,
  cityId: 0, // 城市id
  cityName: '全国',
  pageNum: 1,
  skeleton: false,
  pageSize: 10,
  hostUrl:'',
  type: 2 ,// 分类类型 1 2 3
  // 获取首页推荐页轮播广告
  datingAD:computed(() => store.getters['datingAD']),
  userInfo:computed(() => store.getters['getUserInfo'])
})

// 商家详情跳转
const toBossDetail = (item) =>{
  router.push(`/bosses/detail/${item.id}`)
}
// 全国按钮
const onClickRight = () =>{
  router.replace(`/city/${state.cityName}?type=${state.nowItem.showType}`)
}
const change = (index,item) =>{
  state.nowItem = item;
  refreshData();
  //保存状态刷新用
  if (route.query.cityId) {
    router.replace(`/dating?cityName=${state.cityName}&cityId=${state.cityId}&type=${state.nowItem.showType}`)
  }
}

const compComponent = (data) =>{
  switch (data) {
    case 1:
      return LfCard
    case 2:
      return SmCard
    case 3:
      return SjCard
    default:
      return LfCard
  }
}
// 上拉加载更多
const moreData =  (loading) =>{
  state.loading = loading
  state.pageNum += 1
  getTypeList()
}

// 下拉刷新
const refreshData = (refreshing) =>{
  state.refreshing = refreshing
  state.skeleton = true
  state.list = []
  state.pageNum = 1
  getTypeList()
  state.finished = false
  state.loading = true
}
// 查看更多
const lookMore = () =>{
  router.push('/bosses/list')
}
// 获取推荐商家列表    
const getDatingBoss = async () =>{
  try {
    const res = await dating_bosses({
      pageNum: 1,
      pageSize: 10,
      reqType: 0
    })
    if (res.code === 200) {
      state.BossList = res.data.bossList
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    return showToast('请求错误，请稍后再试!!')
  }
}
// 获取楼凤，上门，商家列表
const getTypeList = async () =>{
  try {
    const res = await dating_category({
      cityId: state.cityId,
      pageNum: state.pageNum,
      pageSize: state.pageSize,
      type: state.nowItem.showType
    })
    if (res.code === 200) {
      state.loading = false
      state.refreshing = false
      switch (state.nowItem.showType) {
        case 1:
          state.list = [...state.list, ...res.data.loufengList]
          if (!res.data.loufengList || res.data.loufengList.length < state.pageSize) {
            state.finished = true
          }
          break
        case 2:
          state.list = [...state.list, ...res.data.modelList]
          if (!res.data.modelList || res.data.modelList.length < state.pageSize) {
            state.finished = true
          }
          break
        case 3:
          state.list = [...state.list, ...res.data.bossList]
          if (!res.data.bossList || res.data.bossList.length < state.pageSize) {
            state.finished = true
          }
          break
      }
    } else {
      state.loading = false
      state.refreshing = false
      state.finished = true
      return showToast(res.tip)
    }
  } catch (error) {
    state.loading = false
    state.refreshing = false
    state.finished = true
    console.log(error)
    return showToast('请求错误，请稍后再试!!')
  }
}
// 跳转发布页
const toPublic = () =>{
  router.push('/dating/release-post')
  // if (state.userInfo.vipType === 11) {
  //   router.push('/dating/release-post')
  // } else {
  //   return showToast('只有商家卡才能发布上门信息')
  // }
}
  
onActivated(async () => {
  if(state.hostUrl==window.location.href) return;
  if(state.cityId==route.query.cityId) return;
  state.hostUrl=window.location.href;
  if(!route.query.type) state.nowItem=state.category[0];
  // 推荐商家请求
  await getDatingBoss()
  if (route.query.cityId) {
    state.cityId = +route.query.cityId
  }
  if (route.query.cityName) {
    state.cityName = route.query.cityName
  }
  if (route.query.type) {
    state.category.forEach((item)=>{
      if(item.showType==+route.query.type){
        state.nowItem=item;
      }
    })
  }
  // 分类详情请求
  refreshData()
})


</script>

<style lang="scss" scoped>
.dating-index {
  min-height: $minHeight;
  padding-top: 1rem;
  position: relative;
  max-width: $pcMaxWidth;
  margin: 0 auto;
}

.right-btn {
  width: 1.6rem;
  height: 0.48rem;
  overflow: hidden;
  background: linear-gradient(to right, #333042, #3c536f);
  border-radius: 0.24rem;
  @include flexbox($jc: center, $ai: center, $fd: row, $fw: nowrap);
  flex-shrink: 0;
  font-size: 0.26rem;
  .van-icon-location {
    color: #fff;
    margin-right: 0.05rem;
  }
}
.LayoutsHeader {
  margin-bottom: 0.3rem;
}
.dating-swiper {
  :deep()  {
    .swiper-container {
      z-index: 0;
      .swiper-wrapper {
        z-index: 0;
      }
    }
  }
}
// 内容主体
.dating-main {
  padding: 0 0.3rem;
  .tj-merchantcard {
    margin: 0.4rem 0 0 0;
    .merchantcard-list {
      @include flexbox($jc: flex-start, $ai: flex-start, $fd: row, $fw: nowrap);
      overflow-x: scroll;
      &-item {
        margin: 0.2rem 0.2rem 0.3rem 0;
        border-radius: 0.05rem;
        box-shadow: $shadow;
      }
    }
  }
}

// 发布上门按钮
.public-btn {
  position: fixed;
  width: 2rem;
  height: 0.7rem;
  right: 0;
  bottom: 0.8rem;
  @include flexbox($jc: center, $ai: center, $fd: row, $fw: nowrap);
  font-weight: 600;
  font-size: 0.32rem;
  background: linear-gradient(to right, #292402, #d5e7fc);
  border-top-left-radius: 0.4rem;
  border-bottom-left-radius: 0.4rem;
}
.dating-main .tj-merchantcard .merchantcard-list::-webkit-scrollbar {
  /*滚动条整体样式*/
  width: 10px; /*高宽分别对应横竖滚动条的尺寸*/
  height: 10px;
}
.dating-main .tj-merchantcard .merchantcard-list::-webkit-scrollbar-thumb {
  /*滚动条里面小方块*/
  border-radius: 10px;
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  background: #83807e;
}
.dating-main .tj-merchantcard .merchantcard-list::-webkit-scrollbar-track {
  /*滚动条里面轨道*/
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  border-radius: 10px;
}
</style>
