<template>
  <div class="wai-wei">
    <LayoutsHeader :title="''" :class="state.color ? 'color' : ''" @onClickRight="checkRight(state.detailData)">
      <template v-slot:right>
        <slot name="right">举报</slot>
      </template>
    </LayoutsHeader>
    <!-- 体验报告 -->
    <PullUp
      @refreshData="refreshData"
      @moreData="moreData"
      :finished="state.finished"
      :loading="state.loading"
      :refreshing="state.refreshing"
      class="list-main"
    >
      <!-- 妹子图片轮播图 -->
      <JavSwiper
        ref="Jav_Swiper"
        :hasSuperiorClick=true
        @clickImg="clickImg"
        :autoplay="0"
        class="ww-swiper"
        :imgs="state.detailData.images"
        :height="'6.77rem'"
      />
      <!-- 价格 -->
      <div class="main-price">
        <h2><span>¥</span> {{ changeGold(state.detailData.infoPrice) }}</h2>
        <div class="right-icon">
          <img src="@/assets/imgs/white-path.svg" alt="" />
          {{ numberFilter(state.detailData.collects)}}
        </div>
      </div>
      <!-- 主体内容 -->
      <div class="wai-wei-main">
        <!-- 标题 -->
        <div class="main-title">
          <div class="top">
            <h2>{{ state.detailData.title }}</h2>
            <div class="city">{{ state.detailData.cityName }}</div>
          </div>
          <div class="bottom">
            <span>{{ formatDate(state.detailData.createdAt) }}</span>
            <span>{{ state.detailData.sells }}人约过</span>
          </div>
        </div>

        <!-- 提示语 -->
        <div class="waring-txt">
          <img src="@/assets/imgs/dating/waring.svg" alt="" />
          <div class="txt">
            凡是有要求路费/定金/保证金/照片验证/视频验证等任何提前付费的
            行为千万不要上当。同时也请注意仙人跳，在寻欢前不要露富和带过
            于贵重随身物品。本APP为分享信息并不对寻欢经历负责，碰到有问 题的信息，请及时举报给我们删除信息。
          </div>
        </div>
        <!-- 分割线 -->
        <div class="line"></div>

        <!-- 基础信息 -->
        <ul class="detail-info">
          <li>
            <span class="label">项目</span>
            <div>{{ state.detailData.serviceItems }}</div>
          </li>
          <li>
            <span class="label">年龄</span>
            <div>{{ state.detailData.age }}</div>
          </li>
          <li>
            <span class="label">颜值</span>
            <div>{{ state.detailData.beautyScore }}</div>
          </li>
          <li>
            <span class="label">介绍</span>
            <div class="process-item">
              {{ state.detailData.introduction }}
            </div>
          </li>
        </ul>
      </div>
      <!-- 联系方式解锁 -->
      <div class="contact">
        <!-- 已解锁 -->
        <div class="left-txt-all" v-if="state.detailData.isBuy">
          <div class="contact-noBuy">
            <div class="left">联系方式</div>
            <div class="right">已解锁(右边复制)</div>          
          </div>
          <div class="contact-noBuy">
            <div class="left">qq：</div>
            <div class="right">{{ state.detailData.qq }}</div> 
            <img
              class="copy-img"
              @click="onCopy(state.detailData.qq)"
              src="@/assets/imgs/copy.svg"
              alt=""
            />                         
          </div>
          <div class="contact-noBuy">
            <div class="left">wx：</div>
            <div class="right">{{ state.detailData.weChat }}</div>
            <img
              class="copy-img"
              @click="onCopy(state.detailData.weChat)"
              src="@/assets/imgs/copy.svg"
              alt=""
            />             
          </div>
          <div class="contact-noBuy">
            <div class="left">联系电话：</div>
            <div class="right">{{ state.detailData.telephone }}</div>
            <img
              class="copy-img"
              @click="onCopy(state.detailData.telephone)"
              src="@/assets/imgs/copy.svg"
              alt=""
            />             
          </div>
        </div>
        <!-- 没有解锁 -->
        <div class="contact-noBuy" v-else @click="state.showBuy = true">
          <div class="left">联系方式</div>
          <div class="right">
            <span>{{ changeGold(state.detailData.infoPrice) }}</span>
            <img src="@/assets/imgs/index/gold.png" alt="" />
            解锁
          </div>
        </div>
      </div>

      <ul class="report-list">
        <li v-for="item in state.reportList" :key="item.createdAt">
          <div class="avatar-left">
            <DecryptImg :imgURL="item.userAvatar"></DecryptImg>
            详细描述
          </div>
          <div class="detail-right">
            <h2>{{ item.userName }}</h2>
            <p>体验时间:{{ timeYmd(item.createdAt) }}</p>
            <div class="detail-desc">
              {{ item.text }}
            </div>
            <div class="detail-images">
              <DecryptImg
                class="img-item"
                :needPadding="false"
                v-for="img in item.images"
                :imgURL="img"
                :key="img"
              ></DecryptImg>
            </div>
          </div>
        </li>
      </ul>
    </PullUp>
    <!-- 底部按钮 -->
    <ul class="footer-btn">
      <li class="like" @click="checkLike(state.detailData)">
        <img
          :src="`${
            !state.detailData.isCollect ? getAssetsFile('white-path.svg') : getAssetsFile('red-path.svg')
          }`"
          alt=""
        />
        {{ `${state.detailData.isCollect ? '已收藏' : '收藏'}` }}
      </li>
      <li class="ren-zheng" @click="releaseReport(state.detailData)">
        <img src="@/assets/imgs/dating/report.svg" alt="" />
        发布体验
      </li>
      <li v-if="!state.detailData.isBuy" @click="state.showBuy = true" class="reserve">
        {{ changeGold(state.detailData.infoPrice) }}金币解锁
      </li>
      <li v-else class="reserve">已解锁</li>
    </ul>
    <!-- 购买弹窗 -->
    <JavShowBuy
      :showBuy="state.showBuy"
      @shoudBuy="shoudBuy"
      @closed="closed"
      :title="'购买此楼凤信息需支付'"
      :price="changeGold(state.detailData.infoPrice)"
    />
  </div>
</template>

<script setup>
import useClipboard from 'vue-clipboard3'
const { toClipboard } = useClipboard()
import { getAssetsFile } from '@/utils/utils_tools'
import { numberFilter , changeGold , formatDate , timeYmd} from '@/utils/filter'
import { dating_report, loufeng_detail, dating_pay } from '@/api/dating'
import { collect } from '@/api/home'
import { showImagePreview, showToast} from 'vant'
import { onUnmounted } from 'vue'
const router = useRouter()
const route = useRoute()
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const JavSwiper = defineAsyncComponent(() => import('@/components/JavSwiper.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const JavShowBuy = defineAsyncComponent(() => import('@/components/JavShowBuy.vue'))
let Jav_Swiper = ref(null)
const state = reactive({
  detailData: {},
  pageNum: 1,
  pageSize: 10,
  reportList: [],
  showBuy: false,
  refreshing: false, // 下拉刷新开关
  loading: false, // 上拉加载
  finished: false, // 上拉加载开关
  color: false
})


// 复制
const onCopy =async (text) =>{
  try {
    await toClipboard(contactInfo)
    showToast('复制成功！！！')
  } catch (e) {
    console.error(e)
  } 
}
// 监听滚动高度
const scrollHandle =(e) =>{
  const top = e.srcElement.scrollingElement.scrollTop // 获取页面滚动高度
  if (top >= 300) {
    state.color = true
  } else {
    state.color = false
  }
}
// 举报按钮
const checkRight =(item) =>{
  if (item.isBuy) {
    // 跳转举报编辑页
    router.push(`/dating/complaint/${item.id}?type=${1}`)
  } else {
    showToast('购买后才能提交举报')
  }
}

// 获取妹子详情
const getLfdetail =async () =>{
  try {
    const res = await loufeng_detail({
      id: +route.params.id
    })
    if (res.code === 200) {
      state.detailData = res.data
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    return showToast('请求错误，请稍后再试！')
  }
}
// 收藏外围信息
const checkLike =async (item) =>{
  try {
    const res = await collect({
      flag: !item.isCollect,
      object_id: item.id,
      collect_type: 6
    })
    if (res.code === 200) {
      state.detailData.isCollect = !item.isCollect
      if (state.detailData.isCollect) {
        return showToast('收藏成功')
      } else {
        return showToast('取消收藏')
      }
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    return showToast('请求失败，请稍后再试')
  }
}
// 发布体验
const releaseReport =async (item) =>{
  if (item.isBuy) {
    //  跳转发布页
    if (item.isReport) {
      showToast('您已发布一次了，试试其他的吧')
    } else {
      router.push(`/dating/release-report/${item.id}?type=${1}`)
    }
  } else {
    showToast('购买后才能发布体验')
  }
}

// 获取报告列表
const getReportList =async (item) =>{
  const res = await dating_report({
    objectId: +route.params.id,
    pageNum: state.pageNum,
    pageSize: state.pageSize,
    type: 1
  })
  if (res.code === 200) {
    state.refreshing = false
    state.loading = false
    state.reportList = [...state.reportList, ...res.data.list]
    if (res.data.list.length < state.pageSize) {
      state.finished = true
    }
  } else {
    state.loading = false
    state.refreshing = false
    state.finished = true
    return showToast(res.tip)
  }
}

// 下拉刷新
const refreshData =(refreshing) =>{
  state.refreshing = refreshing
  state.pageNum = 1
  state.finished = false
  state.loading = true
  state.reportList = []
  getReportList()
}

// 上拉加载
const moreData =(loading) =>{
  state.loading = loading
  state.pageNum += 1
  getReportList()
}

// 图片预览
const clickImg =(imgUrl) =>{
  const imgArr = []
  let index = 0
  const domArr = Jav_Swiper.value.refImg
  domArr.forEach((itemBlob, indexBlob) => {
    if (imgUrl === itemBlob.imgURL) {
      index = indexBlob
    }
    imgArr.push(itemBlob.realUrl)
  })
  showImagePreview({
    images: imgArr, // 需要预览的图片 URL 数组
    showIndex: true, // 是否显示页码
    loop: true, // 是否开启循环播放
    startPosition: index // 图片预览起始位置索引
  })
}

// 购买弹窗关闭事件
const closed =(close) =>{
  state.showBuy = close
}

// 购买弹窗购买按钮
const shoudBuy =async () =>{
  try {
    const res = await dating_pay({
      objectId: state.detailData.id,
      type: 1
    })
    if (res.code === 200) {
      state.detailData.isBuy = true
      state.showBuy = false
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    return showToast('请求错误，请稍后再试！')
  }
}


onMounted(() => {
  getLfdetail()
  getReportList()
  window.addEventListener('scroll', scrollHandle) 
}) 

onUnmounted(() => {
  window.removeEventListener('scroll', scrollHandle)
}) 
</script>

<style lang="scss" scoped>
.wai-wei {
  padding: 0;
  padding-bottom: 1rem;
  background: #030303;
  min-height: 100vh;
  max-width: 640px;
  margin: 0 auto;
  :deep()  {
    .van-nav-bar {
      background: transparent !important;
      border: none !important;
    }
    .van-icon-arrow-left,
    .van-nav-bar__title,
    .van-nav-bar__content {
      color: $mainTxtColor1 !important;
    }
  }
  .ww-swiper {
    :deep()  {
      .warp {
        border-radius: 0;
        img {
          border-radius: 0;
        }
      }
    }
  }
  &-main {
    padding: 0.3rem 0.3rem 0 0.3rem;
    //  padding-top:7.77rem;
    background: $mainBgColor;
    margin-top: 0.3rem;
    box-shadow: $shadow;
  }
  // 顶部价格
  .main-price {
    @include flexbox();
    height: 1.12rem;
    padding: 0 0.24rem;
    background: $mainBgColor;
    box-shadow: $shadow;
    span {
      font-size: 0.2rem;
    }
    h2 {
      font-weight: 600;
      margin: 0;
      font-size: 0.36rem;
    }
    .right-icon {
      @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
      flex: none;
      font-size: 0.28rem;
      color: #848494;
      img {
        width: 0.228rem;
        height: 0.212rem;
        margin-right: 0.105rem;
      }
    }
  }
  // 顶部标题
  .main-title {
    font-size: 0.24rem;
    color: #989cae;
    h2 {
      margin: 0;
      font-size: 0.32rem;
    }
    .top {
      color: rgb(249, 249, 249);
    }
    .top,
    .bottom {
      @include flexbox();
      margin-bottom: 0.2rem;
      .city {
        font-size: 0.22rem;
        padding: 0.03rem 0.13rem;
        font-weight: 400;
        border-radius: 0.06rem;
        background: linear-gradient(to right, #191918, #474337);
      }
    }
  }
  .line {
    height: 0.04rem;
    background: #848494;
    margin: 0.3rem 0;
  }
  // 警告提示语
  .waring-txt {
    padding: 0.16rem 0.3rem;
    color: #f64562;
    background: $mainBgColor;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 0.16rem;
    font-weight: 500;
    border-radius: 0.2rem;

    box-shadow: $shadow;
    .txt {
      text-align: justify;
      text-justify: auto;
    }
    img {
      width: 0.62rem;
      height: 0.62rem;
      flex-shrink: 0;
      margin-right: 0.34rem;
    }
  }

  // 预约价格
  .detail-info {
    padding: 0.3rem;
    background: $mainBgColor;

    font-size: 0.26rem;
    // 基础信息
    li {
      margin-bottom: 0.15rem;
      font-weight: 400;
      @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
      .label {
        font-size: 0.3rem;
        font-weight: 600;
        margin-right: 0.27rem;
        white-space: nowrap;
      }
      div {
        box-shadow: $shadow;
        padding: 0.15rem 0.3rem;
        border-radius: 0.09rem;
        width: 6.1rem;
      }
    }
  }
}
.color {
  :deep()  {
    .van-nav-bar {
      background: transparent !important;
    }
    .van-icon-arrow-left,
    .van-nav-bar__title,
    .van-nav-bar__content {
      color: #000 !important;
    }
  }
}
// 联系方式
.contact {
  margin: 0.3rem 0.25rem;
  box-shadow: $shadow;
  border-radius: 0.05rem;

  .contact-noBuy {
    @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
    font-size: 0;
    width: 100%;
    margin-bottom: 0.2rem;
    text-align: center;
    .left {
      background: $btnBg;
      font-size: 0.37rem;
      font-weight: 800;
      width: 30%;
      flex-shrink: 0;

      height: 0.8rem;
      line-height: 0.8rem;
    }
    .right {
      @include flexbox($jc: center, $ai: center, $fd: row, $fw: nowrap);
      padding: 0 0.2rem;
      background: linear-gradient(to right, #585858, #000000);
      color: #ffc529;
      font-size: 0.32rem;
      font-weight: 400;
      min-height: 0.8rem;
      width: 70%;
      font-size: 0.32rem;

      span {
        font-size: 0.42rem;
        font-weight: 600;
      }
      img {
        width: 0.27rem;
        height: 0.27rem;
        margin: 0 0.25rem;
      }
    }
    .copy-img{
      width: 0.5rem;
    }
  }
}

.report-list {
  li {
    padding: 0.3rem 0.12rem;
    background-color: $mainBgColor;
    display: flex;
    font-size: 0.24rem;
    margin-bottom: 0.15rem;
    // 左侧头像
    .avatar-left {
      display: flex;
      flex-direction: column;
      align-items: center;
      font-weight: 600;
      margin-right: 0.23rem;
      white-space: nowrap;
      :deep()  {
        .default {
          width: 0.9rem;
          height: 0.9rem;
          margin-bottom: 0.14rem;
        }
        .warp {
          border-radius: 50%;
          img {
            border-radius: 50%;
          }
        }
      }
    }
    .detail-right {
      h2 {
        margin: 0;
      }
      p {
        margin: 0.09rem 0 0.2rem 0;
      }
    }
    .detail-images {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      margin-top: 0.12rem;
      .img-item {
        width: 1.3rem;
        height: 1.3rem;
        margin-right: 0.25rem;
      }
      .img-item:nth-child(3n) {
        margin-right: 0;
      }
    }
  }
}
// 底部按钮
.footer-btn {
  display: flex;
  position: fixed;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  max-width: $pcMaxWidth;
  background-color: $mainBgColor;
  height: 1rem;
  font-size: 0.26rem;
  bottom: 0;
  padding: 0 0 0 0.52rem;
  box-sizing: border-box;
  li {
    display: flex;
    align-items: center;

    img {
      margin-right: 0.13rem;
      filter: brightness(100);
    }
  }
  .like {
    img {
      width: 0.36rem;
      height: 0.31rem;
    }
  }

  .ren-zheng {
    img {
      width: 0.323rem;
      height: 0.349rem;
    }
  }
  .reserve {
    background: $btnBg;
    justify-content: center;
    font-weight: 600;
    font-size: 0.34rem;
    img {
      filter: brightness(100);
      width: 0.273rem;
      height: 0.327rem;
    }
    width: 2.8rem;
    height: 100%;
  }
}
</style>
