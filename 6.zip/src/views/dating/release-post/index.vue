<template>
  <div>
    <div class="release">
      <LayoutsHeader :title="'上门发布'" />
      <div class="release-main">
        <van-form @submit="onSubmit" :validate-trigger="'onSubmit'" submit-on-enter :show-error="false">
          <div class="upload-mian">
            <!-- 图片上传 -->
            <div class="upload-img">
              <div class="img-left">
                上传图片
                <div><span>•</span> <span>第一张为封面</span></div>
              </div>
              <UploadImg :imgs="state.form.images" @result="result" />
            </div>
          </div>
          <van-field
            v-model="state.form.title"
            name="title"
            :maxlength="40"
            show-word-limit
            placeholder="请输入标题(2-40字)"
            :rules="[{ required: true, message: '请输入标题(2-40字)' }]"
            class="form-title"
          />

          <van-field
            v-model.number="state.ypPrice"
            name="age"
            label="设定价格"
            placeholder="请输入约炮价格"
            :label-width="'1.4rem'"
            :rules="[{ required: true, message: '请输入约炮价格' }]"
          />

          <van-field
            v-model="state.form.contactInfo"
            placeholder="请输入微信或者电话联系方式"
            label="联系方式"
            :label-width="'1.4rem'"
            :rules="[{ required: true, message: '请输入联系方式' }]"
          />

          <div class="input-warp">
            <div class="input-inner set-options">设定参数</div>
            <div class="input-inner">
              <van-field
                v-model.number="state.form.girlHeight"
                class=""
                placeholder="请输入身高"
                name="身高"
                type="number"
                :rules="[{ required: true, message: '请输入身高' }]"
              >
              </van-field>
            </div>
            <div class="input-inner">
              <van-field
                :rules="[{ required: true, message: '请输入年龄' }]"
                v-model.number="state.form.girlAge"
                name="年龄"
                type="number"
                placeholder="请输入年龄"
              >
              </van-field>
            </div>
            <div class="btn" @click="changeShowStaus('showCupSelect')">
              <div class="btn-txt">{{ state.cupName }}</div>
              <transition name="van-fade">
                <ul class="select-panle" v-show="state.showCupSelect">
                  <li
                    class="select-item"
                    @click="clickSelectItem(state.cupData, index, 'cup')"
                    v-for="(item, index) in state.cupData"
                    :key="item.name"
                  >
                    {{ item.name }}
                  </li>
                </ul>
              </transition>
            </div>
          </div>
          <div class="input-warp">
            <div class="input-inner">
              <span>设定项目</span>
            </div>
            <div class="btn" @click="changeShowStaus('showItem')">
              <div class="btn-txt">
                请选择/ <span > 已选{{ state.form.serviceItems.length }} </span>
              </div>
            </div>
          </div>
          <div class="input-warp">
            <div class="input-inner">
              <span>设定方式</span>
            </div>
            <div class="btn" @click="changeShowStaus('showType')">
              <div class="btn-txt">
                请选择/ <span > 已选{{ state.form.serviceType.length }} </span>
              </div>
            </div>
          </div>
          <div class="input-warp">
            <div class="input-inner">
              <span>设定地区</span>
            </div>
            <div class="btn" @click="changeShowStaus('city')">
              <div class="btn-txt">
                请选择 / <span > 已选{{ state.form.serviceCity.length }} </span>
              </div>
            </div>
          </div>
          <!-- 设定详细描述 -->
             <van-field
            v-model="state.form.desc"
            name="desc"
            rows="3"
            show-word-limit
            placeholder="具体详情描述|建议不超过100个字"
            maxlength="100"
            :rules="[{ required: true, message: '请输入具体详情描述' }]"
              type="textarea"
          />
          <!-- 发布规则 -->
          <div class="pulic-tip">
            <span class="title">发布规则</span>
            <ul>
              <li>1.发布约炮资源可设置价格，审核通过后，将会在社区页展示</li>
              <li>2.发布成功，解锁可获得40%的解锁收益</li>
              <li>3.有非本APP的网址，水印，联系方式的，不通过</li>
              <!-- <li>
                4.设置更高的金额，请联系<span class="kf-btn" @click="$router.push(`/mine/setting/kf`)">在线客服</span>
              </li> -->
            </ul>
          </div>
          <div class="btn" style="margin-top: 16px">
            <van-button round block type="info" native-type="submit">发布</van-button>
          </div>
        </van-form>
      </div>
    </div>
    <!-- 服务城市 -->
    <!-- :title="`当前选择:${state.form.serviceCity}`" -->
    <van-action-sheet v-model:show="state.showCitySheet" :title="`请勾选城市`">
      <div class="city-select-all" @click="checkedChange">
        <div>全选</div>
        <van-checkbox  v-model="state.checkedAll" shape="square"></van-checkbox>
      </div>
      <div class="content">
        <van-index-bar class=" city-list" :sticky="false">
          <div v-for="(citys, key) in state.alphabet" :key="key">
            <van-index-anchor :index="key" :key="'anchor' + key" />
            <van-checkbox-group :key="'checkbox' + key" v-model="state.form.serviceCity">
              <van-cell-group>
                <van-cell
                  class="city-item"
                  v-for="(city, idx) in citys"
                  :title="city"
                  clickable
                  @click="toggle('serviceCitycheckboxes', idx , city, state.alphabet)"
                  :key="'anchor' + key + 'city' + idx"
                >
                  <template #right-icon>
                    <van-checkbox :name="city" ref="serviceCitycheckboxes" />
                  </template>
                </van-cell>
              </van-cell-group>
            </van-checkbox-group>
          </div>
        </van-index-bar>
      </div>
    </van-action-sheet>
    <!-- // 选择服务方式 -->
    <van-action-sheet v-model:show="state.showServiceSheet" :title="`选择服务方式`">
      <div class="content">
        <van-checkbox-group v-model="state.form.serviceType">
          <van-cell-group>
            <van-cell
              v-for="(item, idx) in state.serviceArr"
              :title="item"
              clickable
              @click="toggle('serviceTypecheckboxes',idx,item,state.serviceArr)"
              :key="item + idx"
            >
              <template #right-icon>
                <van-checkbox :name="item" ref="serviceTypecheckboxes" />
              </template>
            </van-cell>
          </van-cell-group>
        </van-checkbox-group>
      </div>
    </van-action-sheet>
    <!-- // 选择服务项目 -->
    <van-action-sheet v-model:show="state.showServiceItemsSheet" :title="`选择服务项目`">
      <div class="city-select-all items" @click="serItemChange">
        <div>全选</div>
        <van-checkbox  v-model="state.checkedAllItems" shape="square"></van-checkbox>
      </div>
      <div class="content">
        <van-checkbox-group v-model="state.form.serviceItems">
          <van-cell-group>
            <van-cell
              v-for="(item, idx) in state.serviceItemArr"
              :title="item"
              clickable
              @click="toggle('ServiceItemsSheet', idx,item,state.serviceItemArr)"
              :key="item + idx"
            >
              <template #right-icon>
                <van-checkbox :name="item" ref="ServiceItemsSheet" />
              </template>
            </van-cell>
          </van-cell-group>
        </van-checkbox-group>
      </div>
    </van-action-sheet>
  </div>
</template>

<script setup>
import { dating_config, dating_publish } from '@/api/dating'
import cnchar from 'cnchar'
import { showToast } from 'vant'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const UploadImg = defineAsyncComponent(() => import('@/components/UploadImg/index.vue'))

const state = reactive({
  checkedAll:false,
  checkedAllItems:false,
  ypPrice:undefined,
  form: {
    title: undefined, // 标题
    girlAge: undefined, // 年龄
    serviceCity: [], // 服务城市
    serviceItems: [], // 服务项目
    serviceType: [], // 服务方式
    price: undefined, // 价格
    girlHeight: undefined, // 身高
    desc: undefined, // 描述信息
    contactInfo: undefined, // 联系方式
    cupValue: undefined, // 罩杯
    images: [], // 妹子图片
    video: undefined, // 视频地址
    taskID: undefined // 视频id
  },
  showCupSelect: false, // 罩杯选择弹窗控制
  showCitySheet: false, // 城市选择弹窗
  cupName: '请选择罩杯',
  cupData: [
    { id: 1, name: 'B罩杯' },
    { id: 2, name: 'C罩杯' },
    { id: 3, name: 'D罩杯' },
    { id: 4, name: 'E罩杯' },
    { id: 5, name: 'F罩杯' },
    { id: 6, name: 'G罩杯' },
    { id: 7, name: 'H罩杯' },
    { id: 8, name: 'I罩杯' },
    { id: 9, name: 'J罩杯' },
    { id: 10, name: 'K罩杯' },
    { id: 11, name: 'L罩杯' }
  ], // 罩杯列表数据
  serviceArr: [], // 服务方式列表数据
  serviceItemArr: [], // 服务项目数据
  showServiceItemsSheet: false, // 服务项目弹窗控制
  showServiceSheet: false, // 服务方式弹窗
  showItem: false, // 设定项目
  showType: false, // 设定方式
  alphabet: {
    A: [],
    B: [],
    C: [],
    D: [],
    E: [],
    F: [],
    G: [],
    H: [],
    I: [],
    J: [],
    K: [],
    L: [],
    M: [],
    N: [],
    O: [],
    P: [],
    Q: [],
    R: [],
    S: [],
    T: [],
    U: [],
    V: [],
    W: [],
    X: [],
    Y: [],
    Z: []
  }
})

const checkedChange = () =>{
  if(!state.checkedAll){
    state.form.serviceCity=[]
    for (const key in state.alphabet) {
      const alphabetArr = state.alphabet[key]
      alphabetArr.forEach((el)=>{
        state.form.serviceCity.push(el)
      })
    }        
  }else{
    state.form.serviceCity=[]
  }
  state.checkedAll=!state.checkedAll;
}

const serItemChange = () =>{
  if(!state.checkedAllItems){
    state.form.serviceItems=[]
    state.serviceItemArr.forEach((el)=>{
      state.form.serviceItems.push(el)
    })    
  }else{
    state.form.serviceItems=[]
  }
  state.checkedAllItems=!state.checkedAllItems;
}
const result = (res) =>{
  state.form.images = res
}
const videoResult = (data) =>{
  state.form.video = data.videoUri
  state.form.taskID = data.id  
}
// 改变下拉状态
const changeShowStaus = (showName) => {
  switch (showName) {
    case 'showCupSelect':
      state.showCupSelect = !state.showCupSelect
      state.showItem ? (state.showItem = false) : null
      state.showType ? (state.showType = false) : null
      break
    case 'showItem':
      state.showServiceItemsSheet = true
      break
    case 'showType':
      state.showServiceSheet = true
      break
    case 'city':
      state.showCitySheet = true
      break
  }
}
// 点击下拉选项
const clickSelectItem = (data, index, type) => {
  if (type && type === 'cup') {
    state.form.cupValue = data[index].id
    state.cupName = data[index].name
  }  
}  
// 提交
const onSubmit = async () => {
  if(!state.form.cupValue) return showToast('罩杯未选择');
  if(!state.form.serviceCity.length) return showToast('服务城市未选择');
  if(!state.form.serviceItems.length) return showToast('服务项目未选择');
  if(!state.form.serviceType.length) return showToast('服务方式未选择');

  if (state.form.images && state.form.images.length < 0 || !state.form.images || state.form.images.length<2) return showToast('妹子照片不能少于2张')
  state.form.price = state.ypPrice * 100
  const res = await dating_publish({
    ...state.form
  })
  if (res.code === 200) {
    clearFrom()
    return showToast('发布成功，请等待审核')
  } else {
    clearFrom()
    return showToast(res.tip)
  }
}
// 还原数据
const clearFrom = (key) => {
  if(key){
    state.form[key]= undefined
  }else{
    state.ypPrice= undefined;
    state.form =  {
      title: undefined, // 标题
      girlAge: undefined, // 年龄
      serviceCity: [], // 服务城市
      serviceItems: [], // 服务项目
      serviceType: [], // 服务方式
      price: undefined, // 价格
      girlHeight: undefined, // 身高
      desc: undefined, // 描述信息
      contactInfo: undefined, // 联系方式
      cupValue: undefined, // 罩杯
      images: [], // 妹子图片
      video: undefined, // 视频地址
      taskID: undefined // 视频id
    };
  }
}

// 点击 城市复选框
const toggle = (refName, index, item, arrList) => {
  //城市定位位置
  if(refName=="serviceCitycheckboxes"){
    let newArr=[];
    for (const key in arrList) {
      const alphabetArr = arrList[key];
      alphabetArr.forEach((el)=>{
        newArr.push(el)
      });
    };
    newArr.forEach((el,i)=>{
      if(el==item){
        let [refName] = ref(null);
        [refName][i].toggle();
        // this.$refs[refName][i].toggle();
      } 
    })
  }else{
    let [refName] = ref(null);
    [refName][index].toggle();    
    // this.$refs[refName][index].toggle();
  }
}

// 获取上门配置数据
const getDatingConfig =async () => {
  try {
    const res = await dating_config()
    if (res.code === 200) {
      state.serviceItemArr = res.data.serviceItems
      state.serviceArr = res.data.serviceType
      res.data.serviceCity.forEach(item => {
        const s = item.spell()[0]
        Object.getOwnPropertyNames(state.alphabet).forEach(key => {
          if (key === s) {
            state.alphabet[key].push(item)
          }
        })
      })
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    return showToast('请求出错，请稍后再试！')
  }  
}
  
onMounted(async () => {
  getDatingConfig()
}) 

</script>

<style lang="scss" scoped>
.release {
  min-height: 100vh;
  padding-top: 1rem;
  max-width: 980px;
  margin: 0 auto;
  :deep() {
    .header-nav {
      border-bottom: 0.02rem solid #999;
    }
  }
  &-main {
    padding: 0 0.2rem;
  }
}
// 表单提交
:deep() {
  .van-field {
    color: #666;
    margin-bottom: 0.2rem;
    border-radius: 0.1rem;
    box-shadow: $shadow;
    background-color: #151515;
    .van-field__label {
      font-weight: 600;
      color: #bfc0c3;
      font-size: 0.28rem;
      white-space: nowrap;
      span::after {
        content: '|';
        margin-left: 0.2rem;
      }
    }
  }
}
.form-title {
  :deep() {
    .van-field__value {
      display: flex;
      justify-content: space-between;
    }
  }
}
// 上传内容
.upload-mian {
  box-shadow: $shadow;
  margin: 0.2rem 0;
  background: $mainBgColor;
  border-radius: 0.12rem;
  padding: 0.2rem;
}
.upload-img {
  display: flex;
  align-items: center;
  font-size: 0.28rem;
  margin-bottom: 0.2rem;
  .img-left {
    text-align: center;
    margin-right: 0.1rem;
    max-width: 1.5rem;
    div {
      display: flex;
    }
    span {
      font-size: 0.2rem;
    }
    span:last-child {
      text-align: left;
      transform: scale(0.9);
    }
    span:first-child {
      color: #3a84f6;
      font-size: 0.32rem;
    }
  }
  :deep() {
    .upload-img-box {
      .upload-img-item {
        width: 1rem;
        height: 1rem;
        line-height: 1.2rem;
      }
      .img-item {
        width: 1rem;
        height: 1rem;
      }
    }
  }
}
// 下拉框
.input-warp {
  margin-bottom: 0.2rem;
  border-radius: 0.1rem;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  background: $mainBgColor;
  box-shadow: $shadow;
  padding: 0.1rem 0.3rem;
  .input-inner {
    color: #bfc0c3;
    border-radius: 0.12rem;
    font-weight: 600;
    font-size: 0.28rem;
    :deep() {
      .van-cell {
        margin: 0;
        width: 1.6rem;
        padding: 0.12rem 0.02rem;
        font-weight: 400;
        background: transparent !important;
        box-shadow: none;
      }
    }
  }

  .set-options::after {
    content: '|';
    margin-left: 0.2rem;
    margin-right: 0.2rem;
  }
  .tranbg {
    background-color: transparent !important;
  }
  .btn-height {
    height: 0.59rem;
    line-height: 0.59rem;
  }
}
.tip-wrap {
  color: #9493b1;
  font-size: 0.24rem;
  margin-top: 0.2rem;
  padding: 0 0.3rem;
  span {
    font-size: 0.26rem;
  }
}
.btn-wrap {
  width: 4rem;
  height: 0.6rem;
  line-height: 0.6rem;
  background: $btnBg;
  font-size: 0.3rem;
  text-align: center;
  margin: 0.96rem auto;
  border-radius: 0.4rem;
}
.btn {
  position: relative;
  font-size: 0.2rem;
  .btn-txt {
    margin-left: 0.2rem;
    background: $btnBg !important;
    font-weight: 600;
    padding: 0.05rem 0.1rem;
    text-align: center;
    border-radius: 0.12rem;
    span{
      color: $mainTxtColor1;
    }
  }
  .select-panle {
    position: absolute;
    top: 0.6rem;
    z-index: 999;
    right: 0;
    overflow: hidden;
    border: 0.02rem solid rgb(141, 139, 139);
    li {

      background:$mainBgColor;
      box-shadow: $shadow;
      padding: 0;
      list-style-type: none;
      padding: 0.08rem 0.12rem;
      text-align: center;
      border-bottom: 0.02rem solid rgb(141, 139, 139);
    }
    li:last-child {
      border-bottom: none;
    }
  }
}
// 发布规则
.pulic-tip {
  font-size: 0.24rem;
  color: #999;
  .title {
    font-weight: 600;
    font-size: 0.26rem;
  }
  ul {
    margin-top: 0.1rem;
    li {
      margin-bottom: 0.1rem;
    }
  }
}
.kf-btn {
  color: #040404;
}
.btn {
  :deep() {
    .van-button--info {
      background: $btnBg;
      border: none;
      color: #fff;
    }
  }
}
.van-popup{
  :deep(){
    .van-index-bar__sidebar{
      top: 60%;
    }
  }
}
:deep(){
  .van-index-bar__sidebar{
    top: 60%;
  }
  .van-field__control{
    color: #fff !important;
  }
}
// 地址全选
.city-select-all{
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 16px;
  line-height: 48px;  
  padding-left: 16px;
  padding-right: 30px;
  &.items{
    padding-right: 16px;
  }
}
.city-item{
  padding: 10px 30px 10px 16px;
}

</style>
