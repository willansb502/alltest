<template>
  <div class="wai-wei">
    <LayoutsHeader :title="''" :class="state.color ? 'color' : ''" @onClickRight="checkRight(state.detailData)">
      <template v-slot:right>
        <slot name="right">举报</slot>
      </template>       
    </LayoutsHeader>
    <!-- 体验报告 -->
    <PullUp
      @refreshData="refreshData"
      @moreData="moreData"
      :finished="state.finished"
      :loading="state.loading"
      :refreshing="state.refreshing"
      class="list-main"
    >
      <!-- 妹子图片轮播图 -->
        <JavSwiper
            ref="Jav_Swiper"
            :hasSuperiorClick=true
            @click="clickImg"
            :autoplay="0"
            class="ww-swiper"
            :imgs="state.detailData.images"
            :height="'6.77rem'"
            :shoudPlay="state.detailData.videoUrl"
          >
        </JavSwiper>
      <!-- 价格 -->
      <div class="main-price">
        <h2><span>¥</span> {{ changeGold(state.detailData.price) }}</h2>
        <div class="right-icon">
          <img src="@/assets/imgs/white-path.svg" alt="" />
          {{ numberFilter(state.detailData.collects) }}
        </div>
      </div>
      <!-- 主体内容 -->
      <div class="wai-wei-main">
        <!-- 标题 -->
        <div class="main-title">
          <div class="top">
            <span class="bg-txt" v-for="item in state.detailData.tag" :key="item">{{ item }}</span>
            <h2>{{ state.detailData.title }}</h2>
          </div>
          <div class="bottom">
            <span v-show="state.detailData.createdAt">{{ formatDate(state.detailData.createdAt) }}</span>
            <span class="bg-txt city">{{ state.detailData.sells }}人约过</span>
          </div>
        </div>
        <!-- 分割线 -->
        <div class="line"></div>
        <!-- 基础信息 -->
        <ul class="detail-info">
          <li>
            <span class="label">项目</span>
            <div class="item-detail left-list">
              <span class="bg-txt city" v-for="item in state.detailData.serviceItems" :key="item"> {{ item }}</span>
            </div>
          </li>
          <li>
            <span class="label">方式</span>
            <div class="item-detail left-list">
              <span class="bg-txt city" v-for="item in state.detailData.serviceType" :key="item"> {{ item }}</span>
            </div>
          </li>
          <li>
            <span class="label">地区</span>
            <div class="item-detail left-list">
              <span class="bg-txt city" v-for="(item,index) in state.detailData.serviceCity" :key="index"> {{ item }}</span>
            </div>
          </li>

          <li>
            <span class="label">资料</span>
            <div class="item-detail">
              <span v-html="`${state.detailData.girlHeight}  | &nbsp`"></span>
              <span v-html="`${state.detailData.girlAge}  | &nbsp`"> </span>
              <span> {{ fillterCup(state.detailData.cupValue) }}</span>
            </div>
          </li>
          <li v-if="state.detailData.isBuy">
            <span class="label">联系方式</span>
              {{state.detailData.contactInfo}}
            <img
              style="width: 0.4rem;margin-left:0.2rem;"
              @click="onCopy(state.detailData.contactInfo)"
              src="@/assets/imgs/copy.svg"
              alt=""
            />              
          </li>
          <li>
            <span class="label">介绍</span>
            <div class="process-item">
              {{ state.detailData.desc ? state.detailData.desc : '暂无详细描述' }}
            </div>
          </li>
        </ul>
      </div>

      <!-- 商家信息 -->
      <div class="boss-info">
        <SjCard :list="state.bossInfo" />
      </div>
      <!-- 体验报告 -->
      <ul class="report-list">
        <li v-for="item in state.reportList" :key="item.createdAt">
          <div class="avatar-left">
            <DecryptImg :imgURL="item.userAvatar"></DecryptImg>
          </div>
          <div class="detail-right">
            <h2>{{ item.userName }}</h2>
            <p>体验时间:{{ timeYmd(item.createdAt) }}</p>
            <div class="detail-desc">
              {{ item.text }}
            </div>
            <div class="detail-images">
              <DecryptImg
                class="img-item"
                :needPadding="false"
                v-for="img in item.images"
                :imgURL="img"
                :key="img"
              ></DecryptImg>
            </div>
          </div>
        </li>
      </ul>
    </PullUp>
    <!-- 底部按钮 -->
    <ul class="footer-btn">
      <li class="ren-zheng" @click="releaseReport(state.detailData)">
        <img src="@/assets/imgs/dating/report.svg" alt="" />
        发布体验
      </li>
      <li class="like" @click="checkLike(state.detailData)">
        <img
          :src="`${
            !state.detailData.isCollect ? getAssetsFile('white-path.svg') : getAssetsFile('red-path.svg')
          }`"
          alt=""
        />
        {{ `${state.detailData.isCollect ? '已收藏' : '收藏'}` }}
      </li>
      <li v-if="!state.detailData.isBuy" @click="$router.push(`/dating/sm_detail/reserve/${state.detailData.id}`)" class="reserve">
        <img src="@/assets/imgs/dating/path-2.svg" alt="" />
        立即预约
      </li>
      <li v-else class="reserve">已预约</li>
    </ul>

  </div>
</template>

<script setup>
import useClipboard from 'vue-clipboard3'
import { numberFilter , changeGold , formatDate , timeYmd, fillterCup } from '@/utils/filter'
import { getAssetsFile } from '@/utils/utils_tools'
import { dating_report, model_detail } from '@/api/dating'
import { collect } from '@/api/home'
import { showImagePreview } from 'vant'
import { showToast } from 'vant'
const router = useRouter()
const route = useRoute()
const { toClipboard } = useClipboard()
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const JavSwiper = defineAsyncComponent(() => import('@/components/JavSwiper.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const SjCard = defineAsyncComponent(() => import('@/components/Dating/Sj_card.vue'))
let Jav_Swiper = ref(null)
const state = reactive({
  detailData: {},
  bossInfo: [],
  pageNum: 1,
  color: false,
  pageSize: 10,
  reportList: [],
  refreshing: false, // 下拉刷新开关
  loading: false, // 上拉加载
  finished: false, // 上拉加载开关
  cdn:computed(() => store.getters['cdn'].imgCdn)
})

// 复制
const onCopy = async(contactInfo) => {
  try {
    await toClipboard(contactInfo)
    showToast('复制成功！！！')
  } catch (e) {
    console.error(e)
  } 
}

// 监听滚动高度
const scrollHandle = (e) => {
  // const top = e.srcElement.scrollingElement.scrollTop // 获取页面滚动高度
  // if (top >= 300) {
  //   state.color = true
  // } else {
  //   state.color = false
  // }
}

const checkRight =async (item) => {
  if (item.isBuy) {
    // 跳转举报编辑页
    router.push(`/dating/complaint/${item.id}?type=${1}`)
  } else {
    showToast('购买后才能提交举报')
  }
}
// 获取妹子详情
const getLfdetail =async () => {
  try {
    const res = await model_detail({
      id: +route.params.id
    })
    if (res.code === 200) {
      state.detailData = res.data.details
      state.bossInfo.push(res.data.bossInfo)
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    return showToast('请求错误，请稍后再试！')
  }
}

// 收藏外围信息
const checkLike =async (item) => {
  const res = await collect({
    flag: !item.isCollect,
    object_id: item.id,
    collect_type: 4
  })
  if (res.code === 200) {
    state.detailData.isCollect = !item.isCollect
    if (state.detailData.isCollect) {
      return showToast('收藏成功')
    } else {
      return showToast('取消收藏')
    }
  } else {
    return showToast(res.tip)
  }
}

// 发布体验
const releaseReport = (item) => {
  if (item.isBuy) {
    if (item.isReport) {
      showToast('您已发布一次了，试试其他的吧')
    } else {
      router.push(`/dating/release-report/${item.id}?type=${2}`)
    }
  } else {
    showToast('购买后才能发布体验')
  }
}

// 获取报告列表
const getReportList =async (item) => {
  const res = await dating_report({
    objectId: +route.params.id,
    pageNum: state.pageNum,
    pageSize: state.pageSize,
    type: 1
  })
  if (res.code === 200) {
    state.refreshing = false
    state.loading = false
    state.reportList = [...state.reportList, ...res.data.list]
    if (res.data.list.length < state.pageSize) {
      state.finished = true
    }
  } else {
    state.loading = false
    state.refreshing = false
    state.finished = true
    return showToast(res.tip)
  }
}

// 下拉刷新
const refreshData = (refreshing) => {
  state.refreshing = refreshing
  state.pageNum = 1
  state.finished = false
  state.loading = true
  state.reportList = []
  getReportList()
}

// 上拉加载
const moreData = (loading) => {
  state.loading = loading
  state.pageNum += 1
  getReportList()
}

// 图片预览
const clickImg = (imgUrl) => {
  const imgArr = []
  let index = 0
  const domArr = Jav_Swiper.value.refImg
  domArr.forEach((itemBlob, indexBlob) => {
    if (imgUrl === itemBlob.imgURL) {
      index = indexBlob
    }
    imgArr.push(itemBlob.realUrl)
  })
  showImagePreview({
    images: imgArr, // 需要预览的图片 URL 数组
    showIndex: true, // 是否显示页码
    loop: true, // 是否开启循环播放
    startPosition: index // 图片预览起始位置索引
  })
}

onMounted(() => {
  getLfdetail()
  getReportList()
  window.addEventListener('scroll', scrollHandle) // 绑定页面滚动事件
}) 

onUnmounted(() => {
  window.removeEventListener('scroll', scrollHandle)
})
</script>

<style lang="scss" scoped>
.wai-wei {
  padding: 0;
  padding-bottom: 1rem;
  min-height: 100vh;
  :deep()  {
    .van-nav-bar {
      background: transparent !important;
      border: none !important;
    }
    .van-icon-arrow-left,
    .van-nav-bar__title,
    .van-nav-bar__content {
      color: $mainTxtColor1 !important;
    }
  }
  .ww-swiper {
    :deep()  {
      .warp {
        border-radius: 0;
        img {
          border-radius: 0;
        }
      }
    }
  }
  &-main {
    padding: 0.3rem 0.3rem 0 0.3rem;
    //  padding-top:7.77rem;
    background: $mainBgColor;
    margin-top: 0.3rem;
    box-shadow: $shadow;
  }
  // 顶部价格
  .main-price {
    @include flexbox();
    height: 1.12rem;
    padding: 0 0.24rem;
    background: $mainBgColor;
    box-shadow: $shadow;
    span {
      font-size: 0.2rem;
    }
    h2 {
      font-weight: 600;
      margin: 0;
      font-size: 0.36rem;
    }
    .right-icon {
      @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
      flex: none;
      font-size: 0.28rem;
      color: #848494;
      img {
        width: 0.228rem;
        height: 0.212rem;
        margin-right: 0.105rem;
      }
    }
  }
  // 顶部标题
  .main-title {
    font-size: 0.24rem;
    color: #989cae;
    h2 {
      margin: 0;
      font-size: 0.32rem;
      margin-left: 0.2rem;
    }
    span {
      font-weight: 600;
    }
    .top {
      color: #fff;
      @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
    }
    .bottom {
      @include flexbox();
      margin-bottom: 0.2rem;
    }
  }
  .line {
    height: 0.04rem;
    background: #848494;
    margin: 0.3rem 0;
  }
  // 警告提示语
  .waring-txt {
    padding: 0.16rem 0.3rem;
    color: #f64562;
    background: $mainBgColor;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 0.16rem;
    font-weight: 500;
    border-radius: 0.2rem;

    box-shadow: $shadow;
    .txt {
      text-align: justify;
      text-justify: auto;
    }
    img {
      width: 0.62rem;
      height: 0.62rem;
      flex-shrink: 0;
      margin-right: 0.34rem;
    }
  }

  // 预约价格
  .detail-info {
    padding: 0.3rem;
    background: $mainBgColor;

    font-size: 0.26rem;
    // 基础信息
    li {
      margin-bottom: 0.15rem;
      font-weight: 400;
      @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
      .label {
        font-size: 0.3rem;
        font-weight: 600;
        margin-right: 0.27rem;
        white-space: nowrap;
      }
      div {
        box-shadow: $shadow;
        padding: 0.15rem 0.3rem;
        border-radius: 0.09rem;
        width: 6.1rem;
      }
    }
  }
}
.color {
  :deep()  {
    .van-nav-bar {
      background: #f4f7fc !important;
    }
    .van-icon-arrow-left,
    .van-nav-bar__title,
    .van-nav-bar__content {
      color: #000 !important;
    }
  }
}
// 商家信息
.boss-info {
  margin: 0.2rem 0.34rem;
}

.report-list {
  li {
    padding: 0.3rem 0.12rem;
    background-color: $mainBgColor;
    display: flex;
    font-size: 0.24rem;
    margin-bottom: 0.15rem;
    // 左侧头像
    .avatar-left {
      display: flex;
      flex-direction: column;
      align-items: center;
      font-weight: 600;
      margin-right: 0.23rem;
      white-space: nowrap;
      :deep()  {
        .default {
          width: 0.9rem;
          height: 0.9rem;
          margin-bottom: 0.14rem;
        }
        .warp {
          border-radius: 50%;
          img {
            border-radius: 50%;
          }
        }
      }
    }
    .detail-right {
      h2 {
        margin: 0;
      }
      p {
        margin: 0;
        font-size: 0.12rem;
        color: #999;
      }
    }
    .detail-images {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      margin-top: 0.12rem;
      .img-item {
        width: 1.3rem;
        height: 1.3rem;
        margin-right: 0.25rem;
      }
      .img-item:nth-child(3n) {
        margin-right: 0;
      }
    }
  }
}
// 底部按钮
.footer-btn {
  display: flex;
  position: fixed;
  align-items: center;
  justify-content: space-around;
  width: 100%;
  max-width: $pcMaxWidth;
  background-color: $mainBgColor;
  height: 1rem;
  font-size: 0.26rem;
  bottom: 0;
  padding: 0 0 0 0.52rem;
  box-sizing: border-box;
  li {
    display: flex;
    align-items: center;

    img {
      margin-right: 0.13rem;
      filter: brightness(100);
    }
  }
  .like {
    img {
      width: 0.36rem;
      height: 0.31rem;
    }
  }

  .ren-zheng {
    img {
      width: 0.323rem;
      height: 0.349rem;
    }
  }
  .reserve {
    background: $btnBg;
    justify-content: center;
    font-weight: 600;
    font-size: 0.34rem;
    width: 2.8rem;
    height: 0.68rem;
    border-radius: 0.5rem;
    img {
      filter: brightness(100);
      width: 0.273rem;
      height: 0.327rem;
    }
  }
}

.bg-txt {
  color: #000;
  font-size: 0.22rem;
  padding: 0.03rem 0.13rem;
  font-weight: 400;
  border-radius: 0.06rem;
  margin-right: 0.1rem;
  background: linear-gradient(to right, #fbe07c, #ffbb10);
}
.bg-txt:last-child {
  margin-right: 0rem;
}
.item-detail {
  @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
}
.city {
  flex-shrink: 0;
  border-radius: 0.5rem;
}
.left-list {
  overflow-x: scroll;
}
</style>
