<template>
  <div class="reserve">
    <LayoutsHeader :title="'在线预约'"></LayoutsHeader>
    <div class="release-main">
      <!-- 联系方式 -->
      <div class="top-contact">
        联系方式
        <div class="contact">
          <div class="contact-div"></div>
          预约完成后,即可获得经纪人联系方式
        </div>
      </div>
      <!-- 复制 -->
      <div class="show-contact" v-if="state.detailData.isBuy">
        {{ state.detailData.contactInfo }}
        <img
          @click="onCopy(state.detailData.contactInfo)"
          src="@/assets/imgs/copy.svg"
          alt=""
        />
      </div>
      <!-- 支付金额 -->
      <div class="price">
        支付金额
        <span>¥</span>
        <span>{{ changeGold(state.detailData.reservationPrice) }}</span>
      </div>
      <!-- 预约流程 -->
      <div class="liucheng">
        预约流程
        <ul>
          <li>1.支付预约金之后，获得经纪人的联系方式</li>
          <li>2.联系经纪人确定约妹时间，在线选妹妹</li>
          <li>3.与妹妹见面满意，则付尾款(全款减去预约金)给妹妹</li>
          <li>4.体验满意，到汁乎APP发布体验报告，获得官方福利</li>
          <li>5.如果经纪人服务过程中出现欺诈或者其他服务问题，可直接联系平台在线客服举报</li>
        </ul>
      </div>
      <!-- 定金预约 -->
      <div class="submit">
        <div class="submit-txt">
          定金预约:
          <span>¥</span>
          <span> {{ changeGold(state.detailData.reservationPrice) }}</span>
        </div>
        <div v-if="!state.detailData.isBuy" class="submit-btn" @click="state.showBuy = true">
          <img src="@/assets/imgs/dating/path-2.svg" alt="" />
          立即预约
        </div>
        <li v-else class="submit-btn">已预约</li>
      </div>
      <!-- 购买弹窗 -->
      <JavShowBuy
        :showBuy="state.showBuy"
        @shoudBuy="shoudBuy"
        @closed="closed"
        :title="'获取此上门信息需支付'"
        :price="Number(changeGold(state.detailData.reservationPrice))"
      />
    </div>
  </div>
</template>

<script setup>
import useClipboard from 'vue-clipboard3'
const { toClipboard } = useClipboard()
import { showToast } from 'vant'
import { changeGold } from '@/utils/filter'
import { model_detail, dating_pay } from '@/api/dating'
const router = useRouter()
const route = useRoute()
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const JavShowBuy = defineAsyncComponent(() => import('@/components/JavShowBuy.vue'))
const state = reactive({
  id: 0,
  showBuy: false,
  detailData: {}
})
// 复制
const onCopy =async (contactInfo) => {
  try {
    await toClipboard(contactInfo)
    showToast('复制成功！！！')
  } catch (e) {
    console.error(e)
  } 
}

// 获取详情数据
const getDetail =async () => {
  try {
    const res = await model_detail({
      id: +route.params.id,
      type: 2 // 2 固定值，外围
    })
    if (res.code === 200) {
      state.detailData = res.data.details
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    return showToast('请求失败，请稍后再试！')
  }
}
const closed =(n) => {
  state.showBuy = n
}
// 购买弹窗购买按钮
const shoudBuy =async () => {
  try {
    const res = await dating_pay({
      objectId: state.detailData.id,
      type: 2
    })
    if (res.code === 200) {
      state.detailData.isBuy = true
      state.showBuy = false
      showToast('购买成功，点上面复制即可')
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    return showToast('请求错误，请稍后再试！')
  }
}

onMounted(() => {
  getDetail()
}) 
</script>

<style lang="scss" scoped>
.reserve {
  min-height: 100vh;
  background: $mainBgColor;
  padding-top: 1rem;
  font-size: 0.26rem;
  :deep()  {
    .header-nav {
      border-bottom: 0.02rem solid #999;
    }
  }
}
// 联系方式
.release-main {
  padding: 0.4rem 0.2rem;
  .top-contact {
    display: flex;
    align-items: center;
    font-weight: 600;
    font-size: 0.32rem;
  }
  .contact {
    font-weight: 400;
    font-size: 0.2rem;
    color: #ff5710;
    margin-left: 0.2rem;
    @include flexbox($jc:flex-start, $ai:center, $fd:row, $fw:nowrap);
    &-div{
      width:0.2rem;
      height:0.2rem;
      border-radius: 50%;
      background:#ff5710;
      margin-right: 0.2rem;
    }
  }
}
.show-contact {
  padding: 0.2rem;
  color: #fff;
  font-weight: 600;
  font-size: 0.35rem;  
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-radius: 0.08rem;
  margin: 0.4rem 0;
  img {
    width: 0.3rem;
  }
}
.price {
  padding-bottom: 0.4rem;
  border-bottom: 0.02rem solid #999;
  font-weight: 600;
  font-size: 0.32rem;
  margin-top: 0.2rem;
  span {
    color: #ff5710;
  }
  span:first-child {
    font-weight: 400;
    font-size: 0.2rem;
  }
}
// 预约流程
.liucheng {
  margin-top: 0.4rem;
  font-weight: 600;
  font-size: 0.32rem;
  ul {
    font-weight: 400;
    font-size: 0.24rem;
    margin-top: 0.2rem;
    li {
      margin-bottom: 0.1rem;
    }
  }
}

// 提交审核
.submit {
  position: fixed;
  bottom: 0rem;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.2rem;
  max-width: $pcMaxWidth;
  background: $mainBgColor;
  color: #666;
  font-size: 0.3rem;
  text-align: center;
  border-top: 0.02rem solid #333;
  left: 50%;
  transform: translate(-50%, 0);
  .submit-txt {
    font-weight: 600;
    font-size: 0.32rem;
    span {
      color: #ff5710;
    }
    span:first-child {
      font-weight: 400;
      font-size: 0.2rem;
    }
  }
  .submit-btn {
    color: #fff;
    background: $btnBg;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: 0.34rem;
    width: 2.8rem;
    height: 0.68rem;
    border-radius: 0.5rem;
    line-height: 0.68rem;
    img {
      filter: brightness(100);
      width: 0.273rem;
      margin-right: 0.2rem;
      height: 0.327rem;
    }
  }
}
</style>
