<template>
  <div class="iosBetaB">
    <div class="close" @click="clickClose">关闭</div>
    <div class="header">
      <h1 class='header_text'>苹果轻量版安装引导</h1>
    </div>
    <main>
      <section class="first" @click="requestAPP">
        <div class="title">点击 <span class="download">下载</span> 苹果轻量版</div>
        <img class="imgbtn" src="@/assets/imgs/download-ios/h5_btn.png" alt="点击下载">
      </section>      
      <section class="body">
        <img src="@/assets/imgs/download-ios/h5_bg1.png" alt="" style="width:100%">
      </section>
      <div class="header">
        <h1 class='header_text' style="font-size: 14px;">回到手机桌面，打开设置➔通用➔VPN与设备管理</h1>
        <h1 class='header_text' style="font-size: 14px;">➔点击已下载的描述文件，安装即可</h1>
      </div>      
      <section class="body" style="position: relative;">
        <div>点击右上角<span class="download" >&lceil;安装&rfloor;</span>进行下一步</div>
        <img src="@/assets/imgs/download-ios/h5_bg2.png" alt="" style="width:100%">
      </section>
      <section class="body">
        <img src="@/assets/imgs/download-ios/h5_bg3.png" alt="" style="width:100%">
      </section>
      <section class="body" style="position: relative;">
        <div>点击右上角<span class="download" >&lceil;安装&rfloor;</span>进行下一步</div>
        <div style="top:80px">并点击完成</div>
        <img src="@/assets/imgs/download-ios/h5_bg4.png" alt="" style="width:100%">
      </section>
      <section class="body h5_bg5">
        <img class="imgbtn" src="@/assets/imgs/download-ios/h5_btn.png" alt="点击下载">
        <img src="@/assets/imgs/download-ios/h5_bg5.png" alt="" style="width:100%">
      </section>
    </main>
   
    <div class="header">
      <h1 style="font-size: 14px">ios轻量版安装引导 <span>放心使用</span></h1>
    </div>
  </div>
</template>

<script setup>
import { publicDownload } from '@/utils/utils_tools'
const router = useRouter()
const requestAPP =() =>{
  publicDownload();
}
const clickClose =() =>{
  if(window.history.length){
    router.back();
  }else{
    router.push('/');
  }  
}


</script>

<style lang="scss" scoped>
.iosBetaB {
  width: 100%;
  min-height: 100vh;
  padding: 10vw 5.33vw;
  background-color: rgba(31, 31, 31, 1);
  .close {
    width: 11vw;
    height: 6vw;
    border-radius: 5%;
    background-color: #585755;
    position: absolute;
    top: 2vw;
    right: 2vw;
    text-align: center;
    font-size: 3.3vw;
    line-height: 6vw;
  }
  .header {
    text-align: center;
    h1 {
      color: #ffcb83;
      margin-top: 1.86vw;
      font-size: 4.5333vw;
    }
  }
  main {
    .download {
      font-size: 20px;
      font-weight: bold;
      color: #ffcb83;
    }
    section {
      width: 100%;
      background-color: #151515;
      margin: 3.66vw 0;
      background-repeat: no-repeat;
      background-size: contain;
    }
    .first {
      border: 1px solid rgb(78, 78, 78);
      background-size: 100% 100%;
      display: flex;
      padding: 20px 0;
      align-items: center;
      flex-direction: column;
      .title {
        font-size: 15px;
        color: #fff;
      }

      .imgbtn {
        margin-top: 20px;
        width: 80px;
        height: 80px;
      }
    }    
    .body {
      border: 1px solid rgb(78, 78, 78);
      background-size: 100% 100%;
      display: flex;
      align-items: center;
      flex-direction: column;
      div {
        position: absolute;
        top: 50px;
        font-size: 14px;
        color: rgb(194, 194, 194);
      }
      &.h5_bg5{
        position: relative;
        .imgbtn{
          position: absolute;
          bottom: 0.5rem;
          left: 50%;
          transform: translateX(-50%);          
          width: 1.2rem;
          height: 1.2rem;
        }
      }
    }
  }
  //提示弹窗
  aside{
    position: fixed;
    top: 50%;
    left: 50%;
    color: #000;
    transform:translate3d(-50%,-50%,0);
    width: 100%;
    max-width: 10rem;
    z-index: 999;
    display: flex;
    justify-content: center;
    animation: showAnimate;
    animation-duration: .2s;    
    .popup-wrap{
      font-size: .36rem;  
      width: 80%;
      border-radius: .2rem;
      background: #fff;
      text-align: center;
      .popupText{
        padding: .5rem .5rem 0 .6rem;
      }
      .popup-close{
        border-top: 1px solid #eee;
        margin-top: .3rem;
        padding-top:.3rem ;
        padding-bottom:.3rem ;
        color: #4395ff;
      }
    }
    @keyframes showAnimate {
      0% {
        opacity: 0;
      }
      50% {
        opacity: .5;
      }          
      100% {
        opacity: 1;
      }
    }             
  }  
}
</style>
