<template>
  <div class="home-actor">
    <LayoutsHeader title="女优" />
    <Actor :type="type"></Actor>
  </div>
</template>
<script setup>
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const Actor = defineAsyncComponent(() => import('@/components/Home/actor.vue'))

const state = reactive({
  type: 13321,
  avcategoryv2:computed(() => store.getters['avcategoryv2']),
})

onMounted(() => {
  state.avcategoryv2.forEach(element => {
    if (element.name == '女优'){
      state.type = element.id
    }
  })
}) 

</script>

<style lang="scss" scoped>
.home-actor {
  padding-top: 0.92rem;
  max-width: $pcMaxWidth;
  margin: 0 auto;
}
</style>
