<!-- home -->
<template>
  <div class="index-container">
    <div style="min-height:3.6rem;">
      <SwiperShow :imgList="avAD"  />
    </div>
    <div class="home-card-warp" style="min-height:3.2rem;background: #1917173d; margin-top: 0.38rem">
      <MuBtnList :tags="state.tagList"></MuBtnList>
    </div>
    <div class="home-card-warp" style="min-height:7.54rem;" >
      <h3 class="home-card-title" style="padding: 0.12rem 0.32rem 0 0.32rem; color: #f4ce4e; font-size: 0.32rem">
        免费片单区
      </h3>
      <HomeCardHeaderTitle
        :title="'免费影片看个够！'"
        :calssName="'home-card-sub-title'"
        :hasMoreBtn="true"
        @clickReplayBtn="getCartoonPage('mfList')"
        @clickMore="() => $router.push(`/recommend`)"
      ></HomeCardHeaderTitle>
      <MuzCard :itemNumber="4" :list="state.mfList" @clickJumpURL="handleJump"></MuzCard>
    </div>
    <div class="merchantcard-list">
      <div class="merchantcard-list-item" @click="toBossDetail(item)" v-for="item in state.BossList" :key="item.id">
        <Merchantcard :item="item" />
      </div>
    </div>
    <div class="home-card-warp" style="min-height:10rem;">
      <h3 class="home-card-title" style="padding: 0.12rem 0.32rem 0 0.32rem; color: #f4ce4e; font-size: 0.32rem">
        独家推送
        <van-icon
          @click="replayExclusivePushesList()"
          class="icon"
          :class="{ iconTrans: state.pushActivation }"
          name="replay"
        />
      </h3>
      <div v-for="(jingxuanCItem, key) in state.jingxuanList" :key="'wlCList' + key">
        <HomeCardHeaderTitle
          :title="jingxuanCItem.name"
          :calssName="'home-card-sub-title'"
          @clickReplayBtn="handleClickDaysReplayBtn(key + 1)"
          @clickMore="
            () =>
              $router.push(
                `/media_detail/${jingxuanCItem['id']}?title=${jingxuanCItem.name}&showType=${jingxuanCItem.showType}&price=${jingxuanCItem.price}`
              )
          "
        ></HomeCardHeaderTitle>
        <div class="" style="position: relative">
          <component
            :typeTxt="'推荐'"
            :id="jingxuanCItem.id"
            :list="jingxuanCItem.mediaList"
            :is="compExclusiveType(jingxuanCItem.showType)"
          ></component>
        </div>
      </div>
    </div>

    <div class="home-card-warp">
      <HomeCardHeaderTitle
        :title="'今日主题'"
        @clickReplayBtn="getCartoonPage()"
        @clickMore="() => $router.push(`/home/sub?name=AV`)"
      ></HomeCardHeaderTitle>
      <MuzCard :list="state.topicList" @clickJumpURL="handleJump"></MuzCard>
    </div>

    <div class="animate-tabs">
      <div :class="{ 'animate-tab-active': state.videoAnimateIndex === 1 }" @click="handleClickVideoTab(1)">国产传媒</div>
      <div :class="{ 'animate-tab-active': state.videoAnimateIndex === 2 }" @click="handleClickVideoTab(2)">欧美精选</div>
      <div :class="{ 'animate-tab-active': state.videoAnimateIndex === 3 }" @click="handleClickVideoTab(3)">动漫二次元</div>
    </div>

    <transition name="van-fade">
      <div v-show="state.videoAnimateIndex == 1" class="home-card-warp" style="">
        <HomeCardHeaderTitle
          :title="''"
          @clickReplayBtn="getMuViCardList(0)"
          @clickMore="() => $router.push(`/home/sub?name=国产`)"
        ></HomeCardHeaderTitle>

        <MuViCard :list="state.gcList" style="position: relative; top: -0.4rem"></MuViCard>
      </div>
    </transition>
    <transition name="van-fade"
      ><div v-show="state.videoAnimateIndex == 2" class="home-card-warp" style="">
        <HomeCardHeaderTitle
          :title="''"
          @clickReplayBtn="getMuViCardList(1)"
          @clickMore="() => $router.push(`/home/sub?name=国产`)"
        ></HomeCardHeaderTitle>
        <MuViCard :list="state.omList" style="position: relative; top: -0.4rem"></MuViCard>
      </div>
    </transition>
    <transition name="van-fade">
      <div class="home-card-warp" v-show="state.videoAnimateIndex == 3">
        <HomeCardHeaderTitle
          :title="''"
          @clickReplayBtn="getMuViCardList(3)"
          @clickMore="() => $router.push(`/home/sub?name=动漫`)"
        ></HomeCardHeaderTitle>
        <MuM2viCard :list="state.comicsVideoList" style="position: relative; top: -0.4rem"></MuM2viCard>
      </div>
    </transition>
    <!-- <transition name="van-fade"
      ><div v-show="state.videoAnimateIndex == 3" class="home-card-warp" style="">
        <HomeCardHeaderTitle
          :title="''"
          @clickReplayBtn="getMuViCardList(2)"
          @clickMore="() => $router.push(`/home/sub?name=国产`)"
        ></HomeCardHeaderTitle>
        <MuViCard :list="mfList" style="position: relative; top: -0.4rem"></MuViCard>
      </div>
    </transition> -->

    <div class="home-card-warp" style="background: linear-gradient(to right, #726355, #587f6f69, #5e5846, #4b454f)">
      <HomeCardHeaderTitle
        @clickReplayBtn="getTHPage(1)"
        :hasMoreBtn="false"
        :title="'♨特惠推荐区'"
      ></HomeCardHeaderTitle>
      <MuzCard :list="state.thList" @clickJumpURL="handleJump"></MuzCard>
    </div>
    <div class="home-card-warp" v-if="state.wlList.length > 0">
      <h3 class="home-card-title" style="padding: 0.12rem 0.32rem 0 0.32rem; color: #f4ce4e">网络大事件推荐</h3>
      <div v-for="(wlCItem, key) in state.wlList" :key="'wlCList' + key">
        <HomeCardHeaderTitle
          :title="wlCItem.name ? wlCItem.name : '网络大事件'"
          :hasReplayBtn="false"
          :hasMoreBtn="wlCItem.name !== ''"
          :calssName="'home-card-sub-title'"
          style="margin-bottom: 0.12rem"
          @clickMore="
            () =>
              $router.push(
                `/media_detail/${wlCItem['id']}?title=${wlCItem.name}&showType=${wlCItem.showType}&price=${wlCItem.price}`
              )
          "
        ></HomeCardHeaderTitle>

        <JavFourCard :typeTxt="'推荐'" :typeID="24372" :id="wlCItem.id" :list="wlCItem.mediaList"></JavFourCard>
      </div>
    </div>

    <div class="home-card-warp">
      <div v-for="(ztCItem, key) in state.ZTList" :key="'ztCItem' + key">
        <HomeCardHeaderTitle
          :hasReplayBtn="false"
          :title="ztCItem.name"
          @clickMore="
            () =>
              $router.push(
                `/media_detail/${ztCItem['id']}?title=${ztCItem.name}&showType=${ztCItem.showType}&price=${ztCItem.price}`
              )
          "
        ></HomeCardHeaderTitle>
        <div class="" style="position: relative">
          <JavShortSix :typeTxt="'推荐'" :id="ztCItem.id" :list="ztCItem.mediaList"></JavShortSix>
        </div>
      </div>
    </div>

    <div class="animate-tabs">
      <!-- <div :class="{ 'animate-tab-active': state.comicsAnimateIndex === 1 }" @click="handlClickTabLoadComisAjax(1)">
        {{ state.isMobile ? '肉番' : '♨肉番【视频】' }}
      </div> -->
      <div :class="{ 'animate-tab-active': state.comicsAnimateIndex === 1 }" @click="handlClickTabLoadComisAjax(1)">
        {{ state.isMobile ? '韩漫' : '♨韩漫【漫画】' }}
      </div>

      <div :class="{ 'animate-tab-active': state.comicsAnimateIndex === 2 }" @click="handlClickTabLoadComisAjax(2)">
        {{ state.isMobile ? 'Cosplay' : '♨Cosplay【美图】' }}
      </div>
      <div :class="{ 'animate-tab-active': state.comicsAnimateIndex === 3 }" @click="handlClickTabLoadComisAjax(3)">
        {{ state.isMobile ? '日漫' : '♨日漫漫画【漫画】' }}
      </div>
      <div :class="{ 'animate-tab-active': state.comicsAnimateIndex === 4 }" @click="handlClickTabLoadComisAjax(4)">
        {{ state.isMobile ? '游戏CG' : '♨游戏CG【漫画】' }}
      </div>
    </div>
    <!-- 动漫 -->

    <!-- ♨韩漫【漫画】 -->
    <transition name="van-fade">
      <div class="home-card-warp" v-show="state.comicsAnimateIndex === 1">
        <HomeCardHeaderTitle
          :title="''"
          @clickReplayBtn="toggleComicsList(1)"
          @clickMore="() => $router.push(`/comics`)"
        ></HomeCardHeaderTitle>
        <MuMviCard :list="state.comicsList" style="position: relative; top: -0.4rem"></MuMviCard>
      </div>
    </transition>
    <!-- ♨Cosplay【美图】 -->
    <transition name="van-fade">
      <div class="home-card-warp" v-show="state.comicsAnimateIndex === 2">
        <HomeCardHeaderTitle
          style="margin-top: 0.1rem"
          :title="''"
          @clickReplayBtn="toggleComicsList(2)"
          @clickMore="() => $router.push(`/comics`)"
        ></HomeCardHeaderTitle>
        <MuMviCard :list="state.cosplayList" style="position: relative; top: -0.4rem"></MuMviCard>
      </div>
    </transition>
    <!-- ♨日漫漫画【漫画】 -->
    <transition name="van-fade">
      <div class="home-card-warp" v-show="state.comicsAnimateIndex === 3">
        <HomeCardHeaderTitle
          style="margin-top: 0.1rem"
          :title="''"
          @clickReplayBtn="toggleComicsList(3)"
          @clickMore="() => $router.push(`/comics`)"
        ></HomeCardHeaderTitle>
        <MuMviCard :list="state.rmList" style="position: relative; top: -0.4rem"></MuMviCard>
      </div>
    </transition>
    <!-- ♨游戏CG【漫画】 -->
    <transition name="van-fade">
      <div class="home-card-warp" v-show="state.comicsAnimateIndex === 4">
        <HomeCardHeaderTitle
          style="margin-top: 0.1rem"
          :title="''"
          @clickReplayBtn="toggleComicsList(4)"
          @clickMore="() => $router.push(`/comics`)"
        ></HomeCardHeaderTitle>
        <MuMviCard :list="state.cgList" style="position: relative; top: -0.4rem"></MuMviCard>
      </div>
    </transition>

    <!-- <div class="home-card-warp">
      <template v-if="wanOuList.length > 0">
        <HomeCardHeaderTitle
          :title="wanOuList && wanOuList.id && wanOuList.name"
          :hasReplayBtn="false"
          @clickMore="
            () =>
              $router.push(
                `/media_detail/${wanOuList['id']}?title=${wanOuList.name}&showType=${wanOuList.showType}&price=${wanOuList.price}`
              )
          "
        ></HomeCardHeaderTitle>
        <div style="overflow: scroll; vertical-align: top">
          <div
            style="font-size: 0.12rem; line-height: 1.2; position: relative; color: #fff; height: auto"
            :style="{
              width: wanOuList && wanOuList.mediaList && wanOuList.mediaList.length * 3.24 + 'rem'
            }"
          >
            <div
              v-for="(woCItem, key) in wanOuList.mediaList"
              :key="'woCItem' + key"
              style="
                position: relative;
                width: 3rem;
                margin: 0.02rem 0.12rem;
                display: inline-block;
                vertical-align: top;
              "
            >
              <div style="padding-top: 57.68%; position: relative">
                <div
                  style="
                    position: absolute;
                    z-index: 1;
                    top: 0;
                    width: 100%;
                    height: 100%;
                    display: flex;
                    flex-flow: row wrap;
                    border-radius: 0.06rem;
                    overflow: hidden;
                  "
                >
                  <template v-if="woCItem">
                    <div class="home-pos-w100" @click="handelVideoPalyerPath(woCItem['videoType'], woCItem)">
                      <DecryptImg :imgURL="woCItem.coverImg" :needPadding="false" class="item-bg">
                        <HomeVideoTypeTag :payType="woCItem.payType" :price="woCItem.price"></HomeVideoTypeTag>
                      </DecryptImg>
                    </div>
                  </template>
                </div>
              </div>
              <div style="margin: 0.2rem 0; font-size: 0.2rem" class="van-multi-ellipsis--l2">{{ woCItem.title }}</div>
            </div>
          </div>
        </div>
      </template>
    </div> -->

    <div class="home-card-warp" v-if="state.wmList.length > 0">
      <h3 class="home-card-title" style="padding: 0.12rem 0.32rem 0 0.32rem; color: #f4ce4e">♨步兵系列推荐</h3>
      <div v-for="(wmCItem, key) in state.wmList" :key="'wmCItem' + key">
        <HomeCardHeaderTitle
          :title="wmCItem.name ? wmCItem.name : '无码步兵'"
          :calssName="'home-card-sub-title'"
          style="margin-bottom: 0.12rem"
          :hasReplayBtn="false"
          :hasMoreBtn="wmCItem.name !== ''"
          @clickMore="
            () =>
              $router.push(
                `/media_detail/${wmCItem['id']}?title=${wmCItem.name}&showType=${wmCItem.showType}&price=${wmCItem.price}`
              )
          "
        ></HomeCardHeaderTitle>
        <div>
          <JavFourCard :typeTxt="'推荐'" :id="wmCItem.id" :list="wmCItem.mediaList"></JavFourCard>
        </div>
      </div>
    </div>

    <!-- 活动弹窗 -->
    <!-- <van-popup
      class="activity-img-pop"
      v-model:show="state.showActivityImg"
      @close="state.showActivityImg = false"
      :overlay-style="{
        backgroundColor: 'rgba(0,0,0,.1)'
      }"
    >
      <div class="activity-img" @click="imgJub">
        <DecryptImg v-if="activityImg && activityImg.length > 0" :needPadding="false" :imgURL="activityImg[0].cover">
        </DecryptImg>
        <van-icon name="close" size="26" color="#fff" @click.stop="state.showActivityImg = false" />
      </div>
    </van-popup> -->
    <!-- 公告弹窗 -->
    <!-- <van-popup
      class="account-img-pop"
      v-model:show="state.showAnnouncemnetPop"
      @close="closeAccountImg"
      :overlay-style="{
        backgroundColor: 'rgba(0,0,0,.1)'
      }"
    >
      <div class="account-img">
        <div class="title-img">
          <img src="@/assets/imgs/index-pop-title.png" alt="" />
          <span>系统公告</span>
          <img src="@/assets/imgs/index-pop-title-right.png" alt="" />
        </div>
        <p class="title" v-if="announcement && announcement.title">{{ announcement.title }}</p>
        <div class="desc" v-if="announcement && announcement.content">{{ announcement.content }}</div>
        <van-icon name="close" size="26" color="#fff" @click="closeAccountImg" />
        <div class="btn" @click="submit">我知道了</div>
      </div>
    </van-popup> -->
    <!-- <div class="app-down">
      <van-dialog
        :close-on-click-overlay="true"
        :overlay="true"
        :lock-scroll="false"
        v-model:show="state.showDown"
        :message="`强烈推荐安装APP！\n ${
          state.isAndroid
            ? ''
            : '苹果用户请使Safari浏览器打开点击下载！\n下载后，在手机设置--通用--设备里找到它并安装！'
        } \n备用域名1:mujiejie01.com\n 备用域名2:mujiejie02.com\n 备用域名3:mujiejie03.com\n   记住本站永久域名:${baseData.VITE_APP_siteURL}     
        `"
        :show-cancel-button="false"
        :confirm-button-text="store.getters['getIsAnIosPhone']=='android'?'安卓有更新请点击下载':`下载${baseData.VITE_APP_title}APP`"
        @confirm="clickDown"
      >
        <ul class="app-dl-dialog">
          <li class="title">强烈推荐安装APP！</li>
          <li v-if="state.isIOS">苹果用户请使Safari浏览器打开点击下载！</li>
          <li v-if="state.isIOS">下载后，在手机设置-通用-设备里找到它并安装！</li>
          <li v-if="state.isAndroid">安卓用户点击下载按钮等待下载完成并安装！</li>
          <li class="domain" v-for="(item,index) in state.domainList" :key="index">备{{index+1}}:{{item}}</li>
          <li>记住本站永久域名:{{baseData.VITE_APP_siteURL}}</li>
        </ul>
      </van-dialog>
    </div>   -->
    <!-- 下载按钮2 -->
    <DownloadApp v-if="state.showDownAppIco"></DownloadApp>
  </div>
</template>

<script setup name="homePage">
  import { showToast } from 'vant';
  import { useStore } from 'vuex'
  const store = useStore()
  const router = useRouter()
  import { dating_bosses } from '@/api/dating'
  import { comicsHome } from '@/api/comics' //api列表
  import { index_home, media_details ,index_home_3,cfgAccessDomain} from '@/api/home'  
  import $device from "current-device"  
  const baseData = import.meta.env;
  import { hot_tag_list } from '@/api/search'
  import { handleParamsRouteJump, handleURlParams, publicDownload} from '@/utils/utils_tools'

  // 首屏不需要按需否则卡
  // const Merchantcard = defineAsyncComponent(() => import('@/components/Dating/Merchantcard.vue'))
  // const DownloadApp = defineAsyncComponent(() => import('@/components/DownloadApp.vue'))
  // const JavShortSix = defineAsyncComponent(() => import('@/components/JavShortSix.vue'))
  // const JavShortFour = defineAsyncComponent(() => import('@/components/JavShortFour.vue'))
  // const JavFourCard = defineAsyncComponent(() => import('@/components/JavFourCard.vue'))
  // const HomeVideoTypeTag = defineAsyncComponent(() => import('@/components/Home/videoTypeTag.vue'))
  // const MuActor = defineAsyncComponent(() => import('@/components/Home/MuActor.vue'))
  // const HomeCardHeaderTitle = defineAsyncComponent(() => import('@/components/Home/headerTitle.vue'))
  // const JavBigList = defineAsyncComponent(() => import('@/components/JavBigList.vue'))
  // const JavSortVideoBigRow = defineAsyncComponent(() => import('@/components/JavSortVideoBigRow.vue'))
  // const MuBtnList = defineAsyncComponent(() => import('@/components/Home/MuBtnList.vue'))
  // const MuViCard = defineAsyncComponent(() => import('@/components/MuViCard.vue'))
  // const MuMviCard = defineAsyncComponent(() => import('@/components/MuMviCard.vue'))
  // const MuM2viCard = defineAsyncComponent(() => import('@/components/MuM2viCard.vue'))
  // const MuzCard = defineAsyncComponent(() => import('@/components/MuzCard.vue'))
  // const JavTab = defineAsyncComponent(() => import('@/components/JavTab.vue'))
  // const Index = defineAsyncComponent(() => import('@/components/Home/index.vue'))
  // const Actor = defineAsyncComponent(() => import('@/components/Home/actor.vue'))
  // const SwiperShow = defineAsyncComponent(() => import('@/components/Swiper/index.vue'))
  // const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
  // const Default = defineAsyncComponent(() => import('@/components/Home/default.vue'))


  import Merchantcard from '@/components/Dating/Merchantcard.vue'
  import DownloadApp  from '@/components/DownloadApp.vue'
  import HomeVideoTypeTag from '@/components/Home/videoTypeTag.vue'
  import MuActor from '@/components/Home/MuActor.vue'
  import HomeCardHeaderTitle from '@/components/Home/headerTitle.vue'
  import JavShortSix from '@/components/JavShortSix.vue'
  import JavShortFour from '@/components/JavShortFour.vue'
  import JavFourCard from '@/components/JavFourCard.vue'
  import JavBigList from '@/components/JavBigList.vue'
  import JavSortVideoBigRow from '@/components/JavSortVideoBigRow.vue'
  import MuBtnList from '@/components/Home/MuBtnList.vue'
  import MuViCard from '@/components/MuViCard.vue'
  import MuMviCard from '@/components/MuMviCard.vue'
  import MuM2viCard from '@/components/MuM2viCard.vue'
  import MuzCard from '@/components/MuzCard.vue'
  import JavTab from '@/components/JavTab.vue'
  import Index from '@/components/Home/index.vue'
  import Actor from '@/components/Home/actor.vue'
  import SwiperShow from '@/components/Swiper/index.vue'
  import DecryptImg from '@/components/DecryptImg/index.vue'
  import Default from '@/components/Home/default.vue'

  let currentComp = shallowRef(null)  
  const state = reactive({
    BossList: [], // 推荐商家列表
    baseData,
    siteURL: self.location.href,
    showDown: false,
    showDownAppIco:false,
    isAndroid: false,
    isIOS: false,
    isDesktop:false,
    isFrist: true, //控制第一次
    isMobile: false,
    videoAnimateIndex: 1,
    comicsAnimateIndex: 1,
    textColor: ['#de849842', '#75b49969', '#67614d70', '#cfbcdd42', '#000000', '#cfbcdd42'],
    type: 0, // 切换的id
    showAnnouncemnetPop: false,
    showActivityImg: false,
    pageNum: 1,
    pageSize: 100,
    topicList: [],
    cgList: [],
    omList: [], //欧美
    gcList: [], //国产
    mfList: [],//免费
    nyList: [], //女优
    wlList: [], //网络大事件
    wmList: [], //无码
    dmList: [], //动漫
    tagList: [],
    thList: [], //特惠
    nvID: '13321',
    comicID: 11501, //漫画ID
    comicsList: [], //禁漫
    cosplayList: [], //cosplay
    rmList: [], // 日漫
    comicsVideoList: [], //动画数据
    PMVID: 21302, //韩国PMV
    WOID: 21301, //玩偶姐姐
    wanOuList: {},
    COSID: 21141, //cosID
    zhutiID: 25181,
    ZTList: [],
    mdnvID: 22821, //麻豆新星秀
    muViCardListID: [14521, 13343, 25341], //第一个是国产，第二个是欧美，第三个是免费
    jingxuanIDs: [
      10367,// 全裸家政妇介绍所 💫
      10384,// 极乐生活 💫
      10386,// 外派私人教学💫
      21005,// 欧美快车
      26605,// 性感COS在线被干 🈲
      27364,// 性感尤物辛尤里⚡
      19858,// 大象传媒💫
      22881,// 网红美女
      22882,// 女神Missa⚡
      24064,// elise兔兔谭晓彤⚡
      21302,// 韩国PMV
      22821,// 深夜精腥秀 💫
      13521,// 精神控制 （动漫）
      27367,// 🏆 日本𝐀𝐕 𝘝𝘐𝘗会员 独享专辑 🏆
      19851,// 被中出的高颜值美少女 💯
      26618, // 首次亮相 新人特辑
      26802, // 深入茎区口爆 🈲
      26204, // 网爆门💥
      26203,  // 吃瓜头条💥
      24417,  //极致反差婊🌹
      26212,  //🔥水果派解说 🔥
      26213,  //🔥水果派原片 🔥
      12962,  //🔥聊天曝光🔥
      12982  //💋套路勾搭🍒
    ],
    exclusivePushesIndex: [],
    jingxuanList: [],
    category: [
      { id: 25033, name: '推荐', showType: 5 },
      { id: 10522, name: '日本', showType: 1 },
      { id: 14521, name: '国产', showType: 1 },
      { id: 13322, name: '无码', showType: 1 },
      { id: 24372, name: '网爆', showType: 1 },
      { id: 25341, name: '动漫', showType: 1 },
      { id: 26142, name: '特惠专区', showType: 1 },
      { id: 13321, name: '女优' },
      { id: 13343, name: '欧美' }
    ],
    pushActivation: false,
    domainList:[]
  })
    
  //新首页接口
  const getHome3 =async () =>{
    try {
      const res = await index_home_3({
        ids: [
          27241,//获取免费片单(主题)27241
          25033,//今日主题(主题)25033
          14521,//国产传媒 欧美精选 动漫二次元(主题)14521
          10522,//特惠(主题)10522
          24372,//网络大事件(主题)24372
          25181,//最新主题数据乘风破浪等(主题)25181
          13322,//步兵无码(主题)13322
        ],          
        pageNum: 1,
        pageSize: 20,
        sort:0
      })
      if (res.code === 200) {
        state.mfList=res.data.mapTopicList["27241"];
        state.topicList=res.data.mapTopicList["25033"];
        state.gcList=res.data.mapTopicList["14521"];
        state.thList=res.data.mapTopicList["10522"];
        state.wlList=res.data.mapTopicList["24372"];
        state.ZTList=res.data.mapTopicList["25181"];
        state.wmList=res.data.mapTopicList["13322"];
      } else {
        showToast(res.tip)
      }
    } catch (error) {
      showToast('请求错误，请稍后再试!')
    }
  }   
  //获取线路检测
  const get_cfgAccessDomain =async () => {
    try {
      const res = await cfgAccessDomain({})
      if (res.code === 200) {
        state.domainList=res.data;
      } else {
        showToast(res.tip)
      }
    } catch (error) {
      showToast('请求错误，请稍后再试!')
    }
  }
  // 数据
  const handleLoadAllData =async () => {
    //热门标签(标签)
    if(store.getters['getIsAnIosPhone']=="h5_pc") state.getTagList() 
    //获取免费片单(主题)27241
    await getMfList() 
    //独家推送（详情列表）
    handleExclusivePushes()      
    //今日主题(主题)25033
    getCartoonPage()
    //国产传媒 欧美精选 动漫二次元(主题)14521
    getMuViCardList()
    //特惠(主题)10522
    await getTHPage()
    //网络大事件(主题)24372
    await getWLPage()
    //最新主题数据乘风破浪等(主题)25181
    await getZTPage()
    //默认漫画板块
    getComicsList(14702, 'comics', 1, true)
    await getComicsList()
    //步兵无码(主题)13322
    await getWMPage()
  }   
  //热门标签
  const getTagList =async () => {
    try {
      const res = await hot_tag_list({
        location: 1
      })
      if (res.code === 200) {
        let tagList = res.data.tagList.filter(i => i.Id !== '')
        let arr = shuffle(tagList)
        state.tagList = arr.slice(0, 10)
      } else {
        return showToast(res.tip)
      }
    } catch (error) {
      console.log(error)
      return showToast('111请求失败，请稍后再试！')
    }
  }    
  // 获取免费片单
  const getMfList =async () => {
    state.mfList = []
    try {
      const res = await index_home({
        id: 27241,
        pageNum: state.pageNum,
        pageSize: state.pageSize
      })
      if (res.code === 200) {
        let list = shuffle(res.data.topicList)
        let arr = list.filter(item => {
          return item && item.id && item.mediaList && item.mediaList.length && item.mediaList.length > 0
        })
        state.mfList = arr.slice(0, 6)
      } else {
        showToast(res.tip)
      }
    } catch (error) {
      showToast('请求错误，请稍后再试!')
    }
  }    
  // 处理独家推送栏目的数据
  const handleExclusivePushes =async () => {
    getRandomArr(3, 0, state.jingxuanIDs.length - 1)
    for (let index = 0; index < 3; index++) {
      await getTopicDetails1(undefined, state.exclusivePushesIndex[index])
    }
  }  
  // 获取今日片单
  const getCartoonPage =async (type) => {
    let id=25033;
    if(type=="mfList"){
      id=27241;
      state.mfList=[];
    }else{
      state.topicList = []
    }
    
    try {
      const res = await index_home({
        id: id,
        pageNum: state.pageNum,
        pageSize: state.pageSize
      })
      if (res.code === 200) {
        let list = shuffle(res.data.topicList)
        let arr = list.filter(item => {
          return item && item.id && item.mediaList && item.mediaList.length && item.mediaList.length > 0
        })
        if(type=="mfList"){
          state.mfList=arr.slice(0, 6)
        }else{
          state.topicList = arr.slice(0, 6)
        }
      } else {
        showToast(res.tip)
      }
    } catch (error) {
      showToast('请求错误，请稍后再试!')
    }
  }   

  //是否开启下载提示，ios安卓状态保存
  const ifOpenDl = () => {
    if (state.isFrist) {
      if(router.currentRoute.value.query.billingType||store.getters['getIsAnIosPhone']=="h5_android"||store.getters['getIsAnIosPhone']=="h5_ios"||store.getters['getIsAnIosPhone']=="android") {
        setTimeout(() => {
          state.showDown = true
          state.isFrist = false
          state.showDownAppIco= true
        }, 2000);
      }else if(store.getters['getIsAnIosPhone']=="h5_pc"){
        state.showDownAppIco= true;
      }
    }
  }
  //点击下载
  const clickDown = () => {
    publicDownload();
  }
  //视频跳转
  const handleJump = ({ i, id }) => {
    if (i) {
      if (i.videoType === 2) {
        router.push(`/short_video/play?id=${id}&detailId=${i.id}&typeTxt=推荐`)
      } else {
        router.push(`/play/${i.id}`)
      }
    }
  }
  //获取约炮商家列表
  const getDatingBoss =async () =>  {
    try {
      const res = await dating_bosses({
        pageNum: 1,
        pageSize: 10,
        reqType: 0,
        sort:1
      })
      if (res.code === 200) {
        state.BossList = res.data.bossList
      } else {
        return showToast(res.tip)
      }
    } catch (error) {
      return showToast('请求错误，请稍后再试!!')
    }
  }
  // 商家详情跳转
  const toBossDetail = (item) => {
    router.push(`/bosses/detail/${item.id}`)
  }
  const toggleComicsList = (index) => {
    state.handlClickTabLoadComisAjax(index, true)
  }
  // 点击独家推送按钮
  const handleClickDaysReplayBtn = (t) => {
    getTopicDetails1(t, state.exclusivePushesIndex[t - 1])
  }
  // 处理视频播放类型
  const handelVideoPalyerPath = (type, v) => {
    if (type === 'comics') {
      router.push(`/comics/decial/${v.id}`)
      return
    }
    if (type === 1 || type === 2) {
      router.push(`/play/${v.id}`)
    }
  }
  //导航跳转
  const toPage = (item) => {
    router.push(item.path)
  }
  //点击漫画tabs
  const handlClickTabLoadComisAjax  = (index, status) => {
    state.comicsAnimateIndex = index
    if (index === 1) {
      getComicsList(14702, 'comics', 1, status)
    } else if (index === 2) {
      getComicsList(11841, 'cosplay', 1, status)
    } else if (index === 3) {
      getComicsList(11142, 'riman', 1, status)
    } else if (index === 4) {
      getComicsList(16841, 'cg', 1, status)
    }
  }
  // 获取漫画数据  comicID: 11501,cosID:21141
  const getComicsList =async (ID = 11501, type = 'comics', sort = 1, status) => {
    if (type === 'comics' && state.comicsList.length > 0) {
      if (status) {
        state.comicsList = []
      } else {
        return
      }
    } else if (type === 'cosplay' && state.cosplayList.length > 0) {
      if (status) {
        state.cosplayList = []
      } else {
        return
      }
    } else if (type === 'cg' && state.cgList.length > 0) {
      if (status) {
        state.cgList = []
      } else {
        return
      }
    } else if (type === 'riman' && state.rmList.length > 0) {
      if (status) {
        state.rmList = []
      } else {
        return
      }
    }
    const res = await comicsHome({
      id: ID,
      pageNum: Random(1, 6),
      pageSize: 36,
      sort
    })
    if (res.code === 200 && res.data) {
      if (res.data.comicsList && res.data.comicsList.length > 0) {
        let arr = []
        for (let index = 1; index <= res.data.comicsList.length; index++) {
          if (index % 6 === 0) {
            arr.push({
              name: index,
              comicsList: [
                res.data.comicsList[index - 6],
                res.data.comicsList[index - 5],
                res.data.comicsList[index - 4],
                res.data.comicsList[index - 3],
                res.data.comicsList[index - 2],
                res.data.comicsList[index - 1]
              ]
            })
          }
        }
        if (type === 'comics') {
          state.comicsList = arr
        } else if (type === 'cosplay') {
          state.cosplayList = arr
        } else if (type === 'cg') {
          state.cgList = arr
        } else if (type === 'riman') {
          state.rmList = arr
        }
      }
    } else {
      return showToast(res.tip)
    }
  }
  const Random = (min, max) => {
    return Math.round(Math.random() * (max - min)) + min
  }
  // len:生成整数的数量   start:最小值   end:最大值
  const getRandomArr = (len, start, end) => {
    state.exclusivePushesIndex = []
    while (state.exclusivePushesIndex.length < len) {
      let num = Random(start, end)
      if (state.exclusivePushesIndex.indexOf(num) == -1) {
        state.exclusivePushesIndex.push(num)
      }
    }
  }
  // 获取动漫数据
  const getComicsVideoList =async (type) => {
    if (type) {
      state.comicsVideoList = []
    }
    const res = await index_home({
      id: 25341,
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200 && res.data) {
      if (res.data.topicList) {
        let list = shuffle(res.data.topicList)
        let arr = list.filter(item => {
          return item && item.id && item.mediaList && item.mediaList.length && item.mediaList.length > 0
        })
        state.comicsVideoList = arr.slice(0, 4)
      }
    } else {
      return showToast(res.tip)
    }
  }
  const replayExclusivePushesList =async () => {
    if (state.pushActivation === false) {
      state.pushActivation = true
      getRandomArr(3, 0, state.jingxuanIDs.length - 1)
      for (let index = 0; index < 3; index++) {
        await getTopicDetails1(index + 1, state.exclusivePushesIndex[index])
      }
      state.pushActivation = false
    }
  }
  // 获取专题详情
  const getTopicDetails1 =async (key, index = 0, clearStatus) => {
    try {
      const res = await media_details({
        id: state.jingxuanIDs[index],
        sort: 0,
        pageNum: 1,
        pageSize: 30
      })
      if (res.code === 200) {
        let topicInfo = res.data.topicInfo
        let list = shuffle(res.data.mediaList)
        topicInfo.mediaList = list.slice(0, 6)
        if (key) {
          state.$set(state.jingxuanList, key - 1, topicInfo)
        } else {
          state.jingxuanList.push(topicInfo)
        }
      } else {
        showToast(res.tip)
      }
    } catch (error) {
      console.log(error)
      showToast('请求失败，请稍后再试！')
    }
  }
  // 获取专题详情
  const getWanOuDetails =async () => {
    try {
      const res = await media_details({
        id: 21301,
        sort: 0,
        pageNum: 1,
        pageSize: 10
      })
      if (res.code === 200) {
        let topicInfo = res.data.topicInfo
        let list = shuffle(res.data.mediaList)
        topicInfo.mediaList = list.slice(0, 6)
        state.wanOuList = topicInfo
      } else {
        showToast(res.tip)
      }
    } catch (error) {
      console.log(error)
      showToast('请求失败，请稍后再试！')
    }
  }
  // 获取步兵无码数据
  const getWMPage =async (type) => {
    try {
      const res = await index_home({
        id: 13322,
        pageNum: state.pageNum,
        pageSize: state.pageSize
      })
      if (res.code === 200) {
        if (res.data.topicList) {
          let list = shuffle(res.data.topicList)
          let arr = list.filter(item => {
            return item && item.id && item.mediaList && item.mediaList.length && item.mediaList.length > 0
          })
          state.wmList = arr.slice(0, 4)
        }
      } else {
        showToast(res.tip)
      }
    } catch (error) {
      showToast('请求错误，请稍后再试!')
    }
  }
  // 获取最新主题数据
  const getZTPage =async (type) => {
    try {
      const res = await index_home({
        id: 25181,
        pageNum: state.pageNum,
        pageSize: state.pageSize
      })
      if (res.code === 200) {
        if (res.data.topicList) {
          let list = shuffle(res.data.topicList)
          let arr = list.filter(item => {
            return item && item.id && item.mediaList && item.mediaList.length && item.mediaList.length > 0
          })
          if (arr.length > 4) {
            state.ZTList = arr.slice(0, 4)
          } else {
            state.ZTList = arr
          }
        }
      } else {
        showToast(res.tip)
      }
    } catch (error) {
      showToast('请求错误，请稍后再试!')
    }
  }
  // 获取木偶推荐数据（原来特惠）
  const getTHPage =async (type) => {
    try {
      if (type) {
        state.thList = []
      }
      const res = await index_home({
        id: 10522,
        pageNum: state.pageNum,
        pageSize: state.pageSize
      })
      if (res.code === 200) {
        let list = shuffle(res.data.topicList)
        state.thList = list.slice(0, 6)
      } else {
        showToast(res.tip)
      }
    } catch (error) {
      showToast('请求错误，请稍后再试!')
    }
  }
  // 获取首页数据
  const getDMPage =async (type) => {
    try {
      const res = await index_home({
        id: 25341,
        pageNum: state.pageNum,
        pageSize: state.pageSize
      })
      if (res.code === 200) {
        let list = shuffle(res.data.topicList)
        state.dmList = list.slice(0, 3)
      } else {
        showToast(res.tip)
      }
    } catch (error) {
      showToast('请求错误，请稍后再试!')
    }
  }
  // 获取网络大事件
  const getWLPage =async (type) => {
    try {
      const res = await index_home({
        id: 24372,
        pageNum: 1,
        pageSize: 20
      })
      if (res.code === 200) {
        let list = shuffle(res.data.topicList)
        state.wlList = list.slice(0, 5)
      } else {
        showToast(res.tip)
      }
    } catch (error) {
      showToast('请求错误，请稍后再试!')
    }
  }
  // 顺序打乱
  const shuffle = (arr) => {
    var array = [...[], ...arr]
    var m = array.length,
      t,
      i
    while (m) {
      i = Math.floor(Math.random() * m--)
      t = array[m]
      array[m] = array[i]
      array[i] = t
    }
    return array
  }
  // 处理点击tab是的逻辑
  const handleClickVideoTab = (index) => {
    state.videoAnimateIndex = index
    switch (index - 1) {
      case 0:
        if (state.gcList && state.gcList.length > 0) {
          return
        }
        break
      case 1:
        if (state.omList && state.omList.length > 0) {
          return
        }
        break
      case 2:
        if (state.comicsVideoList && state.comicsVideoList.length > 0) {
          return
        }
        break
    }
    getMuViCardList(index - 1)
  }
  const getMuViCardList =async (index = 0) => {
    try {
      const res = await index_home({
        id: state.muViCardListID[index],
        pageNum: state.pageNum,
        pageSize: state.pageSize
      })
      if (res.code === 200) {
        let list = shuffle(res.data.topicList)
        let arr = list.filter(item => {
          return item && item.id && item.mediaList && item.mediaList.length && item.mediaList.length > 0
        })
        let slist = arr.slice(0, 6)
        switch (index) {
          case 0:
            state.gcList = slist
            break
          case 1:
            state.omList = slist
            break
          case 2:
            state.comicsVideoList = slist
            break
        }
      } else {
        showToast(res.tip)
      }
    } catch (error) {
      showToast('请求错误，请稍后再试!')
    }
  }
  const change = (type) => {
    // 分类id存入vuex
    store.dispatch('setAvIndex', type)
    state.type = type
  }
  //  1:主题  2:竖版 模版 3:横板 模版  4:女优 5:推荐
  //  Default（2,3切换列表：最新，最热，人气） Index（5+1主题+） Actor(4女优)
  // const compComponent = (data) => {
  //   switch (data) {
  //     case 3:
  //       return Default
  //     case 2:
  //       return Default
  //     case 4:
  //       return Actor
  //     default:
  //       return Index
  //   }
  // }
  const compExclusiveType = (showType) => {
    switch (showType) {
      case 1:
        return JavFourCard
      case 2:
        return JavBigList
      case 3:
        return JavShortSix
      case 4:
        return JavShortFour
      default:
        return JavShortSix
    }
  }
  // 关闭活动弹窗
  const closeAccountImg = () => {
    store.commit('SET_ANNOUNCEMENT_POP', false)
    state.showAnnouncemnetPop = announcementPop
  }
  const closeActivityImg = () => {
    store.commit('SET_ACTIVITY_POP', false)
    state.showActivityImg = activityPop
  }
  const submit = () => {
    if (announcement && announcement.jumpUrl) {
      const code = handleURlParams(announcement.jumpUrl)
      handleParamsRouteJump(code)
    }
    store.commit('SET_ANNOUNCEMENT_POP', false)
    state.showAnnouncemnetPop = announcementPop
  }
  const imgJub = () => {
    if (activityImg[0].href) {
      const code = handleURlParams(activityImg[0].href)
      handleParamsRouteJump(code)
    }
    store.commit('SET_ACTIVITY_POP', false)
    state.showActivityImg = activityPop
  }

  // 获取首页推荐页轮播广告
  const avAD = computed(() => {
    return store.getters['avAD']
  })  
  // 获取首页顶部视频分类导航列表
  const homecategoryV2 = computed(() => {
    return store.getters['homecategoryV2']
  })
  // 获取公告弹窗开关
  const announcementPop = computed(() => {
    return store.getters['announcementPop']
  })
  // 获取公告内容开关
  const announcement = computed(() => {
    return store.getters['announcement']
  })
  // 获取首页活动弹窗内容
  const activityImg = computed(() => {
    return store.getters['popAD']
  })
  // 获取首页活动内容弹窗开关
  const activityPop = computed(() => {
    return store.getters['activityPop']
  })
  // 初次加载的默认id
  const indexActive = computed(() => {
    if (store.getters['avIndex']) {
      return store.getters['avIndex']
    } else if (homecategoryV2 && homecategoryV2.length > 0) {
      const firstArr = homecategoryV2.filter(item => {
        return item.showType === 5
      })
      return firstArr[0].id
    } else {
      return 0
    }
  })
  


  onMounted(async () => {
    state.isMobile = $device.mobile()
    state.isAndroid = $device.android()
    state.isIOS = $device.ios()
    state.isDesktop=$device.desktop()
    //获取线路
    get_cfgAccessDomain()
    if(announcement.value) state.showAnnouncemnetPop = true;
    if(activityImg.length) {
      state.showActivityImg = activityPop;
    }else{
      ifOpenDl();
    }
    //热门标签(标签)
    if(store.getters['getIsAnIosPhone']=="h5_pc") getTagList()  
    getDatingBoss()   
    //获取主题
    await getHome3()         
    //独家推送（详情列表）
    handleExclusivePushes()       
    //默认漫画板块
    getComicsList(14702, 'comics', 1, true)
    getComicsList()         
  })

</script>
<style lang="scss" scoped>
.index-container {
  padding: 0.8rem 0 1rem 0;
  min-height: $minHeight;
  max-width: $pcMaxWidth;
  margin: 0 auto;
  :deep()  {
    .imgNoPadding {
      object-fit: cover;
    }
    .item-bg {
      height: 100%;
    }
  }
  .container-tab {
    :deep()  {
      .van-sticky {
        margin-bottom: 0.2rem;
        background: $mainBgDeepColor;
        position: fixed;
        top: 1.3rem;
        @include transformCenter();
      }
    }
  }
}
.home-card-warp {
  background: #4641413d;
  backdrop-filter: blur(5px);
  margin: 0 0.1rem;
  border-radius: 0.08rem;
  margin-bottom: 0.2rem;
}
.home-card-title {
  font-size: 0.28rem;
  padding: 0.12rem 0.1rem;
  margin: 0 0;
}
.home-card-sub-title {
  font-size: 0.26rem;
  margin: 0.12rem 0.1rem;

  color: #aba9a9;
}
.home-card-list-scroll {
  overflow-x: scroll;
  overflow-y: hidden;
  vertical-align: top;
}
.home-card-body-base {
  font-size: 0.16rem;
  line-height: 1.2;
  position: relative;
  color: #fff;
  height: auto;
}
.home-six-card-text {
  font-size: 0.16rem;
  position: relative;
  color: #fff;
  height: auto;
}

.home-card-body-width {
  position: relative;
  width: 1.4rem;
  margin: 0.02rem 0.12rem;
  display: inline-block;
  vertical-align: top;
  top: 0.08rem;
}
// 约炮
.merchantcard-list {
  @include flexbox($jc: flex-start, $ai: flex-start, $fd: row, $fw: nowrap);
  overflow-x: scroll;
  &-item {
    width: 25%;
    min-width: 5.6rem;
    margin: 0.2rem 0.2rem 0.3rem 0;
    border-radius: 0.05rem;
    box-shadow: $shadow;
  }
  :deep()  {
    .merchant-card {
      width: 100%;
    }
  }  
}
.merchantcard-list::-webkit-scrollbar {
  /*滚动条整体样式*/
  width: 10px; /*高宽分别对应横竖滚动条的尺寸*/
  height: 10px;
}
.merchantcard-list::-webkit-scrollbar-thumb {
  /*滚动条里面小方块*/
  border-radius: 10px;
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  background: #83807e;
}
.merchantcard-list::-webkit-scrollbar-track {
  /*滚动条里面轨道*/
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  border-radius: 10px;
}
// 名优馆推荐
.home-card-body-width-ac {
  position: relative;
  width: 2.5rem;
  margin: 0.02rem 0.12rem;
  display: inline-block;
  vertical-align: top;
  top: 0.14rem;
}

.home-card-body-bg {
  position: absolute;
  width: 89%;
  top: -0.08rem;
  padding-top: 90%;
  border-radius: 0.16rem;
  overflow: hidden;
  left: 0;
  right: 0;
  margin: auto;
}
.home-card-body-content {
  position: absolute;
  z-index: 1;
  top: 0;
  width: 100%;
  display: flex;
  flex-flow: row wrap;
  border-radius: 0.16rem;
  overflow: hidden;
}

.home-pos-w100 {
  position: absolute;
  top: 0;
  width: 100%;
  height: 100%;
}

.account-img-pop {
  background-color: transparent;
  min-height: 7.78rem;
  overflow-y: visible;
}
.account-img {
  width: 80vw;
  height: 100%;
  background: linear-gradient(to top, #0a0707, #303030);
  background-size: 100% 100%;
  background-repeat: no-repeat;
  padding: 0.3rem 0.2rem 0.2rem 0.2rem;
  text-align: center;
  border-radius: 15px;
  :deep()  {
    .van-icon {
      cursor: pointer;
      @include transformCenter(-50%, 0);
      position: absolute;
      right: -0.1rem;
      top: 0.2rem;
    }
  }
  .title-img {
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.36rem;
    margin-bottom: 0.4rem;
    span {
      color: rgb(233, 202, 63);
      margin: 0 0.1rem;
    }
    img {
      width: 1.4rem;
    }
  }
  p {
    margin: 0 0 0.2rem 0;
    font-size: 0.4rem;
    color: #eb3876;
  }

  .desc {
    max-height: 2rem;
    overflow: auto;
    text-align: left;
    font-size: 0.26rem;
    white-space: pre-line;
    color: #f5db73;
    margin: 0.3rem 0 0.45rem 0;
  }
  .btn {
    background: $btnBg;
    color: $mainTxtColor1;
    font-size: 0.3rem;
    border-radius: 0.36rem;
    width: 3.12rem;
    height: 0.7rem;
    line-height: 0.7rem;
    margin: 0 auto;
    color: #f5db73;
  }
  .btn:hover {
    cursor: pointer;
  }
}
.activity-img-pop {
  background-color: transparent;
  min-height: 7.78rem;
  overflow-y: visible;
  .activity-img {
    width: 6rem;
    height: 100%;
    :deep()  {
      .van-icon {
        cursor: pointer;
        @include transformCenter(-50%, 0);
        position: absolute;
        right: 0rem;
        top: 0.2rem;
      }
    }
  }
}

.home-card-list-scroll::-webkit-scrollbar {
  /*滚动条整体样式*/
  width: 10px; /*高宽分别对应横竖滚动条的尺寸*/
  height: 10px;
}
.home-card-list-scroll::-webkit-scrollbar-thumb {
  /*滚动条里面小方块*/
  border-radius: 10px;
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  background: #83807e;
}
.home-card-list-scroll::-webkit-scrollbar-track {
  /*滚动条里面轨道*/
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  border-radius: 10px;
  background: #241e1e;
}
.animate-tabs {
  width: auto;
  margin-bottom: 1px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 0.24rem;
  height: 0.68rem;
  line-height: 0.68rem;
  position: relative;
  top: 0.04rem;
  z-index: 9;
  div {
    overflow: hidden;
    cursor: pointer;
    border: 1px solid #f4ce4e4d;
    text-align: center;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    width: 100px;
  }
  div:first-child {
    border-radius: 0.22rem 0 0 0;
  }
  div:last-child {
    border-radius: 0 0.22rem 0 0;
  }
  .animate-tab-active {
    border-bottom-color: #151313;
    color: #f4ce4e;
  }
}

.icon {
  cursor: pointer;
}
.iconTrans {
  transform: rotate(720deg);
  -webkit-transition: transform 0.25s linear;
  -moz-transition: transform 0.25s linear;
  -o-transition: transform 0.25s linear;
  transition: transform 0.25s linear;
}
.iconTrans2 {
  transform: rotate(-720deg);
  -webkit-transition: transform 0.25s linear;
  -moz-transition: transform 0.25s linear;
  -o-transition: transform 0.25s linear;
  transition: transform 0.25s linear;
}
.app-down{
  .app-dl-dialog{
    position: relative;
    text-align: center;
    padding: 0.2rem 0.4rem 0.4rem 0.4rem;
    font-size: 0.26rem;
    background: url("https://jinmantiankong.com/attachment/section-1-bg.jpeg") $mainTxtColor2;
    background-size:cover ;
    &::before{
      content: '';
      position: absolute;
      left: 0;
      right: 0;
      bottom: 0;
      top: 0;
      background-color: rgba(0,0,0, .7);
      backdrop-filter: blur(1px);
      z-index: 1;
    }
    li{
      position: relative;
      z-index: 2;      
      // white-space: nowrap;
    }
    .title{
      padding: 0.2rem 0;
      font-size: 0.3rem;
    }
    .domain{
      text-align: center;
    }
  }
  :deep()  .van-popup{
    .van-button__content{
      background: #f4ce4e;
      .van-button__text{
        color: #ee0a24;
      }
    }           
  }
 
}

@media screen and (min-width: 750px) {
  .account-img,
  .activity-img {
    width: 8rem !important;
  }
  .animate-tabs {
    font-size: 0.3rem;
    padding: 0.2rem 0.1rem;
    div {
      width: 220px;
    }
  }
  :deep()  {
    .long-four {
      &-item:nth-of-type(6) {
        display: none !important;
      }
    }
  }
}
</style>

