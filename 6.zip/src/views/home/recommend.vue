<!-- home -->
<template>
  <div class="index-container">
    <!-- <SwiperShow :imgList="state.avAD" v-if="state.avAD && state.avAD.length && state.type === state.homecategoryV2[0].id" /> -->
    <!--切换面板   :addClass="'home-av-tab'"-->
    <JavTab
      class="container-tab"
      @change="change"
      :sticky="true"
      :titles="state.homecategoryV2"
      :active="state.type ? state.type : state.homecategoryV2 && state.homecategoryV2[0] ? state.homecategoryV2[0].id : 0"
      :animated="false"
      :needBack="true"
    >
      <template v-slot:default="scope">
        <component
          :navItem="scope"
          :showType="scope.data"
          :avAD="state.avAD"
          :type="state.type ? state.type : state.homecategoryV2 && state.homecategoryV2[0] ? state.homecategoryV2[0].id : 0"
          :is="compComponent(scope.data)"
        ></component>
      </template>
    </JavTab>
  </div>
</template>

<script setup>
const JavTab = defineAsyncComponent(() => import('@/components/JavTab.vue'))
const Index = defineAsyncComponent(() => import('@/components/Home/index.vue'))
const Actor = defineAsyncComponent(() => import('@/components/Home/actor.vue'))
const SwiperShow = defineAsyncComponent(() => import('@/components/Swiper/index.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const Default = defineAsyncComponent(() => import('@/components/Home/default.vue'))
import { useStore } from 'vuex'
const store = useStore()
const state = reactive({
  type: 0,
  // 获取首页推荐页轮播广告
  avAD:computed(() => store.getters['avAD']),
  // 获取首页顶部视频分类导航列表
  homecategoryV2:computed(() => store.getters['homecategoryV2']),
  // 初次加载的默认id
  indexActive:computed(() => {
    if (store.getters['avIndex']) {
      return store.getters['avIndex']
    } else if (state.homecategoryV2 && state.homecategoryV2.length > 0) {
      const firstArr = state.homecategoryV2.filter(item => {
        return item.showType === 5
      })
      return firstArr[0]&&firstArr[0].id
    } else {
      return 0
    }
  })  
})

const change =(type) =>{
  // 分类id存入vuex
  store.dispatch('setAvIndex', type)
  state.type = type
}
//  1:主题  2:竖版 模版 3:横板 模版  4:女优 5:推荐
//  Default（2,3切换列表：最新，最热，人气） Index（5+1主题+） Actor(4女优)
const compComponent =(data) =>{
  switch (data) {
    case 3:
      return 'Default'
    case 2:
      return 'Default'
    case 4:
      return 'Actor'
    default:
      return 'Index'
  }
}  
onMounted(() => {
  state.type = state.indexActive
}) 
</script>
<style lang="scss" scoped>
.index-container {
  padding: 1.8rem 0 1rem 0;
  min-height: $minHeight;
  max-width: $pcMaxWidth;
  margin: 0 auto;
  .container-tab {
    :deep()  {
      .van-sticky {
        margin-bottom: 0.2rem;
        background: $mainBgDeepColor;
        position: fixed;
        top: 1.3rem;
        @include transformCenter();
      }
    }
  }
}
.account-img-pop {
  background-color: transparent;
  min-height: 7.78rem;
  overflow-y: visible;
}
.account-img {
  width: 6rem;
  height: 100%;
  background-image: url('../../assets/imgs/index-activity-bg.png');
  background-size: 100% 100%;
  background-repeat: no-repeat;
  padding: 0.3rem 0.2rem 0.2rem 0.2rem;
  text-align: center;
  :deep()  {
    .van-icon {
      @include transformCenter(-50%, 0);
      position: absolute;
      right: 0rem;
      top: 0.8rem;
    }
  }
  .title-img {
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.26rem;
    margin-bottom: 0.4rem;
    color: $mainBgDeepColor;
    span {
      margin: 0 0.2rem;
    }
    img {
      width: 1.4rem;
    }
  }
  p {
    margin: 0 0 0.2rem 0;
    font-size: 0.63rem;
    color: #eb3876;
  }
  .desc {
    text-align: left;
    font-size: 0.26rem;
    white-space: pre-line;
    color: #666666;
    margin: 0.3rem 0 0.45rem 0;
  }
  .btn {
    background: linear-gradient(to right, #52b5f7, #6ce6f3);
    color: $mainTxtColor1;
    font-size: 0.3rem;
    border-radius: 0.36rem;
    width: 3.12rem;
    height: 0.7rem;
    line-height: 0.7rem;
    margin: 0 auto;
  }
}
.activity-img-pop {
  background-color: transparent;
  min-height: 7.78rem;
  overflow-y: visible;
  .activity-img {
    width: 6rem;
    height: 100%;
    :deep()  {
      .van-icon {
        @include transformCenter(-50%, 0);
        position: absolute;
        right: 0rem;
        top: 0.8rem;
      }
    }
  }
}
@media screen and (min-width: 750px) {
  :deep()  {
    .long-four {
      &-item:nth-of-type(6) {
        display: none !important;
      }
    }
    .big-list {
      &-item:nth-of-type(5) {
        display: none !important;
      }
      &-item:nth-of-type(6) {
        display: none !important;
      }
    }
  }
}
</style>
