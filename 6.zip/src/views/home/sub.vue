<!-- home -->
<template>
  <div class="sub-container">
    <LayoutsHeader :title="$route.query.name" />
    <MuBtnList style="margin: 0.25rem 0"></MuBtnList>
    <!-- <SwiperShow :imgList="state.avAD" v-if="state.avAD.length > 0" /> -->
    <!--切换面板 -->
    <JavTab
      class="container-tab"
      :addClass="'home-sub-tab'"
      :sticky="true"
      :titles="state.category"
      :active="state.active"
      :animated="false"
      :needBack="true"
      @change="change"
    >
      <template v-slot:default="scope">
        <component
          showRemShortVideoType="sub"
          :navItem="scope"
          :showType="scope.data"
          :type="scope.item.id"
          :is="compComponent(scope.data)"
        ></component>
      </template>
    </JavTab>
  </div>
</template>

<script setup>
const MuBtnList = defineAsyncComponent(() => import('@/components/Home/MuBtnList.vue'))
const SwiperShow = defineAsyncComponent(() => import('@/components/Swiper/index.vue'))
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const JavTab = defineAsyncComponent(() => import('@/components/JavTab.vue'))
const Index = defineAsyncComponent(() => import('@/components/Home/index.vue'))
const Actor = defineAsyncComponent(() => import('@/components/Home/actor.vue'))
const Default = defineAsyncComponent(() => import('@/components/Home/default.vue'))
import { useStore } from 'vuex'
const store = useStore()
const route = useRoute()
const state = reactive({
  category: [],
  active: 0,
  avAD:computed(() => store.getters['avAD']),
})
onMounted(() => {
  if (route.query.name == 'AV') state.category = store.getters['avcategoryv2']
  if (route.query.name == '原创') state.category = store.getters['createcategoryV2']
  if (route.query.name == '国产') state.category = store.getters['mdcategoryV2']
  if (route.query.name == '动漫') state.category = store.getters['cartooncategoryV2']
  if (route.query.name == '小视频') state.category = store.getters['shortcategoryV2']
  if (route.query.type == 'om') {
    for (let index = 0; index < state.category.length; index++) {
      const element = state.category[index]
      if (element.name === '欧美') {
        state.active = element.id
      }
    }
  }
}) 

const change =(data) =>{
  state.active = data.item.id
}
//  1:主题  2:竖版 模版 3:横板 模版  4:女优 5:推荐
//  Default（2,3切换列表：最新，最热，人气） Index（5+1主题+） Actor(4女优)
const compComponent =(data) =>{
  switch (data) {
    case 3:
      return 'Default'
    case 2:
      return 'Default'
    case 4:
      return 'Actor'
    default:
      return 'Index'
  }
}
</script>
<style lang="scss" scoped>
.sub-container {
  margin-top: 0.5rem;
  padding: 1.3rem 0rem 1rem 0rem;
  min-height: $minHeight;
  background: $mainBgColor;
  max-width: $pcMaxWidth;
  margin: 0 auto;
  :deep()  {
    .home-btn-list {
      display: none;
    }
    .home-index {
      .short-four {
        padding-top: 0;
      }
    }
    .big-list {
      padding-top: 0.2rem;
    }
  }
}
@media screen and (min-width: 750px) {
  /**
  :deep()  {
    .long-four {
      &-item:nth-of-type(6) {
        display: none !important;
      }
    }
    .big-list {
      &-item:nth-of-type(5) {
        display: none !important;
      }
      &-item:nth-of-type(6) {
        display: none !important;
      }
    }
  }
  **/
}
</style>
