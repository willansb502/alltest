<template>
  <div class="search-type">
    <LayoutsHeader :title="'所有分类'" />

    <!-- 顶部分类 -->
    <ul class="top-list">
      <li class="top-list-type">
        <div class="label">分类</div>
        <ul class="type-list">
          <li :class="state.location === 1 ? 'active' : 'default'" @click="thClick(1)">日本AV</li>
          <li :class="state.location === 2 ? 'active' : 'default'" @click="thClick(2)">小视频专区</li>
          <li :class="state.location === 3 ? 'active' : 'default'" @click="thClick(3)">动漫专区</li>
        </ul>
      </li>
      <li class="top-list-type">
        <div class="label">类别</div>
        <ul class="type-list">
          <li :class="state.sort === 1 ? 'active' : 'default'" @click="oneClick(1)">最多播放</li>
          <li :class="state.sort === 2 ? 'active' : 'default'" @click="oneClick(2)">最多收藏</li>
          <li :class="state.sort === 3 ? 'active' : 'default'" @click="oneClick(3)">最多上架</li>
        </ul>
      </li>
      <li class="top-list-type" v-if="state.location === 1">
        <div class="label">类型</div>
        <ul class="type-list">
          <li :class="state.coded === 1 ? 'active' : 'default'" @click="twoClick(1)">骑兵有码</li>
          <li :class="state.coded === 2 ? 'active' : 'default'" @click="twoClick(2)">步兵无码</li>
        </ul>
      </li>
      <li class="top-list-type label-list">
        <div class="label">标签</div>
        <ul class="type-list">
          <template v-for="(item, index) in state.tagList">
            <li
              @click="threeClick(item.name)"
              :class="state.tag === item.name ? 'active' : 'default'"
              v-if="item.name"
              :key="'tag' + state.location + index"
            >
              {{ item.name }}
            </li>
          </template>
        </ul>
      </li>
    </ul>

    <!-- 卡片内容 -->
    <div class="main">
      <div class="cover-type">
        <div @click="changeCoverType()" :class="state.coverType === 1 ? 'coverType1' : 'coverType2'"></div>
      </div>
      <PullUp
        @refreshData="refreshData"
        @moreData="moreData"
        :finished="state.finished"
        :loading="state.loading"
        :refreshing="state.refreshing"
      >
        <JavShortFour
          :tag="state.tag"
          :id="state.location"
          :coded="state.coded"
          :sort="state.sort"
          typeTxt="分类"
          :list="state.list"
          v-if="state.coverType==1"
        />

        <JavFourCard
          style="padding-top:0.4rem;"
          :tag="state.tag"
          :coded="state.coded"
          :sort="state.sort"
          :id="state.location"
          typeTxt="分类"
          :list="state.list"
          v-if="state.coverType==2"
        />

      </PullUp>
    </div>
  </div>
</template>

<script setup name="hotTagDecial">
import { showToast } from 'vant'
import { tag_detail, hot_tag_list } from '@/api/search'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const JavFourCard = defineAsyncComponent(() => import('@/components/JavFourCard.vue'))
const JavShortFour = defineAsyncComponent(() => import('@/components/JavShortFour.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const route = useRoute()
const router = useRouter()
const state = reactive({
  location: +route.params.location,
  sort: undefined,
  coded: undefined,      
  pageNum: 1,
  pageSize: 20,
  coverType: 1,
  tag: '',
  refreshing: false, // 下拉刷新开关
  loading: false, // 上拉加载
  finished: false, // 上拉加载开关
  tagList: [],
  list: [] // 数据列表
})

const thClick =(index) =>{
  router.replace(`/tag/detail/1`)
  state.location = index
  state.tag = undefined
  getTagHotList()
  refreshData()
}
const oneClick =(item) =>{
  if (state.sort === item) {
    state.sort = undefined
  } else {
    state.sort = item
  }
  refreshData()
}
const twoClick =(item) =>{
  if (state.coded === item) {
    state.coded = undefined
  } else {
    state.coded = item
  }
  refreshData()
}
const threeClick =(item) =>{
  if (state.tag === item) {
    state.tag = undefined
  } else {
    // 高亮控制
    state.tag = item
  }
  router.replace(`/tag/detail/1?name=${state.tag}`)
  refreshData()
}
const changeCoverType =() =>{
  state.coverType === 1 ? (state.coverType = 2) : (state.coverType = 1);
  refreshData();
}
// 获取tagList  1日本 2小视频  3 动漫 
const getTagHotList =async () =>{
  try {
    const res = await hot_tag_list({
      location: state.location
    })
    if (res.code === 200) {
      state.tagList = res.data.tagList
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    showToast('请求错误，请稍后再试！')
  }
}
 // 获取tagDetail请求横版
const getTagDetailList =async () =>{
  try {
    const res = await tag_detail({
      coverType: state.coverType,
      sort: state.sort,
      coded: state.location === 1 ? state.coded : undefined,
      location: state.location,
      pageNum: state.pageNum,
      pageSize: state.pageSize,
      tag: state.tag ? state.tag : undefined
    })
    if (res.code === 200) {
      state.refreshing = false
      state.loading = false
      state.list = [...state.list, ...res.data.mediaList]
      if (res.data.mediaList.length < state.pageSize || !res.data.mediaList) {
        state.finished = true
      }
      if(!state.list.length&&state.pageNum==1&&state.coverType==1||!state.list.length&&state.pageNum==2&&state.coverType==1) {
        state.coverType=2;
        state.pageNum=1;
        state.loading = true;
        state.refreshing = true; 
        setTimeout(() => {
          state.finished = false;
        }, 500);               
        getTagDetailList();
        return showToast("竖版没有视频数据");
      }
    } else {
      state.loading = false
      state.refreshing = false
      state.finished = true
      return showToast(res.tip)
    }
  } catch (error) {
    state.loading = false
    state.refreshing = false
    state.finished = true
    console.log(error)
  }
}
// 下拉刷新
const refreshData =(refreshing) =>{
  state.tag=route.query.name
  state.refreshing = refreshing
  state.pageNum = 1
  state.finished = false
  state.loading = true
  state.list = []
  getTagDetailList()
}

// 上拉加载
const moreData =(loading) =>{
  state.loading = loading
  state.pageNum += 1
  getTagDetailList()
}

onMounted(() => {
  getTagHotList()
  refreshData()
}) 

onActivated(() => {
  if(state.tag&&state.tag==route.query.name) return
  if(state.tag&&state.tag!=route.query.name) refreshData()
})

</script>

<style lang="scss" scoped>
.search-type {
  min-height: 120vh;
  padding-top: 1rem;
}

.top-list {
  color: #eaeaec;
  margin: 0.3rem;
  margin-bottom: 0;
  z-index: 2;
  .top-list-type {
    @include flexbox($jc: flex-start, $ai: flex-start, $fd: row, $fw: wrap);
    font-size: 0.24rem;
    font-weight: 600;
    width: 100%;
    border-bottom: $border;
    margin-bottom: 0.12rem;
    .label {
      display: none;
      width: 1.4rem;
      height: 0.5rem;
      font-size: 0.24rem;
      line-height: 0.5rem;
      flex-shrink: 0;
      color: #2b3142;
      border-radius: 0.45rem;
      text-align: center;
      margin-right: 0.25rem;
      background: linear-gradient(to right, #fbdf7a, #ffbb10);
    }
    .type-list {
      max-height: 2.4rem;
      overflow-y:auto ;
      @include flexbox($jc: flex-start, $ai: flex-start, $fd: row, $fw: wrap);
      li {
        width: 1.57rem;
        text-align: center;
        color: #848494;
        height: 0.5rem;
        border-radius: 0.25rem;
        line-height: 0.45rem;
        margin-right: 0.2rem;
        margin-bottom: 0.1rem;
        cursor: pointer;
        white-space: nowrap;
        overflow: hidden;
      }
      .default {
        border: 0.02rem solid #848494;
      }
      .active {
        border: 0.02rem solid #e8c948;
        color: #e8c948;
      }
    }
    &.label-list{
      .type-list{
        li{
          max-width: 1.57rem;
          margin-right: 0.15rem;
          width: 24%;
        }
      }

    }
  }
}
.main {
  padding: 0 0.25rem;
  margin-top: 0.2rem;
  .cover-type {
    box-shadow: $shadow;
    div {
      cursor: pointer;
      width: 100%;
      height: 0.847rem;
    }
  }
  .coverType1 {
    background: url('../../assets/imgs/search/covertype1.svg') no-repeat;
    background-size: 100% 100%;
  }
  .coverType2 {
    background: url('../../assets/imgs/search/covertype2.svg') no-repeat;
    background-size: 100% 100%;
  }
}

.cardList {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}
@media screen and (min-width: 750px) {
  .top-list {
    .top-list-type {
      .label {
        display: block;
      }
    }
  }
}
</style>
