<template>
  <div class="hot-tag">
    <LayoutsHeader :title="'热门标签'" />
    <div class="card-list" v-if="tagList && tagList.length > 0">
      <DecryptImg
        v-for="(item, index) in tagList"
        :key="index"
        @clickImg="$router.push(`/tag/detail/${$route.params.location}?name=${item.name}`)"
        :imgURL="item.cover"
        class="card-img"
        :needPadding="false"
      >
        <div class="title">{{ item.name }}</div>
      </DecryptImg>
    </div>
  </div>
</template>

<script setup>
import { showToast } from 'vant'
import { hot_tag_list } from '@/api/search'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const route = useRoute()
const state = reactive({
  tagList: []
})

const getTagList =async () =>{
  try {
    const res = await hot_tag_list({
      location: +route.params.location
    })
    if (res.code === 200) {
      state.tagList = [...state.tagList, ...res.data.tagList]
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    return showToast('请求失败，请稍后再试！')
  }
}

onMounted(() => {
  getTagList()
}) 


</script>

<style lang="scss" scoped>
.hot-tag {
  min-height: 100vh;
  padding-top: 1.2rem;
  max-width: 960px;
  margin: 0 auto;
  :deep()  {
    .van-nav-bar {
      border-bottom: 0.01rem solid #5b5b6f;
    }
  }

  .card-list {
    cursor: pointer;
    border-radius: 0.1rem;
    @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: wrap);
    padding: 0 0.2rem;
    .card-img {
      width: 33%;
      max-width: 2.32rem;
      height: 2.25rem;
      border-radius: 0.1rem;
      margin-top: 0.25rem;
      position: relative;
      padding: 0 0.13rem;
      :deep()  {
        .warpNoPadding {
          border-radius: 0.1rem;
          img {
            border-radius: 0.1rem;
          }
        }
      }
      .title {
        position: absolute;
        @include transformCenter(-50%, 0);
        left: 50%;
        bottom: 0;
        width: 100%;
        height: 0.5rem;
        text-align: center;
        line-height: 0.5rem;
        background: rgba($color: #000000, $alpha: 0.5);
        font-size: 0.3rem;
        border-bottom-left-radius: 0.1rem;
        border-bottom-right-radius: 0.1rem;
        color: $mainTxtColor1;
      }
    }
  }
}
</style>
