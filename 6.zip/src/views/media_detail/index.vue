<template>
  <div class="media-detail">
    <!-- 顶部返回导航 -->
    <LayoutsHeader :title="$route.query.title"> </LayoutsHeader>
    <!-- 合集信息 -->
    <div class="gather-info" v-if="+$route.query.price">
      <div class="video-count">
        作品数量：<span>{{ state.topicInfo.movieCount }}部</span>
      </div>
      <div class="price-btn" @click.stop="buyCollection">
        <div class="price">
          {{ changeGold(state.topicInfo.price) }}
          <img src="@/assets/imgs/index/gold.png" alt="" />
        </div>
        <div class="btn">
          <img
            :src="
              state.topicInfo.isBuy
                ? getAssetsFile('index/row-suo.svg')
                : getAssetsFile('index/row-suo-back.svg')
            "
            alt=""
          />
          {{ !state.topicInfo.isBuy ? '解锁' : '已解锁' }}
        </div>
      </div>
    </div>
    <!--切换面板 -->
    <JavTab
      :addClass="'bgTab'"
      class="dating-tab"
      @change="change"
      :titles="state.category"
      :active="state.sort"
      :animated="false"
      :needBack="false"
    >
      <template>
        <!-- 列表 -->
        <div class="pull-content">
          <PullUp
            @refreshData="refreshData"
            @moreData="moreData"
            :finished="state.finished"
            :loading="state.loading"
            :refreshing="state.refreshing"
          >
            <component
              :list="state.mediaList"
              :typeTxt="'详情'"
              :sort="state.sort"
              :id="+$route.params.id"
              :is="compComponent($route.query.showType)"
            ></component>
          </PullUp>
        </div>
      </template>
    </JavTab>
    <JavShowBuy
      :title="'购买此合集需支付'"
      :showBuy="state.showBuy"
      :width="'80%'"
      :position="'center'"
      @shoudBuy="shoudBuy"
      @closed="closed"
      :price="changeGold(state.topicInfo.price)"
    />
  </div>
</template>

<script setup>
import { getAssetsFile } from '@/utils/utils_tools'
import { showToast } from 'vant'
import { changeGold } from '@/utils/filter'
import { media_details } from '@/api/home'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const JavTab = defineAsyncComponent(() => import('@/components/JavTab.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const JavShortFour = defineAsyncComponent(() => import('@/components/JavShortFour.vue'))
const JavFourCard = defineAsyncComponent(() => import('@/components/JavFourCard.vue'))
const JavBigList = defineAsyncComponent(() => import('@/components/JavBigList.vue'))
const JavShowBuy = defineAsyncComponent(() => import('@/components/JavShowBuy.vue'))
const JavShortSix = defineAsyncComponent(() => import('@/components/JavShortSix.vue'))
const route = useRoute()
const state = reactive({
  refreshing: false,
  loading: false,
  finished: false,
  pageNum: 1,
  pageSize: 20,
  mediaList: [],
  category: [
    { id: 0, name: '最新发布' },
    { id: 1, name: '最热观看' },
    { id: 2, name: '最受好评' }
  ],
  topicInfo: {},
  showBuy: false,
  sort: 0 // 分类类型 0 1 2
})
// 合集购买
const buyCollection =() =>{
  if (!state.topicInfo.isBuy) {
    state.showBuy = true
  }
}

// 购买弹窗关闭事件
const closed =() =>{
  state.showBuy = close
}

// 购买弹窗购买按钮
const shoudBuy =async () =>{
  try {
    const res = await gather_buy({
      id: state.topicInfo.id
    })
    if (res.code === 200) {
      state.topicInfo.isBuy = true
      state.showBuy = false
    } else {
      return showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    return showToast('请求错误，请稍后再试！')
  }
}

const change =(index) =>{
  state.finished = false
  state.sort = index
  refreshData()
}

const moreData =(loading) =>{
  state.loading = loading
  state.pageNum += 1
  getTopicDetails()
}

const refreshData =(refreshing) =>{
  state.refreshing = refreshing
  state.loading = true
  state.finished = false
  state.pageNum = 1
  state.mediaList = []
  getTopicDetails()
}

// 获取专题详情
const getTopicDetails =async () =>{
  try {
    const res = await media_details({
      id: +route.params.id,
      sort: state.sort,
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      state.refreshing = false
      state.loading = false
      state.topicInfo = res.data.topicInfo
      state.mediaList = [...state.mediaList, ...res.data.mediaList]
      if (!res.data.mediaList || res.data.mediaList.length < state.pageSize) {
        state.finished = true
      }
    } else {
      state.refreshing = false
      state.loading = false
      state.finished = true
      showToast(res.tip)
    }
  } catch (error) {
    state.refreshing = false
    state.loading = false
    state.finished = true
    console.log(error)
    showToast('请求失败，请稍后再试！')
  }
}

// 展示方式  1:横版(三排两列)长视频大横排 2:横版(大列表) 3:竖版(两排三列)短视频四宫格 4:竖版(三排两列)短视频六宫格
const compComponent =(showType) =>{
  switch (+showType) {
    case 1:
      return 'JavFourCard'
    case 2:
      return 'JavBigList'
    case 3:
      return 'JavShortSix'
    case 4:
      return 'JavShortFour'
    default:
      return 'JavShortSix'
  }
}

onMounted(() => {
  refreshData()
}) 

</script>

<style lang="scss" scoped>
.media-detail {
  padding-top: 1.3rem;
  max-width: $pcMaxWidth;
  margin: 0 auto;
  .pull-content {
    padding: 0 0;
  }
}
.dating-tab {
  :deep()  {
    .van-tabs__wrap {
      background: transparent !important;
      box-shadow: none !important;
    }
  }
}
.price-btn {
  display: flex;
  align-items: center;
  font-size: 0.25rem;
  margin-right: 0.14rem;
  .price,
  .btn {
    display: flex;
    align-items: center;
    justify-content: center;
    border: 0.01rem solid #9e1f5a;
    padding: 0.05rem 0.12rem;
    white-space: nowrap;
  }

  .price {
    color: #9e1f5a;
    font-weight: 600;
    border-right: none;
    img {
      width: 0.24rem;
      height: 0.24rem;
      margin-left: 0.04rem;
    }
  }
  .btn {
    color: $mainTxtColor1;
    background: linear-gradient(to right, #e13177, #550d3b);
    border-left: none;
    img {
      width: 0.18rem;
      margin-right: 0.03rem;
    }
  }
}
// 合集信息
.gather-info {
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 0.01rem solid rgba($color: #5b5b6f, $alpha: 0.5);
  padding: 0.3rem 0.3rem;
  .video-count {
    font-size: 0.26rem;
    span {
      font-size: 0.3rem;
      font-weight: 600;
    }
  }
}
</style>
