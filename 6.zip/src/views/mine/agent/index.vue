

<template>
  <div class="income">
    <LayoutsHeader :title="'分享赚钱'" />
    <!-- 账户余额 -->
    <div class="content">
      <div class="user-money">
        <div class="lv">
          <span>当前等级：{{ state.incomeInfo.level }}</span>
        </div>
        <div class="user-gold">
          <div class="money-left">
            <div>金币余额</div>
            {{ changeGold(state.incomeInfo.balance,2) }}
          </div>
          <div class="line"></div>
          <div class="moeny-sy">
            <div>总收益</div>
            {{ changeGold(state.incomeInfo.totalIncome,2) }}
          </div>
        </div>
      </div>
      <!-- 按钮 -->
      <div class="btn">
        <div @click="$router.push('/mine/withdraw')">金币提现</div>
        <div @click="$router.push('/mine/share')">推广分享</div>
      </div>
      <!-- 收益 -->
      <ul class="sy-data">
        <li>
          <p>当月推广收益</p>
          <p class="price">{{ changeGold(state.incomeInfo.currentMonthIncome,2) }}</p>
        </li>
        <li class="line"></li>
        <li>
          <p>当月推广人数</p>
          <p class="price">{{ state.incomeInfo.currentMonthProxy }}</p>
        </li>
        <li class="line"></li>
        <li>
          <p>累计推广人数</p>
          <p class="price">{{ state.userInfo.invites }}</p>
        </li>
      </ul>

      <!-- 活动规则 -->
      <div class="tip">
        <h2>活动规则</h2>
        <p>1.在APP中，我的-分享推广中，分享推广链接或复制推广码，分享给好友</p>
        <p>2.用户下载安装APP后，自动绑定推荐关系，用户开通会员，最高比例可返55%</p>
        <p>备注:推广等级总共分为4级,达到指定业绩自动升级,即可享有该等级的返佣比例.</p>
        <div class="footer-text">
          <img src="@/assets/imgs/mine/share-tip.svg" alt="" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { changeGold } from '@/utils/filter'  
import { user_income } from '@/api/user'
import { showToast } from 'vant'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))

const state = reactive({
  incomeInfo: {
    runningLights: []
  },
  userInfo:computed(() => store.getters['getUserInfo'])
})

// 获取代理收益
const getMyInviteInfo =async () =>{
  const res = await user_income({})
  if (res.code === 200) {
    state.incomeInfo = res.data
  } else {
    return showToast(res.tip)
  }
}

onMounted(() => {
  getMyInviteInfo()
}) 
</script>

<style lang="scss" scoped>
.income {
  margin: 0 auto;
  max-width: 940px;
  min-height: 100vh;
  padding-top: 1rem;
  .top-tip {
    height: 0.6rem;
    font-size: 0.3rem;
    overflow: hidden;
    text-align: center;
    line-height: 0.6rem;
    span:first-child {
      font-weight: 600;
    }
  }
  .content {
    padding: 0.52rem 0.3rem;
  }
  .user-money {
    background: linear-gradient(to bottom, #141414, #444242);
    font-size: 0.24rem;
    border-radius: 0.42rem;
    color: $mainTxtColor1;
    .lv {
      display: flex;
      justify-content: flex-end;
      margin-bottom: 0.45rem;
      span {
        min-width: 1.9rem;
        height: 0.44rem;
        background: $btnBg;
        text-align: center;
        line-height: 0.44rem;
      }
    }
    .user-gold {
      @include flexbox($jc: space-around, $ai: center, $fd: row, $fw: nowrap);
      font-size: 0.7rem;
      color: $mainTxtColor1;
      text-align: center;
      .line {
        width: 0.02rem;
        height: 1.29rem;
        margin-bottom: 0.3rem;
        background: #6f707f;
      }
      .money-left,
      .moeny-sy {
        @include flexbox($jc: center, $ai: center, $fd: column, $fw: nowrap);

        div {
          background: $btnBg;
          text-align: center;
          height: 0.48rem;
          width: 1.3rem;
          color: $mainTxtColor1;
          border-radius: 0.37rem;
          line-height: 0.48rem;
          font-size: 0.24rem;
          border-radius: 0.05rem;
        }
      }
    }
  }
  .btn {
    @include flexbox($jc: space-between, $ai: center, $fd: row, $fw: nowrap);
    margin: 0.3rem 0;
    div {
      background: $btnBg;
      font-size: 0.36rem;
      width: 3.2rem;
      height: 0.74rem;
      line-height: 0.74rem;
      text-align: center;
      box-shadow: $shadow;
    }
  }
  .sy-data {
    @include flexbox($jc: space-between, $ai: center, $fd: row, $fw: nowrap);
    height: 2rem;
    margin: 0.3rem 0;
    background-color: $mainBgColor;
    box-shadow: $shadow;
    font-size: 0.26rem;
    border-radius: 0.09rem;
    justify-content: space-around;
    p {
      text-align: center;
      font-size: 0.24rem;
    }
    .price {
      font-size: 0.48rem;
      color: #848494;
      margin: 0;
    }
    .line {
      width: 0.02rem;
      height: 1.29rem;
      background: #848494;
    }
  }

  .tip {
    font-size: 0.24rem;
    color: #ccc;

    p {
      margin: 0;
      margin-bottom: 0.1rem;
    }
    .rolor {
      color: #0082ff;
    }
  }
}

.footer-text {
  padding-top: 0.3rem;
  text-align: center;
  img {
    max-width: 750px;
    width: 100%;
  }
}
@media screen and (min-width: 750px) {
  .btn {
    padding: 0 0.5rem !important;
    div {
      cursor: pointer;
      border-radius: 0.12rem;
      font-size: 0.28rem !important;
    }
  }
  .footer-text {
    width: 50%;
    margin: 0 auto;
  }
}
</style>
