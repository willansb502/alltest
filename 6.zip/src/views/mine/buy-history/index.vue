<template>
  <div class="buy-history">
    <LayoutsHeader :title="'购买记录'" />
    <JavTab
      @change="change"
      :sticky="true"
      :titles="state.cartoonCategory"
      :active="state.indexActive"
      :animated="false"
      :addClass="'mine-tab'"
    >
      <PullUp
        @refreshData="refreshData"
        @moreData="moreData"
        :finished="state.finished"
        :loading="state.loading"
        :refreshing="state.refreshing"
        :skeleton="state.skeleton"
        v-if="state.payList && state.payList.length > 0"
        class="myPublissh-pullup"
      >
        <template v-if="state.indexActive === 5">
          <CommunityDefault v-for="(item, index) in state.payList" :key="index" :itemData="item" :status="item.status">
            <template v-slot:decialBtn> </template>
          </CommunityDefault>
        </template>
        <component v-else :list="state.payList" typeTxt='购买记录' :is="compComponent(state.indexActive)"></component>
      </PullUp>
      <Nodata :text="'您还没有购买哦～'" v-else />
    </JavTab>
  </div>
</template>
<script setup>
import { pay_history } from '@/api/user'
import { showToast } from 'vant'
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const CommunityDefault = defineAsyncComponent(() => import('@/components/Community/default.vue'))
const JavShortFour = defineAsyncComponent(() => import('@/components/JavShortFour.vue'))
const Lf_card = defineAsyncComponent(() => import('@/components/Dating/Lf_card.vue'))
const Sm_card = defineAsyncComponent(() => import('@/components/Dating/Sm_card.vue'))
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const Actor = defineAsyncComponent(() => import('@/components/JavActor.vue'))
const Nodata = defineAsyncComponent(() => import('@/components/JavNodata.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const JavTab = defineAsyncComponent(() => import('@/components/JavTab.vue'))

const state = reactive({
  //上拉加载
  loading: false,
  //上拉加载完成
  finished: false,
  //下拉刷新
  refreshing: false,
  //文章列表
  payList: [],
  indexActive: 1,
  skeleton: false,
  //当前页
  pageNum: 1,
  // 当前个数
  pageSize: 5,
  cartoonCategory: [
    { id: 1, name: 'AV' },
    { id: 2, name: '小视频' },
    { id: 3, name: '动漫' },
    { id: 5, name: '帖子' },
    { id: 4, name: '上门' },
    { id: 6, name: '楼凤' }
  ]
})

//切换
const change =(id) =>{
  state.indexActive = +id
  refreshData()
}

//下拉加载
const moreData =(loading) =>{
  state.loading = loading
  state.pageNum++
  getList()
}

//上拉刷新
const refreshData =(refreshing) =>{
  state.refreshing = refreshing
  //表示处于可以下拉状态
  state.finished = false
  state.loading = true
  state.pageNum = 1
  state.skeleton = true
  state.payList = []
  getList()
}
//获取列表
const getList =async () =>{
  try {
    const res = await pay_history({
      type: state.indexActive,
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      state.refreshing = false
      state.loading = false
      // ContentTypeNone         ContentType = 0 // 占位符，无意义
      // ContentTypeVideoAv      ContentType = 1 // AV
      // ContentTypeVideoMedia   ContentType = 2 // 视频
      // ContentTypeCartoon      ContentType = 3 // 动漫
      // ContentTypeViodeModel   ContentType = 4 // 上门
      // ContentTypePost         ContentType = 5 // 帖子
      // ContentTypeViodeLoufeng ContentType = 6 // 楼风
      // ContentTypeActor        ContentType = 7 // 女优
      switch (state.indexActive) {
        case 1:
        case 2:
        case 3:
          if (res.data.mediaList) {
            state.payList = [...state.payList, ...res.data.mediaList]
          }

          if (!res.data.mediaList || (res.data.mediaList && res.data.mediaList.length < state.pageSize)) {
            state.finished = true
          }
        case 4:
          if (res.data.modelList) {
            state.payList = [...state.payList, ...res.data.modelList]
          }

          if (!res.data.modelList || (res.data.modelList && res.data.modelList.length < state.pageSize)) {
            state.finished = true
          }
        case 5:
          if (res.data.postList) {
            state.payList = [...state.payList, ...res.data.postList]
          }

          if (!res.data.postList || (res.data.postList && res.data.postList.length < state.pageSize)) {
            state.finished = true
          }
        case 6:
          if (res.data.loufengList) {
            state.payList = [...state.payList, ...res.data.loufengList]
          }

          if (!res.data.loufengList || (res.data.loufengList && res.data.loufengList.length < state.pageSize)) {
            state.finished = true
          }
      }
    } else {
      showToast(res.tip)
      state.refreshing = false
      state.loading = false
      state.finished = true
    }
  } catch (error) {
    state.refreshing = false
    state.loading = false
    state.finished = true
    console.log(error)
    showToast('请求错误，请稍后再试！')
  }
}

const compComponent =(type) =>{
  switch (type) {
    case 4:
      return 'Sm_card'
    case 6:
      return 'Lf_card'
    default:
      return 'JavShortFour'
  }
}

onMounted(() => {
  refreshData()
}) 
</script>
<style lang="scss" scoped>
.buy-history {
  padding-top: 1.3rem;
  padding-bottom: 1rem;
  color: #333;
  min-height: 100vh;
  background: $mainBgColor;
  :deep()  {
    .van-pull-refresh {
      padding: 0 0.25rem;
    }
  }
}
</style>
