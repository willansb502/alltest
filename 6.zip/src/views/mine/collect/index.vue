<template>
  <div class="collect">
    <LayoutsHeader :title="'我的收藏'" @onClickRight="onClickRight">
      <template v-slot:right>
        <div class="right-btn" name="right">
          {{ state.btnTxt }}
        </div>
      </template>         
    </LayoutsHeader>
    <JavTab
      @change="change"
      :sticky="true"
      :titles="state.cartoonCategory"
      :active="state.indexActive"
      :animated="false"
      :addClass="'mine-tab'"
    >
      <PullUp
        @refreshData="refreshData"
        @moreData="moreData"
        :finished="state.finished"
        :loading="state.loading"
        :refreshing="state.refreshing"
        :skeleton="state.skeleton"
        class="myPublissh-pullup"
        v-if="state.collectList && state.collectList.length > 0"
      >
        <template v-if="state.indexActive === 5">
          <CommunityDefault
            @clickItem="clickItem"
            :showMask="state.showMask"
            v-for="(item, index) in state.collectList"
            :key="index"
            :itemData="item"
            :status="item.status"
          >
          </CommunityDefault>
        </template>
        <component
          @clickItem="clickItem"
          v-else
          :showMask="state.showMask"
          typeTxt="'收藏记录'"
          :list="state.collectList"
          :is="compComponent(state.indexActive)"
        ></component>
      </PullUp>
      <Nodata :text="'您还没有收藏哦～'" v-else />
    </JavTab>
    <van-popup
      v-model:show="state.showType"
      class="pay-pop"
      @close="cancelConfirm"
      close-icon="cross"
      position="bottom"
      lazy-render
    >
      <div class="content">
        <span>确认删除？</span>
        <div class="btn-wrap">
          <div @click="confirm">删除</div>
          <div @click="cancelConfirm">取消</div>
        </div>
      </div>
    </van-popup>
  </div>
</template>
<script setup>
import { collect_list, collect_del } from '@/api/user'
import { showToast } from 'vant'
import { useStore } from 'vuex'
const store = useStore()
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const CommunityDefault = defineAsyncComponent(() => import('@/components/Community/default.vue'))
const JavShortFour = defineAsyncComponent(() => import('@/components/JavShortFour.vue'))
const Lf_card = defineAsyncComponent(() => import('@/components/Dating/Lf_card.vue'))
const Sm_card = defineAsyncComponent(() => import('@/components/Dating/Sm_card.vue'))
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const Nodata = defineAsyncComponent(() => import('@/components/JavNodata.vue'))
const Actor = defineAsyncComponent(() => import('@/components/JavActor.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const JavTab = defineAsyncComponent(() => import('@/components/JavTab.vue'))


const state = reactive({
  //上拉加载
  loading: false,
  showMask: false, // 删除遮罩层显示控制
  //上拉加载完成
  finished: false,
  //下拉刷新
  refreshing: false,
  showType: false,
  //文章列表
  collectList: [],
  indexActive: 1,
  skeleton: false,
  btnTxt: '编辑',
  //当前页
  pageNum: 1,
  // 当前个数
  pageSize: 5,
  cartoonCategory: [
    { id: 1, name: '长视频' },
    { id: 2, name: '小视频' },
    { id: 5, name: '帖子' },
    { id: 4, name: '上门' },
    { id: 6, name: '楼凤' },
    { id: 7, name: '女优' }
  ],
  // 批量删除的id
  objectIds: []
})

// 选择完成
const clickItem =(array) =>{
  state.objectIds = array
}

// 编辑按钮
const onClickRight =() =>{
  if (state.btnTxt == '编辑') {
    state.showMask = true
    return (state.btnTxt = '完成')
  }
  state.showType = true
}

//取消
const cancelConfirm =() =>{
  state.showMask = false
  state.showType = false
  state.btnTxt = '编辑'
}

//确定删除
const confirm =async () =>{
  if (!state.objectIds || state.objectIds.length === 0) return
  try {
    const res = await collect_del({
      objectIds: state.objectIds,
      type: state.indexActive
    })
    if (res.code === 200) {
      state.showMask = false
      state.showType = false
      state.btnTxt = '编辑'
      refreshData()
    } else {
      showToast(res.tip)
    }
  } catch (error) {
    console.log(error)
    showToast('请求失败，请稍后再试！')
  }
}
//切换
const change =(id) =>{
  state.indexActive = +id
  refreshData()
}
//下拉加载
const moreData =(loading) =>{
  state.loading = loading
  state.pageNum++
  getList()
}
//上拉刷新
const refreshData =(refreshing) =>{
  state.refreshing = refreshing
  //表示处于可以下拉状态
  state.finished = false
  state.loading = true
  state.pageNum = 1
  state.skeleton = true
  state.collectList = []
  getList()
}

//获取列表
const getList =async () =>{
  try {
    const res = await collect_list({
      type: state.indexActive,
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      state.refreshing = false
      state.loading = false
      // ContentTypeNone         ContentType = 0 // 占位符，无意义
      // ContentTypeVideoAv      ContentType = 1 // AV
      // ContentTypeVideoMedia   ContentType = 2 // 视频
      // ContentTypeCartoon      ContentType = 3 // 动漫
      // ContentTypeViodeModel   ContentType = 4 // 上门
      // ContentTypePost         ContentType = 5 // 帖子
      // ContentTypeViodeLoufeng ContentType = 6 // 楼风
      // ContentTypeActor        ContentType = 7 // 女优
      switch (state.indexActive) {
        case 1:
        case 2:
          state.collectList = [...state.collectList, ...res.data.mediaList]
          if (!res.data.mediaList || (res.data.mediaList && res.data.mediaList.length < state.pageSize)) {
            state.finished = true
          }
        case 4:
          state.collectList = [...state.collectList, ...res.data.modelList]
          if (!res.data.modelList || (res.data.modelList && res.data.modelList.length < state.pageSize)) {
            state.finished = true
          }
        case 5:
          state.collectList = [...state.collectList, ...res.data.postList]
          if (!res.data.postList || (res.data.postList && res.data.postList.length < state.pageSize)) {
            state.finished = true
          }
        case 6:
          state.collectList = [...state.collectList, ...res.data.loufengList]
          if (!res.data.loufengList || (res.data.loufengList && res.data.loufengList.length < state.pageSize)) {
            state.finished = true
          }
        case 7:
          state.collectList = [...state.collectList, ...res.data.actorList]
          if (!res.data.actorList || (res.data.actorList && res.data.actorList.length < state.pageSize)) {
            state.finished = true
          }
      }
    } else {
      showToast(res.tip)
      state.refreshing = false
      state.loading = false
      state.finished = true
    }
  } catch (error) {
    state.refreshing = false
    state.loading = false
    state.finished = true
    console.log(error)
    showToast('请求错误，请稍后再试！')
  }
}

const compComponent =(type) =>{
  switch (type) {
    case 4:
      return 'Sm_card'
    case 6:
      return 'Lf_card'
    case 7:
      return 'Actor'
    default:
      return 'JavShortFour'
  }
}

onMounted(() => {
  refreshData()
}) 

</script>
<style lang="scss" scoped>
.collect {
  padding-top: 1rem;
  padding-bottom: 1rem;
  color: #333;
  min-height: 100vh;
  background: $mainBgColor;
  max-width: $pcMaxWidth;
  margin: 0 auto;
  :deep()  {
    .van-pull-refresh {
      padding: 0 0.25rem;
    }
  }
}
.pay-pop {
  background: linear-gradient(to bottom, #e7e3fe, #d6e7fc, $mainTxtColor1);
  border-top-left-radius: 0.3rem;
  border-top-right-radius: 0.3rem;
  font-size: 0.36rem;
  text-align: center;
  font-weight: 600;
  .content {
    span {
      display: block;
      padding: 0.3rem 0;
    }
    .btn-wrap {
      font-size: 0.28rem;
      border-top: 0.02rem solid #adadb7;
      div {
        padding: 0.3rem 0;
        &:last-child {
          background: $btnBg;
        }
      }
    }
  }
}
</style>
