<template>
  <div class="myWallet-container">
    <LayoutsHeader title="关注"></LayoutsHeader>

    <JavTab
      @change="changeActive"
      :sticky="true"
      :titles="state.cartoonCategory"
      :active="state.indexActive"
      :animated="false"
      :addClass="'mine-tab'"
    >
      <PullUp
        @refreshData="refreshData"
        @moreData="moreData"
        :finished="state.finished"
        :loading="state.loading"
        :refreshing="state.refreshing"
        :skeleton="state.skeleton"
        v-if="state.careList && state.careList.length > 0"
      >
        <ul class="care-listWrap">
          <li class="item" v-for="(item, index) in state.careList" :key="index">
            <div class="left" @click="$router.push(`/up/index/${item.id}`)">
              <div class="avatar">
                <DecryptImg :imgURL="item.avatar" />
              </div>
              <div class="name">
                <div>{{ item.name }}</div>
                <div>{{ item.introduction }}</div>
              </div>
            </div>
            <div @click="removeCare(item, index)" class="right">
              <div>取消关注</div>
            </div>
          </li>
        </ul>
      </PullUp>
      <Nodata :text="state.indexActive === 1 ? '您还没有关注别人哦～' : '您还没有粉丝哦~'" v-else />
    </JavTab>
  </div>
</template>
<script setup>
import { care_cancel } from '@/api/home'
import { care_list, care_fans } from '@/api/user'
import { showToast } from 'vant'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const JavTab = defineAsyncComponent(() => import('@/components/JavTab.vue'))
const Nodata = defineAsyncComponent(() => import('@/components/JavNodata.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))

const state = reactive({
  // 上拉加载（loading:false代表可继续上拉加载）
  loading: false,
  // 上拉加载完成（完成只需要出现1次，finished: true，转圈消失，加载完成字体出现）
  finished: false,
  // 下拉刷新
  refreshing: false,
  // 关注列表
  careList: [],
  cartoonCategory: [
    { id: 1, name: '我的关注' },
    { id: 2, name: '我的粉丝' }
  ],
  skeleton: false,
  indexActive: 1,
  // 当前页
  pageNum: 1,
  // 当前个数
  pageSize: 5
})

// 获取关注列表
const getCareList =async () =>{
  try {
    const res = await care_list({
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      state.refreshing = false
      state.loading = false
      state.careList = [...state.careList, ...res.data.list]
      if (res.data && res.data.list.length < state.pageSize) {
        state.finished = true
      }
    } else {
      showToast(res.tip)
      state.refreshing = false
      state.loading = false
      state.finished = true
    }
  } catch (error) {
    state.refreshing = false
    state.loading = false
    state.finished = true
    console.log(error)
    showToast('请求出错，请稍后再试！')
  }
}
// 获取粉丝列表
const getCareFans =async () =>{
  try {
    const res = await care_fans({
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      state.refreshing = false
      state.loading = false
      state.careList = [...state.careList, ...res.data.list]
      if (res.data && res.data.list.length < state.pageSize) {
        state.finished = true
      }
    } else {
      showToast(res.tip)
      state.refreshing = false
      state.loading = false
      state.finished = true
    }
  } catch (error) {
    state.refreshing = false
    state.loading = false
    state.finished = true
    console.log(error)
    showToast('请求出错，请稍后再试！')
  }
}
// 下拉加载
const moreData =(loading) =>{
  state.loading = loading
  state.pageNum++
  if (state.indexActive === 1) {
    getCareList()
  } else {
    getCareFans()
  }
}

// 上拉刷新
const refreshData =(refreshing) =>{
  state.refreshing = refreshing
  state.finished = false
  state.loading = true
  state.careList = []
  state.pageNum = 1
  state.skeleton = true
  if (state.indexActive === 1) {
    getCareList()
  } else {
    getCareFans()
  }
}

// 取消关注
const removeCare =async (item, index) =>{
  const res = await care_cancel({
    Ids: [item.id]
  })
  if (res.code === 200) {
    state.careList.splice(index, 1)
    showToast('取消关注')
  } else {
    showToast(res.tip)
  }
}

const changeActive =(type) =>{
  if (state.indexActive !== type) {
    state.indexActive = type
    refreshData()
  } 
}

onMounted(() => {
  refreshData()
}) 
</script>
<style lang="scss" scoped>
.myWallet-container {
  padding-top: 1rem;
  min-height: 100vh;
  box-sizing: border-box;
  .top-nav {
    @include flexbox($jc: center, $ai: center, $fd: row, $fw: nowrap);
    font-size: 0.28rem;
    color: #848494;
    margin-top: 0.3rem;
    li {
      width: 3.1rem;
      height: 0.6rem;
      text-align: center;
      line-height: 0.6rem;
    }
    .active {
      background: $btnBg;
      color: #040404;
      font-weight: 600;
    }
  }
  .care-listWrap {
    padding-top: 0.3rem;
    .item {
      padding: 0.13rem 0.25rem;
      @include flexbox;
      box-shadow: $shadow;
      margin-bottom: 0.15rem;
      margin-left: 0.3rem;
      margin-right: 0.3rem;
      .left {
        @include flexbox;

        .avatar {
          width: 0.95rem;
          flex-shrink: 0;
          :deep()  {
            .warp {
              border-radius: 50%;
              img {
                border-radius: 50%;
              }
              .imgTag {
                height: 100%;
                object-fit: cover;
              }
            }
          }
        }
        .name {
          padding-left: 0.15rem;
          font-size: 0.28rem;
          width: 3.8rem;
          div {
            &:last-child {
              padding-top: 0.1rem;
              font-size: 0.24rem;
              color: #a7a7a7;
            }
          }
        }
      }
      .right {
        @include flexbox($jc: center, $ai: center, $fd: row, $fw: nowrap);
        div {
          @include flexbox($jc: center, $ai: center, $fd: row, $fw: nowrap);
          width: 1.4rem;
          height: 0.5rem;
          font-size: 0.26rem;
          background: $btnBg;
          border-radius: 0.25rem;
        }
      }
    }
  }
}
</style>
