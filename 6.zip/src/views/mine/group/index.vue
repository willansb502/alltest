<template>
  <div class="contact-container">
    <LayoutsHeader title="交流群"></LayoutsHeader>
    <ul >
      <li @click="openPage(item)" class="item" v-for="(item,index) in state.contactList" :key="index">
        <DecryptImg  :imgURL="item.cover" />
      </li>
    </ul>
  </div>
</template>
<script setup>
import {config_contact} from '@/api/user'
import { showToast } from 'vant'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const state = reactive({
  contactList:[]
})
//获取联系方式
const getConfigContact =async () =>{
  const res = await config_contact({
  })
  if (res.code === 200) {
    state.contactList=res.data;
  } else {
    showToast(res.tip);
  }
}

//打开页面
const openPage = (item) =>{
  if(item.jumpUrl) window.open(item.jumpUrl, '_blank');
}

onMounted(() => {
  getConfigContact();
}) 

</script>
<style lang="scss" scoped>
.contact-container{
  padding-top: 1rem;
  min-height: 100vh;

  ul{
    display: flex;
    flex-flow: wrap;
    padding-top: .6rem;
    .item{
      width: 2.28rem;
      height: 2.28rem;
      margin: 0 .57rem .8rem .9rem;
      :deep()  {
        .warp{
          font-size: 0;

          background-color: transparent;
        }
      }
    }
  }

}
</style>
