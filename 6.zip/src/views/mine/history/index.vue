<template>
  <div class="history">
    <LayoutsHeader :title="'观看记录'" @onClickRight="onClickRight">
      <template v-slot:right>
        <div class="right-btn" name="right">
          {{ state.btnTxt }}
        </div>
      </template>        
    </LayoutsHeader>
    <JavTab
      @change="change"
      :sticky="true"
      :titles="state.cartoonCategory"
      :active="state.indexActive"
      :animated="false"
      :addClass="'mine-tab'"
    >
      <div class="history-content-wrap">
        <JavShortFour
          @clickItem="clickItem"
          :list="state.historyList"
          :showMask="state.showMask"
          v-if="state.historyList && state.historyList.length > 0"
          :typeTxt="'观看记录'"
        />

        <Nodata :text="'暂无观看记录哦～'" v-else />
      </div>
    </JavTab>
    <!-- 弹窗 -->
    <van-popup
      v-model:show="state.showType"
      class="pay-pop"
      @close="cancelConfirm"
      close-icon="cross"
      position="bottom"
      lazy-render
    >
      <div class="content">
        <span>确认删除？</span>
        <div class="btn-wrap">
          <div @click="confirm">删除</div>
          <div @click="cancelConfirm">取消</div>
        </div>
      </div>
    </van-popup>
  </div>
</template>
<script setup>
import { useStore } from 'vuex'
const store = useStore()
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const CommunityDefault = defineAsyncComponent(() => import('@/components/Community/default.vue'))
const JavShortFour = defineAsyncComponent(() => import('@/components/JavShortFour.vue'))
const Lf_card = defineAsyncComponent(() => import('@/components/Dating/Lf_card.vue'))
const Sm_card = defineAsyncComponent(() => import('@/components/Dating/Sm_card.vue'))
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const Actor = defineAsyncComponent(() => import('@/components/JavActor.vue'))
const Nodata = defineAsyncComponent(() => import('@/components/JavNodata.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const JavTab = defineAsyncComponent(() => import('@/components/JavTab.vue'))

const state = reactive({
  //文章列表
  historyList: [],
  spliceList: [],
  indexActive: 1,
  showType: false,
  btnTxt: '编辑',
  showMask: false,
  cartoonCategory: [
    { id: 1, name: 'AV' },
    { id: 2, name: '小视频' },
    { id: 3, name: '动漫' }
  ],
  // 获取短视频观看记录列表
  shortList:computed(() => store.getters['shortList']),
  // 获取长视频观看记录列表
  avList:computed(() => store.getters['avList']),
  // 获取动漫视频观看记录列表
  cartoonList:computed(() => store.getters['cartoonList']),
})

const clickItem =(array) =>{
  state.spliceList = array
}
//切换
const change =(id) =>{
  state.indexActive = +id
  refreshData()
}
// 编辑按钮
const onClickRight =() =>{
  if (state.btnTxt == '编辑') {
    state.showMask = true
    return (state.btnTxt = '完成')
  }
  state.showType = true
}

//取消
const cancelConfirm =() =>{
  state.showMask = false
  state.showType = false
  state.btnTxt = '编辑'
}

//确定删除
const confirm =() =>{
  if (state.indexActive === 1) {
    store.dispatch('setAvList', { type: 'del', arr: state.spliceList })
  } else if (state.indexActive === 2) {
    store.dispatch('setShortList', { type: 'del', arr: state.spliceList })
  } else {
    store.dispatch('setCartoonList', { type: 'del', arr: state.spliceList })
  }
  state.showMask = false
  state.showType = false
  state.btnTxt = '编辑'
  refreshData()
}
//上拉刷新
const refreshData =() =>{
  state.historyList = []
  if (state.indexActive === 1) {
    state.historyList = state.avList
  } else if (state.indexActive === 2) {
    state.historyList = state.shortList
  } else {
    state.historyList = state.cartoonList
  }
}

onMounted(() => {
  refreshData()
}) 

</script>
<style lang="scss" scoped>
.history {
  padding-top: 0.93rem;
  padding-bottom: 0.93rem;
  color: #333;
  min-height: 100vh;
  background: $mainBgColor;
  max-width: $pcMaxWidth;
  margin: 0 auto;
  :deep()  {
    .van-pull-refresh {
      padding: 0 0.25rem;
    }
  }
  .history-content-wrap {
    padding: 0 0.3rem;
  }
}
.pay-pop {
  background: linear-gradient(to bottom, #e7e3fe, #d6e7fc, $mainTxtColor1);
  border-top-left-radius: 0.3rem;
  border-top-right-radius: 0.3rem;
  font-size: 0.36rem;
  text-align: center;
  font-weight: 600;
  .content {
    span {
      display: block;
      padding: 0.3rem 0;
    }
    .btn-wrap {
      font-size: 0.28rem;
      border-top: 0.02rem solid #adadb7;
      div {
        padding: 0.3rem 0;
        &:last-child {
          background: $btnBg;
        }
      }
    }
  }
}
.nodata {
  line-height: 60vh;
  font-size: 0.26rem;
  color: #ccc;
  text-align: center;
}
</style>
