<template>
  <div class="md-mine" ref="mine">
    <!-- 头部 -->
    <van-icon class="s-nav" @click="$router.go(-1)" size="0.34rem" name="arrow-left" />
    <div class="logo-mini" @click="clickLogo">
      <img src="@/assets/imgs/header-left.png" alt="" />
    </div>
    <div class="md-mine-main">
      <div class="main-top">
        <div class="md-mine-info">
          <DecryptImg
            @click="$router.push('/mine/setting')"
            class="md-mine-photo"
            :imgURL="state.info.avatarUrl ? state.info.avatarUrl : ''"
          >
          </DecryptImg>
          <div class="md-mine-account">
            <div class="name-wrap">
              <span>
                {{ state.info.nickName }}
              </span>
              <span class="id"> {{ state.info.id }} </span>
              <span class="vip" v-if="state.info.cardName && state.isMember" @click="$router.push('/vip')">{{
                state.info.cardName
              }}</span>
              <span class="vip" v-if="!state.isMember" @click="$router.push('/vip')">VIP开通 ></span>
            </div>
          </div>
          <!-- <div class="md-mine-account">
            <div class="name">
              <span>
                {{ state.info.nickName }}
              </span>
              <span class="id"> ID:{{ state.info.id }} </span>
            </div>
            <div class="desc" v-if="state.info.cardName && state.isMember">会员卡类型：{{ state.info.cardName }}</div>
            <div class="desc" @click="goRouter('/mine/recharge')" v-if="!state.isMember">开通会员享受更多权益</div>
            <div class="desc" v-else>会员到期时间:{{ timeYmd(state.info.vipExpireTime) }}</div>
          </div> -->
        </div>

        <div class="md-mine-profile">
          <div class="md-mine-profile-item">
            <p>{{ changeGold(state.info.balance,2) }} 金币</p>
          </div>
          <div class="md-mine-profile-item">
            <p v-if="state.isMember">无限</p>
            <p v-else>免费观看剩余次数{{ state.info.leftWatchTimes }}</p>
          </div>
        </div>
      </div>

      <div class="md-mine-property-panel">
        <router-link to="/mine/my-wallet" class="md-mine-property-info">
          <img src="@/assets/imgs/mine/my-walter.png" alt="" />
          <p>我的钱包</p>
        </router-link>
        <router-link to="/mine/agent" class="md-mine-property-info">
          <img src="@/assets/imgs/mine/share.png" alt="" />
          <p>代理赚钱</p>
        </router-link>
        <router-link to="/application" class="md-mine-property-info">
          <img src="@/assets/imgs/mine/aplication.png" alt="" />
          <p>应用中心</p>
        </router-link>
        <router-link to="/mine/group" class="md-mine-property-info">
          <img src="@/assets/imgs/mine/group.png" alt="" />
          <p>交流群</p>
        </router-link>
      </div>
      <!-- 广告轮播 -->
      <!-- <JavSwiper :imgs="state.mineAD" :height="'1.2rem'" :radius="true" /> -->
      <!-- 跳转列表 -->
      <div class="md-mroe-servic">       
        <van-cell title="观看记录" is-link :to="'mine/history'">
          <!-- 使用 right-icon 插槽来自定义右侧图标 -->
          <template #icon>
            <van-icon :name="getAssetsFile('mine/watch-history.svg')" class="md-mine-icon" />
          </template>
        </van-cell>
        <van-cell title="消息列表" is-link :to="'mine/msg'">
          <div class="msg-red-dot" v-if="state.info.newMsg"></div>
          <template #icon>
            <van-icon :name="getAssetsFile('mine/msg-list.png')" class="md-mine-icon" />
          </template>
        </van-cell>        
        <van-cell title="收藏" is-link to="/mine/collect">
          <!-- 使用 right-icon 插槽来自定义右侧图标 -->
          <template #icon>
            <van-icon :name="getAssetsFile('mine/path.svg')" class="md-mine-icon" />
          </template>
        </van-cell>
        <van-cell title="购买记录" is-link to="/mine/buy-history">
          <!-- 使用 right-icon 插槽来自定义右侧图标 -->
          <template #icon>
            <van-icon :name="getAssetsFile('mine/buy-history.svg')" class="md-mine-icon" />
          </template>
        </van-cell>      
        <van-cell title="我的发布" is-link :to="'/mine/my-publish'">
          <!-- 使用 right-icon 插槽来自定义右侧图标 -->
          <template #icon>
            <van-icon :name="getAssetsFile('mine/my-public.svg')" class="md-mine-icon" />
          </template>
        </van-cell>
        <van-cell title="商务联系" is-link to="mine/setting/kf">
          <!-- 使用 right-icon 插槽来自定义右侧图标 -->
          <template #icon>
            <van-icon :name="getAssetsFile('mine/kf.svg')" class="md-mine-icon" />
          </template>
        </van-cell> 
        <van-cell title="找回账号" is-link :to="'/mine/setting/accoutCode-camera'">
          <!-- 使用 right-icon 插槽来自定义右侧图标 -->
          <template #icon>
            <van-icon :name="getAssetsFile('mine/find-account.png')" class="md-mine-icon" />
          </template>
        </van-cell>                        
        <van-cell title="兑换码" is-link to="/mine/redemption-code">
          <!-- 使用 right-icon 插槽来自定义右侧图标 -->
          <template #icon>
            <van-icon :name="getAssetsFile('mine/code.svg')" class="md-mine-icon" />
          </template>
        </van-cell>
        <van-cell title="切换账号" is-link :to="'mine/setting/phone'">
          <!-- 使用 right-icon 插槽来自定义右侧图标 -->
          <template #icon>
            <van-icon :name="getAssetsFile('mine/bind-phone.png')" class="md-mine-icon" />
          </template>
        </van-cell>            
      </div>
    </div>
    <!-- <van-popup v-model:show="state.showAccountImgBtn" @close="closeAccountImg">
      <div class="account-img" v-if="state.showAccountImgBtn">
        <h2>防止账号丢失</h2>
        <p>请您保存账号凭证</p>
        <div class="qrcode-warp">
          <qrcode-vue class="qrcode" :value="state.qrCode" level="H" :size="130" />
        </div>
        <div class="desc van-ellipsis">永久域名 {{ state.ldyCdn }}</div>
      </div>
      <div class="bottom-btn" v-if="state.showAccountImgBtn">
        <van-button class="btn" @click="saveImg" color="#ff5710">立即保存</van-button>
      </div>
    </van-popup> -->
  </div>
</template>
<script setup name="minePage">
import { showToast } from 'vant'
import { useStore } from 'vuex'
const store = useStore()
// 处理参数类型
import { handleURlParams, handleParamsRouteJump , getAssetsFile} from '@/utils/utils_tools'
import { changeGold  , timeYmd} from '@/utils/filter'  
import { userQrcode, userInfo } from '@/api/user'
import QrcodeVue from 'qrcode.vue'
import axios from 'axios'
const router = useRouter()

const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const Header = defineAsyncComponent(() => import('@/components/Header.vue'))
const JavSwiper = defineAsyncComponent(() => import('@/components/JavSwiper.vue'))

const state = reactive({
  web: '',
  app: '',
  qrCode: '',
  backup: '',
  showAccountImgBtn: false,
  ldyCdn:computed(() => store.getters['ldyCdn']),
  mineAD:computed(() => store.getters['mineAD']),
  info:computed(() => store.getters['getUserInfo']),
  isMember:computed(() => store.getters['isMember']),
  showAccountImg:computed(() => store.state.user.showAccountImg),
  isSaveImg:computed(() => store.state.user.isSaveImg),
})

const getUserInfo = async () =>{
  const res = await userInfo()
  if (res && res.code === 200) {
    store.dispatch('setUserInfo', res.data)
  }
}

const clickLogo = () =>{
  router.push('/')
}

const goRouter = (path = '/') =>{
  router.push(path)
}

// 点击顶部轮播图广告
const clickTopSwiperSlide = (item) =>{
  if (item.href) {
    const type = handleURlParams(item.href)
    handleParamsRouteJump(code)
  }
}

const getUerQrcode = async (item) =>{
  const res = await userQrcode()
  if (res && res.code === 200) {
    state.web = res.data.web
    state.app = res.data.app
    state.qrCode = res.data.value
    state.backup = res.data.backup
  }
}

// 保存图片
const saveImg = () =>{
  axios
    .get('/hqcredentials.png', {
      params: {
        inviteUrl: state.qrCode,
        domain: state.ldyCdn
      }
    })
    .then(res => {
      closeAccountImg()
      if (res.status === 200) {
        state.base64Url = res.data.base64
        try {
          const eleLink = document.createElement('a')
          eleLink.href = res.data.base64
          eleLink.download = `来自${state.info.nickName}的个人凭证.png`
          document.body.appendChild(eleLink)
          eleLink.click()
          document.body.removeChild(eleLink)
          // 记录是否保存过图片，如果保存过了，则不再弹出保存弹窗
          store.commit('isSaveImg', true)
          state.closeAccountImg()
        } catch (err) {
          console.log(err)
          console.log('保存失败')
        }
      } else {
        showToast(res.tip)
      }
    })
} 

// 下载图片
const download = (href) =>{
  const eleLink = document.createElement('a')
  eleLink.href = href
  eleLink.setAttribute('download',  `来自${state.info.nickName}的个人凭证.png`)
  document.body.appendChild(eleLink)
  eleLink.click()
  document.body.removeChild(eleLink)
  closeAccountImg()
}

const closeAccountImg = (href) =>{
  store.commit('SET_ACCOUNT_IMG', false)
}

onMounted(async () => {
  getUserInfo()
  state.showAccountImgBtn = state.showAccountImg && !state.isSaveImg
  // await getUerQrcode()  
})

</script>
<style lang="scss" scoped>
.s-nav,
.logo-mini {
  display: none;
}
.md-mine {
  max-width: $pcMaxWidth;
  margin: 0 auto;
  min-height: 100vh;
  position: relative;
  padding: 0.1rem 0.25rem 1.2rem 0.25rem;

  .md-mine-main {
    max-width: 760px;
    margin: 0 auto;
  }
  .header-right-wrap {
    .search {
      font-size: 0.24rem;
      color: $mainTxtColor1;
    }
  }
  .main-top {
    background-image: url('../../assets/imgs/mine/bg_mine_agent_level.png');
    background-size: contain;
    background-repeat: no-repeat;
    border-radius: 0.14rem;
    box-shadow: $shadow;
    background-position: 50% 0;
    margin-top: 0.2rem;
    color: $mainTxtColor1;
    .md-mine-info {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      margin-top: 1rem;
      .md-mine-photo {
        width: 1.5rem;
        height: 1.5rem;
        margin-top: -0.75rem;
        border-radius: 50%;
        overflow: hidden;
        border: 2px red solid;
      }
      .md-mine-account {
        padding-top: 0.1rem;
        .name-wrap {
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 0.3rem;
          font-weight: 600;
          .id {
            margin: 0 0.05rem;
          }
          .vip {
            display: inline-block;
            background: #767676;
            border-radius: 999px;
            padding: 0 0.1rem;
            font-size: 0.18rem;
          }
        }
      }
    }
    .md-mine-profile {
      position: relative;
      top: 0.2rem;
      display: flex;
      justify-content: center;
      padding: 0.1rem 0.3rem 0 0.3rem;
      .md-mine-profile-item {
        height: 0.6rem;
        &:first-child {
          margin-right: 0.3rem;
        }

        p {
          font-size: 0.26rem;
          font-weight: normal;
          font-stretch: normal;
          font-style: normal;
          color: #b8b8b8;
          margin: 0;
        }
      }
    }
  }
  .md-mine-property-panel {
    padding: 0.38rem 0.2rem;
    margin: 0.2rem 0;
    background: $mainBgColor;
    border-radius: 0.14rem;
    box-shadow: $shadow;
    @include flexbox($jc: space-around, $ai: center, $fd: row, $fw: nowrap);
    a {
      color: $mainTxtColor1 !important;
    }
  }
  :deep(.md-mroe-servic){
    background: $mainBgColor;
    border-radius: 0.14rem;
    box-shadow: $shadow;
    margin-top: 0.3rem;
    .van-cell {
      background-color: transparent;
      font-size: 0.28rem;
      font-weight: normal;
      font-stretch: normal;
      font-style: normal;
      text-align: left;
      padding: 0.3rem 0.4rem 0.2rem 0.4rem;
      color: $mainTxtColor1;
    }

    .van-cell::after {
      display: none !important;
    }
    .van-cell:nth-child(3)::after {
      display: block !important;
    }
    .van-cell__value{
      position: static;
    }


    .md-mine-icon {
      font-size: 0.28rem;
      padding: 0.05rem 0;
      img {
        width: 0.36rem;
        height: 0.36rem;
        object-fit: contain;
        margin-right: 0.26rem;
      }
    }
    .van-cell:nth-child(4)::after {
      left: 0;
      right: 0;
      border-bottom: 1px solid #666666;
    }
    .msg-red-dot{
      position: absolute;
      width: 0.1rem;
      height: 0.1rem;
      border-radius: 50%;
      background: #e64b3b;
      left: 2.3rem;
    }
  }

  &-activity {
    padding: 0.2rem 0.3rem 0 0.3rem;
    img {
      width: 100%;
      object-fit: contain;
    }
  }

  &-property-info {
    text-align: center;
    display: flex;
    flex-flow: column nowrap;
    align-items: center;
    justify-content: center;
    img {
      width: 0.8rem;
      height: 0.8rem;
      margin-bottom: 0.25rem;
      object-fit: contain;
    }
    p {
      font-size: 0.22rem;
      font-weight: normal;
      font-stretch: normal;
      font-style: normal;

      text-align: left;
      margin: 0 0;
      padding: 0 0;
    }
  }

  .tag {
    font-size: 0.38rem;
    margin: 0 0.1rem;
    position: relative;
    top: 0.05rem;
  }
  .account-img {
    h2 {
      font-size: 0.58rem;
      margin: 0;
    }
    p {
      font-size: 0.43rem;
      margin: 0;
    }
    width: 6rem;
    height: 8rem;
    color: $mainTxtColor1;
    background-image: url('../../assets/imgs/mine/mine-bg.svg');
    background-size: contain;
    background-repeat: no-repeat;
    text-align: center;
    display: flex;
    flex-flow: column wrap;
    justify-content: center;
    align-items: center;
    .qrcode-warp {
      margin: 0.5rem;
      padding: 0.1rem;
    }
    .qrcode {
      height: 130px;
    }
    .desc {
      font-size: 0.28rem;
      font-weight: 400;
    }
  }
  .bottom-btn {
    width: 100%;
    text-align: center;
    .btn {
      width: 4.2rem;
      height: 0.7rem;
      line-height: 0.7rem;
      border-radius: 0.3rem;
      font-size: 0.32rem;
      font-weight: 600;
      color: $mainTxtColor1;
    }
  }
  :deep()  {
    .van-popup {
      background-color: transparent;
    }
  }
}
@media screen and (min-width: 750px) {
  .s-nav {
    display: block !important;
    cursor: pointer;
    position: absolute;
    z-index: 999;
    left: 0.28rem;
    top: 0.28rem;
  }
  .s-nav {
    left: 0.28rem;
  }
  .logo-mini {
    cursor: pointer;
    position: absolute;
    right: 0.28rem;
    top: 0.28rem;
    z-index: 999;
    display: block !important;
    width: 2rem;
    height: 0.5rem;
    font-size: 0;
    margin-right: 0.3rem;
    img {
      width: 100%;
      height: 100%;
    }
  }
}
</style>

