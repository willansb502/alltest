<template>
  <div class="message-container">
    <LayoutsHeader title="系统公告"></LayoutsHeader>
    <PullUp
      @refreshData="refreshData"
      @moreData="moreData"
      :finished="state.finished"
      :loading="state.loading"
      :refreshing="state.refreshing"
      :skeleton="state.skeleton"
    >
      <ul class="message-listWrap">
        <li class="item" :key="index" v-for="(item, index) in state.tipList">
          <div class="top">
            <div>
              <img src="@/assets/imgs/mine/message.png" alt="" />
              官方通知
            </div>
            <div>
              {{ item.createdAt.split('T')[0] }}
            </div>
          </div>
          <div class="bottom">
            <div>{{ item.title }}</div>
            <div>{{ item.content }}</div>
          </div>
        </li>
      </ul>
    </PullUp>
  </div>
</template>
<script setup>
import { message_list } from '@/api/user'
import { showToast } from 'vant'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const state = reactive({
  tipList: [],
  // 当前页
  pageNum: 1,
  // 当前个数
  pageSize: 5,
  // 上拉加载
  loading: false,
  // 上拉加载完成
  finished: false,
  // 下拉刷新
  refreshing: false,
  skeleton: false
})

// 获取消息列表
const get_tipList =async () =>{
  try {
    const res = await message_list({
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      state.refreshing = false
      state.loading = false
      state.tipList = [...state.tipList, ...res.data.list]
      if (!res.data.list ||( res.data && res.data.list.length < state.pageSize)) {
        state.finished = true
      }
    } else {
      state.refreshing = false
      state.loading = false
      state.finished = true
      showToast(res.tip)
    }
  } catch (error) {
    state.refreshing = false
    state.loading = false
    state.finished = true
    console.log(error)
  }
}

// 下拉加载
const moreData =(loading) =>{
  state.loading = loading
  state.pageNum++
  get_tipList()
}

// 上拉刷新
const refreshData =(refreshing) =>{
  state.refreshing = refreshing
  state.loading = true
  state.finished = false
  state.pageNum = 1
  state.tipList = []
  state.skeleton = true
  get_tipList()
}

onMounted(() => {
  refreshData()
}) 


</script>
<style lang="scss" scoped>
.message-container {
  padding: 1rem 0;

  min-height: 100vh;
  box-sizing: border-box;
  .message-listWrap {
    margin: 0.3rem 0;
    .item {
      display: flex;
      flex-direction: column;
      font-size: 0.24rem;
      align-items: center;
      padding: 0.16rem 0.25rem;
      margin: 0.3rem 0.3rem;
      box-shadow: $shadow;
      .top {
        width: 100%;
        @include flexbox();
        img {
          width: 0.5rem;
          height: 0.45rem;
        }
        div {
          &:first-child {
            @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: wrap);
            padding-bottom: 0.22rem;
            img {
              margin-right: 0.1rem;
            }
          }
          &:last-child {
            color: #9493b1;
          }
        }
      }
      .bottom {
        div {
          &:first-child {
            font-size: 0.28rem;
            text-align: center;
            padding-bottom: 0.2rem;
          }
          &:last-child {
            font-size: 0.24rem;
            color: #9493b1;
            white-space: pre-line;
          }
        }
      }
    }
    .item-title {
      font-size: 0.32rem;
      padding-left: 0.3rem;
      padding-top: 0.15rem;
    }
  }
}
</style>
