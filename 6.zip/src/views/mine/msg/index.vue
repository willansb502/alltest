<template>
  <div class="message-container">
    <LayoutsHeader title="消息中心"></LayoutsHeader>
    <PullUp
      @refreshData="refreshData"
      @moreData="moreData"
      :finished="state.finished"
      :loading="state.loading"
      :refreshing="state.refreshing"
      :skeleton="state.skeleton"
    >
      <ul class="message-listWrap">
        <li class="item" @click="$router.push('/mine/msg/ads')" >
          <div class="left">
            <img src="@/assets/imgs/mine/message.png" alt="" />
          </div>
          <div class="right">
            <div>系统公告</div>
            <div>{{ state.lastSystemMsg }}</div>
          </div>
        </li>
        <!-- <li class="item" @click="$router.push('/mine/setting/kf')">
          <div class="left">
            <img src="@/assets/imgs/mine/message.png" alt="" />
          </div>
          <div class="right">
            <div>在线客服</div>
            <div>客服小姐姐等你撩哦！</div>
          </div>
        </li> -->
        <li class="item-title">私信列表</li>
        <li
          class="item"
          v-for="item in state.sessionList"
          :key="item.id"
          @click="
            $router.push({
              path: `/oneSession/${item.peerId}`,
              query: { 
                userName: item.nickName,
                avatar: item.avatar
              }
            })
          "
        >
          <div class="left">
            <DecryptImg class="avatary" :imgURL="item.avatar" />
          </div>
          <div class="right">
            <div class="nickName">
              <div>{{ item.nickName }}</div>
              <div class="count" v-if="item.count">{{item.count}}</div>
            </div>
            <div>{{ item.lastText }}</div>
          </div>
        </li>
      </ul>
    </PullUp>
  </div>
</template>
<script setup>
import { showToast } from 'vant'
import { message_dialog } from '@/api/user'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))

const state = reactive({
  // 当前页
  pageNum: 1,
  // 当前个数
  pageSize: 10,
  lastSystemMsg: '',
  // 会话列表
  sessionList: [],
  skeleton: false,
  refreshing: false, // 下拉刷新开关
  loading: false, // 上拉加载
  finished: false // 上拉加载开关
})
// 获取私信列表
const get_sessionList =async () =>{
  try {
    const res = await message_dialog({
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      state.refreshing = false
      state.loading = false
      res.data.dialoglist.forEach(element => {
        if(!element.avatar) element.avatar="image/ep/rb/197/wl/2064cf576fc710d00a200c99f8012f88.jpg";
      });
      state.sessionList = [...state.sessionList, ...res.data.dialoglist]
      state.lastSystemMsg = res.data.lastSystemMsg
      if (res.data.dialoglist < state.pageSize || !res.data.dialoglist) {
        state.finished = true
      }
    } else {
      state.loading = false
      state.refreshing = false
      state.finished = true
      return showToast(res.tip)
    }
  } catch (error) {
    state.loading = false
    state.refreshing = false
    state.finished = true
    console.log(error)
  }
}
// 下拉刷新
const refreshData =(refreshing) =>{
  state.refreshing = refreshing
  state.loading = true
  state.finished = false
  state.pageNum = 1
  state.skeleton = true
  state.sessionList = []
  get_sessionList()
}

// 上拉加载
const moreData =(loading) =>{
  state.loading = loading
  state.pageNum += 1
  get_sessionList()
}

onMounted(() => {
  refreshData()
}) 

</script>
<style lang="scss" scoped>
.message-container {
  padding-top: 1rem;
  .message-listWrap {
    .item {
      display: flex;
      font-size: 0.24rem;
      align-items: center;
      padding: 0.16rem 0.25rem;
      margin: 0.3rem 0.3rem;
      box-shadow: $shadow;
      .left {
        margin-right: 0.34rem;
        align-items: center;
        display: flex;
        flex-direction: column;
        img,
        .avatary {
          width: 0.95rem;
          :deep()  {
            img{
              border-radius:50% ;
            }            
          }

        }
      }
      .right {
        .nickName {
          display: flex;
          &:first-child {
            font-size: 0.28rem;
            padding-bottom: 0.09rem;
          }
          .count{
            color: #e64b3b;
            width: 0.3rem;
            height: 0.3rem;
            line-height: 0.3rem;
            text-align: center;
            border-radius: 50%;
            font-size: 0.24rem;
          }
        }
      }
    }
    .item-title {
      font-size: 0.32rem;
      padding-left: 0.3rem;
      padding-top: 0.15rem;
    }
  }
}
</style>
