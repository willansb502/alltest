<template>
  <div class="publish">
    <LayoutsHeader :title="'我的发布'" />
    <JavTab
      @change="change"
      :sticky="true"
      :titles="state.cartoonCategory"
      :active="state.indexActive"
      :animated="false"
      :addClass="'mine-tab'"
    >
      <PullUp
        @refreshData="refreshData"
        @moreData="moreData"
        :finished="state.finished"
        :loading="state.loading"
        :refreshing="state.refreshing"
        :skeleton="state.skeleton"
        class="myPublissh-pullup"
        v-if="state.articleListData && state.articleListData.length > 0"
      >
        <CommunityDefault
          v-for="(item, index) in state.articleListData"
          :key="index"
          :itemData="item"
          :status="item.base.status"
        >
          <template v-slot:decialBtn> </template>
        </CommunityDefault>
      </PullUp>
      <Nodata :text="'您还没有发布哦～'" v-else />
    </JavTab>
  </div>
</template>
<script setup>
import { publish_list, publish_del } from '@/api/user'
import { showToast } from 'vant'
import { useStore } from 'vuex'
const store = useStore()
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const PullUp = defineAsyncComponent(() => import('@/components/PullUp.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const CommunityDefault = defineAsyncComponent(() => import('@/components/Community/default.vue'))
const Nodata = defineAsyncComponent(() => import('@/components/JavNodata.vue'))
const JavTab = defineAsyncComponent(() => import('@/components/JavTab.vue'))

const state = reactive({
  //上拉加载
  loading: false,
  //上拉加载完成
  finished: false,
  //下拉刷新
  refreshing: false,
  //文章列表
  articleListData: [],
  indexActive: 1,
  skeleton: false,
  //当前页
  pageNum: 1,
  // 当前个数
  pageSize: 5,
  cartoonCategory: [
    { id: 1, name: '帖子' },
    { id: 2, name: '上门' }
  ]
})

//切换
const change =(id) =>{
  state.indexActive = +id
  refreshData()
}
//下拉加载
const moreData =(loading) =>{
  state.loading = loading
  state.pageNum++
  getList()
}
//上拉刷新
const refreshData =(refreshing) =>{
  state.refreshing = refreshing
  //表示处于可以下拉状态
  state.finished = false
  state.loading = true
  state.pageNum = 1
  state.skeleton = true
  state.articleListData = []
  getList()
}

//获取列表
const getList =async () =>{
  try {
    const res = await publish_list({
      type: state.indexActive,
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      state.refreshing = false
      state.loading = false
      if (state.indexActive === 1) {
        state.articleListData = [...state.articleListData, ...res.data.postList]
        if (!res.data.postList || (res.data.postList && res.data.postList.length < state.pageSize)) {
          state.finished = true
        }
      } else {
        state.articleListData = [...state.articleListData, ...res.data.modelList]
        if (res.data.modelList && res.data.modelList.length < state.pageSize) {
          state.finished = true
        }
      }
    } else {
      showToast(res.tip)
      state.refreshing = false
      state.loading = false
      state.finished = true
    }
  } catch (error) {
    state.refreshing = false
    state.loading = false
    state.finished = true
    console.log(error)
    showToast('请求错误，请稍后再试！')
  }
}

onMounted(() => {
  //切换页面初始化
  refreshData()
}) 

</script>
<style lang="scss" scoped>
.publish {
  padding: 1rem 0;
  color: #333;
  min-height: 100vh;
  background: $mainBgColor;
  max-width: $pcMaxWidth;
  margin: 0 auto;
  :deep()  {
    .van-pull-refresh {
      padding: 0 0.25rem;
    }
  }
}
</style>
