<template>
  <div class="recharge">
    <LayoutsHeader :title="'钱包'" @onClickRight="onClickRight">
      <template v-slot:right>
        <div class="right-btn" name="right">流水记录</div>
      </template>        
    </LayoutsHeader>
    <!-- 账户余额 -->
    <div class="user-gold">
      <p>账户余额</p>
      {{ changeGold(state.userInfo.balance,2) }}
    </div>
    <!-- 账户余额类型 -->
    <ul class="my-moeny-type">
      <li>
        <div class="top">
          <span class="bg">绑定金币</span>
          <span class="tip">充值及福利任务奖励</span>
        </div>
        <span class="balance"> {{ changeGold(state.userInfo.recharge,2) }}</span>
      </li>
      <li>
        <div class="top">
          <span class="tip">打赏及推广金币</span>
          <span class="bg">钱包余额</span>
        </div>
        <span class="balance"> {{ changeGold(state.userInfo.income,2) }}</span>
      </li>
    </ul>
    <!-- 主题内容 -->
    <div class="recharge-main">
      <!-- 提现按钮 -->
      <div class="withdraw-btn" @click="$router.push('/mine/withdraw')">提现</div>
      <!-- 选择金币类型 -->
      <div class="gold-list">
        <span class="title">购买金币</span>
        <ul class="check-type">
          <li
            v-for="(item, index) in state.priceList"
            :class="{ active: state.active === index }"
            @click="changeActive(index)"
            :key="item.id"
          >
            <div class="top-text">
              <img src="@/assets/imgs/index/gold.png" alt="" />
              {{ changeGold(item.payAmount,2) }}
            </div>
            <p class="name">{{ item.name }}</p>
          </li>
        </ul>
      </div>

      <!-- 底部支付按钮 -->
      <div class="footer-btn" @click="showPopFn">立即支付订单</div>
    </div>

    <!-- 底部支付弹窗 -->
    <van-popup v-model:show="state.showPop" position="bottom" :style="{ height: '50vh' }" class="submit-pop">
      <div class="content">
        <div class="title">
          请选择支付方式
          <div>
            支付问题遇到问题？请联系
            <span @click="$router.push('/mine/setting/kf')">在线客服</span>
          </div>
        </div>
        <ul class="pay-list">
          <li :key="index" v-for="(item, index) in state.activeData.rchgType" @click="fn_sel(item.type)" class="item">
            <div class="left" v-if="item.type == 'alipay'">
              <img src="@/assets/imgs/mine/zfb.png" alt="" />{{ item.typeName }}
            </div>
            <div class="left" v-if="item.type == 'wechat'">
              <img src="@/assets/imgs/mine/weChat.png" alt="" />{{ item.typeName }}
            </div>
            <div class="left" v-if="item.type == 'overage'">
              <img src="@/assets/imgs/mine/gold.png" alt="" />{{ item.typeName }}
            </div>
            <div class="left" v-if="item.type == 'union'">
              <img src="@/assets/imgs/mine/bank.png" alt="" />{{ item.typeName }}
            </div>
            <div class="right">
              <div class="active" v-if="item.type == state.payMode"></div>
            </div>
          </li>
        </ul>
        <div class="tip-wrap">
          支付提示：<br />
          1、出现支付风险提示不要担心，重新支付即可<br />
          2、当支付通道无法付款，请选择其他方式<br />
          3、付款如遇到其他问题，可咨询在线客服处理
        </div>
        <div class="submit" @click="fn_submit">
          <div>确认支付</div>
        </div>
      </div>
    </van-popup>
  </div>
</template>

<script setup>
import { changeGold } from '@/utils/filter'  
import { paytypeinfo, recharge_sumbit } from '@/api/home'
import { showToast , showLoadingToast } from 'vant'
const router = useRouter()
const route = useRoute()
import { useStore } from 'vuex'
const store = useStore()
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const state = reactive({
  priceList: [],
  active: 0,
  activeData: {},
  showPop: false,
  payMode: '',
  userInfo:computed(() => store.getters['getUserInfo'])
})
// 消费记录
const onClickRight =() => {
  router.push(`/mine/recharge/record`)
}
// 获取购买金币列表
const getPaytypeinfo =async () => {
  const res = await paytypeinfo({})
  if (res.code === 200) {
    state.priceList = res.data.payModes
  } else {
    showToast(res.tip)
  }
}
// 打开底部弹窗
const showPopFn =() => {
  if(state.activeData.rchgType&&!state.activeData.rchgType.length){
    return showToast(state.activeData.name+'渠道已关闭，请选择其他金额')
  }
  state.showPop = true;
}
// 切换卡片类型
const changeActive =(index) => {
  state.active = index
  state.activeData = state.priceList[index]
  if (state.activeData.rchgType && state.activeData.rchgType.length !== 0) {
    state.payMode = state.activeData.rchgType[0].type
  }
}
// 选择支付方式   
const fn_sel =(type) => {
  state.payMode = type
}   
// 支付金币 
const fn_submit =async () => {
  if (!state.payMode) return showToast('请选择支付通道！！！')
  showLoadingToast({
    duration: 0,
    message: '跳转中请稍后'
  })
  const res = await recharge_sumbit({
    payAmount: state.activeData.payAmount,
    payMode: state.payMode,
    productId: state.activeData.id,
    rchgUse: state.activeData.rchgUse
  })
  if (res.code === 200) {
    
    state.showPop = false
    if (!res.data) return showToast('购买成功！！！')
    if (res.data && res.data.isOpenNewBrowser) {
      downloadFileByTagA(res.data.payUrl)
    }
  } else {
    showToast(res.tip)
  }
}   
/* 利用a标签跳转safari浏览器机制 */
const downloadFileByTagA =(fileUrl) => {
  const TagA = document.createElement('a')
  TagA.href = fileUrl
  // TagA.target = '__blank';
  TagA.className = 'oInput'
  TagA.style.display = 'none'
  // 兼容ios safari浏览器
  const e = document.createEvent('MouseEvent')
  e.initEvent('click', false, false)
  TagA.dispatchEvent(e)
}

onMounted(async () => {
  await getPaytypeinfo()
  if (state.priceList && state.priceList.length > 0) {
    state.activeData = state.priceList[0]
    if (state.activeData.rchgType && state.activeData.rchgType.length !== 0) {
      state.payMode = state.activeData.rchgType[0].type
    }
  }
}) 
</script>

<style lang="scss" scoped>
.recharge {
  max-width: 640px;
  margin: 0 auto;
  min-height: 100vh;
  padding-top: 1rem;
  background: linear-gradient(to bottom, #44495e, #303145);
  color: $mainTxtColor1;
  :deep()  {
    .LayoutsHeader {
      .van-nav-bar {
        background: transparent;
        border: none;
        .van-icon-arrow-left,
        .van-nav-bar__title {
          color: $mainTxtColor1 !important;
        }
      }
    }
  }
  .right-btn {
    border: 1px solid $mainTxtColor1;
    border-radius: 0.37rem;
    font-size: 0.24rem;
    height: 0.48rem;
    width: 1.4rem;
    text-align: center;
    line-height: 0.48rem;
  }
  .user-gold {
    font-size: 0.7rem;
    font-weight: 600;
    text-align: center;
    margin: 0.6rem 0 0.48rem 0;
    p {
      font-size: 0.24rem;
      font-weight: 400;
      margin: 0;
    }
  }
  .recharge-main {
    background: $mainBgColor;
    padding-top: 0.4rem;
    color: #848494;
    font-size: 0.35rem;
    min-height: calc(100vh - 4.16rem);
    .withdraw-btn {
      background: $btnBg;
      box-shadow: $shadow;
      width: 3.2rem;
      height: 0.74rem;
      text-align: center;
      line-height: 0.74rem;
      margin: 0 auto;
      color: $mainTxtColor1;
      font-size: 0.36rem;
      border-radius: 0.05rem;
    }
    .gold-list {
      box-shadow: $shadow;
      margin: 0.4rem 0.15rem 0.9rem 0.15rem;
      padding: 0.2rem;
      border-radius: 0.05rem;
      .title {
        font-size: 0.33rem;
        color: #fff;
        font-weight: 600;
      }
      ul {
        @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: wrap);
        justify-content: space-between;
        li {
          width: 30%;
          height: 1.2rem;
          border: 0.01rem solid #707070;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          margin-right: 0.2rem;
          margin-top: 0.15rem;
          border-radius: 0.05rem;
          padding: 0.16rem 0;
          p {
            margin: 0;
          }

          .top-text {
            color: #fff;
            @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: wrap);
            img {
              margin-right: 0.15rem;
              width: 0.37rem;
              height: 0.37rem;
            }
          }
          .name {
            transform: scale(0.7);
          }
        }
        li:nth-child(3n) {
          margin-right: 0;
        }
        .active {
          background: linear-gradient(to bottom, #fd9c3a, #fc342d);
          color: $mainTxtColor1;
          border: none;
        }
      }
    }
  }
  //账户余额类型
  .my-moeny-type {
    @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
    font-size: 0.2rem;
    box-shadow: $shadow;
    li {
      background: #656673;
      width: 50%;
      text-align: center;
      .top {
        text-align: right;
        .tip {
          margin-top: 0.1rem;
          display: inline-block;
          color: #f8d75e;
        }
        .bg {
          margin-left: 0.1rem;
          background: $btnBg;
          color: #fff;
          padding: 0.04rem 0.12rem;
          font-size: 0.24rem;
          border-bottom-left-radius: 0.12rem;
        }
      }
      .balance {
        font-size: 0.56rem;
        font-weight: 600;
        margin-top: 0.12rem;
        display: inline-block;
        @include textoverflow();
      }
    }
    li:first-child {
      border-right: 0.01rem solid $mainTxtColor1;
      .top {
        text-align: left;
      }
      .bg {
        margin-right: 0.1rem;
        margin-left: 0;
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0.12rem;
      }
    }
  }
  // 会员卡类型

  // 底部按钮
  .footer-btn {
    width: 6.3rem;
    margin: 0 auto;
    height: 0.9rem;
    color: $mainTxtColor1;
    background: $btnBg;
    text-align: center;
    font-weight: 600;
    line-height: 0.9rem;
    border-radius: 0.05rem;
  }

  // 弹窗
  .submit-pop {
    max-width: 640px;
    left: 0;
    right: 0;
    margin: 0 auto;
    background: $mainBgColor;
    border-top-left-radius: 0.15rem;
    border-top-right-radius: 0.15rem;
    padding: 0.7rem 0.3rem;
    .title {
      font-size: 0.28rem;
      display: flex;
      align-items: center;
      color: #fff;
      margin-bottom: 0.48rem;
      div {
        color: #666;
        font-size: 0.26rem;
        margin-left: 0.1rem;
      }
      span {
        color: #ed9200;
        font-weight: 600;
      }
    }

    // 支付方式
    .item {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .left {
      display: flex;
      align-items: center;
      font-size: 0.28rem;
      color: #fff;
      img {
        width: 0.7rem;
        height: 0.7rem;
        margin-right: 0.33rem;
      }
    }
    // 选中状态
    .right {
      width: 0.28rem;
      height: 0.28rem;
      border-radius: 50%;
      border: 0.02rem solid #ed9200;

      position: relative;
      .active {
        width: 0.2rem;
        height: 0.2rem;
        background: #ed9200;
        border-radius: 50%;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
      }
    }
    .tip-wrap {
      font-size: 0.24rem;
      color: #ed9200;
      margin-top: 0.5rem;
      margin-right: 0.7rem;
    }
    // 支付按钮
    .submit {
      width: 2.1rem;
      height: 0.68rem;
      text-align: center;
      line-height: 0.68rem;
      background-image: linear-gradient(to right, #ffd89d, #e4a760);
      color: #431100;
      font-size: 0.3rem;
      border-radius: 0.4rem;
      margin: 0 auto;
      margin-top: 0.6rem;
    }
  }
}
@media screen and (max-width: 960px) {
  .top-text {
    font-size: 0.28rem;
  }
}
</style>
