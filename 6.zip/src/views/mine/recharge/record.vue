<template>
  <div class="record-container">
    <LayoutsHeader title="流水记录"></LayoutsHeader>
    <van-pull-refresh v-if="state.transList && state.transList.length>0" v-model="state.refreshing" @refresh="onRefresh">
      <van-list v-model:loading="state.loading" :finished="state.finished" finished-text="暂时没有更多数据！" @load="onLoad">
        <ul class="record-listWrap">
          <li class="item" v-for="(item, index) in state.transList" :key="index">
            <div class="left">
              <div>订单号：{{ item.orderNo }}</div>
              <div>{{ formatDate(item.createdAt) }}</div>
              <div>{{ item.desc }}</div>
            </div>
            <div class="right">
              <div 
                @click="onCopy(item.orderNo)"
              >
                <span>复制订单号</span>
              </div>
              <div>
                {{ changeGold(item.coinAmount,2) }}
                <img src="@/assets/imgs/index/gold.png" alt="" />
              </div>
            </div>
          </li>
        </ul>
      </van-list>
    </van-pull-refresh>
     <Nodata :text="'您还没有记录哦～'" v-else/>
  </div>
</template>
<script setup>
import useClipboard from 'vue-clipboard3'
const { toClipboard } = useClipboard()
import { showToast } from 'vant'
import { formatDate , changeGold } from '@/utils/filter'
import { transList } from '@/api/user'
const Nodata = defineAsyncComponent(() => import('@/components/JavNodata.vue'))
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const state = reactive({
  // 上拉加载（loading:false代表可继续上拉加载）
  loading: false,
  // 上拉加载完成（完成只需要出现1次，finished: true，转圈消失，加载完成字体出现）
  finished: false,
  // 下拉刷新
  refreshing: false,
  // 关注列表
  transList: [],
  // 请求类型
  getType: '',
  // 当前页
  pageNum: 1,
  // 当前个数
  pageSize: 10
})
// 获取流水记录
const get_transList =async (type) => {
  try {
    const res = await transList({
      pageNum: state.pageNum,
      pageSize: state.pageSize
    })
    if (res.code === 200) {
      state.refreshing = false
      state.loading = false
      state.transList = [...state.transList, ...res.data.list]
      if (res.data && res.data.list.length < state.pageSize) {
        state.finished = true
      }
    } else {
      // 下拉消失（自动开启下拉）
      state.refreshing = false
      state.loading = false
      state.finished = true
      showToast(res.tip)
    }
  } catch (error) {
    state.refreshing = false
    state.loading = false
    state.finished = true
    console.log(error)
    showToast('请求错误，请稍后再试！')
  }
}
// 下拉加载
const onLoad =() => {
  state.pageNum++
  get_transList()
}
// 上拉刷新
const onRefresh =() => {
  state.finished = false
  state.loading = true
  state.pageNum = 1
  state.transList = []
  get_transList()
}
// 复制
const onCopy =async (text) => {
  try {
    await toClipboard(contactInfo)
    showToast('复制成功！！！')
  } catch (e) {
    console.error(e)
  } 
}
onMounted(() => {
  onRefresh()
}) 
</script>
<style lang="scss" scoped>
.record-container {
  padding-top: 1rem;
  min-height: 100vh;

  .record-listWrap {
    margin: 0.3rem 0;
    .item {
      display: flex;
      justify-content: space-between;
      font-size: 0.24rem;
      align-items: center;
      padding: 0.16rem 0.25rem;
      background: $mainBgColor;
      margin: 0.15rem 0.3rem;
      box-shadow: $shadow;
      .left {
        display: flex;
        flex-direction: column;
        div {
          &:nth-child(2) {
            padding: 0.15rem 0;
            color: #93939e;
          }
          &:nth-child(3) {
           @include textoverflow();
          }
        }
      }
      .right {
        div {
          &:first-child {
            span {
              display: inline-block;
              width: 1.74rem;
              height: 0.5rem;
              border-radius: 0.43rem;
              background: $btnBg;
              margin-bottom: 0.53rem;
              text-align: center;
              line-height: 0.5rem;
            }
          }
          &:last-child {
            font-size: 0.32rem;
            text-align: right;
            img {
              width: 0.3rem;
              height: 0.3rem;
              margin-left: 0.1rem;
            }
          }
        }
      }
    }
  }
}
</style>
