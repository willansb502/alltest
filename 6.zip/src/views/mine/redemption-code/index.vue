<template>
  <div class="exchange-container">
    <LayoutsHeader :title="'兑换码'" />
    <van-pull-refresh   style="min-height: calc(100vh - 1rem);"  v-model="state.refreshing" @refresh="onRefresh">
      <van-list
        v-model:loading="state.loading"
        :finished="state.finished"
        :finished-text="state.redeemcodeList.length?'':''"
        @load="onLoad"
      >
      <div class="exchange-codeWrap">
        <div class="btn" @click="submitRedeemcode">提交</div>
        <input v-model="state.redeemcode" placeholder="请输入您的兑换码" type="text">
      </div>
      <ul class="exchange-listWrap">
        <li class="item item-title">
          <div class="left top">
            <div>兑换码</div>
          </div>

          <div class="center  top">
            <div>兑换类型</div>
          </div>
          <div class="right  top">
            <div>兑换时间</div>
          </div>
        </li>
        <li class="item item-decial" v-for="(item,index) in state.redeemcodeList" :key="index">
          <div class="left left-add">
            {{item.code}}
          </div>
          <div class="center center-add">
            {{item.desc}}
          </div>
          <div class="right right-add">
            {{item.activedAt.split('T')[0]}}
          </div>
        </li>
        <div class="nodata" v-if="!state.redeemcodeList.length">暂时没有数据</div>
      </ul>
      </van-list>
    </van-pull-refresh>
  </div>
</template>
<script setup>
import { showToast } from 'vant'
import { redeemcode_user, redeemcode_list } from '@/api/user'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const state = reactive({
  redeemcode: '',
  loading: false,
  finished: false,
  // 下拉刷新
  refreshing: false,
  // 兑换列表
  redeemcodeList: [],
  // 请求类型
  getType: '',
  // 当前页
  pageNum: 1,
  // 当前个数
  pageSize: 50
})
// 获取关注列表
const getRedeemcodeList =async (type) =>{
  const res = await redeemcode_list({
    pageNum: state.pageNum,
    pageSize: state.pageSize
  })
  if (res.code === 200) {
    state.refreshing = false
    state.loading = false
    if (!res.data.list) {
      res.data.list = []
    }
    if (type === 'pull') state.redeemcodeList = []
    state.redeemcodeList = [...state.redeemcodeList, ...res.data.list]
    if (res.data && res.data.list.length < state.pageSize) {
      state.finished = true
    }
  } else {
    showToast(res.tip)
    state.refreshing = false
    state.loading = false
    state.finished = true
  }
}
// 下拉加载
const onLoad = () =>{
  state.pageNum++
  getRedeemcodeList()
}

// 上拉刷新
const onRefresh = () =>{
  state.finished = false
  state.loading = true
  state.pageNum = 1
  getRedeemcodeList('pull')
}
// 提交兑换码   
const submitRedeemcode =async () =>{
  if (!state.redeemcode) return showToast('请输入兑换码！！!')
  const res = await redeemcode_user({
    code: state.redeemcode.trim()
  })
  if (res.code === 200) {
    state.redeemcode = ''
    showToast('恭喜兑换成功！！！')
    onRefresh()
  } else {
    state.redeemcode = ''
    showToast(res.tip)
  }
}

onMounted(() => {
  onRefresh()
}) 

</script>
<style lang="scss" scoped>
.exchange-container{
  max-width: 980px;
  margin: 0 auto;
  padding-top: 1rem;
  min-height: 100vh;
  box-sizing: border-box;
  background: $mainBgColor;
  .exchange-codeWrap{
    position: relative;
    box-sizing: border-box;
    padding: .5rem .3rem;
    text-align: center;
    border-radius: .09rem;
    font-size: 0;
    input{
      color: $mainTxtColor1;
      width: 100%;
      border: 0;
      outline: none;
      background: $mainBgColor;
      font-size: .26rem;
      line-height: .6rem;
      border-radius: .05rem;
      text-indent: .15rem;
      padding: .15rem;
    }
    .btn{
      color: $mainTxtColor1;
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      right: .4rem;
      padding: 0 .2rem;
      height: .6rem;
      line-height: .6rem;
      background: $btnBg;
      font-size: .26rem;
      border-radius: .05rem;
    }
  }
  .exchange-listWrap{
    margin: 0 .3rem;
    background: $mainBgColor;
    padding: .15rem .15rem .6rem .15rem;
    min-height: 70vh;
    border-radius: .1rem;
    .item{
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: .24rem;
      width: 100%;
      white-space: nowrap;
      text-align: center;
      line-height: .48rem;
      &.item-title{
        border-bottom: 1px solid #eee;
      }

      .left{
        width: 33.33%;
      }
      .center{
        width: 33.33%;
      }
      .right{
        width: 33.33%;
      }
    }
    .nodata{
      line-height: 60vh;
      font-size: .26rem;
      color: #ccc;
      text-align: center;
    }
  }
}
</style>
