<template>
  <div class="accout">
    <LayoutsHeader class="header" :title="'找回账号'" />
    <div class="accout-main">
      <div class="top">
        <p>如果您的账号丢失，可以使用以下方法找回</p>
        <p>1.使用您已经保存的账号凭证</p>
        <p>2.输入您已经绑定的手机号，接收验证码找回</p>
        <p>3.联系 <span class="top-kf" @click="toDetail('kf')">在线客服</span></p>
      </div>
      <ul class="bot">
        <li @click="toDetail('accoutCode-camera')">
          使用账号凭证找回
          <van-icon name="arrow" color="#333" size="30" />
        </li>
        <li @click="toDetail('phone')">
          使用手机号找回
          <van-icon name="arrow" color="#333" size="30" />
        </li>
        <li @click="toDetail('kf')">
          联系客服找回
          <van-icon name="arrow" color="#333" size="30" />
        </li>
      </ul>
    </div>
  </div>
</template>

<script setup>
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const router = useRouter()
const toDetail =(type) =>{
  router.push(`/mine/setting/${type}`)
}
</script>

<style lang="scss" scoped>
.accout {
  min-height: 100vh;
  background: $mainBgColor;
  font-size: 0.28rem;
  padding-top: 1rem;
  max-width: 640px;
  margin: 0 auto;
  .top {
    padding: 0.47rem 0.64rem 0 0.64rem;
    font-size: 0.24rem;
    color: #9f9fa2;
    p:first-child {
      font-weight: 600;
    }
  }
  .bot {
    padding: 0.3rem;
    li {
      padding: 0.3rem;
      border-top: 0.02rem solid #9f9fa2;

      font-size: 0.32rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    li:last-child {
      border-bottom: 0.02rem solid #9f9fa2;
    }
  }
}
.top-kf {
  color: #ff4649;
}
</style>
