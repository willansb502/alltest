<template>
  <div class="accoutCode-camera">
    <LayoutsHeader  :title="'扫描登陆'" />
    <div class="camera-box" >
      <div class="md-login-main" :class="{'isAndroid':state.isAndroid}">
        <canvas ref="canvas_scan" class="canvas" />
        <div v-if="!state.isAndroid" class="scan-view">
          <div class="line" />
          <div class="angle" />
        </div>
        <p v-if="!state.isAndroid" class="scan-desc">对准二维码即可自动识别</p>
        <p v-if="state.isAndroid" style="width:80%;text-align: center;" class="scan-desc">找到账户凭证二维码即可识别登录</p>
        

        <div class="scanning-btn">
          <div class="btn" @click="clickChoosePhone()">
            相冊
            <input
              ref="fileInput"
              type="file"
              accept="image/*"
              style="display: none"
              @change="pictureChange"
            />
            <canvas ref="qrCanvas" style="display: none" />
          </div>

          <div class="btn" @click="goCredentials">我的凭证</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { showToast,showNotify } from 'vant'
import {user_qrcode_info} from '@/api/user'
import jsQR from 'jsqr'
import qrcodeParser from "qrcode-parser";
import QrCode from 'qrcode-reader'
import { useStore } from 'vuex'
const store = useStore()
const router = useRouter()
let fileInput = ref(null)
let canvas_scan = ref(null)
const JavComment = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const state = reactive({
  loading: false,
  isAnimation: true,
  audio: Object,
  video: Object,
  cvsele: Object,
  canvas: Object,
  isAndroid:false,
  result:'',
  imgurl:'',
  popupShow:computed(() => store.state.popup.showLoginPop),
  popupInfo:computed(() => store.state.popup.popupInfo),
  token:computed(() => store.state.user.token),
  info:computed(() => store.state.user.info),
  timer:null
})

//关闭摄像头
const fn_closeTracks = () => {
  if(state.video&&state.video.srcObject&&state.video.srcObject.getTracks&&state.video.srcObject.getTracks().length){
    state.video.srcObject.getTracks().forEach((track)=>{
      track.stop();
    });        
  }
}
const toBack = () => {
  return router.go('-1')
}
const startScanning = () => {
  state.isAnimation = true
  navigator.getUserMedia =
    navigator.getUserMedia ||
    navigator.webkitGetUserMedia ||
    navigator.mozGetUserMedia ||
    navigator.msGetUserMedia
  if (navigator.mediaDevices) {
    navigator.mediaDevices
      .getUserMedia({
        video: { facingMode: 'environment' },
      })
      .then((stream) => {
        state.video.srcObject = stream
        state.video.setAttribute('playsinline', true)
        state.video.setAttribute('webkit-playsinline', true)
        state.video.addEventListener('loadedmetadata', () => {
          state.video.play()
          sweep()
        })
      })
      .catch(() => {
        cance()
        showNotify('对不起：未识别到扫描设备!')
      })
  } else if (navigator.getUserMedia) {
    navigator.getUserMedia(
      {
        video: { facingMode: 'environment' },
      },
      (stream) => {
        state.video.srcObject = stream
        state.video.setAttribute('playsinline', true)
        state.video.setAttribute('webkit-playsinline', true)
        state.video.addEventListener('loadedmetadata', () => {
          state.video.play()
          sweep()
        })
      },
      () => {
        cance()
        showNotify('对不起：未识别到扫描设备!')
      }
    )
  } else if (
    navigator.userAgent.toLowerCase().match(/chrome/) &&
    !location.origin.includes('https://')
  ) {
    showNotify(
      '获取浏览器录音功能，因安全性问题，需要在localhost 或 127.0.0.1 或 https 下才能获取权限！'
    )
  } else {
    cance()
    alert('对不起：未识别到扫描设备!')
  }
}
const sweep = () => {
  if (state.video.readyState === state.video.HAVE_ENOUGH_DATA) {
    const { videoWidth, videoHeight } = state.video
    state.cvsele.width = videoWidth
    state.cvsele.height = videoHeight
    state.canvas.drawImage(state.video, 0, 0, videoWidth, videoHeight)
    try {
      const img = state.canvas.getImageData(0, 0, videoWidth, videoHeight)

      state.imgurl = img
      const obj = jsQR(img.data, img.width, img.height, {
        inversionAttempts: 'dontInvert',
      })
      if (obj) {
        const loc = obj.location
        draw(loc.topLeftCorner, loc.topRightCorner)
        draw(loc.topRightCorner, loc.bottomRightCorner)
        draw(loc.bottomRightCorner, loc.bottomLeftCorner)
        draw(loc.bottomLeftCorner, loc.topLeftCorner)
        if (obj.data) {
          cance()
          onDecode(obj.data)
        }
      } else {
        cance()
        // showNotify('识别失败，请检查二维码是否正确！')
      }
    } catch (err) {
      showNotify('识别失败，请检查二维码是否正确！')
    }
  }
  if (state.isAnimation) {
    state.timer = requestAnimationFrame(() => {
      sweep()
    })
  }
}
const draw = (begin, end) => {
  state.canvas.beginPath()
  state.canvas.moveTo(begin.x, begin.y)
  state.canvas.lineTo(end.x, end.y)
  state.canvas.lineWidth = 3
  state.canvas.strokeStyle = 'red'
  state.canvas.stroke()
}
const cance = () => {
  state.isAnimation = false
  cancelAnimationFrame(state.timer)
}
// 跳转我的凭证
const goCredentials = () => {
  router.push('/mine/setting/accoutCode')
}
// 我的相册
const clickChoosePhone = (e) => {
  fileInput.value.click()
}
// 选择图片
const pictureChange = (e) => {
  showToast({
    message: '二维码识别中...'
  })
  const file = e.target.files[0]
  const createObjectURL =
    window.createObjectURL ||
    window.URL.createObjectURL ||
    window.webkitURL.createObjectUR
  state.result = ''
  state.imgurl = createObjectURL(file)
  fileInput.value.value = ''
  const fReader = new FileReader()
  fReader.readAsDataURL(file) // Base64 8Bit字节码
  // fReader.readAsBinaryString(file);  // Binary 原始二进制
  // fReader.readAsArrayBuffer(file);   // ArrayBuffer 文件流
  fReader.onload =async (e) => {
    const codeString= await qrcodeParser(e.target.result)
    state.result = codeString
    onDecode()
  }
}    
// 请求
const onDecode =async () => {
  if (state.result) {
    const res = await user_qrcode_info({
      value: state.result,
    })
    if (res && res.code === 200) {
      showNotify({
        color: '#ad0000',
        background: '#ffe0b5',
        type: 'success',
        message: '扫描成功，正在跳转...',
      })
      store.dispatch('setUserInfo',res.data)
      store.dispatch('setToken', res.data.token)
      router.push('/mine')
    } else {
      showNotify({
        color: '#ad0000',
        background: '#ffe0b5',
        type: 'success',
        message: res.tip,
      })
    }
  }
}
const onInit = async (promise) => {
  state.loading = true
  try {
    await promise
  } catch (error) {
    console.error(error)
  } finally {
    state.loading = false
  }
}

onMounted( () => {
  const s = document.createElement('script');
  s.type = 'text/javascript';
  s.src = 'https://g.alicdn.com/dingding/dinglogin/0.0.2/ddLogin.js';
  document.body.appendChild(s);  

  if(store.getters['getIsAnIosPhone']=="android") state.isAndroid = true;
  if(!state.isAndroid){
    nextTick(() => {
      setTimeout(() => {
        state.video = document.createElement('video')
        state.cvsele = canvas_scan
        state.canvas = state.cvsele.getContext('2d')
        startScanning()
      }, 50)
    })
  }
})
onUnmounted(() => {
  fn_closeTracks();    
  cance()
})
</script>



<style lang="scss" scoped>
.accoutCode-camera {
  min-height: 100vh;
  background: #202234;
  font-size: 0.28rem;
  color: $mainTxtColor1;
  
}
.canvas {
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  width: 100vw;
}
.scan-desc {
  position: absolute;
  top: 55%;
  left: 50%;
  font-size: 0.28rem;
  transform: translateX(-50%);
  margin-top: 15px;
}

.scan-view {
  width: 75vw;
  height: 75vw;
  max-height: 75vh;
  max-width: 75vh;
  position: absolute;
  left: 50%;
  top: 5rem;
  transform: translate(-50%, -50%);
  overflow: hidden;
  //border: 0.1rem solid rgba(255, 255, 255, 0.2);

  .line {
    height: calc(100% - 2px);
    width: 100%;
    background: linear-gradient(180deg, rgba(255, 255, 255, 0) 43%, #fff 211%);
    border-bottom: 5px solid $mainTxtColor1;
    transform: translateY(-100%);
    animation: radar-beam 2s infinite;
    animation-timing-function: cubic-bezier(0.53, 0, 0.43, 0.99);
  }

  &:before,
  &:after,
  .angle:before,
  .angle:after {
    content: '';
    display: block;
    position: absolute;
    width: 3vw;
    height: 3vw;

    border: 0.2rem solid transparent;
  }
  &:before,
  &:after {
    top: 0;
    border-top-color: $mainTxtColor1;
  }
  .angle:before,
  .angle:after {
    bottom: 0;
    border-bottom-color: $mainTxtColor1;
  }

  &:before,
  .angle:before {
    left: 0;
    border-left-color: $mainTxtColor1;
  }
  &:after,
  .angle:after {
    right: 0;
    border-right-color: $mainTxtColor1;
  }
  @keyframes radar-beam {
    0% {
      transform: translateY(-100%);
    }

    100% {
      transform: translateY(0);
    }
  }
}
.scanning-btn {
  position: absolute;
  display: flex;
  justify-content: space-between;
  align-items: center;
  left: 50%;
  top: 65%;
  transform: translate(-50%, 0);
  width: 80%;
  .btn {
    box-sizing: border-box;
    width: 40%;
    padding: 0.2rem 0;
    opacity: 0.7;
    border-radius: 0.22rem;
    border: solid 1px #ffe0b5;
    background-color: #000;
    font-size: 0.28rem;
    text-align: center;
    font-weight: normal;
    font-stretch: normal;
    font-style: normal;
    line-height: 0.88;
    color: #ffae69;
  }
}
.md-login {
  width: 100%;
  box-sizing: border-box;

  .scan-desc {
    width: 680px;
    font-size: 30px;
    margin: 20px auto;
    text-align: center;
  }
}
.isAndroid{
  .scanning-btn {
    top: 30%;
  } 
  .scan-desc {
    top: 45%;
  }   
}
</style>
