<template>
  <div class="my-code">
    <LayoutsHeader class="header" :title="'账号凭证'" />
    <div class="main" >
      <div class="new-blicredentials" ref="html2_canvas">
        <qrcode-vue class="code-img" :value="state.code" level="H"></qrcode-vue>
        <img style="width:100%;" src="@/assets/imgs/blicredentials.png" alt="">
      </div>
      
      <!-- <div class="code" ref="html2_canvas">
        <qrcode-vue class="code-img" :value="state.code" level="H"></qrcode-vue>
      </div>
      <div class="line-box">
        <div class="line"></div>
        <span>友情提示</span>
        <div class="line"></div>
      </div>
      <div class="waring">
        <p>1.请您保存二维码凭证，以便找回您的账号</p>
        <p>2.请妥善保管此账号凭证，不要随意透漏给任何人</p>
        <p>3.若账号不慎丢失，可通过APP账号安全扫取该二维码凭证登录账号</p>
      </div> -->
      <div class="footer">
        <div class="text">
          <div class="icon-bg">
            <img src="@/assets/imgs/waring-icon.svg" alt="" />
          </div>

          若保存失败，请截屏保存
        </div>
        <div class="btn" @click="clickSaveImg2">保存账号凭证</div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { showToast } from 'vant'
import { userQrcode } from '@/api/user'
import html2canvas from 'html2canvas';
import axios from 'axios'
const baseData = import.meta.env
import QrcodeVue from 'qrcode.vue'
const router = useRouter()
import { useStore } from 'vuex'
const store = useStore()
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
let html2_canvas = ref(null)
const state = reactive({
  code: '',
  web: '',
  base64Url: '',
  width: 1,
  height: 1,
  // 落地页
  ldyCdn:computed(() => store.getters['ldyCdn']),  
  info:computed(() => store.getters['getUserInfo'])
})
// 返回
const toBack =() =>{
  return router.go('-1')
}
// 获取个人二维码
const getUserCode =async () =>{
  const res = await userQrcode()
  if (res.code === 200) {
    state.code = res.data.value
    state.web = res.data.app
  } else {
    return showToast('请求失败，请稍后再试')
  }
}
// 保存图片
const clickSaveImg =() =>{
  axios
    .get(baseData.VITE_APP_nodeServeUrl+'/credentials.png', {
      params: {
        shareURL: state.code,
        domain: state.ldyCdn
      }
    })
    .then(res => {
      if (res.status === 200) {
        state.base64Url = res.data.base64
        try {
          const eleLink = document.createElement('a')
          eleLink.href = res.data.base64
          eleLink.download = `来自木偶${state.info.nickName}的个人凭证.png`
          document.body.appendChild(eleLink)
          eleLink.click()
          document.body.removeChild(eleLink)
        } catch (err) {
          console.log(err)
        }
      } else {
        showToast(res.tip)
      }
    })
}
// 下载图片
const download =(href) =>{
  const eleLink = document.createElement('a')
  eleLink.href = href
  eleLink.setAttribute('download', `来自${state.info.nickName}的个人凭证.png`)
  document.body.appendChild(eleLink)
  eleLink.click()
  document.body.removeChild(eleLink)
}
//保存图片
const clickSaveImg2 =() =>{
  if(store.getters['getIsAnIosPhone']=="android"){
    return showToast('安卓用户截图保存')
  }
  html2canvas(html2_canvas, {
    // width: state.width,
    // height: state.height,
    // backgroundColor: null,
    useCORS: true, // 解决文件跨域问题
  }).then(canvas => {
    const url = canvas.toDataURL('image/png'); // 生成的图片
    // 可以上传后端或者直接显示
    downloadIamge2(url);
  });
}

const downloadIamge2 =(url) =>{
  const a = document.createElement('a'); // 生成一个a元素
  const event = new MouseEvent('click'); // 创建一个单击事件
  a.download = `来自${state.info.nickName}的个人凭证.png`; // 设置图片名称
  a.href = url; // 将生成的URL设置为a.href属性
  a.dispatchEvent(event); // 触发a的单击事件
}

onMounted(() => {
  getUserCode()
  state.width = window.innerWidth
  state.height = window.innerHeight
}) 
</script>

<style lang="scss" scoped>
.my-code {
  min-height: 100vh;
  background: $mainBgColor;
  font-size: 0.28rem;
  padding-top: 1rem;
  .main {
    padding: 0.3rem;
    .code-img {
      width: 100%;
      height: 100%;
      :deep()  {
        canvas {
          width: 100% !important;
          height: 100% !important;
        }
      }
    }
  }
  .code {
    padding: 0.2rem;
    width: 5.1rem;
    height: 5.1rem;
    margin: 0 auto;
    background: $mainBgColor;
  }
  .logo-wrap {
    width: 100%;
    height: auto;
    @include flexbox();
    padding: 0.3rem 0;
    img {
      width: 50%;
    }
  }
  .line-box {
    color: #9493b1;
    font-size: 0.3rem;
    display: flex;
    align-items: center;
    span {
      margin: 0 0.2rem;
      white-space: nowrap;
    }
    .line {
      height: 0.02rem;
      background: #9493b1;
      width: 100%;
    }
  }
  .waring {
    font-size: 0.24rem;
    color: #9493b1;
  }
  .new-blicredentials{
    position: relative;
    .code-img{
      position: absolute;
      width: 4rem;
      height: 4rem;
      top: 3rem;
      left: 1.4rem;
      padding: 0.1rem;
      background: #fff;
    }
  }
}
.footer {
  margin-top: 0.3rem;
  .text {
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    .icon-bg {
      width: 0.35rem;
      height: 0.35rem;
      background: $btnBg;
      text-align: center;
      line-height: 0.36rem;
      border-radius: 50%;
      margin-right: 0.1rem;
      img {
        filter: brightness(80);
        width: 0.072rem;
        height: 0.226rem;
      }
    }
  }
  .btn {
    width: 6.5rem;
    height: 0.9rem;
    line-height: 0.9rem;
    font-size: 0.3rem;
    margin: 0 auto;
    margin-top: 0.33rem;
    text-align: center;
    background: $btnBg;
    border-radius: 0.46rem;
  }
}
</style>
