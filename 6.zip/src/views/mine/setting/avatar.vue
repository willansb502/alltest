<template>
  <div class="default-avatar">
    <LayoutsHeader class="header" :title="'修改头像'" @onClickRight="checkRight">
      <template v-slot:right>
        <slot name="right"> 完成 </slot>
      </template>      
    </LayoutsHeader>

    <div class="top">
      <DecryptImg class="item" :imgURL="avatarUrl" />
    </div>
    <div class="avatar-list">
      <DecryptImg @clickImg="changeImg" v-for="item in list" :key="item" :imgURL="item" class="item" />
    </div>
  </div>
</template>

<script setup>
import { showToast } from 'vant'
const route = useRoute()
import { user_avatar, update_info } from '@/api/user'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
const DecryptImg = defineAsyncComponent(() => import('@/components/DecryptImg/index.vue'))
const state = reactive({
  isMember:computed(() => store.getters['isMember']),
  list: [],
  avatarUrl: '',
  curUrl: ''  
})

onMounted(() => {
  state.avatarUrl = route.query.userAvatarUrl
  getAvatar()
}) 
// 获取头像列表
const aaa =async() =>{

}
    
    async getAvatar() {
      try {
        const res = await user_avatar()
        if (res.code === 200) {
          this.list = res.data
        } else {
          showToast(res.tip)
        }
      } catch (error) {
        console.log(error)
        showToast('请求错误，请稍后再试！')
      }
    },
    // 完成按钮
    async checkRight() {
      if (this.isMember) {
        const res = await update_info({
          avatar: this.curUrl
        })
        if (res.code === 200) {
          showToast('修改成功')
        } else {
          showToast(res.tip)
        }
      } else {
        showToast('亲，您还不是会员，不能修改噢')
      }
    },
    // 选择头像
    changeImg(item) {
      // 现在的头像路径 未解密
      this.curUrl = item
      // 已经解密的
      this.avatarUrl = item
    }


</script>

<style lang="scss" scoped>
.default-avatar {
  min-height: 100vh;
  background: #202234;
  padding-top: 1rem;
  max-width: 640px;
  margin: 0 auto;
}
.top {
  padding: 0.4rem 0;
  .item {
    width: 1.8rem;
    width: 1.8rem;
    margin: 0 auto;
    border-radius: 50%;
    :deep()  {
      .warp {
        font-size: 0;
        border-radius: 50%;
      }
    }
  }
}
.avatar-list {
  background: #27283d;
  padding: 0.54rem;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  justify-content: space-between;
  .item {
    width: 1.3rem;
    width: 1.3rem;
    margin: 0 auto 0.2rem auto;
    border-radius: 50%;
    font-size: 0;
    :deep()  {
      .warp {
        border-radius: 50%;
      }
    }
  }

  .item:last-child {
    margin-left: 0.35rem;
  }
}
.avatar-list::after {
  content: '';
  flex: auto;
  margin-left: 0.1rem;
}
</style>
