<template>
  <div class="setting">
    <LayoutsHeader class="mine-head" title="我的" @onClickRight="submit">
      <template v-slot:right>
        <slot name="right"> 保存 </slot>
      </template>
    </LayoutsHeader>
    <div class="setting-main">
      <DecryptImg
        class="avatar"
        @clickImg="$router.push(`/mine/setting/avatar?userAvatarUrl=${userAvatarUrl}`)"
        :imgURL="userAvatarUrl ? userAvatarUrl : ''"
      >
      </DecryptImg>
      <!-- 基本信息 -->
      <div class="update-info">
        <div class="name">
          <div class="lable">昵 称</div>
          <van-field maxlength="10" v-model="nickName" placeholder="请输入昵称" />
          <span class="count">{{ nickName ? nickName.length : 0 }}/8</span>
        </div>
        <div class="info">
          <div class="lable">简 介</div>
          <van-field maxlength="30" v-model="introduction" placeholder="请输入个人简介" />
          <span class="count">{{ introduction ? introduction.length : 0 }}/30</span>
        </div>
        <div class="gander">
          <div class="lable" @click="show = true">性 别</div>
          <div class="input" @click="show = true">
            {{ gender ? gender : '请选择性别' }}
          </div>
          <van-icon name="arrow" color="#9493b1" size="22" />
        </div>
        <!-- 绑定手机号 -->
        <div class="bind-phone" @click="bindPhone">
          <div class="lable">绑定手机</div>
          <van-field maxlength="30" :disabled="true" :value="oldMobile" placeholder="请输入个人简介" />
          <van-icon name="arrow" color="#9493b1" size="22" />
        </div>
        <!-- 找回账号 -->
        <div class="accout" @click="accout">
          找回账号
          <van-icon name="arrow" color="#9493b1" size="22" />
        </div>
        <!-- 账号凭证 -->
        <div class="accout-code" @click="accoutCode">
          账号凭证
          <van-icon name="arrow" color="#9493b1" size="22" />
        </div>
      </div>
      <!-- 修改性格 -->
      <van-popup v-model:show="show" position="bottom" :style="{ backgroundColor: 'transparent' }">
        <div class="title">请选择性别</div>
        <div class="content">
          <van-radio-group v-model="type" direction="horizontal">
            <van-radio name="1">男</van-radio>
            <van-radio name="2">女</van-radio>
          </van-radio-group>

          <div class="submit" @click="changeGander(type)">确认</div>
        </div>
      </van-popup>
    </div>
  </div>
</template>

<script>
import { update_info } from '@/api/user'
import { userInfo } from '@/api/user'
import { showToast } from 'vant'
export default {
  name: 'Setting',
  components: {
    DecryptImg: () => import('@/components/DecryptImg/index.vue'),
    LayoutsHeader: () => import('@/components/LayoutsHeader.vue')
  },
  computed: {
    oldMobile() {
      return this.$store.getters['getUserInfo'].mobile
    },
    newUserInfo({ $store }) {
      return $store.getters['getUserInfo']
    },
    isMember({ $store }) {
      return $store.getters['isMember']
    }
  },
  data() {
    return {
      show: false,
      type: 0,
      gender: '',
      introduction: '',
      nickName: '',
      userAvatarUrl: ''
    }
  },
  mounted() {
    this.getUserInfo()
    if (this.newUserInfo.gender === 2) {
      this.gender = '女'
    } else if (this.newUserInfo.gender === 1) {
      this.gender = '男'
    } else {
      this.gender = ''
    }
    this.type = this.newUserInfo.gender.toString()
    this.introduction = this.newUserInfo.introduction
    this.nickName = this.newUserInfo.nickName
    this.userAvatarUrl = this.newUserInfo.avatarUrl
  },
  methods: {
    async getUserInfo() {
      const res = await userInfo()
      if (res && res.code === 200) {
        this.$store.dispatch('setUserInfo', res.data)
      }
    },
    // 提交
    async submit() {
      if (!this.isMember) {
        return showToast('亲，您还不是会员，不能修改噢')
      }
      try {
        const res = await update_info({
          gender: +this.type,
          introduction: this.introduction,
          nickName: this.nickName,
          avatar: this.userAvatarUrl
        })
        if (res.code === 200) {
          showToast('修改成功')
        } else {
          showToast(res.tip)
        }
      } catch (error) {
        console.log(error)
        showToast('请求失败，请稍后再试！')
      }
    },
    // 更改性别
    async changeGander(type) {
      this.type = +type
      if (this.type === 1) {
        this.gender = '男'
      } else {
        this.gender = '女'
      }
      const res = await update_info({
        gender: +this.type
      })
      this.show = false
    },
    // 绑定手机号
    bindPhone() {
      this.$router.push('/mine/setting/bindPhone')
    },
    // 找回账号
    accout() {
      this.$router.push('/mine/setting/accout')
    },
    // 账号凭证
    accoutCode() {
      this.$router.push('/mine/setting/accoutCode')
    }
  }
}
</script>

<style lang="scss" scoped>
.setting {
  min-height: 100vh;
  padding-top: 1rem;
  background: $mainBgColor;
  max-width: 640px;
  margin: 0 auto;
}
.setting-main {
  padding: 0.4rem 0.52rem;
  .avatar {
    width: 1.8rem;
    border-radius: 50%;
    margin: 0 auto;
    margin-bottom: 0.5rem;
    :deep()  {
      .warp {
        border-radius: 50%;
      }
    }
  }
}

// 个人信息
.bind-phone,
.name,
.info,
.gander {
  display: flex;
  align-items: center;
  margin-top: 0.5rem;
  font-size: 0.28rem;
  .lable {
    padding-right: 0.4rem;
    border-right: 0.02rem solid #999999;
    margin-right: 0.28rem;
    width: 2rem;
    box-sizing: border-box;
  }
  .input {
    width: 100%;
    color: #999999;
    font-size: 0.24rem;
    padding-left: 0.32rem;
  }
  .van-cell {
    width: 100%;
    background: $mainBgColor;
    font-size: 0.24rem;
    font-weight: 400;
    :deep()  {
      .field-placeholder-text-color {
        font-weight: 400;
        color: #999999;
      }
      .van-field__control {
        color: #999999;
      }
    }
  }
  :deep()  {
    .van-cell::after {
      display: none;
    }
  }
}

.update-info {
  color: $mainTxtColor1;
  padding: 0 0.5rem;
  .van-cell {
    background: transparent;
  }
}
// 账号凭证等
.bind-phone,
.accout-code,
.accout {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 0.28rem;
  margin-top: 0.5rem;
}
// 性别弹窗

.title {
  background: $btnBg;
  margin-bottom: 0.12rem;
  height: 1.22rem;
  font-size: 0.33rem;
  font-weight: 600;
  text-align: center;
  line-height: 1.22rem;
  border-radius: 0.12rem;
  color: $mainTxtColor1;
}

.content {
  background-color: $mainBgColor;
  height: 2.9rem;
  border-radius: 0.12rem;
  :deep()  {
    .van-radio-group {
      display: flex;
      justify-content: center;
      font-size: 0.3rem;
      color: #999999;
      padding-top: 0.5rem;
      .van-radio__label {
        color: $mainTxtColor1;
      }
      .van-radio__icon--checked .van-icon {
        background-color: #000;
        border-color: #000;
      }
    }
  }
}
.submit {
  width: 2.4rem;
  height: 0.8rem;
  text-align: center;
  line-height: 0.8rem;
  background: $btnBg;
  font-size: 0.36rem;
  border-radius: 0.2rem;
  margin: 0.4rem auto;
  color: $mainTxtColor1;
}
</style>
