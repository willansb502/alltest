<template>
  <div class="kf">
    <!-- <LayoutsHeader class="header" :title="'在线客服'" />
    <div class="iframe-box" frameborder="0">
      <iframe class="iframe" :src="url"></iframe>
    </div> -->
    <LayoutsHeader class="header" :title="'商务对接'" />
    <div @click="copyAccount" class="business">
      <div>
        <img src="@/assets/imgs/telegram.png" alt="" />     
      </div>
      <div>
        @lufei9527
      </div>
    </div>
  

  </div>
</template>

<script>
import useClipboard from 'vue-clipboard3'
const { toClipboard } = useClipboard()
import { kf } from '@/api/home'
import { showToast } from 'vant'
export default {
  components: {
    LayoutsHeader: () => import('@/components/LayoutsHeader.vue')
  },
  data() {
    return {
      url: ''
    }
  },
  mounted() {
    // this.getKfUrl()
  },
  computed: {
    apiUrl({ $store }) {
      return $store.getters['apiUrl']
    }
  },
  methods: {
    //复制商务
    async copyAccount(){
      let text="@lufei9527";
      await toClipboard(text)
      showToast('复制tg号成功') 
      setTimeout(() => {
        window.open("https://t.me/lufei9527");
      }, 1000);     
    },
    toBack() {
      return this.$router.go('-1')
    },
    async getKfUrl() {
      const res = await kf()
      if (res.code === 200) {
        let url = res.data.endpoint.replace('kefu/customer/im?', '?')
        this.url = 'https://hfive.cwabh.com/' + url
      } else {
        return showToast('获取在线客服地址失败，请稍后再试')
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.kf {
  max-width: 980px;
  margin: 0 auto;  
  min-height: 100vh;
  background: $mainBgColor;
  font-size: 0.28rem;
  padding-top: 1rem;
  max-width: $pcMaxWidth;
  margin: 0 auto;
  .iframe-box {
    height: calc(100vh - 1rem);
    padding: 0.3rem;
    box-sizing: border-box;
    .iframe {
      width: 100%;
      max-width: $pcMaxWidth;
      height: 100%;
    }
  }
  .business{

    cursor: pointer;
    margin: 0.2rem 0 0 0.3rem;
    display: flex;
    flex-direction: column;
    img{
      width: 1.5rem;
      
    }
  }
}
</style>
