<template>
  <div class="bind-phone">
    <LayoutsHeader
      class="header"
      :hasSuperiorClick="true"
      @goBack="clickLogo"
      :title="state.toggleStatus ? '账户注册(綁定手機)' : '手机号登陆'"
    >
    </LayoutsHeader>
    <div class="bind-phone-main">
      <div class="logo" @click="clickLogo">
        <img :src="`${baseUrl}/${logoName}`" alt="" />
      </div>
      <!-- 手机号 -->
      <div class="phone-number">
        <van-field class="country-input" v-model="state.country" placeholder="编码" />
        <div class="line"></div>
        <van-field class="phone-input" maxlength="11" v-model="state.mobile" placeholder="输入您的11位手机号码" />
      </div>
      <!-- 验证码 -->
      <div class="captcha-number">
        <van-field readonly class="txt" placeholder="验证码" />
        <div class="line"></div>
        <van-field maxlength="6" type="number" class="captcha-input" v-model="state.captcha" placeholder="输入短信验证码" />
        <div class="btn" :class="{ disabled: state.time }" @click="getCaptcha">
          {{ state.time ? state.num + 's' : '获取验证码' }}
        </div>
      </div>

      <div class="prompt">
        <span>{{ state.toggleStatus ? '已经绑定过手机了？' : '还没有註冊账户(綁定手機)？' }}</span>
        <span class="prompt-color" @click="toggleInputCard"> {{ state.toggleStatus ? '去登录' : '去注册(去綁定)?' }} </span>
      </div>

      <!-- 按钮 -->
      <div class="submit" @click="bindPhoneFn">{{ state.toggleStatus ? '账户注册' : '手机号登录' }}</div>
    </div>
  </div>
</template>

<script  setup>
const logoName = import.meta.env.VITE_APP_logoName
const baseUrl = import.meta.env.VITE_APP_baseUrl
import { login_captcha, phone_login, bind_Phone } from '@/api/home'
import { showToast } from 'vant'
const LayoutsHeader = defineAsyncComponent(() => import('@/components/LayoutsHeader.vue'))
import { useStore } from 'vuex'
const store = useStore()
const router = useRouter()

const state = reactive({
  toggleStatus: false,
  country: '+86',
  mobile: '',
  captcha: undefined, // 验证码
  time: false, // 定时器开关
  num: 60,
  countryArr: []
})


const clickLogo = () =>{
  if(window.history.length){
    router.back();
  }else{
    router.push('/');
  }
}
const toggleInputCard = () =>{
  state.toggleStatus = !state.toggleStatus
  state.mobile = ''
  state.captcha = ''  
}
// 获取验证码
const getCaptcha =async () =>{
  state.countryArr = state.country.split('+')
  if (!state.country || !state.countryArr[1]) {
    return showToast('请输入国家编码')
  }
  if (!state.mobile) {
    return showToast('请输入手机号')
  }

  state.time = true
  let t
  if (state.time) {
    t = setInterval(() => {
      if (state.num > 0) {
        state.num--
      } else {
        state.time = false
        state.num = 60
        window.clearInterval(t)
      }
    }, 1000)
    const res = await login_captcha({
      country: state.countryArr[1],
      mobile: state.mobile
    })
    if (res.code === 200) {
      return showToast('验证码已发送，请输入验证码')
    } else {
      return showToast(res.tip)
    }
  }
}
// 绑定手机号
const bindPhoneFn =async () =>{
  state.countryArr = state.country.split('+')
  if (!state.country || !state.countryArr[1]) {
    return showToast('请输入国家编码')
  }
  if (!state.mobile) {
    return showToast('请输入手机号')
  }
  if (!state.captcha) {
    return showToast('请输入验证码')
  }
  let res = null
  if (state.toggleStatus) {
    res = await bind_Phone({
      captcha: state.captcha, // 验证码
      country: state.countryArr[1], // 编码
      mobile: state.mobile // 手机号
    })
  } else {
    res = await phone_login({
      captcha: state.captcha, // 验证码
      country: state.countryArr[1], // 编码
      mobile: state.mobile // 手机号
    })
  }

  if (res.code === 200) {
    store.dispatch('setUserInfo', res.data)
    store.dispatch('setToken', res.data.token)
    showToast('登陆成功')
    router.push('/')
  } else {
    return showToast(res.tip)
  }
}   


</script>

<style lang="scss" scoped>
.bind-phone {
  min-height: 100vh;
  font-size: 0.24rem;
  position: relative;
  .logo-mini {
    display: none;
  }
  &-main {
    position: relative;
    max-width: 540px;
    margin: 0 auto;
    padding: 0.7rem;
    height: 100vh;
    box-sizing: border-box;
    margin: 0 auto;
    display: flex;
    flex-flow: column wrap;
    justify-content: center;
    .logo {
      display: block;
      width: 2rem;
      font-size: 0;
      margin: 0 auto;
      img {
        width: 100%;
        height: 100%;
      }
    }
    .logo:hover,
    .submit:hover,
    .btn:hover {
      cursor: pointer;
    }
    .line {
      height: 0.3rem;
      width: 0.02rem;
      background: #545560;
      margin: 0.2rem;
    }
    .phone-number {
      display: flex;
      align-items: center;
      box-sizing: border-box;
      margin-top: 0.75rem;
      .phone-input {
        padding: 0;
        border-bottom: 0.02rem solid #545560;
        background: transparent;
      }
      .country-input {
        background: transparent;
        color: #333;
        width: 1.24rem;
        padding: 0;
        border-bottom: 0.02rem solid #545560;
      }
    }
    .captcha-number {
      box-sizing: border-box;
      display: flex;
      align-items: center;
      border-bottom: 0.02rem solid #545560;
      margin-top: 0.75rem;
      .txt {
        padding: 0;
        width: 2rem;
      }
      .captcha-input {
        width: 100%;
        padding: 0;
      }
      .btn {
        width: 2.24rem;
        padding: 0.05rem 0.15rem;
        border-radius: 0.4rem;
        background: $btnBg;
        text-align: center;
        white-space: nowrap;
      }
      .disabled {
        background: rgba($color: #f3c048, $alpha: 0.5);
      }
    }
    .waring {
      text-align: right;
      color: #9493b1;
      font-size: 0.24rem;
    }
  }
  .prompt {
    width: 100%;
    cursor: pointer;
    height: 1rem;
    line-height: 1rem;
    padding: 0 0.2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 0.22rem;

    &-color {
      font-size: 0.24rem;
      font-weight: normal;
      font-stretch: normal;
      font-style: normal;
      line-height: 1.1;
      letter-spacing: 0.0036rem;
      text-align: left;
      color: #ffae69;
      background: rgb(88, 83, 83);
      padding: 0.12rem 0.12rem;
      border-radius: 0.12rem;
    }
  }
  :deep()  {
    .van-cell {
      background: transparent !important;
      box-sizing: border-box;
      padding: 0.09rem 0.388rem;
      background: $mainBgColor;
      color: $mainTxtColor1;
      .van-field__body {
        width: 100%;
        height: 0.84rem;
      }
      .van-field__control {
        color: $mainTxtColor1;
      }
    }
    .txt {
      .van-field__control::-webkit-input-placeholder {
        color: #fff;
      }
    }
    .van-cell::after {
      display: none;
    }
  }
}
.submit {
  background: $btnBg;
  padding: 0.2rem 1.8rem;
  text-align: center;
  border-radius: 0.4rem;
  margin-top: 0.5rem;
}
@media screen and (min-width: 750px) {
  .bind-phone {
    &-main {
      .logo {
        img {
          width: 3rem;
        }
      }
    }
  }
  .logo-mini {
    display: block !important;
    width: 2rem;
    height: 0.5rem;
    font-size: 0;
    margin-right: 0.3rem;
    img {
      width: 100%;
      height: 100%;
    }
  }
}
</style>
