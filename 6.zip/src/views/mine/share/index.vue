<template>
  <div class="share">
    <LayoutsHeader :title="'分享邀请'" />
    <div class="share-main">
      <div class="top-num">
        累计分享人数：<span>{{ userInfo.invites }}</span>
      </div>
      <p class="tip-txt">邀请一位下载，即可获得1天VIP 无限领取</p>
      <div class="code">
        <qrcode-vue class="qrcode" :value="inviteUrl" level="H" :size="130" />
      </div>
      <div class="line"></div>
      <p style="color: red">
        永久域名
      </p>      
      <p class="inviteUrl">
        {{ inviteUrl }}
      </p>
    </div>
    <div class="btn">
      <div @click="clickSaveImg">保存图片分享</div>
      <div 
        @click="onCopy(inviteUrl)"
      >复制链接分享</div>
    </div>
    <div class="tip">
      <p>推广说明</p>
      <span>好友通过您的二维码或者推广链接下载APP,并启动后即算推广成功。</span>
      <span>备注：永久vip 无限领取 ～～。</span>
    </div>
  </div>
</template>

<script>
import useClipboard from 'vue-clipboard3'
const { toClipboard } = useClipboard()
import QrcodeVue from 'qrcode.vue'
import axios from 'axios'
import { showToast } from 'vant'
export default {
  name: 'MineShare',
  components: {
    QrcodeVue,
    LayoutsHeader: () => import('@/components/LayoutsHeader.vue'),
    DecryptImg: () => import('@/components/DecryptImg/index.vue')
  },
  data() {
    return {
      inviteUrl: 'https://muoujiejie.com/'
    }
  },
  computed: {
    userInfo({ $store }) {
      return $store.getters['getUserInfo']
    }
  },
  methods: {
    // 复制
    const onCopy =async (text) => {
      try {
        await toClipboard(contactInfo)
        showToast('复制成功！！！')
      } catch (e) {
        console.error(e)
      } 
    }
    //保存图片
    async clickSaveImg() {
      axios
        .get('/hqshareImg.png', {
          shareCount: this.userInfo.invites,
          shareURL: inviteUrl
        })
        .then(res => {
          if (res.status == 200) {
            try {
              const eleLink = document.createElement('a')
              eleLink.href = res.data.base64
              eleLink.download = `来自${this.info.nickName}的个人凭证.png`
              document.body.appendChild(eleLink)
              eleLink.click()
              document.body.removeChild(eleLink)
            } catch (err) {
              console.log(err)
              console.log('保存失败')
            }
          } else {
            showToast(res.tip)
          }
        })
    },
    //下载图片
    download(href, name) {
      const eleLink = document.createElement('a')
      eleLink.href = href
      eleLink.setAttribute('download', `${this.userInfo.nickName}${name}的分享.png`)
      document.body.appendChild(eleLink)
      eleLink.click()
      document.body.removeChild(eleLink)
    }
  },
  mounted(){
    this.inviteUrl=this.userInfo.inviteUrl;
  }
}
</script>

<style lang="scss" scoped>
.share {
  padding-top: 1.2rem;
  // padding: 1.2rem 0.75rem;
  font-size: 0.24rem;
  max-width: 640px;
  margin: 0 auto;
}
.share-main {
  width: 6rem;
  height: 7.2rem;
  margin: 0 auto;
  background: url('../../../assets/imgs/mine/share-bg.svg') no-repeat;
  background-size: 100% 100%;
  box-shadow: $shadow;
  font-size: 0.24rem;
  @include flexbox($jc: center, $ai: center, $fd: column, $fw: nowrap);
  .top-num {
    color: $mainTxtColor2;
    font-size: 0.3rem;
    font-weight: 600;
  }
  .tip-txt {
    margin: 0.14rem 0 0.44rem 0;
    color: $mainTxtColor2;
  }
  .code {
    padding: 0.26rem;
    box-shadow: $shadow;
  }
  .line {
    height: 0.01rem;
    width: 5rem;
    background: #5b5b6f;
    margin: 0.3rem 0;
  }
  p {
    margin: 0;
    font-size: 0.3rem;
  }
  .inviteUrl{
    color: red;
    width:80%;
    margin: 0 auto;
  }
}
.btn {
  cursor: pointer;
  @include flexbox($jc: space-around, $ai: center, $fd: row, $fw: nowrap);
  margin: 0.3rem 0 0.34rem 0;
  div {
    background: $btnBg;
    border-radius: 0.45rem;
    width: 2.26rem;
    height: 0.68rem;
    text-align: center;
    line-height: 0.68rem;
    box-shadow: $shadow;
  }
}
.tip {
  padding: 0 0.75rem;
  p {
    font-size: 0.26rem;
    font-weight: 600;
  }
  span {
    color: #848494;
  }
}
@media screen and (min-width: 750px) {
  .share {
    padding-top: 3.2rem !important;
  }
}
</style>
