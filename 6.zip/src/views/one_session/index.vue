<template>
  <div class="session-main">
    <LayoutsHeader :title="this.$route.query.nickName ? this.$route.query.nickName : '私信'" />
    <van-pull-refresh
      pulling-text=""
      success-text=""
      loosing-text="加载消息中..."
      pull-distance="20"
      head-height="40"
      v-model="refreshing"
      @refresh="onRefresh"
    >
      <div class="conetnt-list message-listWrap">
        <!-- 别人发的消息 -->
        <template>
          <div
            v-for="(item, index) in msgList"
            :class="item.fromId == userInfo.id ? 'my-message' : 'other-message'"
            :key="index"
          >
            <!-- 我的消息 -->
            <div class="text-box" v-if="item.fromId == userInfo.id">
              <div class="msg-item">
                <div class="msg-item-content" style="">
                  <div class="time">
                    {{ filterTime(item.createdAt && item.createdAt.split('T')[1].substring(0, 8)) }}
                  </div>
                  <p class="text">
                    {{ item.text }}
                  </p>
                </div>
              </div>
              <DecryptImg :imgURL="userInfo.avatarUrl"></DecryptImg>
            </div>
            <!-- 别人的消息 -->
            <div class="text-box" v-else>
              <DecryptImg :imgURL="friendInfo.avatar"></DecryptImg>
              <div class="msg-item">
                <div class="msg-item-content" style="">
                  <div class="time">
                    {{ filterTime(item.createdAt && item.createdAt.split('T')[1].substring(0, 8)) }}
                  </div>
                  <p class="text">
                    {{ item.text }}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </template>
        <div id="scrollIntoViewChat"></div>
      </div>
    </van-pull-refresh>
    <!-- 评论输入框 -->
    <div class="comment-text">
      <van-field @keyup.enter="sendMsg" v-model="text" class="send-input" placeholder="请输入你的文字内容" />
      <!-- <slot name="right-icon"
        ><van-icon name="photo" @click="sendImgMsg" size="32" color="f0f0f0" />
        <input ref="filElem" type="file" accept="image/*" name="image"
        style="display:none" @change="tirggerFile($event)">
      </slot>       -->
      <span class="send-text" @click="sendMsg">发送</span>
    </div>
  </div>
</template>

<script>
import { msg_info, msg_send } from '@/api/user'
import { filterTime } from '@/utils/filter'
import { showToast } from 'vant'
export default {
  name: 'OneSession',
  components: {
    LayoutsHeader: () => import('@/components/LayoutsHeader.vue'),
    DecryptImg: () => import('@/components/DecryptImg/index.vue')
  },
  data() {
    return {
      id: 0,
      msgList: [],
      text: '',
      pageNum: 1,
      pageSize: 3,
      refreshing: false,
      navTit: '',
      // 聊天对象信息
      friendInfo: {
        id: '',
        nickName: '',
        avatar: ''
      },
      myInterval:null
    }
  },

  computed: {
    // 图片cdn
    cdn({ $store }) {
      return $store.getters['cdn'].imgCdn
    },
    userInfo({ $store }) {
      return $store.getters['getUserInfo']
    },
    isMember({ $store }) {
      return $store.getters['isMember']
    }
  },
  methods: {
    // 初始化聊天对象数据
    initUserData() {
      this.friendInfo.id = Number(this.$route.params.id)
      this.friendInfo.nickName = this.$route.query.nickName
      this.friendInfo.avatar = this.$route.query.avatar
      if (this.friendInfo.nickName) {
        this.navTit = `与${this.friendInfo.nickName}私信中`
      } else {
        this.navTit = `私信`
      }
    },
    //获取消息列表
    async getMessageInfo() {
      let query = {
        pageNum: this.pageNum,
        pageSize: 100,
        peerId: this.friendInfo.id
      }
      const res = await msg_info(query)
      if (res.code === 200) {
        this.refreshing = false
        this.msgList = res.data.messageList.reverse()
      } else {
        this.refreshing = false
        showToast(res.tip)
      }
    },
    //上拉刷新
    onRefresh() {
      ++this.pageNum
      this.getMessageInfo()
    },
    //发送消息
    async sendMsg() {
      if (!this.text) return showToast('请输入消息')
      const res = await msg_send({
        text: this.text,
        peerId: this.friendInfo.id
      })
      
      if (res.code === 200) {
        this.msgList.push({
          text: this.text,
          fromId: this.userInfo.id,
          createdAt: this.$dateFormat08(
            new Date(
              new Date().getTime() + (parseInt(new Date().getTimezoneOffset() / 60) + 8) * 3600 * 1000
            ).getTime() +
              1000 * 3600 * 8
          )
        })
        showToast('发送成功')

        this.text = ''
        this.$nextTick(() => {
          this.fn_scrollView()
        })
      } else {
        showToast(res.tip)
      }
    },
    //滚动
    fn_scrollView() {
      this.$nextTick(() => {
        document.querySelector('.message-listWrap').lastChild.scrollIntoView({
          behavior: 'smooth'
        })
      })
    }
  },

  async mounted() {
    if (this.isMember) {
      await this.initUserData()
      await this.getMessageInfo()
      this.myInterval=setInterval(() => {
        this.getMessageInfo("new")
      }, 5000);
      setTimeout(() => {
        this.fn_scrollView()
      }, 1000);
    } else {
      showToast('亲，只有会员才支持私信哦～')
      return
    }
  },
  destroyed(){
    clearInterval(this.myInterval);
  }
}
</script>

<style lang="scss" scoped>
.session-main {
  min-height: 100vh;
  background: #f2f5fa;
  padding-top: 1rem;
  .conetnt-list {
    padding: 0.3rem 0 1rem 0;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    min-height: calc(100vh - 0.92rem);
  }
}
.text-box {
  display: flex;
  align-items: center;
  :deep()  {
    .default {
      border-radius: 50%;
      width: 0.8rem;
      .warp {
        border-radius: 50%;
      }
    }
  }
  .msg-item-content {
    padding-left: 0.2rem;
    color: #939496;
    .text {
      padding: .16rem 0.45rem .16rem .3rem;
      background: #fff;
      font-weight: 600;
      border-radius:.4rem ;
      border-top-left-radius: 0;   
      box-shadow: 0 0 0.1rem 0 #1a000000; 
    }
  }
}
// 对话
.other-message {
  margin-bottom: 0.4rem;
  display: flex;
  justify-content: flex-start;
  margin-left: 0.25rem;
  .msg-item {
    margin-right: 0.2rem;
    font-size: 0.2rem;
    text-align: left;
    p {
      background: $btnBg;
      text-align: right;
      border-radius: 0.1rem;
      font-size: 0.24rem;
      max-width: 6.2rem;
      padding: 0 0.1rem;
      max-width: 5rem;
    }
    /** 通过对小正方形旋转45度解决 **/
  }
}
.my-message {
  margin-bottom: 0.4rem;
  margin-right: 0.25rem;
  display: flex;
  justify-content: flex-end;
  .msg-item {
    margin-right: 0.2rem;
    font-size: 0.2rem;
    text-align: right;
    p {
      background: $btnBg;
      text-align: left;
      border-radius: 0.1rem;
      font-size: 0.24rem;
      max-width: 6.2rem;
      padding: 0 0.1rem;
      max-width: 5rem;
    }
    /** 通过对小正方形旋转45度解决 **/
  }
}

// 输入框
.comment-text {
  position: fixed;
  height: 1rem;
  background: $mainBgColor;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.3rem 0.2rem;
  font-size: 0.32rem;
  color: #333;
  width: 100%;
  bottom: 0;
  max-width: $pcMaxWidth;
  box-sizing: border-box;
  .send-input {
    background: $mainBgColor;
    height: 0.6rem;
    line-height: 0.6rem;

    :deep()  {
      .van-field__body {
        padding-left: 0.2rem;
      }
      .field-placeholder-text-color {
        color: #9493b1;
      }
      .van-field__control {
        border-radius: 0.3rem;
        background: #f3f5fa;
        text-indent: 0.3rem;
        color: #333;
      }
    }
  }
  :deep()  {
    .van-cell {
      padding: 0 !important;

      border-radius: 0.2rem;
    }
    .van-cell::after {
      display: none;
    }
  }
  .send-text {
    background: $btnBg;
    width: 1.2rem;
    padding: 0.05rem 0;
    text-align: center;
    margin-left: 0.1rem;
    border-radius: 0.4rem;
    font-size: 0.28rem;
    color: $mainTxtColor1;
  }
}
</style>

