<template>
  <div class="session-main">
    <LayoutsHeader :title="this.$route.query.nickName ? this.$route.query.nickName : '私信'" />
    <van-pull-refresh
      pulling-text=""
      success-text=""
      loosing-text="加载消息中..."
      pull-distance="20"
      head-height="40"
      v-model="refreshing"
      @refresh="onRefresh"
    >
      <div class="conetnt-list  message-listWrap">
        <!-- 别人发的消息 -->
        <template >
          <div
            v-for="(item,index) in tipList"
            :class="item.chaterId != userInfo.id?'other-message':'my-message'"
            :key="index"
          >
            <div class="text-box" v-if="item.chaterId != userInfo.id">
              <img class="portrait" :src="otherPic?otherPic:defaultImg" alt="">
              <div class="right-wrap">
                <div class="time">{{filterTime(item.createdAt&&item.createdAt.split('T')[1].substring(0,8))}}</div>                
                <div class="text">
                  {{ item.value }}
                </div>
              </div>
            </div>
            <div class="text-box my" v-else>
              <div class="right-wrap">
                <div class="time">{{filterTime(item.createdAt&&item.createdAt.split('T')[1].substring(0,8))}}</div>
                <div class="text">
                  {{ item.value }}
                </div>   
              </div>   
              <div class="portrait">
                 <img   :src="myPic?myPic:defaultImg" alt="">
              </div>         
             
            </div>            
          </div>
        </template>
        <div id="scrollIntoViewChat"></div>
      </div>
    </van-pull-refresh>
    <!-- 评论输入框 -->
    <div class="comment-text">
      <van-field
        @keyup.enter="sendMsg"
        v-model="text"
        class="send-input"
        placeholder="请输入你的文字内容"
      />
      <!-- <slot name="right-icon"
        ><van-icon name="photo" @click="sendImgMsg" size="32" color="f0f0f0" />
        <input ref="filElem" type="file" accept="image/*" name="image"
        style="display:none" @change="tirggerFile($event)">
      </slot>       -->
      <span class="send-text" @click="sendMsg">
        <span>发送</span>
      </span>
    </div>

  </div>
</template>

<script>
import { filterTime } from '@/utils/filter'
import { msg_info, msg_send } from '@/api/user'
import { showToast } from 'vant'
export default {
  loading: false,
  components: {
    LayoutsHeader: () => import('@/components/LayoutsHeader.vue'),
  },
  data() {
    return {
      nickName:'',
      defaultImg:"/defaultIcon.png",
      otherPic:"",
      myPic:"",
      id: 0,
      name: '',
      tipList: [],
      text: '',
      pageNum: 1,
      refreshing: false,
      timer: null,
      canGetDatas:true
    }
  },

  methods: {
    // 发送图片消息
    sendImgMsg() {
      this.$refs.filElem.dispatchEvent(new MouseEvent('click'))
    },
    // 获取上传文件信息，并调上传接口
    async tirggerFile(event) {
      // 获取当前选中的文件
      if (event.target.files[0]) {
        const file = event.target.files[0]
        const imgMasSize = 1024 * 1024 * 4 // 10MB
        // 检查文件类型
        if (
          ['jpeg', 'png', 'gif', 'jpg'].indexOf(file.type.split('/')[1]) < 0
        ) {
          // 自定义报错方式
          showToast('文件类型仅支持 jpeg/png/gif！')
          return
        }
        // 文件大小限制
        if (file.size > imgMasSize) {
          // 文件大小自定义限制
          showToast('文件大小不能超过4MB！')
          return
        }
        const formData = new FormData()
        // 自定义formData中的内容
        // type
        formData.append('type', file.type)
        // size
        formData.append('size', file.size || 'image/jpeg')
        // name
        formData.append('name', file.name)
        // lastModifiedDate
        formData.append('lastModifiedDate', file.lastModifiedDate)
        // append 文件
        formData.append('upload', file)
        // 已上传图片
        const res = await this.$uploadImg(formData)
        if (res.code === 200) {
          this.result = res.data.path
          this.sendMsg()
          this.$refs.filElem.value = null
        } else {
          showToast('发送失败')
        }
      }
    },    
    //返回    
    toBack() {
      this.$router.go('-1')
    },
    // 图片转换
    async imgTransfer(imgPath){
      // const resImg = await handleVerImg(this.imgCDN + imgPath);
      // this.otherPic = window.URL
      //   ? window.URL.createObjectURL(new Blob([resImg]))
      //   : window.webkitURL.createObjectURL(new Blob([resImg]));
    },      
    // 图片转换
    async imgTransfer2(imgPath){
      // const resImg = await handleVerImg(this.imgCDN + imgPath);
      // this.myPic = window.URL
      //   ? window.URL.createObjectURL(new Blob([resImg]))
      //   : window.webkitURL.createObjectURL(new Blob([resImg]));
    },    
    //获取私聊会话
    async get_p2pmessageSession() {
      const res = await msg_info({
        peerId:this.id,    
        pageNum: 1,
        pageSize: 100           
      })
      if (res.code === 200) {
        res.data.chaters.forEach((item)=>{
          if(this.id==item.id){
            this.imgTransfer(item.avatar);
          }
        })
      } else {
        showToast(res.tip)
      }
    },    
    //获取消息列表
    async get_tipList(type) {
      //防止二次调用
      if(!this.canGetDatas) return;
      this.canGetDatas=false;  
      let data = {};
      // 上啦获取历史消息
      if (type === 'pull'||type === 'start') {
        data = {
          forward: false,
          targetId: this.id,
          size: 10,
          start: 0

        }
      };
      if (type === 'update'||type === 'send') {
        data = {
          forward: true,
          targetId: this.id,
          size: 10,
          start: this.tipList[this.tipList.length - 1]
            ? this.tipList[this.tipList.length - 1].createdAt
            : dateFormat08(
                new Date(
                  new Date().getTime() +
                    (parseInt(new Date().getTimezoneOffset() / 60) + 8) *
                      3600 *
                      1000
                ).getTime() + 1000*3600*8
              ),
        }
      };      
      const res = await msg_info(data);
      if (res.code === 200) {
        this.refreshing = false;
        //第一次滚到底部,不要动画
        if(type=="start"){
          this.tipList = res.data.list;
          this.$nextTick(() => {
            document.querySelector('.message-listWrap').lastChild.scrollIntoView();
          })           
        }    
        // 获取到的历史消息
        if (type == 'pull') {
          this.tipList = [...res.data.list, ...this.tipList]
        }           
        //收到新消息且处于底部位置 先获取值，否则算不对
        if(type=="update"){    
          let htmlScrollTop=document.querySelector('html').scrollTop;
          let offsetHeight=document.querySelector('.session-main').offsetHeight;
          let innerHeight=window.innerHeight;   
          this.tipList = [...this.tipList, ...res.data.list];
          // console.log(htmlScrollTop,'htmlScrollTop');
          // console.log(offsetHeight-innerHeight);
          // console.log((offsetHeight-innerHeight)-htmlScrollTop)
          if((offsetHeight-innerHeight)-htmlScrollTop<=100){             
            this.fn_scrollView();
          }
        } 
        if(type=="send"){
          this.tipList = [...this.tipList, ...res.data.list];
          this.fn_scrollView();
        } 
        this.canGetDatas=true;          
      } else {
        this.canGetDatas=true;
        this.refreshing = false;
        showToast(res.tip);
      }
    },
    //上拉刷新没用，7天数据一次性
    onRefresh() {
      this.pageNum++;
      this.get_tipList("pull");
    },
    //发送消息
    async sendMsg() {
      if (!this.text) return showToast('请输入消息')
      const res = await this.$p2pmessageSend({
        value: this.text,
        targetId: this.id,
        msgType: 1      
      })
      if (res.code === 200) {
        this.text = '';
        showToast('发送成功');
        this.get_tipList("send");
      } else {
        if(res.code==20001) return showToast("您已被禁言！");
        showToast(res.tip);
      }
    },
    //滚动
    fn_scrollView() {       
      this.$nextTick(() => {
        document.querySelector('.message-listWrap').lastChild.scrollIntoView({
          behavior: 'smooth',
        })          
      });      
    }  
  },
  mounted() {
    this.nickName=this.$route.query.name;
    this.id=+this.$route.params.id;    
    this.get_p2pmessageSession();
    this.get_tipList("start");
    clearInterval(this.timer);
    this.timer=setInterval(()=>{
      this.get_tipList("update");
    },5000);
    this.imgTransfer2(this.userInfo.avatarUrl);
  },
  computed: {
    // 获取个人user
    userInfo({ $store }) {
      return $store.getters['getUserInfo']
    },
    imgCDN({$store}) {
      return $store.getters['config/cdn'].imgCdn
    }   
  },  
  beforeDestroy() {
    clearInterval(this.timer);
  }
}
</script>

<style lang="scss" scoped>
.session-main {
  min-height: 100vh;
  background: #f2f5fa;
  padding-top: .92rem;
  .conetnt-list {
    padding: 0.3rem 0 1rem 0;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    min-height: calc(100vh - 0.92rem);    
  }
}
.text-box{
  display: flex;
  align-items: center;
  .portrait{
    img{
      border-radius: 50%;
      width: .8rem;
      height: .8rem;      
    }

  }
  .right-wrap{
    display: flex;
    justify-content: center;
    align-items: flex-start;
    flex-direction: column;
    margin-left: 0.2rem;
    .text{
      display: flex;
      align-items: center;
    } 
    .time{
      font-size: .24rem;
      color: #999;
      padding-bottom: .05rem;
      transform: scale(.8);
      margin-left: -.1rem;
    }     
  }

  &.my{
    .right-wrap{
      align-items: flex-end;
      margin-right: .2rem;
    }
    .time{
      margin-right: -.1rem;
      margin-left: 0;
    }      
  }
}
// 对话
.other-message {
  font-size: 0.28rem;
  max-width: 6.2rem;
  margin-bottom: 0.4rem;
  display: flex;
  justify-content: flex-start;  
  margin-left: .3rem;
  .text {
    padding: .16rem 0.45rem .16rem .3rem;
    background: #fff;
    font-weight: 600;
    border-radius:.4rem ;
    border-top-left-radius: 0;   
    box-shadow: 0 0 0.1rem 0 #1a000000; 
  }
  span {
    font-size: 0.2rem;
    transform: scale(0.8);
    display: inline-block;
  }
}
.my-message {
  font-size: 0.28rem;
  color: #fff;

  margin-bottom: 0.4rem;
  padding-right: 0.3rem;
  display: flex;
    justify-content: flex-end;

  .text {
    max-width: 6.2rem;
    font-weight: 600;
    padding: .16rem 0.45rem .16rem .3rem;
    background: linear-gradient(to right, #ff86a8, #ff467c);
    border-radius: 0.1rem;
    color: #fff;
    border-radius:.4rem ;
    border-top-right-radius: 0;    
  }
  span {
    transform: scale(0.8);
    display: inline-block;
    font-size: 0.2rem;
    display: flex;
    justify-content: flex-end;
  }
}

// 输入框
.comment-text {
  position: fixed;
  height: 1rem;
  background: #fff;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.3rem .2rem;
  font-size: 0.32rem;
  color: #333;
  width: 100%;
  bottom: 0;
  max-width: $pcMaxWidth;
  box-sizing: border-box;
  .send-input {
    background: #fff;
    height: 0.6rem;
    line-height: 0.6rem;
    

    :deep()  {
      .van-field__body {
        padding-left: 0.2rem;
      }
      .field-placeholder-text-color {
        color: #9493b1;
      }
      .van-field__control {
        border-radius: .3rem;
        background: #f3f5fa;
        text-indent: .3rem;
        color: #333;
      }
    }
  }
  :deep()  {
    .van-cell {
      padding: 0 !important;

      border-radius: 0.2rem;
    }
    .van-cell::after {
      display: none;
    }
  }
  .send-text {
    margin: 0 auto;
    display: flex;
    justify-content: center;
    align-items: center;  
    background-image: linear-gradient(to right, #ff86a8, #ff467c);
    color: #fff;
    border-radius: 999px;//默认全圆角
    width: 1.2rem;
    padding: .05rem 0;
    text-align: center;
    margin-left: .1rem;
    font-size: .28rem;

  }
}
</style>
