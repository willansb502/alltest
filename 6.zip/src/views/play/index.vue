<template>
  <div class="play-main">
    <PullUp
      @refreshData="refreshData"
      @moreData="moreData"
      :finished="finished"
      :loading="loading"
      :refreshing="refreshing"
      :skeleton="skeleton"
    >
      <LayoutsHeader :title="videoInfo.title">
        <template #right>
          <router-link to="/home" class="md-mine-property-info">
            <p style="color: #f4ce4e">主页</p>
          </router-link>
          <div class="logo-mini" @click="clickLogo">
            <img :src="`${baseUrl}/${logoName}`" alt="" />
          </div>
        </template>
      </LayoutsHeader>

      <div class="play-main-max-width">
        <div
          class="play-main-inner"
          style="position: relative; width: 100%; overflow: hidden; padding-top: calc(57% + 1rem)"
        >
          <JavVideo
            :videoInfo="videoInfo"
            :hasPreview="hasPreview"
            ref="videoPlayNow"
            @skipPreview="skipPreview"
            v-if="videoInfo && videoInfo.id"
          >
            <template>
              <!-- 视频播放购买提示 -->
              <div class="playWaring" v-if="showPorp">
                <div class="vipTip" v-show="code === 6031 || code === 6032">
                  <van-icon name="cross" size="28" class="playWaring-close" color="#fff" @click="showPorp = false" />
                  <div class="vipTip-first">
                    <h2>免费观看次数已用完</h2>
                    <p>您今日的观看次数已经全部用完,开通会员可以无限畅看</p>
                    <div class="btn">
                      <span @click="$router.push('/mine/share')">邀请好友</span>
                      <span @click="$router.push('/vip')">开通会员</span>
                    </div>
                    <span>分享成功可以免费获得3天会员哦</span>
                  </div>
                </div>
                <div v-show="code === 6033" class="goldTip">
                  <van-icon name="cross" size="28" color="#fff" @click="showPorp = false" />
                  <div class="goldTip-first">
                    <h2>本片需要付费观看</h2>
                    <p>本片需要付费观看，请您购买后继续观看</p>
                    <div class="btn">
                      <span
                        @click="
                          () => {
                            if (user.mobile) {
                              videoPlay(1)
                            } else {
                              $router.push('/mine/setting/phone')
                            }
                          }
                        "
                        >{{ changeGold(videoInfo.price) }}金币</span
                      >
                      <span class="txt-btn" @click="showPorp = false">忍着不看</span>
                    </div>
                  </div>
                </div>
                <div v-show="code === 6018" class="goldTip-noGold">
                  <van-icon name="cross" size="28" color="#fff" @click="showPorp = false" />
                  <div class="goldTip-noGold-first">
                    <h2>您的余额不足以支付本片</h2>
                    <p>您的钱包余额不足,请充值金币后继续购买观看</p>
                    <div class="btn">
                      <span
                        @click="
                          () => {
                            if (user.mobile) {
                              $router.push('/mine/my-wallet')
                            } else {
                              $router.push('/mine/setting/phone')
                            }
                          }
                        "
                        >前往充值</span
                      >
                      <span class="txt-btn" @click="showPorp = false">忍着不看</span>
                    </div>
                  </div>
                </div>
              </div>
            </template>
          </JavVideo>
        </div>
        <!-- 标题 -->
        <div class="video-title">
          <div></div>
          <h2>{{ videoInfo.title }}</h2>
          <p class="desc">{{ videoInfo.desc }}</p>
          <div class="video-detail">
            <div class="watchs">
              <img src="@/assets/imgs/plays.svg" alt="" />
              {{ numberFilter(videoInfo.watchTimes) }}
            </div>
            <div class="likes" @click="checkLike(videoInfo)">
              <img v-if="!videoInfo.isLike" src="@/assets/imgs/white-path.svg" alt="" />
              <img v-else src="@/assets/imgs/red-path.svg" alt="" />
              {{ numberFilter(videoInfo.likes) }}
            </div>
            <div class="comments" @click="comments_fn">
              <img src="@/assets/imgs/comments.svg" alt="" />
              {{ numberFilter(videoInfo.comments) }}
            </div>
            <!-- 分享 -->
            <div class="comments" @click="share_fn">538分享<van-icon name="share-o" /></div>
          </div>
          <div class="video-detail-pc">
            <div>
              <span>观看： {{ numberFilter(videoInfo.watchTimes) }}</span>
            </div>
            <div @click="checkLike(videoInfo)" class="like">
              <img v-if="!videoInfo.isLike" src="@/assets/imgs/white-path.svg" alt="" />
              <img v-else src="@/assets/imgs/red-path.svg" alt="" />
              <span>喜欢： {{ numberFilter(videoInfo.likes) }}</span>
            </div>
            <div @click="shareBtn(0, 0)">复制本片链接</div>

            <div @click="comments_fn">去评论</div>
            <div @click="downShow = true">手机观看</div>
            <!-- <div>点击下载APP</div> -->
            <div @click="$router.push('/vip')" class="buyVIP" style="flex: 2">购买VIP</div>
          </div>
        </div>
        <!-- 标签信息 -->
        <div class="videoInfo-main">
          <div class="tag" v-if="videoInfo.tags && videoInfo.tags.length > 0">
            <span class="label">标签</span>
            <div class="tag-list">
              <div
                class="tag-txt"
                v-for="item in videoInfo.tags"
                @click="$router.push(`/tag/detail/${videoInfo.videoType}?name=${item}`)"
                :key="item"
              >
                {{ item }}
              </div>
            </div>
          </div>
          <div class="bango" v-if="videoInfo.bango">
            <span class="label">番号</span>
            <div class="bango-txt">{{ videoInfo.bango }}</div>
          </div>
          <div class="time">
            <span class="label">上架</span>
            <span class="time-txt" v-if="videoInfo.addedTime">{{ timeYmd(videoInfo.addedTime) }}</span>
          </div>
        </div>

        <van-overlay :show="downShow" @click="downShow = false">
          <div class="down-wrapper">
            <p style="font-size: 0.28rem">手机扫描二维码</p>
            <div class="qrcode-warp">
              <qrcode-vue class="qrcode" :value="playURL" level="H" :size="150" />
            </div>
          </div>
        </van-overlay>
        <div class="other-main">
          <!-- 视频广告 -->
          <JavSwiper v-if="playAD.length" class="ww-swiper" :imgs="playAD" :height="'auto'" />
          <!-- 猜你喜欢列表 -->
          <div class="like-title" v-if="videoLike && videoLike.length > 0">猜你喜欢</div>

          <JavShortSix :isLike="true" :list="videoLike" />

          <!-- 评论弹窗 -->
          <JavComment
            :showComment="showComment"
            :objectype="1"
            @close="close"
            :publisher="videoInfo.publisher.id"
            :objectId="videoInfo.id"
          />
          <!-- 分享弹窗 -->
          <BlShare
            :isShow="showShare"
            @select="shareBtn"
            @cancel="
              e => {
                showShare = e
              }
            "
          />
        </div>
      </div>
    </PullUp>
  </div>
</template>

<script>
import useClipboard from 'vue-clipboard3'
const { toClipboard } = useClipboard()
import { numberFilter ,changeGold  , timeYmd} from '@/utils/filter'
const logoName = import.meta.env.VITE_APP_logoName
const baseUrl = import.meta.env.VITE_APP_baseUrl
import QrcodeVue from 'qrcode.vue'
import { video_play, video_like, video_pay } from '@/api/play'
import { collect } from '@/api/home'
import { showToast } from 'vant'
export default {
  name: 'Play',
  components: {
    QrcodeVue,
    JavShortSix: () => import('@/components/JavShortSix.vue'),
    JavVideo: () => import('@/components/JavVideo.vue'),
    LayoutsHeader: () => import('@/components/LayoutsHeader.vue'),
    PullUp: () => import('@/components/PullUp.vue'),
    JavShortFour: () => import('@/components/JavShortFour.vue'),
    JavSwiper: () => import('@/components/JavSwiper.vue'),
    BlShare: () => import('@/components/BlShare/index.vue'),
    JavComment: () => import('@/components/JavComment.vue')
  },
  data() {
    return {
      playURL: 'https://fanhaoshe.club/#/home',
      downShow: false, //显示下载弹出框
      videoInfo: {
        publisher: {}
      },
      videoLike: [],
      viedeoinfoAll: {},
      pageNum: 1,
      pageSize: 12,
      finished: false,
      loading: false,
      refreshing: false,
      skeleton: false,
      showComment: false, // 评论弹窗控制
      code: 0, // 是否可以播放code  6018。金币不足。6031/6032。 次数不足。   6033 需付费
      playable: false, // 是否可以播放
      showPorp: false,
      showShare: false
    }
  },
  watch: {
    $route: {
      async handler(n) {
        await this.getVideoInfo()
        await this.refreshData()
        // 存入视频 1为av  3为动漫
        this.$nextTick(() => {
          if (this.videoInfo.videoType === 1) {
            this.$store.dispatch('setAvList', {
              type: 'add',
              item: this.videoInfo
            })
          } else if (this.videoInfo.videoType === 3) {
            this.$store.dispatch('setCartoonList', {
              type: 'add',
              item: this.videoInfo
            })
          }
        })
      },
      immediate: true
    }
  },
  mounted() {
    this.playURL = self.location.href
  },
  computed: {
    hasPreview() {
      // 只有不是免费视频才走下面一层逻辑
      if (this.playable && this.code === 200) {
        return true
      } else {
        return false
      }
    },
    // 用户余额
    user({ $store }) {
      return $store.getters['getUserInfo']
    },
    playAD({ $store }) {
      return $store.getters['playAD']
    }
  },
  methods: {
    clickLogo() {
      this.$router.push('/')
    },
    share_fn() {
      this.showShare = true
    },
    // 评论弹窗事件
    comments_fn() {
      this.showComment = true
    },
    // 剪贴板
    async doCopy(text) {
      await toClipboard(text)
      showToast('复制地址成功')    
    },
    // 点击分享按钮
    shareBtn(options, index) {
      switch (index) {
        case 0:
          let str = window.location.href;
          this.doCopy(str)
          break
        default:
          this.$router.push({ path: '/mine/share' })
          break
      }
    },
    // 列表刷新
    refreshData(refreshing) {
      this.refreshing = refreshing
      this.loading = true
      this.finished = false
      this.videoLike = []
      this.pageNum = 1
      this.getVideoLike()
      this.skeleton = true
    },
    // 加载更多
    moreData(loading) {
      this.loading = loading
      this.pageNum += 1
      this.getVideoLike()
    },
    // 跳过预览事件
    skipPreview(child) {
      this.showPorp = child
    },
    // 视频收藏接口
    async checkLike(item) {
      const res = await collect({
        flag: !item.isLike,
        object_id: item.id,
        collect_type: item.videoType
      })
      if (res.code === 200) {
        item.isLike = !item.isLike
        if (this.videoInfo.isLike) {
          item.likes += 1
          return showToast('收藏成功')
        } else {
          item.likes -= 1
          return showToast('取消收藏')
        }
      } else {
        return showToast(res.tip)
      }
    },
    // 获取视频信息
    async getVideoInfo() {
      try {
        const res = await video_play({
          id: +this.$route.params.id
        })
        if (res.code === 200) {
          this.videoInfo = res.data.mediaInfo
          this.code = res.data.code
          this.playable = res.data.playable
        } else {
          return showToast(res.tip)
        }
      } catch (error) {
        console.log(error)
        return showToast('请求错误，请稍后再试!')
      }
    },
    // 获取猜你喜欢列表
    async getVideoLike() {
      try {
        const res = await video_like({
          id: +this.$route.params.id,
          pageNum: this.pageNum,
          pageSize: this.pageSize
        })
        if (res.code === 200) {
          this.loading = false
          this.refreshing = false
          this.videoLike = [...this.videoLike, ...res.data.mediaList]
          if (!res.data.mediaList || (res.data.mediaList && res.data.mediaList.length < this.pageSize)) {
            this.finished = true
          }
        } else {
          this.loading = false
          this.refreshing = false
          this.finished = true
          return showToast(res.tip)
        }
      } catch (error) {
        this.loading = false
        this.refreshing = false
        this.finished = true
        console.log(error)
        return showToast('请求错误，请稍后再试!')
      }
    },
    //  视频购买接口
    async videoPlay(type) {
      // 先判断当前余额
      if (this.user.balance < this.videoInfo.price) {
        this.code = 6018
        return
      }
      try {
        const res = await video_pay({
          id: +this.$route.params.id,
          payType: type
        })
        if (res.code === 200) {
          this.$refs.videoPlayNow.skipVideoPlay()
          this.showPorp = false
          this.code = 200
          this.playable = true
        } else {
          return showToast(res.tip)
        }
      } catch (error) {
        console.log(error)
        return showToast('请求失败，请稍后再试！')
      }
    },
    // 评论弹窗关闭
    close(show) {
      this.showComment = show
    }
  }
}
</script>
<style lang="scss" scoped>
.play-main {
  //max-width: 1380px;
  margin: 0 auto;
  min-height: 100vh;
  overflow: hidden;
  // transform: translate3d(0, 0, 0);
}
.down-wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-flow: column wrap;
  height: 100%;
  .qrcode-warp {
    padding: 0.2rem 0.2rem;
    background: #fff;
    font-size: 0;
  }
}

.play-main-max-width {
  max-width: 1280px;
  margin: 0 auto;
}
.logo-mini {
  display: none;
}
.play-main::-webkit-scrollbar {
  width: 0;
  height: 0;
}
.play-main::-moz-scrollbar {
  width: 0;
  height: 0;
}
.play-main::-ms-scrollbar {
  width: 0;
  height: 0;
}
.play-main::-o-scrollbar {
  width: 0;
  height: 0;
}
.video-title {
  background: $mainBgColor;
  box-shadow: $shadow;
  padding: 0.2rem 0.25rem;

  .desc {
    @include textoverflow(3);
    margin: 0;
    font-size: 0.2rem;
    color: #ccc;
  }
  h2 {
    margin: 0;
    font-size: 0.28rem;
  }
  .video-detail {
    @include flexbox($jc: space-between, $ai: center, $fd: row, $fw: nowrap);
    font-size: 0.24rem;
    color: #ccc;
    margin-top: 0.15rem;
    img {
      width: 0.2rem;
      height: 0.2rem;
      margin-right: 0.07rem;
    }
  }
}
// 标签列表
.videoInfo-main {
  margin-top: 0.2rem;
  background: $mainBgColor;
  box-shadow: $shadow;
  padding: 0.2rem 0.25rem 0.2rem 0.25rem;
  .tag,
  .bango,
  .time {
    @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
    margin-bottom: 0.35rem;
    .label {
      font-size: 0.24rem;
      font-weight: 600;
      margin-right: 0.28rem;
      flex-shrink: 0;
    }
  }
  .time {
    margin: 0;
  }
}
.tag {
  .label {
    margin-top: 0.2rem;
  }
}

.tag-list {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
}
.tag-txt {
  padding: 0.02rem 0.2rem;
  color: #848494;
  border: 0.02rem solid #848494;
  border-radius: 0.25rem;
  font-size: 0.22rem;
  margin-right: 0.34rem;
  margin-top: 0.2rem;
}
.tag-txt:hover,
.bango-txt:hover {
  cursor: pointer;
}
.bango-txt {
  padding: 0.01rem 0.16rem;
  color: #848494;
  border: 0.02rem solid #848494;
  border-radius: 0.05rem;
  font-size: 0.22rem;
  transform: scale(0.8);
}
.time-txt {
  font-size: 0.26rem;
  color: #848494;
}
.other-main {
  padding: 0.13rem 0.12rem;
}
.like-title {
  font-size: 0.3rem;
  font-weight: 600;
  margin: 0.3rem 0 0.2rem 0;
}
// 视频购买提示
.playWaring {
  width: 100%;
  z-index: 2;
  height: 100%;
  position: absolute;
  max-width: $pcMaxWidth;
  top: 0rem;
  left: 0;
  z-index: 999;
  background-color: rgba(0, 0, 0, 0.7);
  color: $mainTxtColor1;
  &-close {
    position: absolute;
    top: 0.2rem;
    right: 0.2rem;
  }
  // 金币购买
  .goldTip,
  .vipTip,
  .goldTip-noGold {
    font-size: 0.3rem;
    width: 100%;
    height: 100%;
    text-align: right;
    :deep()  {
      .van-icon {
        margin-top: 0.3rem;
      }
    }
    .goldTip-noGold-first,
    .goldTip-first,
    .vipTip-first {
      height: 100%;
      box-sizing: border-box;
      @include flexbox($jc: center, $ai: center, $fd: column, $fw: nowrap);
      h2 {
        font-size: 0.32rem;
        margin: 0.2rem 0;
      }
      p {
        margin: 0;
      }
      p,
      span {
        font-size: 0.2rem;
      }
      .btn {
        margin: 0.5rem 0;
        width: 100%;
        text-align: center;
        span {
          padding: 0.08rem 0.3rem;
          background: $btnBg;
          border-radius: 0.3rem;
          color: $mainTxtColor1;
          margin-right: 0.3rem;
        }
        span:last-child {
          background: none;
          border: 0.02rem solid $mainTxtColor1;
          color: $mainTxtColor1;
        }
      }
      .btn span:hover,
      .txt-btn:hover {
        cursor: pointer;
      }
    }
  }
}
.video-detail-pc {
  display: none;
}
@media screen and (min-width: 960px) {
  .logo-mini {
    display: block !important;
    width: 2rem;
    height: 0.5rem;
    font-size: 0;
    margin-right: 0.3rem;
   
    img {
      width: 100%;
      height: 100%;
    }
  }
  .md-mine-property-info {
    display: none;
  }
  :deep()  {
    .van-nav-bar {
      background: #000 !important;
    }
  }
  .video-title {
    padding: 0 0;
    h2 {
      padding: 0.15rem 0.25rem;
      font-size: 0.38rem;
    }
    .desc {
      padding: 0.05rem 0.25rem;
      font-size: 0.3rem;
    }
  }
  .bango-txt {
    font-size: 0.32rem !important;
  }
  .video-detail {
    display: none !important;
  }
  .video-detail-pc {
    @include flexbox($jc: space-between, $ai: center, $fd: row, $fw: nowrap);
    font-size: 0.24rem;
    div {
      cursor: pointer;
      flex: 1;
      text-align: center;
      border: #848494 1px solid;
      height: 0.75rem;
      line-height: 0.75rem;
    }
    .buyVIP {
      background: $btnBg;
    }
    .like img {
      position: relative;
      top: 0.05rem;
      width: 0.3rem;
      height: 0.3rem;
      margin-right: 0.07rem;
    }
  }
  :deep()  {
    .short-six-item {
      width: 16.6666% !important;
    }
    .van-nav-bar__title {
      display: none !important;
    }
  }
}
</style>
