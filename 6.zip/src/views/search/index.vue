<template>
  <div class="search-index">
    <!-- 输入框 -->
    <div class="search-input">
      <van-icon name="arrow-left" size="25" @click="toBack" />
      <van-search v-model="value" shape="round" background="#323232" placeholder="请输入您想搜索的内容" />
      <span class="sarch-btn" @click="searchBtn">搜索</span>
    </div>
    <!-- 面板 -->
    <div class="search-main">
      <!-- 历史记录 -->
      <ul class="history" v-if="historyList.length > 0">
        <li class="title">
          <span class="lable">历史记录</span>
          <span class="clear" @click="claerHistory">清除记录</span>
        </li>
        <li class="history-item">
          <ul>
            <li v-for="(item, index) in historyList" :key="item">
              <div class="lable-title" @click="toSearchType(item)">
                <img src="@/assets/imgs/search/history.svg" alt="" />
                {{ item }}
              </div>
              <div class="clear">
                <img @click="clear(index)" src="@/assets/imgs/search/clear.svg" alt="" />
              </div>
            </li>
          </ul>
        </li>
      </ul>
      <div class="history-nodata" v-else>暂无搜索记录</div>
      <!-- 热点 -->
      <div class="hot-main">
        <div class="title">
          <img class="clear" src="@/assets/imgs/search/search-hot.svg" alt="" />
          热点
        </div>
        <ul class="hot-list">
          <li v-for="item in hotList" @click="toSearchType(item)" :key="item">
            {{ item }}
          </li>
        </ul>
      </div>
      <!-- 广告 -->
      <!-- <img @click="toRank" class="banner" src="@/assets/imgs/search/search-rank.jpg" alt="" /> -->
    </div>
  </div>
</template>

<script>
import { showToast } from 'vant'
import { search_hot } from '@/api/search'
export default {
  name: 'SearchIndex',
  components: {},
  data() {
    return {
      value: '',
      hotList: []
    }
  },
  computed: {
    historyList({ $store }) {
      const arr = JSON.parse(JSON.stringify($store.getters['getSaerchlist'].reverse())).splice(0, 8)
      return arr
    }
  },
  mounted() {
    this.getHotList()
  },
  methods: {
    // 清空历史记录
    claerHistory() {
      this.$store.dispatch('setSaerchlist', {
        type: 'remove',
        value: []
      })
    },
    // 搜索按钮
    searchBtn() {
      if (this.value) {
        this.$store.dispatch('setSaerchlist', {
          type: 'add',
          value: this.value
        })

        this.$router.push(`/search/result/${this.value}`)
        this.value = null
      } else {
        return showToast('请输入您想搜索的内容')
      }
    },
    // 跳转搜索结果
    toSearchType(content) {
      if (content) {
        this.$store.dispatch('setSaerchlist', {
          type: 'add',
          value: content
        })
        this.$router.push(`/search/result/${content}`)
        content = null
      }
    },
    // 跳转排行榜
    toRank() {
      this.$router.push(`/rank`)
    },
    // 返回
    toBack() {
      this.$router.go('-1')
    },
    // 清除历史记录
    clear(index) {
      this.$store.dispatch('setSaerchlist', {
        type: 'del',
        value: index
      })
    },
    // 热门列表
    async getHotList() {
      const res = await search_hot()
      if (res.code === 200) {
        this.hotList = res.data.content
      } else {
        return showToast('请求失败，请稍后再试')
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.search-index {
  padding: 0;
  transform: translate3d(0, 0, 0);

  margin: 0 auto;
}
.search-input {
  height: 1rem;
  position: fixed;
  @include flexbox();
  padding: 0.2rem;
  font-size: 0.32rem;
  width: 100%;
  background: #323232;
  color: #fff;
  z-index: 10;
  .van-search {
    width: 80%;

    :deep()  {
      .van-search__content {
        padding-left: 0;
      }
      .van-cell__value {
        padding-right: 0.2rem;
      }
      .van-cell {
        border-radius: 0.25rem;
        padding: 0.04rem 0 0.04rem 0.18rem;
        color: #fff;
        background: linear-gradient(to right, #212125, #2d353d);
        .van-field__left-icon {
          color: #939496;
        }
        .van-field__control{
          color: #fff;
        }
      }
    }
  }
}
.search-main {
  max-width: $pcMaxWidth;
  min-height: 100vh;
  padding: 0.3rem;
  padding-top: 1.41rem;
  overflow: hidden;
  margin: 0 auto;
}
// 记录
.history {
  font-size: 0.22rem;
  width: 100%;
  padding: 0.3rem 0.42rem;
  box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
  background: $mainBgColor;
  &-item {
    overflow: auto;

    ul {
      width: 100%;
      padding: 0.2rem 0;
      li:first-child {
        font-size: 0.24rem;
        font-weight: 400;
      }
      li {
        margin-top: 0.2rem;
      }
    }
  }
  li {
    @include flexbox();
  }
  li:first-child {
    font-size: 0.3rem;
    font-weight: 600;
  }
  .lable-title {
    @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
    color: #939496;
    img {
      filter: brightness(100);
      width: 0.23rem;
      height: 0.23rem;
      margin-right: 0.15rem;
    }
  }
  .clear {
    text-align: center;
    min-width: 1.2rem;
    img {
      width: 0.158rem;
      height: 0.158rem;
    }
  }
}
// 没有搜索记录
.history-nodata {
  height: 2rem;
  text-align: center;
  width: 100%;
  line-height: 2rem;
  box-shadow: $shadow;

  font-size: 0.32rem;
  color: #939496;
}
// 热点
.hot-main {
  padding: 0.48rem 0.42rem;
  font-size: 0.24rem;
  .title {
    font-weight: 600;
    display: flex;
    align-items: center;

    img {
      width: 0.24rem;
      height: 0.28rem;
      margin-right: 0.15rem;
    }
  }
  .hot-list {
    display: flex;
    align-items: center;
    flex-wrap: wrap;

    li {
      @include textoverflow();
      padding: 0.05rem 0.2rem;
      margin-top: 0.22rem;
      margin-right: 0.26rem;
      max-width: 2rem;
      border: 0.02rem solid #e4e4e4;
      border-radius: 0.25rem;
    }
  }
}
.banner {
  width: 100%;
  height: 1.8rem;
}
</style>
