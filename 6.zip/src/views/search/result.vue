<template>
  <div class="search-index">
    <!-- 输入框 -->
    <div class="search-input">
      <van-icon name="arrow-left" size="25" @click="toBack" />
      <van-search v-model="value" shape="round" background="transparent" placeholder="请输入您想搜索的内容" />
      <span class="sarch-btn" @click="searchBtn">搜索</span>
    </div>
    <!-- 面板 -->
    <div class="search-main">
      <ul class="search-title">
        <li @click="changeActive(1)" :class="{ active: activeIndex === 1 }">
          <span>AV</span>
        </li>
        <li @click="changeActive(2)" :class="{ active: activeIndex === 2 }">
          <span>小视频</span>
        </li>
        <li @click="changeActive(7)" :class="{ active: activeIndex === 7 }">
          <span>女优</span>
        </li>
        <li @click="changeActive(3)" :class="{ active: activeIndex === 3 }">
          <span>动漫</span>
        </li>
        <li @click="changeActive(8)" :class="{ active: activeIndex === 8 }">
          <span>漫画</span>
        </li>        
      </ul>
      <!-- 上拉，下拉 -->
      <PullUp
        v-if="list.length > 0"
        @refreshData="refreshData"
        @moreData="moreData"
        :finished="finished"
        :loading="loading"
        :refreshing="refreshing"
      >
        <!-- <JavFourCard v-if="activeIndex === 1" :list="list" /> -->
        <JavShortFour
          :id="value"
          typeTxt="搜索"
          :list="list"
          v-if="activeIndex === 2 || activeIndex === 3 || activeIndex === 1"
        />
        <div class="actor-list" v-if="activeIndex === 7">
          <div class="actor-list-item" @click="toAcortDeatial(item)" v-for="item in list" :key="item.id">
            <DecryptImg class="actore-avatar" :imgURL="item.avatar" />
            <span>{{ item.name }}</span>
          </div>
          <i class="actor-list-item"></i>
          <i class="actor-list-item"></i>
          <i class="actor-list-item"></i>
          <i class="actor-list-item"></i>
        </div>
        <div class="list-wrap" v-if="activeIndex === 8">
          <ul>
            <DmComicCard v-for="(item, index) in list" :item="item" :key="index"></DmComicCard>
          </ul>
        </div>
      </PullUp>
      <Nodata :text="'搜索不到任何结果哦～'" v-else />
    </div>
  </div>
</template>

<script>
import { search } from '@/api/search'
import { showToast } from 'vant'
export default {
  name: 'SearchResult',
  components: {
    DmComicCard: () => import('@/components/Comic/oneCard/index.vue'),
    JavFourCard: () => import('@/components/JavFourCard.vue'),
    JavShortFour: () => import('@/components/JavShortFour.vue'),
    DecryptImg: () => import('@/components/DecryptImg/index.vue'),
    Nodata: () => import('@/components/JavNodata.vue'),
    PullUp: () => import('@/components/PullUp.vue')
  },
  data() {
    return {
      content: '',
      list: [],
      refreshing: false, // 下拉刷新开关
      loading: false, // 上拉加载
      finished: false, // 上拉加载开关
      mediaType: 0, // 1短视频 2长视频
      pageNum: 1,
      pageSize: 10,
      activeIndex: 1,
      value: ''
    }
  },
  computed: {
    historyList({ $store }) {
      return $store.getters['history/getSaerchlist']
    }
  },
  mounted() {
    this.value = this.$route.params.value;
    if(!this.list.length) this.getResultList();
    
  },

  methods: {
    // 搜索按钮
    searchBtn() {
      this.pageNum = 1
      this.list = []
      this.getResultList()
      this.$store.dispatch('setSaerchlist', {
        type: 'add',
        value: this.value
      })
    },
    // 女优详情跳转
    toAcortDeatial(item) {
      this.$router.push(`/actor/detail/${item.id}`)
    },
    // 改变状态
    changeActive(type) {
      this.activeIndex = type
      this.refreshData()
    },
    // 返回
    toBack() {
      this.$router.go('-1')
    },
    // 清除历史记录
    clear(index) {
      this.$store.dispatch('setSaerchlist', {
        type: 'del',
        value: index
      })
    },
    // 搜索请求
    async getResultList() {
      if (this.value) {
        try {
          const res = await search({
            content: this.value,
            type: this.activeIndex,
            pageNum: this.pageNum,
            pageSize: this.pageSize
          })
          if (res.code === 200) {
            this.refreshing = false
            this.loading = false
            // 女优的activeIndex 为7
            if (this.activeIndex === 7) {
              this.list = [...this.list, ...res.data.actorList]
              if (res.data.actorList.length < this.pageSize || !res.data.actorList) {
                this.finished = true
              }
            }else if (this.activeIndex === 8) {
              this.list = [...this.list, ...res.data.comicsList]
              if (res.data.comicsList.length < this.pageSize || !res.data.comicsList) {
                this.finished = true
              }
            } else {
              this.list = [...this.list, ...res.data.mediaList]
              if (res.data.mediaList.length < this.pageSize || !res.data.mediaList) {
                this.finished = true
              }
            }
          } else {
            this.loading = false
            this.refreshing = false
            this.finished = true
            return showToast(res.tip)
          }
        } catch (error) {
          this.loading = false
          this.refreshing = false
          this.finished = true
          console.log(error)
          return showToast('请求出错，请稍后再试！')
        }
      } else {
        showToast('请输入搜索关键词')
      }
    },
    // 下拉刷新
    refreshData(refreshing) {
      this.refreshing = refreshing
      this.pageNum = 1
      this.finished = false
      this.loading = true
      this.list = []
      this.getResultList()
    },
    // 上拉加载
    moreData(loading) {
      this.loading = loading
      this.pageNum += 1
      this.getResultList()
    }
  }
}
</script>

<style lang="scss" scoped>
.search-index {
  transform: translate3d(0, 0, 0);
  margin: 0 auto;
  padding: 0;
}
.search-input {
  height: 1rem;
  position: fixed;
  @include flexbox();
  padding: 0.2rem;
  font-size: 0.32rem;
  width: 100%;

  background: $mainBgDeepColor;
  z-index: 10;
  color: $mainTxtColor1;
  .van-search {
    width: 80%;
    :deep()  {
      .van-field__control {
        color: #fff;
      }
      .van-search__content {
        padding-left: 0;
      }
      .van-cell__value {
        padding-right: 0.2rem;
      }
      .van-cell {
        border-radius: 0.25rem;
        padding: 0.04rem 0 0.04rem 0.18rem;
        background: linear-gradient(to right, #212125, #2d353d);
        .van-field__left-icon {
          color: #939496;
        }
      }
    }
  }
}
.search-main {
  min-height: 100vh;
  padding: 0.3rem;
  padding-top: 2.3rem;
  max-width: $pcMaxWidth;
  margin: 0 auto;
  .search-title {
    display: flex;
    align-items: center;
    text-align: center;
    position: fixed;
    width: 100%;
    max-width: $pcMaxWidth;
    top: 1rem;
    left: 50%;
    @include transformCenter(-50%, 0);
    z-index: 2;
    background: $mainBgDeepColor;
    padding: 0.3rem 0.2rem 0 0.2rem;
    li {
      line-height: 0.82rem;
      width: 50%;
      height: 0.95rem;
      color: #fff;
      font-size: 0.28rem;
    }
  }
}
// 女优单独列表
.actor-list {
  @include flexbox($jc: space-between, $ai: flex-start, $fd: row, $fw: wrap);
  padding: 0.25rem;
  .actor-list-item {
    font-size: 0.24rem;
    margin-bottom: 0.3rem;
    text-align: center;
    margin-right: 4%;
    width: 20%;
    span {
      color: #f0a244;
      margin: 0;
      margin-top: 0.2rem;
      font-size: 0.24rem;
      display: block;
    }
    .actore-avatar {
      border-radius: 50%;
      :deep()  {
        .warp {
          border-radius: 50%;
          img {
            border-radius: 50%;
          }
        }
      }
    }
  }
  &-item:nth-child(4n) {
    margin-right: 0;
  }
}
//漫画
.list-wrap {
  ul {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    li {
      display: flex;
      flex-direction: column;
      margin-bottom: 0.2rem;
      .md-img {
        height: 2.86rem;
      }
      .decial-wrap {
        width: 100%;
        border-radius: 0.12rem;
        .decial {
          display: flex;
          flex-direction: column;
          div {
            &:first-child {
              padding-top: 0.12rem;
              font-size: 0.28rem;
              color: #6a6a6a;
            }
            &:last-child {
              font-size: 0.18rem;
              color: #a0a0a0;
              overflow: hidden;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              white-space: normal;
            }
          }
        }
      }
    }
  }
}
.active {
  span {
    font-weight: 600;
    background: linear-gradient(to right, #ef347d, #450835);
    -webkit-background-clip: text;
    &::after {
      content: '';
      width: 0.36rem;
      display: block;
      height: 0.08rem;
      margin: 0.03rem auto 0 auto;
      background: -webkit-linear-gradient(left, #ef347d, #450835);
      background: linear-gradient(to right, #ef347d, #450835);
      border-radius: 0.12rem;
      text-align: center;
    }
  }
}
</style>
