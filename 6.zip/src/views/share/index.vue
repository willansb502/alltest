<template>
  <div class="share"></div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>

</style>
