<template>
  <!-- 首页播放页 -->
  <div class="home-short-video">
    <van-icon class="s-nav" @click="$router.go(-1)" size="0.34rem" name="arrow-left" />
    <div class="logo-mini" @click="clickLogo">
      <img src="@/assets/imgs/header-left.png" alt="" />
    </div>

    <ul class="tab-wrap">
      <li
        v-for="(item, index) in state.tabsList"
        :class="{ active: state.tabsActiveItem.name == item.name }"
        :key="index"
        @click="tabsListSel(item)"
      >
        {{ item.name }}
      </li>
    </ul>
    <!-- 推荐 -->
    <ShortVideoRem v-if="state.tabsActiveItem.name == '推荐'" :homeSvParams="state.tabsActiveItem"></ShortVideoRem>
    <ShortVideoFocus v-if="state.tabsActiveItem.name == '关注'" :homeSvParams="state.tabsActiveItem"></ShortVideoFocus>
  </div>
</template>
<script setup>
const ShortVideoRem = defineAsyncComponent(() => import('@/components/ShortVideo/index.vue'))
const ShortVideoFocus = defineAsyncComponent(() => import('@/components/ShortVideo/index.vue'))
const router = useRouter()
//切换选项内容
const state = reactive({
  tabsActiveItem: { name: '推荐', id: 2, nowPosit: '首页短视频' },
  tabsList: [
    { name: '推荐', id: 2, nowPosit: '首页短视频' },
    { name: '关注', id: 1, nowPosit: '首页短视频' }
  ]
})

const clickLogo = () =>{
  router.push('/')
}

const tabsListSel = () =>{
  state.tabsActiveItem = item
}

</script>

<style lang="scss" scoped>
.s-nav {
  cursor: pointer;
  position: absolute;
  z-index: 999;
  left: 0.28rem;
  top: 0.28rem;
}
.logo-mini {
  display: none;
}
.home-short-video {
  min-height: 100%;
  overflow: hidden;
  background: #000;
  // 导航
  .tab-wrap {
    position: fixed;
    z-index: 99;
    left: 50%;
    transform: translateX(-50%);
    width: 100%;
    max-width: $pcMaxWidth;
    padding-bottom: 0.2rem;
    display: flex;
    justify-content: center;
    align-items: center;
    color: $mainTxtColor1;
    font-size: 0.32rem;
    padding-top: 0.3rem;
    li {
      cursor: pointer;
      &:nth-child(1) {
        margin-right: 1.2rem;
      }
      &.active {
        position: relative;
        font-weight: 700;
        &::after {
          position: absolute;
          content: '';
          width: 50%;
          height: 0.08rem;
          background: linear-gradient(to right, #e9e24b, #e365c2);
          bottom: -0.15rem;
          left: 50%;
          transform: translateX(-50%);
          border-radius: 0.4rem;
        }
      }
    }
  }
  // 播放页
}

@media screen and (min-width: 750px) {
  .home-short-video {
    .s-nav {
      left: 1.98rem;
    }
    .logo-mini {
      cursor: pointer;
      position: absolute;
      right: 1.98rem;
      top: 0.28rem;
      z-index: 999;
      display: block !important;
      width: 2rem;
      height: 0.5rem;
      font-size: 0;
      margin-right: 0.3rem;
      img {
        width: 100%;
        height: 100%;
      }
    }
  }
}
</style>
