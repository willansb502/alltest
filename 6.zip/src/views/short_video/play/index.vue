<template>
  <!-- 常规播放页 -->
  <div class="home-short-video">
    <!-- <van-icon class="s-nav" @click="$router.go(-1)" size="0.34rem" name="arrow-left" /> -->
    <ShortVideo></ShortVideo>
  </div>
</template>
<script>
export default {
  components: {
    ShortVideo: () => import('@/components/ShortVideo/index.vue')
  }
}
</script>
<style scoped>
.home-short-video {
  max-height: 100vh;
  overflow: hidden;
}
</style>