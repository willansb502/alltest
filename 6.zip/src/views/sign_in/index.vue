<template>
  <div class="sign-in">
    <LayoutsHeader :title="'签到'" />
    <div class="sign-main">
      <div class="top">
        <div class="top-left">
          <img src="@/assets/imgs/icon_sign_title.png" style="filter: invert(50%)" alt="" />
          <div class="days">
            已连续签到<span>{{ checkData.checkedDays }}</span
            >天 中途中断会清零
          </div>
        </div>
        <div class="btn" @click="checkIn(checkData.todayChecked)">{{ checkData.todayChecked ? '已签到' : '签到' }}</div>
      </div>
      <!-- 签到进度条 -->
      <ul class="progress">
        <li v-for="item in 7" :key="item">
          <img
            v-if="checkData.todayChecked && item <= checkData.checkedDays"
            src="@/assets/imgs/icon_sign_today_signed.png"
            alt=""
          />
          <img
            v-else
            :src="
              !checkData.todayChecked && item <= checkData.checkedDays
                ? getAssetsFile('icon_sign_used_signed.png')
                : getAssetsFile(`icon_sign_no_signed${item}.png`)
            "
            alt=""
          />

          <p>{{ 7 >= checkData.checkedDays ? item : item + (checkData.checkedDays - 7) }}</p>
        </li>
        <li class="line"></li>
      </ul>
    </div>
    <!-- 中间的图 -->
    <div class="img-center"><img src="@/assets/imgs/icon_sign_reward.png" alt="" /></div>
    <!-- 领取规则 -->
    <ul class="setup-list">
      <li v-for="item in checkData.checkin_setup" :key="item.id">
        <span>{{ item.setups.day_num === 1 ? '每日领取' : `连续${item.setups.day_num}天充值奖励` }}</span>
        <div class="gold_num">
          <img src="@/assets/imgs/index/gold.png" alt="" />

          金币+{{ changeGold(item.setups.gold_num) }}
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
import { getAssetsFile } from '@/utils/utils_tools'
import { showToast } from 'vant'
import { changeGold } from '@/utils/filter'
import { checkin_list, checkin_click } from '@/api/home'
export default {
  name: 'signIn',
  components: {
    LayoutsHeader: () => import('@/components/LayoutsHeader.vue'),
    DecryptImg: () => import('@/components/DecryptImg/index.vue')
  },
  data() {
    return {
      checkData: {}
    }
  },
  created() {
    this.getCheckInList()
  },
  methods: {
    // 获取签到记录列表
    async getCheckInList() {
      try {
        const res = await checkin_list()
        if (res.code === 200) {
          this.checkData = res.data
        } else {
          showToast(res.tip)
        }
      } catch (error) {
        showToast('请求失败，请稍后再试！')
      }
    },

    // 用户签到
    async checkIn(todayChecked) {
      if (!todayChecked) {
        try {
          const res = await checkin_click()
          if (res.code === 200) {
            this.getCheckInList()
            showToast('签到成功')
          } else {
            showToast(res.tip)
          }
        } catch (error) {
          showToast('请求失败，请稍后再试！')
        }
      } else {
        return
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.sign-in {
  max-width: 960px;
  margin: 0 auto;
  padding-top: 1rem;
  .sign-main {
    background-image: linear-gradient(to bottom, rgba(255, 255, 255, 0), #000);
    box-shadow: 0 3px 12px 0 rgba(0, 0, 0, 0.16);
    padding: 0.25rem;
    .btn {
      border-radius: 0.37rem;
      box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.16);
      border: solid 2px $mainTxtColor1;
      background-image: linear-gradient(to bottom, #fbe07c 94%, #ffbb10 3%);
      padding: 0.1rem 0.56rem;
      color: #000;
    }
    .btn:hover {
      cursor: pointer;
    }
    .days {
      span {
        font-size: 0.39rem;
        color: #fff;
        margin: 0 0.02rem;
      }
    }
    .top {
      @include flexbox();
      font-size: 0.26rem;
      color: #fff;
      img {
        width: 1.48rem;
        height: 1.03rem;
      }
    }
  }

  .progress {
    @include flexbox($jc: center, $ai: center, $fd: row, $fw: nowrap);
    margin-top: 0.48rem;
    position: relative;
    li {
      @include flexbox($jc: center, $ai: center, $fd: column, $fw: nowrap);
      img {
        width: 0.44rem;
        height: 0.44rem;
      }
      p {
        font-size: 0.24rem;
        color: #fff;
        margin: 0.14rem 0 0.1rem 0;
      }
    }
    .line {
      position: absolute;
      height: 0.15rem;
      width: 90%;
      top: 0.14rem;
      left: 50%;
      z-index: -1;
      @include transformCenter(-50%, 0);
      box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.16);
      background-image: linear-gradient(to right, #fd0000 0%, rgba(252, 52, 45, 0.2) 98%);
    }
  }
}
.img-center {
  text-align: center;
  margin: 0.4rem 0 0.3rem 0;
  img {
    width: 4.13rem;
    height: 0.78rem;
  }
}
.setup-list {
  padding: 0 0.25rem;
  li {
    background-size: 100% 100%;
    @include flexbox();
    font-size: 0.32rem;
    padding: 0.17rem 0.8rem 0.17rem 0.41rem;
    margin-bottom: 0.2rem;
    box-shadow: $shadow;
    .gold_num {
      display: flex;
      align-items: center;
      img {
        width: 0.27rem;
        height: 0.27rem;
        margin-right: 0.2rem;
      }
    }
  }
}
@media screen and (min-width: 750px) {
  .setup-list {
    padding: 0 0.25rem;
    li {
      background-size: 100% 100%;
      @include flexbox();
      font-size: 0.32rem;
      padding: 0.57rem 0.8rem 0.57rem 0.41rem;
      margin-bottom: 0.2rem;
      box-shadow: $shadow;
      .gold_num {
        display: flex;
        align-items: center;
        img {
          width: 0.27rem;
          height: 0.27rem;
          margin-right: 0.2rem;
        }
      }
    }
  }
}
</style>
