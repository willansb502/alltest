<template>
  <div class="up">
    <LayoutsHeader :title="upInfoData.name" />
    <div class="up-main">
      <div class="top-avatar">
        <DecryptImg class="avatar" :imgURL="upInfoData.avatar" />
        <div class="top-title">
          <p>{{ upInfoData.name }}</p>
          <span>粉丝 {{ upInfoData.fans }}</span>
        </div>
        <span @click.stop="clickPrivateLetter(upInfoData)">私信</span>
        <span @click.stop="addCare(upInfoData)">{{ upInfoData.isFollow ? '取消关注' : '关注' }}</span>
      </div>
      <!-- 切换 -->
      <JavBgNav @navChange="navChange" :titles="childCategory" :active="indexActive" />
      <PullUp
        @refreshData="refreshData"
        @moreData="moreData"
        :finished="finished"
        :loading="loading"
        :refreshing="refreshing"
        class="tab-main"
      >
        <JavShortFour :id="$route.params.id" typeTxt="up" v-if="indexActive === 0" :list="mediaList" />
        <div class="postList" v-else>
          <PostItem class="post-item" v-for="item in publishList" :key="item.base.id" :itemData="item" />
        </div>
      </PullUp>
    </div>
  </div>
</template>

<script>
import { user_publish, user_media } from '@/api/community'
import { care_add } from '@/api/home'
import { showToast } from 'vant'
export default {
  name: 'upIndex',
  components: {
    LayoutsHeader: () => import('@/components/LayoutsHeader.vue'),
    DecryptImg: () => import('@/components/DecryptImg/index.vue'),
    JavBgNav: () => import('@/components/JavBgNav.vue'),
    PullUp: () => import('@/components/PullUp.vue'),
    JavShortFour: () => import('@/components/JavShortFour.vue'),
    PostItem: () => import('@/components/Community/default.vue')
  },
  data() {
    return {
      info: [], //up主个人信息
      pageSize: 10,
      indexActive: 0,
      pageNum: 1,
      finished: false, //
      loading: false,
      refreshing: false,
      upInfoData: {}, //个人信息
      mediaList: [], //短视频列表
      childCategory: [
        { id: 0, name: '小视频' },
        { id: 1, name: '帖子' }
      ],
      publishList: [] // 帖子列表
    }
  },
  created() {
    this.refreshData()
  },
  computed: {
    isMember({ $store }) {
      return $store.getters['isMember']
    }
  },
  methods: {
    navChange(index) {
      this.indexActive = index
      this.refreshData()
    },
    /**
     * 点击私信
     */

    clickPrivateLetter(data) {
      if (this.isMember) {
        this.$router.push({
          path: `/oneSession/${data.id}`,
          query: {
            nickName: data.name,
            avatar: data.avatar
          }
        })
      } else {
        showToast('开通会员才能发起私聊！')
      }
    },
    // 上拉加载更多
    moreData(loading) {
      this.loading = loading
      this.pageNum += 1
      if (this.indexActive === 0) {
        this.upMedia()
      } else {
        this.upInfo()
      }
    },
    // 下啦刷新
    refreshData(refreshing) {
      this.refreshing = refreshing
      this.loading = true
      this.finished = false
      this.publishList = []
      this.mediaList = []
      this.pageNum = 1
      if (this.indexActive === 0) {
        this.upMedia()
      } else {
        this.upInfo()
      }
    },
    // 获取帖子
    async upInfo() {
      try {
        const res = await user_publish({
          userId: +this.$route.params.id,
          pageSize: this.pageSize,
          pageNum: this.pageNum
        })
        if (res.code === 200) {
          this.loading = false
          this.refreshing = false
          if (!res.data.list || (res.data.list && res.data.list.length < this.pageSize)) {
            this.finished = true
          }
          this.publishList = [...this.publishList, ...res.data.list]
        } else {
          this.loading = false
          this.refreshing = false
          this.finished = true
          showToast(res.tip)
        }
      } catch (error) {
        this.loading = false
        this.refreshing = false
        this.finished = true
        console.log(error)
        showToast('请求错误，请稍后再试！')
      }
    },
    // 获取个人小视频列表
    async upMedia() {
      try {
        const res = await user_media({
          userId: +this.$route.params.id,
          pageSize: this.pageSize,
          pageNum: this.pageNum
        })
        if (res.code === 200) {
          this.loading = false
          this.refreshing = false
          if (this.pageNum === 1) {
            this.upInfoData = res.data.publisher
          } else {
            res.data.publisher ? (this.upInfoData = res.data.publisher) : (this.upInfoData = this.upInfoData)
          }
          if (!res.data.mediaList || (res.data.mediaList && res.data.mediaList.length < this.pageSize)) {
            this.finished = true
          }
          this.mediaList = [...this.mediaList, ...res.data.mediaList]
        } else {
          this.loading = false
          this.refreshing = false
          this.finished = true
          showToast(res.tip)
        }
      } catch (error) {
        this.loading = false
        this.refreshing = false
        this.finished = true
        console.log(error)
        showToast('请求错误，请稍后再试！')
      }
    },
    async addCare(item) {
      // 关注用户
      try {
        const res = await care_add({
          id: item.id,
          add: !item.isFollow
        })
        if (res.code === 200) {
          item.isFollow = !item.isFollow
          if (item.isFollow) {
            return showToast('关注成功')
          } else {
            return showToast('取消关注')
          }
        } else {
          return showToast(res.tip)
        }
      } catch (error) {
        console.log(error)
        return showToast('请求失败，请稍后再试')
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.up {
  padding-top: 1rem;
}
.up-main {
  padding: 0 0.25rem;
}
.postList {
  max-width: 640px;
  margin: 0 auto;
  .post-item{
    :deep()  {
      .care{
        display: none;
      }
    }    
  }
}
// 顶部头像
.top-avatar {
  @include flexbox($jc: center, $ai: center, $fd: row, $fw: nowrap);
  font-size: 0.22rem;
  margin: 0.2rem 0;
  white-space: nowrap;
  height: 1.8rem;
  box-shadow: $shadow;
  border-radius: 0.05rem;
  .top-title {
    margin-left: 0.19rem;
    span {
      color: #848494;
      border: none;
      padding: 0;
      margin: 0;
    }
  }
  p {
    margin: 0;
    font-size: 0.28rem;
    font-weight: 600;
  }
  .avatar {
    width: 1.2rem;
    border-radius: 50%;
    :deep()  {
      .warp {
        border-radius: 50%;
      }
    }
  }
  span {
    padding: 0.01rem 0.23rem;
    border: 0.02rem solid #fd9a3a;
    color: #fd9a3a;
    border-radius: 0.19rem;
    margin-left: 0.3rem;
  }
}
</style>
