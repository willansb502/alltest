<template>
  <div class="vip-main">
    <LayoutsHeader :title="'会员中心'" />
    <div class="vip-content">
      <!-- 用户信息 -->
      <div class="user">
        <div class="user-detail">
          <DecryptImg :imgURL="user.avatarUrl" />
          <div class="user-name">
            <h2>{{ user.nickName }}</h2>
            <div class="user-vip" v-if="isMember">
              <div>VIP类型：{{ user.cardName }}</div>
              <div>到期时间：{{ user.vipExpireTime.split('T')[0] }}</div>
            </div>
          </div>
        </div>
      </div>
      <!-- 卡片权益 -->
      <div class="card-main">
        <ul class="card-list">
          <li
            v-for="(item, index) in list.list"
            :key="item.id"
            @click="change(item, index)"
            :class="{ bg: active === item.id }"
          >
            <h2>{{ item.title }}</h2>
            <div class="price">{{ changeGold(item.money) }}</div>
            <div class="desc" v-if="item.dayMoney">{{ item.dayMoney }}</div>
            <div class="hd" v-if="item.cardRemark">{{ item.cardRemark }}</div>
          </li>
        </ul>
        <!-- 活动倒计时 -->
        <div class="advertiseTimeOut" v-if="time(activeItem.rewardsCountdown)">
          {{ activeItem.newUserGift }}
          <van-count-down :time="time(activeItem.rewardsCountdown) ? time(activeItem.rewardsCountdown) : 0">
            <template #default="timeData">
              <span class="advertiseTimeOut-block">{{ timeData.days }}</span>
              <span class="advertiseTimeOut-text">天</span>
              <span class="advertiseTimeOut-block">{{ timeData.hours }}</span>
              <span class="advertiseTimeOut-text">时</span>
              <span class="advertiseTimeOut-block">{{ timeData.minutes }}</span>
              <span class="advertiseTimeOut-text">分</span>
              <span class="advertiseTimeOut-block">{{ timeData.seconds }}</span>
              <span class="advertiseTimeOut-text">秒</span>
            </template>
          </van-count-down>
        </div>
        <!-- 卡片描述 -->
        <p class="activeItem-desc">{{ activeItem.desc }}</p>
        <!-- 开通按钮 -->
        <div class="btn" v-if="!activeItem.isBuy" @click="shoudBuy = true">
          <div class="price-box">
            <span class="price">{{ changeGold(activeItem.money) }}</span>
            <span class="old-price">¥{{ changeGold(activeItem.preMoney) }}</span>
          </div>
          <div class="txt">立即开通</div>
        </div>
        <div class="isBuy-btn" v-else>已开通</div>
        <!-- 权益 -->
        <ul class="active-card-right">
          <li><span class="line"></span><span> ●</span> 会员权益<span> ●</span> <span class="line"></span></li>
          <li v-for="item in activeItem.rights" :key="item.name">
            <p>{{ item.name }}</p>
            <p>{{ item.desc }}</p>
          </li>
        </ul>
      </div>
    </div>

    <!-- 底部支付弹窗 -->
    <van-popup v-model:show="shoudBuy" position="bottom" :style="{ height: '50vh' }" class="submit-pop">
      <div class="content">
        <div class="title">
          请选择支付方式
          <div>
            支付问题遇到问题？请联系
            <span @click="$router.push('/mine/setting/kf')">在线客服</span>
          </div>
        </div>
        <ul class="pay-list">
          <li :key="index" v-for="(item, index) in activeItem.rchgType" @click="fn_sel(item.type)" class="item">
            <div class="left" v-if="item.type === 'alipay'">
              <img src="@/assets/imgs/mine/zfb.png" alt="" />{{ item.typeName }}
            </div>
            <div class="left" v-if="item.type === 'wechat'">
              <img src="@/assets/imgs/mine/weChat.png" alt="" />{{ item.typeName }}
            </div>
            <div class="left" v-if="item.type === 'overage'">
              <img src="@/assets/imgs/mine/gold.png" alt="" />{{ item.typeName }}
            </div>
            <div class="left" v-if="item.type === 'union'">
              <img src="@/assets/imgs/mine/bank.png" alt="" />{{ item.typeName }}
            </div>
            <div class="left" v-if="item.type === 'daichong'">
              <img src="@/assets/imgs/mine/gold.png" alt="" />{{ item.typeName }}
            </div>
            <div class="right">
              <div class="active" v-if="item.type === payMode"></div>
            </div>
          </li>
        </ul>
        <div class="tip-wrap">
          支付提示：<br />
          1、出现支付风险提示不要担心，重新支付即可<br />
          2、当支付通道无法付款，请选择其他方式<br />
          3、付款如遇到其他问题，可咨询在线客服处理
        </div>
        <div class="submit" @click="fn_submit">
          <div>确认支付</div>
        </div>
      </div>
    </van-popup>
  </div>
</template>

<script>
import { showToast , showLoadingToast } from 'vant'
import { changeGold } from '@/utils/filter'
import { vip_list, recharge_sumbit } from '@/api/home'
import { userInfo } from '@/api/user'
export default {
  name: 'Vip',
  data() {
    return {
      list: {},
      active: 0,
      activeItem: {},
      shoudBuy: false,
      payMode: ''
    }
  },

  components: {
    LayoutsHeader: () => import('@/components/LayoutsHeader.vue'),
    DecryptImg: () => import('@/components/DecryptImg/index.vue')
  },
  computed: {
    user({ $store }) {
      return $store.getters['getUserInfo']
    },
    isMember({ $store }) {
      return $store.getters['isMember']
    }
  },
  async created() {
    await this.getVipList()
    await this.getUserInfo()
  },
  methods: {
    // 时间差计算
    time(date) {
      const nowTiem = new Date().getTime()
      const newTime = Date.parse(date)
      const other = newTime - nowTiem
      if (other && other > 0) {
        return other
      } else {
        return false
      }
    },
    change(item, index) {
      this.activeItem = this.list.list[index]
      this.active = item.id
    },
    // 获取用户信息
    async getUserInfo() {
      const res = await userInfo()
      if (res && res.code === 200) {
        this.$store.dispatch('setUserInfo', res.data)
      }
    },
    // 获取会员卡列表
    async getVipList() {
      try {
        const res = await vip_list()
        if (res.code === 200 && res.data.list) {
          this.list = res.data.list.detailList[0]
          this.activeItem = this.list.list[0]
          this.active = this.list.list[0].id
          this.payMode = this.list.list[0].rchgType[0].type
        } else {
          return showToast(res.tip || '请求错误，请稍后再试！')
        }
      } catch (error) {
        console.log(error)
        return showToast('请求错误，请稍后再试！')
      }
    },
    // 选择支付方式
    fn_sel(type) {
      this.payMode = type
    },
    // 支付金币
    async fn_submit() {
      if (!this.payMode) return showToast('请选择支付通道！！！')
      showLoadingToast({
        duration: 0,
        message: '跳转中请稍后'
      })
      const res = await recharge_sumbit({
        payAmount: this.activeItem.money,
        payMode: this.payMode,
        productId: this.activeItem.id,
        rchgUse: this.activeItem.rchgUse
      })
      if (res.code === 200) {
        this.showPop = false
        this.activeItem.isBuy = true
        if (!res.data) return showToast('购买成功！！！')
        if (res.data && res.data.isOpenNewBrowser) {
          this.downloadFileByTagA(res.data.payUrl)
        }
      } else {
        showToast(res.tip)
      }
    },
    /* 利用a标签跳转safari浏览器机制 */
    downloadFileByTagA(fileUrl) {
      const TagA = document.createElement('a')
      TagA.href = fileUrl
      // TagA.target = '__blank';

      TagA.className = 'oInput'
      TagA.style.display = 'none'

      // 兼容ios safari浏览器
      const e = document.createEvent('MouseEvent')
      e.initEvent('click', false, false)
      TagA.dispatchEvent(e)
    }
  }
}
</script>

<style lang="scss" scoped>
.vip-main {
  padding-top: 1rem;
  min-height: 100vh;
  max-width: 540px;
  margin: 0 auto;
  .user {
    background-image: linear-gradient(106deg, #8996b5 10%, #4f5789 97%);
    padding: 0.67rem 0.65rem 0 0.65rem;
    &-detail {
      height: 1.56rem;
      box-shadow: 0 3px 12px 0 rgba(68, 68, 230, 0.16);
      background-image: linear-gradient(97deg, #e0f7ff 1%, #eef9ff 28%, #8e9bc8 98%);
      font-size: 0.2rem;
      color: #7c88ab;
      border-top-left-radius: 0.15rem;
      border-top-right-radius: 0.15rem;
      @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
      padding: 0.2rem 0.2rem 0 0.2rem;
      :deep()  {
        .default {
          border-radius: 50%;
          width: 1.12rem;
        }
        .warp {
          border-radius: 50%;
        }
      }
      h2 {
        font-size: 0.32rem;
        color: #616e97;
        margin: 0 0 0.1rem 0.2rem;
      }
      .user-vip {
        @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
        white-space: nowrap;
        transform: scale(0.9);
        div:first-child {
          margin-right: 0.1rem;
        }
      }
    }
  }
  // 会员卡
  .card-main {
    background: url('../../assets/imgs/vip/card-bg.jpg') no-repeat;
    background-size: 100% 100%;
    min-height: calc(100vh - 2.5rem);
    padding-top: 0.5rem 0.3rem 0 0.3rem;
    font-size: 0.34rem;
    padding-bottom: 1.6rem;
    // 卡片列表
    .card-list {
      @include flexbox($jc: flex-start, $ai: center, $fd: row, $fw: nowrap);
      overflow-x: auto;
      padding: 0.6rem 0.38rem;
      color: $mainTxtColor2;
      li {
        cursor: pointer;
        background: url('../../assets/imgs/vip/default-card.svg') no-repeat;
        background-size: 100%, 100%;
        min-width: 1.57rem;
        min-height: 2.1rem;
        padding: 0.07rem;
        text-align: center;
        position: relative;
        margin-right: 0.2rem;
        h2 {
          margin: 0.25rem 0 0 0;
          font-size: 0.26rem;
          @include textoverflow(2);
        }
        .hd {
          position: absolute;
          padding: 0.02rem 0.2rem 0.03rem 0.2rem;
          box-sizing: border-box;
          top: -0.1rem;
          left: -0.05rem;
          box-sizing: content-box;
          background-image: linear-gradient(to right, #fd9c3a, #fc342d);
          color: $mainTxtColor1;
          border-top-left-radius: 0.15rem;
          border-bottom-right-radius: 0.15rem;
          font-size: 0.12rem;
          transform: scale(0.9);
          @include textoverflow();
          max-width: 100%;
        }
        .price {
          font-size: 0.3rem;
          font-weight: 600;
          margin: 0.12rem 0 0.2rem 0;
        }
        .desc {
          padding: 0.02rem 0.05rem;
          border-radius: 0.26rem;
          zoom: 0.85;
          font-size: 0.16rem;
          border: 0.02rem solid #b68149;
          white-space: nowrap;
          box-sizing: border-box;
        }
        .price::before {
          content: '¥';
          font-size: 0.2rem;
          font-weight: 600;
          margin-right: 0.1rem;
        }
      }
      .bg {
        background: url('../../assets/imgs/vip/check-card.svg') no-repeat;
        background-size: 100%, 100%;
        min-width: 1.8rem;
        min-height: 2.4rem;

        .desc {
          border: 0.02rem solid #303d72;
        }
      }
    }
  }
}
// 新手活动
.advertiseTimeOut {
  @include flexbox($jc: center, $ai: center, $fd: row, $fw: nowrap);
  padding: 0.12rem 0.2rem;
  border-radius: 0.23rem;
  max-width: 80%;
  background-image: linear-gradient(to right, #fff3e5, #ffe8cf);
  font-size: 0.24rem;
  margin: 0 auto;
  &-block {
    display: inline-block;
    padding: 0 0.1rem;
    border-radius: 0.08rem;
    color: $mainTxtColor1;
    font-size: 0.28rem;
    text-align: center;
    background-color: #b68149;
  }
  &-text {
    display: inline-block;
    text-align: center;
    font-size: 0.2rem;
    text-align: center;
    margin: 0 0.05rem;
    font-weight: 600;
  }
  :deep()  {
    .van-count-down {
      margin-left: 0.4rem;
    }
  }
}
.activeItem-desc {
  text-align: center;
  color: #d1d1d1;
}
.btn {
  border-radius: 0.52rem;
  margin: 0 0.4rem 0.3rem 0.4rem;
  background: $btnBg;
  @include flexbox($jc: center, $ai: center, $fd: row, $fw: nowrap);
  box-shadow: $shadow;
  .price-box {
    border-right: 0.02rem solid #000;
    margin: 0.06rem 0.5rem 0.06rem 0;
    .price {
      font-weight: 600;
      font-size: 0.39rem;
    }
    .price::before {
      content: '¥';
      font-size: 0.2rem;
      font-weight: 600;
      margin-right: 0.1rem;
    }
    .old-price {
      position: relative;
      margin: 0 0.34rem 0 0.17rem;
    }
    .old-price::before {
      position: absolute;
      content: '——';
      top: 50%;
      left: 50%;
      @include transformCenter();
    }
    .txt {
      font-size: 0.45rem;
    }
  }
}
.btn:hover {
  cursor: pointer;
}
.isBuy-btn {
  border-radius: 0.52rem;
  margin: 0 0.25rem 0.3rem 0.25rem;
  padding: 0.12rem 0;
  background: $btnBg;
  @include flexbox($jc: center, $ai: center, $fd: row, $fw: nowrap);
  box-shadow: $shadow;
}
// 会员权益
.active-card-right {
  margin: 0 0.25rem;
  color: #e3d4d4;
  border-radius: 0.05rem;
  padding: 0.2rem;
  li:first-child {
    @include flexbox($jc: center, $ai: center, $fd: row, $fw: nowrap);
    .line {
      width: 1.5rem;
      height: 0.02rem;
      background: #848494;
    }
    span {
      margin: 0 0.1rem;
      font-size: 0.2rem;
      transform: scale(0.8);
    }
  }
  li {
    p {
      margin: 0;
    }
    p:first-child {
      color: #f4ce4e;
      font-size: 0.26rem;
      margin-top: 0.3rem;
    }
    p:last-child {
      font-size: 0.22rem;
    }
  }
}
// 弹窗
.submit-pop {
  max-width: 640px;
  left: 0;
  right: 0;
  margin: 0 auto;
  background: $mainBgColor;
  border-top-left-radius: 0.15rem;
  border-top-right-radius: 0.15rem;
  //padding: 0.7rem 0.3rem;
  padding: 0.7rem 0.3rem 2rem 0.3rem;
  .title {
    font-size: 0.28rem;
    display: flex;
    align-items: center;
    color: #e1dada;
    margin-bottom: 0.48rem;
    div {
      color: #666;
      font-size: 0.26rem;
      margin-left: 0.1rem;
    }
    span {
      color: #ed9200;
      font-weight: 600;
    }
  }

  // 支付方式
  .item {
    padding-top: 0.2rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    &:first-child {
      padding-top: 0;
    }
  }
  .left {
    color: #fff;
    display: flex;
    align-items: center;
    font-size: 0.28rem;
    img {
      width: 0.7rem;
      height: 0.7rem;
      margin-right: 0.33rem;
    }
  }
  // 选中状态
  .right {
    width: 0.28rem;
    height: 0.28rem;
    border-radius: 50%;
    border: 0.02rem solid #ed9200;

    position: relative;
    .active {
      width: 0.2rem;
      height: 0.2rem;
      background: #ed9200;
      border-radius: 50%;
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
    }
  }
  .tip-wrap {
    font-size: 0.24rem;
    color: #ed9200;

    margin-top: 0.5rem;
    margin-right: 0.7rem;
  }
  // 支付按钮
  .submit {
    width: 2.1rem;
    height: 0.68rem;
    text-align: center;
    line-height: 0.68rem;
    background-image: linear-gradient(to right, #ffd89d, #e4a760);
    color: #431100;
    font-size: 0.3rem;
    border-radius: 0.4rem;
    margin: 0 auto;
    margin-top: 0.6rem;
  }
}
</style>
