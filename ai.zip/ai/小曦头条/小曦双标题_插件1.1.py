# -*- coding: utf-8 -*-
#作者：淘小白 VX:TXB2196
import sys,importlib
import urllib
from urllib import parse
from urllib.parse import unquote
from urllib.parse import quote
import json
import requests
import re
import random
import time

from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.nlp.v20190408 import nlp_client, models


baidu_headers = {
    "Accept": 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36",
    # "Accept-Encoding": "gzip, deflate, br",
    'Cookie': r'BIDUPSID=923CEC236A2DE3C4430068EEF35E16E5; PSTM=1659360748; BAIDUID=923CEC236A2DE3C4D094F882E09CA292:FG=1; BD_UPN=12314753; BDUSS=VjbldDSUJjbGI1OU5iVW94UEhzfmk0eDMzQURMNFlUWVdVUG1zcWVJejNEMWhqSVFBQUFBJCQAAAAAAAAAAAEAAACNfq-CTG9nZ2luZzg4OAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPeCMGP3gjBjSU; BDUSS_BFESS=VjbldDSUJjbGI1OU5iVW94UEhzfmk0eDMzQURMNFlUWVdVUG1zcWVJejNEMWhqSVFBQUFBJCQAAAAAAAAAAAEAAACNfq-CTG9nZ2luZzg4OAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPeCMGP3gjBjSU; H_WISE_SIDS=110085_180636_188743_194529_204910_205168_209307_209568_210321_211986_212296_213046_213362_215727_216853_216941_217167_218566_219562_219723_219943_219946_220014_221678_221874_221967_222298_222396_222624_223064_223209_224045_224047_224080_224159_224436_224458_224892_225636_225860_226088_226547_226628_226723_226946_226956_227264_227515_227528_227745_227816_227865_227869_227895_227932_227974_228221_228374_228402_228615_228650_229028_229036_229061_229071_229154_229261_229379_229411_229494_229524_229685_229691_229913_229933_229938_229946_229975_229976_230083_230232_230241_230248_230305_230396_230664_230687_230849_230864_230925_230930_231091_231108_231209_231431_231467_231628_231653_231665_231763_231833_231876_231921_231929_8000056_8000110_8000119_8000142_8000149_8000165_8000178_8000182_8000185_8000188; BAIDUID_BFESS=923CEC236A2DE3C4D094F882E09CA292:FG=1; ZFY=rjzNLjwZGM:BKzViQigZXsYKpRqWgp1z34XSxk0HHqcs:C; baikeVisitId=2915a88e-9791-4848-b4b7-470609e6f674; COOKIE_SESSION=29883_0_9_9_8_5_1_0_9_5_0_0_194844_0_2_0_1667756138_0_1667756136|9#986185_22_1665897395|7; BDRCVFR[BASDVugcKF6]=IdAnGome-nsnWnYPi4WUvY; delPer=0; BD_CK_SAM=1; PSINO=7; BDORZ=FFFB88E999055A3F8A630C64834BD6D0; BA_HECTOR=808k0004ag0h2005840h8e1j1hmhtpq1f; Hm_lvt_aec699bb6442ba076c8981c6dc490771=1666639246,1667216378,1667656999,1667823432; Hm_lpvt_aec699bb6442ba076c8981c6dc490771=1667823432; H_PS_PSSID=36549_37559_37584_36884_37628_37726_36806_37538_37499_37716_26350; H_PS_645EC=09a5pNAL4+HEDI3DxZSNqygOLeJXxt8yzpm+GF7MihHXuS4mQvbeLJ1QryISxf7TPxcf; BDSVRTM=0'
    
    }
    
tt_headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    # 'Accept-Encoding': 'gzip, deflate, br',
    # 'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    # 'Connection': 'keep-alive',
    # 'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"',
    # 'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    # 'Sec-Fetch-Dest': 'document',
    # 'Sec-Fetch-Mode': 'navigate',
    # 'Sec-Fetch-Site': 'same-origin',
    # 'Sec-Fetch-User': '?1',
    # 'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36',
    'Cookie': r'_S_IPAD=0; MONITOR_WEB_ID=7136047123719554568; tt_webid=7136047123719554568; _S_DPR=1; _tea_utm_cache_4916=undefined; msToken=GIoGW-T1OK58lDwNaR2F_mL_E6h0ydhr-ql_NZOb9h0aSYaGyxT_D3qWAq2QWzV5uyCaHeMhRnlWr-Ordvh7tudTdebPhNS6sI2yuK1WzHY=; ttwid=1|3JWnfkxeyICHtH09cefB20g2t9yStobnytFgGZ_N8P4|1667825317|e1740b4f360e47df37de29f92a1b0f891c1dcaaa14257ee35573fd7c2a9630b5; _S_WIN_WH=1637_980'

    }
sogo_headers = {

    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    'Cache-Control': 'max-age=0',
    'Connection': 'keep-alive',
    'Cookie': 'SUID=8EA8246F2680A40A0000000061E13A35; SUV=1642384947378816; ssuid=5019841333; wuid=AAGUrrMuPAAAAAqgDEQsIQEAkwA=; front_screen_resolution=1920*1080; front_screen_dpi=1.25; CXID=5ACE5AF0DD69D33993E53D8D2816E238; usid=T5calBMzNn9jLJZh; sw_uuid=6522655744; IPLOC=CN3701; sg_uuid=6195457418; SMYUV=1658997912955535; ariaDefaultTheme=undefined; FUV=26bc544ecfa47b6846a5f28286bd29a1; SNUID=653EC876AAAF4CD4F0CD5E12AA1A2E18; ld=Iyllllllll2PiGc1lllllpad8fylllllbhvo0kllll9lllll9klll5@@@@@@@@@@; LSTMV=316%2C76; LCLKINT=1482; ABTEST=0|1660800934|v1; search_tip=1660800935208',
    'Host': 'pic.sogou.com',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.0.0 Safari/537.36'

}
'''
公共方法1、排序提取关键词，相关度微调修改这里
'''
def paixu(key):
    fu_title_list = sorted(key, key=lambda s: s[1])
    fu_title = fu_title_list[-1][0] 
    return fu_title

'''
公共方法2、 腾讯ai 短文本相似度 
'''
def tx_xsd(key,keylist):
    # 腾讯ai_key
    cred = credential.Credential("AKIDX6c8appdHivyqXGn8UjnfaTZnvtsfGqO", "W0NkwxnTzQsFXaP7csviR1TkrrgJjAWh")
    httpProfile = HttpProfile()
    httpProfile.endpoint = "nlp.tencentcloudapi.com"

    clientProfile = ClientProfile()
    clientProfile.httpProfile = httpProfile
    client = nlp_client.NlpClient(cred, "ap-guangzhou", clientProfile)

    req = models.TextSimilarityProRequest()
    params = {
        "SrcText": key,
        "TargetText": keylist
    }
    req.from_json_string(json.dumps(params))
    resp = client.TextSimilarityPro(req)
    result = resp.to_json_string()
    pat = re.compile(r'{"Text": "(.*?)", "Score": (.*?)}')
    key_socre = re.findall(pat,result)
    return key_socre

'''
主体：标题生成相关方法
'''

#百度下拉词 相关方法
bd_xl_url = 'https://www.baidu.com/sugrec?pre=1&p=3&ie=utf-8&json=1&prod=pc&from=pc_web&&wd={}'
def get_bdxl_link_keys(key,key_len):
    try:
        link_keys = []
        tt_req = requests.get(bd_xl_url.format(''.join(key)),headers=baidu_headers,timeout=20)
        tt_resp = tt_req.text
        link_key_pre = re.findall(r'"q":"(.*?)"',''.join(tt_resp))
        for i in link_key_pre:
            if i != key:
                if len(i)>int(key_len):
                    link_keys.append(i)
                else:
                    pass
            else:
                pass
        if len(link_keys)>1:
            return link_keys
        else:
            keys_lst = []
            for j in link_key_pre:
                if j != key:
                    keys_lst.append(j)
                else:
                    pass
            max_len_key = max(keys_lst, key=len, default='')
            return max_len_key
    except:
        return None

def get_bdxl_key(key,key_len):
    try:  
        keylist = get_bdxl_link_keys(''.join(key),key_len)
        if keylist:
            keyword_list = tx_xsd(key,keylist)
            keyword = paixu(keyword_list)
            return keyword
        else:
            return None
    except:
        return None

#百度相关词 相关方法
bd_xg_url = "https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&rsv_idx=1&tn=baidu&wd={}&usm=3&rsv_idx=2&rsv_page=1"
def get_bdxg_link_keys(key):
    try:
        xg_req = requests.get(bd_xg_url.format(''.join(key)),headers=baidu_headers,timeout=20)
        xg_res = xg_req.text
        link_keys = re.findall(r'"word":"(.*?)"',xg_res)
        return link_keys
    except:
        var = None

def get_bdxg_key(key): 
    try: 
        keylist = get_bdxg_link_keys(''.join(key))

        keyword_list = tx_xsd(key,keylist)
        keyword = paixu(keyword_list)
        return keyword
    except:
        return None


#1、获取头条urls
def get_list_title_urls(key,num,comment_onoff):
    result_titles = []
    qx_content_divs=[]
    for i in range(int(num)):
        url = 'https://so.toutiao.com/search?keyword={}&pd=information&source=search_subtab_switch&dvpf=pc&aid=4916&page_num={}'.format(key,i)
        req = requests.get(url,headers =tt_headers,timeout=10)
        time.sleep(3)
        if req.status_code == 200:
            res = req.text
            # print(res)
            content_ten_divs=re.findall(r'<div class="cs-view cs-view-block cs-card-content">(.*?)<script>PerfTag',res)
            for content_div in content_ten_divs:
                if comment_onoff == '关':   
                    if '<span class="text-ellipsis margin-right-4">' in content_div:
                        qx_content_divs.append(content_div)
                    else:
                        pass
                else:
                    qx_content_divs.append(content_div)
            else:
                pass
        else:
            pass
    if len(qx_content_divs)>0:
        tt_ids = re.findall(r'<div data-log-click.*?www.toutiao.com%2Fa(.*?)%2F',''.join(qx_content_divs))
        tt_titles = re.findall(r'<div data-log-click.*?class="text-ellipsis text-underline-hover">(.*?)</a>',''.join(qx_content_divs))
        for tt_title in tt_titles:
            result_titles.append(qx_bd(tt_title))
        return tt_ids,result_titles
    else:
        pass

#2、清洗标题标签
def  qx_bd(cons):
    bd_fhs=[r'\\u003cem\\u003e',r'\\u003c/em\\u003e','</em>','<em>']
    for i in bd_fhs:
        pat = re.compile(i,re.I)
        cons = pat.sub('',cons)
    return cons

#3、分割标题
def fg_bt(title):
    title_ps = re.split('[,_/-?，？！!、#()“”""{}|《》【】（） -]',title)

    result_titles = max(title_ps, key=len, default='')

    return ''.join(result_titles)

#4、提取头条内容
def tq_cons(url):
    req = requests.get(url,headers=tt_headers,timeout=10)
    if req.status_code == 200:
        res = req.text
        json_data = json.loads(res)
        cons = re.findall(r'<article>(.*?)</article>',str(json_data))
        return ''.join(cons)
    else:
        pass 
#5、清洗p，慎用，可能清洗的没内容了
def qx_p(html):
    contents = []
    pat  = re.compile(r'<p>(.*?)</p>',re.S)
    cons = re.findall(pat,html)
    keywords = ['编辑','公众号','关注','快手','大家好','新闻客户端','原标题','抖音','小编','APP','图源','来源','收藏','留言','探讨','评论区','点赞','了解更多','专栏','咨询','二维码','记者','报导','讯','必究','版权','作者','责编','审稿','百度app','习近平','军事','培训学校','图片仅供参考','更多文章','@','摄图网','如图所示','报道','时报','图虫创意','侵权','摘自网络','文/','文|','来自网络','资料图','记者','By','文案：','图：','海报：','#','参考资料' ,'搜索','微信号']
    for i in cons:
        if any(keyword in i for keyword in keywords): continue
        j = ''.join(i)
        contents.append('<p>'+j+'</p>')
    return ''.join(contents)

#6、清洗html标签
def qx_html(m):
    pat_bqs = re.compile(r'<.*?>',re.I)
    all_bqs = re.findall(pat_bqs,m)
    a_pat = re.compile(r'<a class="image".*?url=',re.I)
    width_pat = re.compile(r'width.*?>',re.I)
    p_pat = re.compile(r'<p.*?>',re.I)

    all_set_bqs = set(all_bqs)
    for i in list(all_set_bqs):

        if '<p' not in ''.join(i) and r'</p>' not in ''.join(i) and '<a class="image"' not in ''.join(i):
            pre_m1 = ''.join(m).replace(''.join(i),'')
            m = pre_m1
        else:
            pass
    m = urllib.parse.unquote(m).replace(r'\u200b','')
    m = p_pat.sub('<p>',m)
    m = a_pat.sub('<img src="',m)
    m = width_pat.sub('width="360px",height="auto" />',m)
    
    return m.replace(r'<p></p>','')
#7、匹配度方法
def pd_key_title(key,title):
    key_lst = set(list(key))
    sx_key = []
    for i in key_lst:
        if '\u4e00' <= i <= '\u9fff':
            if i not in title:
                pass 
            else:
                sx_key.append(i)
        else:
            pass

    key_in_rate = len(sx_key)/len(key_lst)
    if key_in_rate>0.5:
        return title
    else:
        pass

#6、主要的提取数据方法
def main_tq_content(key,zhu_title,num,comment_onoff):
    urls_titles = []
    ids_titles = get_list_title_urls(key,num,comment_onoff)
    if ids_titles:
        for x,y in zip(ids_titles[0],ids_titles[1]):
            urls_titles.append('http://a6.pstatp.com/article/content/21/1/'+x+'/1/0/?iid=0'+',,'+y)
    else:
        pass
    #网址标题组合在一个一起，',,'分割
    ok_urls_titles = []
    for i in urls_titles:
        pre_i = re.split(',,',i)
        pd_ok_title = pd_key_title(zhu_title,pre_i[1])
        if pd_ok_title :
            ok_urls_titles.append(i)
        else:
            pass
    #腾讯ai提取最相关标题
    tx_titles = []
    for j in ok_urls_titles:
        tt_titles = re.split(',,',j)
        tx_titles.append(tt_titles[1])
    if len(tx_titles)>0:
        tt_title_list = tx_xsd(key,tx_titles)
        tt_title = paixu(tt_title_list)
        if tt_title:
            for url_title in ok_urls_titles:
                db_url_title = re.split(',,',url_title)
                if tt_title == db_url_title[1]:
                    pre_cons = tq_cons(db_url_title[0])
                    if pre_cons:
                        result_cons = qx_html(pre_cons)
                        p_img_pat = re.compile(r'</p>rom=.*?</p>',re.I)
                        result_new_cons = p_img_pat.sub('</p>',result_cons)
                        result_new_cons = result_new_cons.replace(r'<img','<p style="text-align: center;"><img').replace(r'/>','/></p>')
                        return tt_title,result_new_cons
                    else:
                        pass
                else:
                    pass
        else:
            pass
    else:
        pass
#7、主逻辑
def run_main(key,title_onoff,page_num,comment_onoff,pic_onoff,key_len):
    
    if title_onoff == '开':
        zhu_title = get_bdxl_key(key,key_len)
        if zhu_title:
            fu_title = get_bdxg_key(key)
            main_title = zhu_title+'('+fu_title+')'
            result_content = main_tq_content(key,zhu_title,page_num,comment_onoff)
            if result_content:
                if pic_onoff == '开':
                    if 'img'  in result_content[1]:
                        return main_title,result_content[1]
                    else:
                        new_content = []
                        sogou_pics = get_sogo_pic(key,1)
                        if sogou_pics:
                            content_ps = re.findall(r'<p>(.*?)</p>',result_content[1])
                            n = 0 
                            for i in content_ps:
                                if n == 3:
                                    new_content.append('<p><img src="'+sogou_pics[0]+'"/></p>'+'<p>'+i+'</p>')
                                else:
                                    new_content.append('<p>'+i+'</p>')
                                n=n+1
                            return main_title,''.join(new_content)
                        else:
                            pass 
                else:
                    return main_title,result_content[1]
        else:
            pass
    elif title_onoff == '关':
        zhu_title = get_bdxl_key(key,key_len)
        result_content = main_tq_content(key,zhu_title,page_num,comment_onoff)
        if result_content:
            fu_title = fg_bt(result_content[0])
            main_title = zhu_title+'('+''.join(fu_title)+')'
            return main_title,result_content[1]
        else:
            pass 
    else:
        return '标题开关切换设置错误，只能是‘开’或者‘关’！','标题开关切换设置错误，只能是‘开’或者‘关’！'

# 获取搜狗图片
def get_sogo_pic(key,need_pic_num):
    pic_imgs = []
    for page_num in range(need_pic_num):
        url = 'http://pic.sogou.com/napi/pc/searchList?mode=2&start={}&xml_len=48&query={}'.format(page_num*48,key[0:10])
        req = requests.get(url,headers=sogo_headers,timeout=10)
        if req.status_code == 200:
            res =req.text
            
            # 使用源站图片地址路径
            # pic_lists = re.findall(r'"oriPicUrl":"(.*?)"',res)

            #使用搜狗云存储图片路径
            pic_lists = re.findall(r'"locImageLink":"(.*?)"',res)

            for i in pic_lists:
                j = i.replace(r'\u002F','/')
                try:
                    pic_req = requests.get(j,timeout=10)
                    if pic_req.status_code == 200:
                        pic_imgs.append(j)
                        if len(pic_imgs)>int(need_pic_num):
                            return pic_imgs
                        else:
                            pass
                    else:
                        pass
                except:
                    pass
        else:
            pass

# if __name__ == '__main__':
#     key='如何自制灌肠液'
#     title = '淡干海参泡发流程'
#     key_len = 5
#     # aa = pd_key_title(key,title)
#     # print(aa)
#     title_onoff = '开' #标题两种方法切换，默认是：双标题 = 搜索词的百度下拉词+百度下拉词的百度相关词
#     page_num = 2 #提取几个列表的数据
#     comment_onoff = '关' #是否卡带评论的文章，默认不打开
#     pic_onoff = '关' #是否卡带图片的文章，默认不打开
#     key = '番茄炒蛋'
#     aa=run_main(key,title_onoff,page_num,comment_onoff,pic_onoff,key_len)
#     print(aa)


# 火车头默认格式
if len(sys.argv)!= 5:
    print(len(sys.argv))
    print("命令行参数长度不为5")
    sys.exit()
else:
    LabelCookie = parse.unquote(sys.argv[1])
    LabelUrl = parse.unquote(sys.argv[2])
    #PageType为List,Content,Pages分别代表列表页，内容页，多页http请求处理，Save代表内容处理
    PageType=sys.argv[3]
    SerializerStr = parse.unquote(sys.argv[4])
    if (SerializerStr[0:2] != '''{"'''):
        file_object = open(SerializerStr)
        try:
            SerializerStr = file_object.read()
            SerializerStr = parse.unquote(SerializerStr)
        finally:
            file_object.close()
    LabelArray = json.loads(SerializerStr)

#以下是用户编写代码区域

    if(PageType=="Save"):
        
        key = LabelArray['搜词']
        title_onoff = LabelArray['标题开关'] #标题两种方法切换，默认是：双标题 = 搜索词的百度下拉词+百度下拉词的百度相关词
        page_num = LabelArray['翻页数量'] #提取几个列表的数据
        comment_onoff = LabelArray['评论开关'] #是否卡带评论的文章，默认不打开
        pic_onoff = LabelArray['图片开关'] #是否卡带图片的文章，默认不打开
        key_len = LabelArray['下拉词长度'] #是否卡带图片的文章，默认不打开
        result_title_content=run_main(key,title_onoff,page_num,comment_onoff,pic_onoff,key_len)
        if result_title_content:
            LabelArray['标题'] = result_title_content[0]
            LabelArray['内容'] = result_title_content[1].replace('\t','')
        else:
            LabelArray['标题'] = ''
            LabelArray['内容'] = ''

    else:
        LabelArray['Html']='当前页面的网址为:'+ LabelUrl +"\r\n页面类型为:" + PageType + "\r\nCookies数据为:"+LabelCookie+"\r\n接收到的数据是:" + LabelArray['Html']
#以上是用户编写代码区域
    LabelArray = json.dumps(LabelArray)
    print(LabelArray)
