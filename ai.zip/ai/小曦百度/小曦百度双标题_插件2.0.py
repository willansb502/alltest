# -*- coding: utf-8 -*-
import sys,importlib
import urllib
from urllib import parse
from urllib.parse import unquote
from urllib.parse import quote
import json
import requests
import re
import random
import time

import chardet
from readability import Document

from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.nlp.v20190408 import nlp_client, models


baidu_headers = {
    "Accept": 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36",
    # "Accept-Encoding": "gzip, deflate, br",
    'Cookie': r'BIDUPSID=923CEC236A2DE3C4430068EEF35E16E5; PSTM=1659360748; BAIDUID=923CEC236A2DE3C4D094F882E09CA292:FG=1; BD_UPN=12314753; BDUSS=VjbldDSUJjbGI1OU5iVW94UEhzfmk0eDMzQURMNFlUWVdVUG1zcWVJejNEMWhqSVFBQUFBJCQAAAAAAAAAAAEAAACNfq-CTG9nZ2luZzg4OAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPeCMGP3gjBjSU; BDUSS_BFESS=VjbldDSUJjbGI1OU5iVW94UEhzfmk0eDMzQURMNFlUWVdVUG1zcWVJejNEMWhqSVFBQUFBJCQAAAAAAAAAAAEAAACNfq-CTG9nZ2luZzg4OAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPeCMGP3gjBjSU; H_WISE_SIDS=110085_180636_188743_194529_204910_205168_209307_209568_210321_211986_212296_213046_213362_215727_216853_216941_217167_218566_219562_219723_219943_219946_220014_221678_221874_221967_222298_222396_222624_223064_223209_224045_224047_224080_224159_224436_224458_224892_225636_225860_226088_226547_226628_226723_226946_226956_227264_227515_227528_227745_227816_227865_227869_227895_227932_227974_228221_228374_228402_228615_228650_229028_229036_229061_229071_229154_229261_229379_229411_229494_229524_229685_229691_229913_229933_229938_229946_229975_229976_230083_230232_230241_230248_230305_230396_230664_230687_230849_230864_230925_230930_231091_231108_231209_231431_231467_231628_231653_231665_231763_231833_231876_231921_231929_8000056_8000110_8000119_8000142_8000149_8000165_8000178_8000182_8000185_8000188; H_WISE_SIDS_BFESS=110085_180636_188743_194529_204910_205168_209307_209568_210321_211986_212296_213046_213362_215727_216853_216941_217167_218566_219562_219723_219943_219946_220014_221678_221874_221967_222298_222396_222624_223064_223209_224045_224047_224080_224159_224436_224458_224892_225636_225860_226088_226547_226628_226723_226946_226956_227264_227515_227528_227745_227816_227865_227869_227895_227932_227974_228221_228374_228402_228615_228650_229028_229036_229061_229071_229154_229261_229379_229411_229494_229524_229685_229691_229913_229933_229938_229946_229975_229976_230083_230232_230241_230248_230305_230396_230664_230687_230849_230864_230925_230930_231091_231108_231209_231431_231467_231628_231653_231665_231763_231833_231876_231921_231929_8000056_8000110_8000119_8000142_8000149_8000165_8000178_8000182_8000185_8000188; delPer=0; BD_CK_SAM=1; PSINO=7; BA_HECTOR=2l0gag0h2k0gaka08l8080mp1hmqg8k1f; BAIDUID_BFESS=923CEC236A2DE3C4D094F882E09CA292:FG=1; ZFY=rjzNLjwZGM:BKzViQigZXsYKpRqWgp1z34XSxk0HHqcs:C; shifen[234443422043_16505]=1668104481; BCLID=9089911718549909300; BCLID_BFESS=9089911718549909300; BDSFRCVID=sr-OJeC62iVS1anjHtAR7iJ7KhC-YqnTH6q2ta0cS9nQxBTfzf4uEG0POU8g0KAbCyVRogKK5mOTH6KF_2uxOjjg8UtVJeC6EG0Ptf8g0f5; BDSFRCVID_BFESS=sr-OJeC62iVS1anjHtAR7iJ7KhC-YqnTH6q2ta0cS9nQxBTfzf4uEG0POU8g0KAbCyVRogKK5mOTH6KF_2uxOjjg8UtVJeC6EG0Ptf8g0f5; H_BDCLCKID_SF=tbue_D8-tDL3ebTgMDT5bt4WMhuX5-RLf57Hsl7F5l8-hRTK0TQHh4In5-QNt-cZJ233556w-RrxOKQlDROHD-t9efTIhUjn5jQh_P5N3KJm8UK9bT3vLtDd2JjN2-biWbTL2MbdJqvP_IoG2Mn8M4bb3qOpBtQmJeTxoUJ25DnJhbLGe4bK-Tr3DHDeJx5; H_BDCLCKID_SF_BFESS=tbue_D8-tDL3ebTgMDT5bt4WMhuX5-RLf57Hsl7F5l8-hRTK0TQHh4In5-QNt-cZJ233556w-RrxOKQlDROHD-t9efTIhUjn5jQh_P5N3KJm8UK9bT3vLtDd2JjN2-biWbTL2MbdJqvP_IoG2Mn8M4bb3qOpBtQmJeTxoUJ25DnJhbLGe4bK-Tr3DHDeJx5; BD_HOME=1; BDRCVFR[feWj1Vr5u3D]=I67x6TjHwwYf0; BDORZ=B490B5EBF6F3CD402E515D22BCDA1598; COOKIE_SESSION=5006_2_8_8_5_17_1_1_8_4_1_6_0_200182_0_0_1668104323_1668104482_1668109473|9#200169_37_1668104467|9; H_PS_PSSID=36549_37559_37726_36806_37538_37499_37716_37741_26350; baikeVisitId=5ebd153e-0cfe-4313-9314-35440a992f93'
    }
    
ty_headers={
    "user-agent": "Mozilla/5.0+(compatible;+Baiduspider/2.0;++http://www.baidu.com/search/spider.html)"
}
sogo_headers = {

    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    'Cache-Control': 'max-age=0',
    'Connection': 'keep-alive',
    'Cookie': 'SNUID=84C21A418B8E61EBE53471AB8BD24E74; IPLOC=KH; SUID=0E4990CB5053A00A00000000633F1722; SUV=1665079074323810; LSTMV=147,28; LCLKINT=6627; ABTEST=7|1668133909|v17',
    'Host': 'pic.sogou.com',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.0.0 Safari/537.36'

}
'''
公共方法1、排序提取关键词，相关度微调修改这里
'''
def paixu(key):
    fu_title_list = sorted(key, key=lambda s: s[1])
    fu_title = fu_title_list[-1][0] 
    return fu_title

'''
公共方法2、 腾讯ai 短文本相似度 
'''
def tx_xsd(key,keylist):
    # 腾讯ai_key
    cred = credential.Credential("AKIDX6c8appdHivyqXGn8UjnfaTZnvtsfGqO", "W0NkwxnTzQsFXaP7csviR1TkrrgJjAWh")
    httpProfile = HttpProfile()
    httpProfile.endpoint = "nlp.tencentcloudapi.com"

    clientProfile = ClientProfile()
    clientProfile.httpProfile = httpProfile
    client = nlp_client.NlpClient(cred, "ap-guangzhou", clientProfile)

    req = models.TextSimilarityProRequest()
    params = {
        "SrcText": key,
        "TargetText": keylist
    }
    req.from_json_string(json.dumps(params))
    resp = client.TextSimilarityPro(req)
    result = resp.to_json_string()
    pat = re.compile(r'{"Text": "(.*?)", "Score": (.*?)}')
    key_socre = re.findall(pat,result)
    return key_socre

'''
主体：标题生成相关方法
'''

#百度下拉词 相关方法
bd_xl_url = 'https://www.baidu.com/sugrec?pre=1&p=3&ie=utf-8&json=1&prod=pc&from=pc_web&&wd={}'
def get_bdxl_link_keys(key):
    try:
        link_keys = []
        tt_req = requests.get(bd_xl_url.format(''.join(key)),headers=baidu_headers,timeout=20)
        tt_resp = tt_req.text
        link_key_pre = re.findall(r'"q":"(.*?)"',''.join(tt_resp))
        for i in link_key_pre:
            if i != key:
                link_keys.append(i)
            else:
                pass
        return link_keys
    except:
        return None

def get_bdxl_key(key):
    try:  
        keylist = get_bdxl_link_keys(''.join(key))
        keyword_list = tx_xsd(key,keylist)
        keyword = paixu(keyword_list)
        return keyword
    except:
         None

#百度相关词 相关方法
bd_xg_url = "https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&rsv_idx=1&tn=baidu&wd={}&usm=3&rsv_idx=2&rsv_page=1"
def get_bdxg_link_keys(key):
    try:
        xg_req = requests.get(bd_xg_url.format(''.join(key)),headers=baidu_headers,timeout=20)
        xg_res = xg_req.text
        link_keys = re.findall(r'"word":"(.*?)"',xg_res)
        return link_keys
    except:
        var = None

def get_bdxg_key(key): 
    try: 
        keylist = get_bdxg_link_keys(''.join(key))

        keyword_list = tx_xsd(key,keylist)
        keyword = paixu(keyword_list)
        return keyword
    except:
        return None

#2、清洗p标签
def  qx_p(html):
    bd_fhs=['搜狐','推荐阅读','关注','微信','本文']
    for i in bd_fhs:
        if i not in html:
            pass
        else:
            return None
    return html


#3、分割标题
def fg_bt(title):
    title_ps = re.split('[,_/-?，？！!、#()“”""{}|《》【】（） -]',title)

    result_titles = max(title_ps, key=len, default='')

    return ''.join(result_titles)


# 4、获取百度搜索结果页的网址
def get_list_title_urls(key_word,num):
    bd_list_url_list = []
    qx_content_divs=[]
    for i in range(int(num)):
        url = "https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&rsv_idx=1&tn=baidu&wd={}&usm=3&rsv_idx=2&rsv_page=1&pn={}".format(key_word,num*10)
        bdlist_req = requests.get(url,headers=baidu_headers,timeout=10)
        time.sleep(3)
        if bdlist_req.status_code ==200:
            bdlist_res = bdlist_req.text
            con_div_pat = re.compile(r'<div class="result c-container xpath-log new-pmd"(.*?)</div></div></div><div></div></div>',re.S)
            content_divs=re.findall(con_div_pat,bdlist_res)

            if content_divs:
                for j in content_divs:
                    
                    bd_urls = re.findall(r'mu="(.*?)"',j)
                    if bd_urls:
                        if 'baidu.com' not in bd_urls[0]:
                            url_title = []
                            url_title.append(bd_urls[0])
                            bd_title = re.findall(r''''title\': \\"(.*?)\\"''',j)

                            if bd_title:
                                url_title.append(bd_title[0])
                            else:
                                pass
                            bd_list_url_list.append(url_title)
                        else:
                            pass
                    else:
                        pass 
                    
            else:
                pass 
        else:
            pass 
    return bd_list_url_list

#自定义删除
def qx_html(html,pic_onoff):
    patterns = [(r'<.*?>',''),(r'\u3000',''),(r'http.*?cn',''),(r'www.*?com',''),(r'\r',''),(r'\t','')]
    for pat in patterns:
        if pic_onoff == '开':
            if 'img' not in html:
                html = re.sub(pat[0], pat[1], html)
            else:
                return html.replace('\u3000','').replace('src="//','src="https://')
        else:
            if 'img' not in html:
                html = re.sub(pat[0], pat[1], html)
                return html.replace('\u3000','').replace('src="//','src="https://')
            else:
                pass
        
    

# 5、自动提取文章内容和标题 ,返回标题和内容，类型：list
def auto_get_content(url,pic_onoff):
    result_content = []
    try:
        response = requests.get(url,headers = ty_headers,timeout=10)
        if response.status_code == 200:
            response.encoding = response.apparent_encoding
            encoding = chardet.detect(response.content)['encoding']
            try:
                doc = Document(response.content.decode(encoding))
            except:
                doc = Document(response.content.decode('utf-8'))
            con_title = doc.title()
            if con_title:
                con_content = doc.summary()
                if con_content:
                    if con_content:
                        result_p = re.findall(r'<p>(.*?)</p>',''.join(con_content))
                        for i in result_p:
                            i = qx_html(i,pic_onoff)
                            if i:
                                i = qx_p(i)
                                if i :
                                    result_content.append(r'<p>'+i+r'</p>')
                                else:
                                    pass
                            else:
                                pass 
                        if len(''.join(result_content)) > 500:
                            return con_title,''.join(result_content)
                        else:
                            pass 

                    else:
                        pass
                else:
                    pass
            else:
                pass
        else:
            pass
    except:
        pass


# 获取搜狗图片
def get_sogo_pic(key,need_pic_num):
    pic_imgs = []
    for page_num in range(need_pic_num):
        url = 'http://pic.sogou.com/napi/pc/searchList?mode=2&start={}&xml_len=48&query={}'.format(page_num*48,key[0:10])
        req = requests.get(url,headers=sogo_headers,timeout=10)
        if req.status_code == 200:
            res =req.text
            
            # 使用源站图片地址路径
            # pic_lists = re.findall(r'"oriPicUrl":"(.*?)"',res)

            #使用搜狗云存储图片路径
            pic_lists = re.findall(r'"locImageLink":"(.*?)"',res)

            for i in pic_lists:
                j = i.replace(r'\u002F','/')
                try:
                    pic_req = requests.get(j,timeout=10)
                    if pic_req.status_code == 200:
                        pic_imgs.append(j)
                        if len(pic_imgs)>int(need_pic_num):
                            return pic_imgs
                        else:
                            pass
                    else:
                        pass
                except:
                    pass
        else:
            pass
def run_main(key,num,pic_onoff):
    
    resu_cons = []
    title_urls = get_list_title_urls(key,num)
    if title_urls:
        for i in title_urls:
            title_content = auto_get_content(i[0],pic_onoff)
            if title_content:
                if 'img' in title_content[1]:

                    return title_content[0],title_content[1]
                else:
                    result_content = []
                    sogou_pic = get_sogo_pic(title_content[0][0:10],1)
                    np_content_ps = re.findall(r'<p>(.*?)</p>',title_content[1])
                    n=0
                    for p in np_content_ps:
                        if n == 2:
                            result_content.append('<p><img src="'+sogou_pic[0]+'"/></p>'+'<p>'+p+'</p>')
                        else:
                            result_content.append('<p>'+p+'</p>')
                        n+=1
                    return title_content[0],''.join(result_content)
            else:
                pass
    else:
        pass
 
def start_crawl(key,num,pic_onoff):
    zhu_title = get_bdxl_key(key)
    if zhu_title:
        fu_title = get_bdxg_key(key)
        if fu_title:
            res_title_content = run_main(fu_title,num,pic_onoff)
            if res_title_content:
                fg_title = fg_bt(res_title_content[0])
                if fg_title:
                    result_title = fu_title+'('+''.join(fg_title)+')'
                    return ''.join(result_title),''.join(res_title_content[1])
                else:
                    pass
            else:
                pass 
        else:
            pass
    else:
        pass 
    
# if __name__ == '__main__':
#     key='如何做泡椒凤爪'
#     # fg_bt(key)
#     num = 2
#     pic_onoff = '关'
#     title_content = start_crawl(key,num,pic_onoff)
#     print(title_content)
#     print('--------------------------------------')
#     if title_content:
#         biaoti=title_content[0]
#         neirong =title_content[1].replace('\t','') 
#         print(biaoti)
#         print(neirong)
#     else:
#         pass 

# 火车头默认格式
if len(sys.argv)!= 5:
    print(len(sys.argv))
    print("命令行参数长度不为5")
    sys.exit()
else:
    LabelCookie = parse.unquote(sys.argv[1])
    LabelUrl = parse.unquote(sys.argv[2])
    #PageType为List,Content,Pages分别代表列表页，内容页，多页http请求处理，Save代表内容处理
    PageType=sys.argv[3]
    SerializerStr = parse.unquote(sys.argv[4])
    if (SerializerStr[0:2] != '''{"'''):
        file_object = open(SerializerStr)
        try:
            SerializerStr = file_object.read()
            SerializerStr = parse.unquote(SerializerStr)
        finally:
            file_object.close()
    LabelArray = json.loads(SerializerStr)

#以下是用户编写代码区域

    if(PageType=="Save"):
        key = LabelArray['搜词']
        page_num = LabelArray['翻页数量'] #提取几个列表的数据
        pic_onoff = LabelArray['图片开关'] #是否卡带图片的文章，默认不打开

        title_content = start_crawl(key,int(page_num),pic_onoff)
        if title_content:
            LabelArray['标题'] = title_content[0]
            LabelArray['内容'] = title_content[1].replace('\t','') 
        else:
            LabelArray['标题'] = ''
            LabelArray['内容'] = ''
    else:
        LabelArray['Html']='当前页面的网址为:'+ LabelUrl +"\r\n页面类型为:" + PageType + "\r\nCookies数据为:"+LabelCookie+"\r\n接收到的数据是:" + LabelArray['Html']
#以上是用户编写代码区域
    LabelArray = json.dumps(LabelArray)
    print(LabelArray)
