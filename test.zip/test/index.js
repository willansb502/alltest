const express = require('express');
const app = express();
const ip = require('ip');
require('./ws/wsBinance');
const indexRouter = require('./ws/router/router');
app.use('/api', indexRouter);

const server = app.listen(29012, function () {
  const port = server.address().port;
  console.log(new Date()+ip.address()+":"+port);
});
