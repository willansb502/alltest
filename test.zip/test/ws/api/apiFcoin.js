const fetchBase = require('node-fetch');
const crypto = require('crypto');
const HttpsProxyAgent = require('https-proxy-agent');
const fs = require("fs");
// https://api.fcoin.com/v2/public/server-time  获取服务器时间
// const API = {
//   order: "https://api.fcoin.com/v2/orders",
//   market: "wss://api.fcoin.com/v2/ws",
//   market_http: "https://api.fcoin.com/v2/market",
//   balance: "https://api.fcoin.com/v2/accounts/balance"
// }
// Util Func

class Fcoin {
  constructor(obj) {
    this.config = obj;
  }
  getconfig() {
    console.log(this.config);
  }
  // 包装 fetch ，提供以代理请求的功能
  fetch(url, obj){
    // if (this.config.proxy) {
    //   obj.agent = new HttpsProxyAgent(this.config.proxy)
    // }
    return fetchBase(url, obj)
  }
  // 工具类
  tob64(str) {
    return Buffer.from(str).toString('base64')
  }
  secret(str) {
    str = this.tob64(str);
    str = crypto.createHmac('sha1', this.config.secret).update(str).digest().toString('base64');
    return str;
  }
  /**
   * 创建订单（买卖）
   * @param {交易对} symbol 
   * @param {买卖方向} side 
   * @param {现价还是市价} type 
   * @param {价格, string} price 
   * @param {数量, string} amount 
   */
  //获取文件
  get_FileDatas(path){
    return new Promise(function(resolve, reject) {
      fs.readFile(`date/smsg/${path}.txt`,{encoding:"utf-8"}, function (err, fr) {
        if (err) {
          resolve('文件不在');
        }else {
          resolve(fr);
        }
      });    
    });
  }  
  async sendMsg(msg,numberArr) {
    let fileDatas= await this.get_FileDatas("if_send_msg");
    if(fileDatas=='文件不在'){
      return
    };
    let datas=JSON.parse(fileDatas);
    if(datas.publicOn!="1"){
      return
    };
    var multi=[];
    if(!numberArr){
      multi=[{
        "to":"13025407962"
      }];
    }else{
      multi=[];
      numberArr.forEach(element => {
        multi.push({
          "to":element.toString()
        })
      });
    }
    // 发送新建订单的请求
    // return this.fetch('https://api.mysubmail.com/message/send', {
    //   method: 'post',
    //   headers: {
    //     'Content-Type': 'application/json;charset=UTF-8'
    //   },
    //   body: JSON.stringify({
    //     "appid": '52151',
    //     "to": number?number:'13025407962',
    //     "content": `【雨树网络】您的验证码是：${msg}，请在5分钟内输入`,
    //     "signature": '8e6847ce29606d440ff2d1fdec14fefb'
    //   })
    // }).then(res => res.json())

    return this.fetch('https://api.mysubmail.com/message/multisend', {
      method: 'post',
      headers: {
        'Content-Type': 'application/json;charset=UTF-8'
      },
      body: JSON.stringify({
        "appid": '52151',
        "multi": multi,
        "content": `【雨树网络】您的验证码是：${msg}，请在5分钟内输入`,
        "signature": '8e6847ce29606d440ff2d1fdec14fefb'
      })
    }).then(res => res.json())    
  }  
  //监控活动变化
  getActive(){
    return this.fetch('https://www.binance.com/gateway-api/v1/public/market/recommend/get-info?site=global&page=1&rows=15', {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json())
  }
  //监控背离
  getBeiLi(){
    return this.fetch('http://47.52.188.179/public/index.php/GetMessage?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1aWQiOjM0NTEsImV4cGlyZSI6MTU5NDExODYwOCwiY29kZSI6IkFrc1RSOGllTGUiLCJyZWdfaWQiOiJDbUtRQmNOaFI1anliUndtZnpQWSIsInJhbmQiOjk0NjN9.onZlQvbyGH6xkbQLGQIS1UykNz7MKob_KVN1-1tO8xA&page=1&model=7', {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json())    
  }
  //获取次高，次低(注意token)
  getCiGao(){
    return this.fetch('http://47.52.188.179/public/index.php/GetMessage?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1aWQiOjM0NTEsImV4cGlyZSI6MTU5NDExODYwOCwiY29kZSI6IkFrc1RSOGllTGUiLCJyZWdfaWQiOiJDbUtRQmNOaFI1anliUndtZnpQWSIsInJhbmQiOjk0NjN9.onZlQvbyGH6xkbQLGQIS1UykNz7MKob_KVN1-1tO8xA&page=1&model=5', {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json()) 
  }

  
  //获取股票更新(注意token)
  getGuPiao(){
    return this.fetch('http://api.stock.aibinance.com/ClOrder?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1aWQiOjM0NTEsImV4cGlyZSI6MTU5NDExMTA1MiwiY29kZSI6IkFrc1RSOGllTGUiLCJwaG9uZSI6IjEzMDI1NDA3OTYyIn0.eHen_-5e0S0U3wpQ-FNUvCzBosddwA6HRsqGDs817UI', {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json()) 
  }
  //获取智能能选股(注意token和上面同)
  getGPzhiNeng(){
    return this.fetch('http://api.stock.aibinance.com/SharesNew?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1aWQiOjM0NTEsImV4cGlyZSI6MTU5NDExMTA1MiwiY29kZSI6IkFrc1RSOGllTGUiLCJwaG9uZSI6IjEzMDI1NDA3OTYyIn0.eHen_-5e0S0U3wpQ-FNUvCzBosddwA6HRsqGDs817UI', {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json()) 
  }  
  //获取芥末圈最新详情
  getJieMo(){
    return this.fetch('https://api250.jiemo100.com/topic/index/index?login_token=000000&group_id=33673&visitor=1', {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json())      
  }
  //获取k线信息bch
  getKlineBN(){
    return this.fetch('https://api.binance.com/api/v1/klines?symbol=BCHUSDT&interval=15m&limit=35', {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json())     
  }
  //获取5分钟k线
  async getKlineBN_btc5m(){
    let fileDatas= await this.get_FileDatas("wsOn");
    if(fileDatas=='文件不在'){
      return
    };
    let josnDatas=JSON.parse(fileDatas);  
    let url="";
    if(josnDatas.title=="ba"){
      url="https://api.binance.com/api/v1/klines?symbol=BTCUSDT&interval=5m&limit=35";
    }else{
      url="https://api.huobi.pro/market/history/kline?period=5min&size=35&symbol=btcusdt";
    }
    return this.fetch(url, {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json())     
  }
  //获取k线信息eth 5m  币安合约k线
  async getKlineBN_eth15m(){
    let fileDatas= await this.get_FileDatas("wsOn");
    if(fileDatas=='文件不在'){
      return
    };
    let josnDatas=JSON.parse(fileDatas);  
    let url="";
    if(josnDatas.title=="ba"){
      // url="https://fapi.binance.com/fapi/v1/klines?symbol=ETHUSDT&interval=15m&limit=35";
      url="https://api.binance.com/api/v1/klines?symbol=ETHUSDT&interval=15m&limit=35";
    }else{
      url="https://api.huobi.pro/market/history/kline?period=15min&size=35&symbol=ethusdt";
    }
    return this.fetch(url, {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json())     
  }  
  //获取k线信息eth
  async getKlineBN_eth1h(){
    let fileDatas= await this.get_FileDatas("wsOn");
    if(fileDatas=='文件不在'){
      return
    };
    let josnDatas=JSON.parse(fileDatas);  
    let url="";
    if(josnDatas.title=="ba"){
      // url="https://fapi.binance.com/fapi/v1/klines?symbol=ETHUSDT&interval=5m&limit=35";
    }else{
      url="https://api.huobi.pro/market/history/kline?period=60min&size=35&symbol=ethusdt";
    }
    return this.fetch(url, {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json())     
  }    
  //获取k线信息btc
  async getKlineBN_btc15m(){
    let fileDatas= await this.get_FileDatas("wsOn");
    if(fileDatas=='文件不在'){
      return
    };
    let josnDatas=JSON.parse(fileDatas);  
    let url="";
    if(josnDatas.title=="ba"){
      url="https://api.binance.com/api/v1/klines?symbol=BTCUSDT&interval=15m&limit=35";
    }else{
      url="https://api.huobi.pro/market/history/kline?period=15min&size=35&symbol=btcusdt";
    }
    return this.fetch(url, {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json())     
  }
  //获取k线信息btc  1h
  async getKlineBN_btc1h(){
    let fileDatas= await this.get_FileDatas("wsOn");
    if(fileDatas=='文件不在'){
      return
    };
    let josnDatas=JSON.parse(fileDatas);  
    let url="";
    if(josnDatas=="ba"){
      url="https://api.binance.com/api/v1/klines?symbol=BTCUSDT&interval=1h&limit=35";
    }else{
      url="https://api.huobi.pro/market/history/kline?period=60min&size=35&symbol=btcusdt";
    }    
    return this.fetch(url, {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json())     
  }  
  //获取k线信息btc  4h
  async getKlineBN_btc4h(){
    let fileDatas= await this.get_FileDatas("wsOn");
    if(fileDatas=='文件不在'){
      return
    };
    let josnDatas=JSON.parse(fileDatas);  
    let url="";
    if(josnDatas=="ba"){
      url="https://api.binance.com/api/v1/klines?symbol=BTCUSDT&interval=4h&limit=35";
    }else{
      url="https://api.huobi.pro/market/history/kline?period=4hour&size=35&symbol=btcusdt";
    }     
    return this.fetch(url, {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json())     
  }       
  //获取k线信息btc
  getKlineBN_eth(){
    return this.fetch('https://api.binance.com/api/v1/klines?symbol=ETHUSDT&interval=15m&limit=35', {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json())     
  }  
  //获取k线信息
  getKlineHB(){
    return this.fetch('https://api.huobi.pro/market/history/kline?period=15min&size=30&symbol=bchusdt', {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json())     
  }
  //获取币安币涨幅排名
  get_Ba24hr(){
    return this.fetch('https://www.binance.com/fapi/v1/ticker/24hr', {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json())     
  }

  // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~,更新token用
  //获取439单子的数据
  async get_439data(){
    let fileDatas= await this.get_FileDatas("349token");
    if(fileDatas=='文件不在'){
      return
    };
    let datas=JSON.parse(fileDatas);    
    return this.fetch('https://www.349assistant.com/api/getPosition?realFirmId=24', {
      method: 'GET',
      headers: {
        lang: 'cn',
        token:datas.token
      }
    }).then(res => res.json())     
  }  
  //获取439公告提示
  async get_439tip(){
    let fileDatas= await this.get_FileDatas("349token");
    if(fileDatas=='文件不在'){
      return
    };
    let datas=JSON.parse(fileDatas);   
    return this.fetch('https://api.coolcoin.vip/api/getMarketAnalyse?pageNo=1&pageSize=12', {
      method: 'GET',
      headers: {
        lang: 'cn',
        token:datas.token
      }
    }).then(res => res.json())     
  }
  //获取全球指数（重要对比）
  async get_global(){   
    return this.fetch('https://api.chainext.cn/v1/coin_detail?id=1', {
      method: 'GET',
      headers: {
        'lang': 'cn'      
      }
    }).then(res => res.json())     
  }
  //更新439提示token
  get_439tokenTip(){
    return this.fetch('https://api.coolcoin.vip/api/login?username=810544050%40qq.com&password=147258qwe', {
      method: 'post',
      headers: {
        'Content-Type': 'application/json;charset=UTF-8'
      }
    }).then(res => res.json()) 
  }
  //更新439用户token
  get_439token(){
    return this.fetch('https://www.349assistant.com/api/login?username=736001033%40qq.com&password=147258qwe123', {
      method: 'post',
      headers: {
        'Content-Type': 'application/json;charset=UTF-8'
      },
      body: JSON.stringify({
        username:'736001033@qq.com',
        password:'147258qwe'
      })
    }).then(res => res.json()) 
  } 
  
  //周总要求
  get_zhouCloseList(symbol,minute){
    //5m 15m 30m 1h 4h
    return this.fetch(`https://api.binance.com/api/v1/klines?symbol=${symbol}&interval=${minute}&limit=100`, {
      method: 'GET',
      headers: {
        lang: 'cn'
      }
    }).then(res => res.json())  
  }
}

module.exports = Fcoin;
