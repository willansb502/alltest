const express = require('express');
const router = express.Router();
const fs = require("fs");
const Fcoin = require('../api/apiFcoin.js');
const wsBinance = require('../wsBinance.js');
//console.log(wsBinance)
let Api = new Fcoin({
  key: '',
  secret: '',
  proxy: '' // 为空则不开启
})
//在后面添加不删除
// fs.writeFile('date/date2.txt', JSON.stringify(newArr), { 'flag': 'a' }, function(err) {
var public_gg={
  get_time(time){
    let date = new Date(time);
    let year = date.getFullYear();
    let month = date.getMonth() + 1;
    let day = date.getDate();
    let hour = date.getHours();
    let min = date.getMinutes();
    let sec = date.getSeconds();
    return `${year}年${month}月${day}日${hour}时${min}分${sec}秒`;
  },  
}
// 获取验证码
function random(max,min){
  return Math.round(Math.random()*(max-min)+min);
}
function randomStr(leng){
    var strData = "";
    for(var i=0;i<4;i++){
        var num = random(0,9);//生成0-9的随机数
        var az = String.fromCharCode(random(97,122));//生成a-z
        var AZ = String.fromCharCode(random(65,90));//生成A-Z
        strData = strData + num + az + AZ;//将生成的字符进行字符串拼接
    }
    var str = "";
    for(var i=0;i<leng;i++){
        str += strData[random(0,strData.length-1)]
    }
    return str;
}
//修改常规数据
router.get('/get_msg',async function(req, res, next) {
  if(!req.query.phone){
    return
  }
  let code=randomStr(4);
  Api.sendMsg(code,req.query.phone).then(data => { 
    res.send({"code":200,result:{code:code},"message":"成功"});
  });
});

var get_smsgFileDatas=function(path){
  return new Promise(function(resolve, reject) {
    fs.readFile(`date/smsg/${path}.txt`,{encoding:"utf-8"}, function (err, fr) {
      if (err) {
        resolve('文件不在');
       }else {
        resolve(fr);
       }
    });    
  });
}  
//常规数据
router.get('/commonDatas',async function(req, res, next) {   
  let fileDatas= await get_smsgFileDatas('if_send_msg');
  if(fileDatas=='文件不在'){ return } ;
  let oldDatas=JSON.parse(fileDatas); 
  res.send({"code":200,result:oldDatas,"message":"成功"});
});
//修改常规数据
router.get('/commonEdit',async function(req, res, next) {
  // 原始数据{"jq088":"0.88","jqbch":"1.88","jqbtc":"60","kqcy":"2","kq088":"2"}
  fs.writeFile(`date/smsg/if_send_msg.txt`, JSON.stringify(req.query), function(err) {
    if (err) {
      res.send({"code":400,result:{},"message":"失败"});
      throw err;
    }else{
      res.send({"code":200,result:{},"message":"成功"});
    }
  });  
});


//破高低数据
router.get('/l_h_Datas',async function(req, res, next) {
  let fileDatas= await get_smsgFileDatas('l_h_tip');
  if(fileDatas=='文件不在'){ return } ;
  let oldDatas=JSON.parse(fileDatas); 
  res.send({"code":200,result:oldDatas,"message":"成功"});
});
//修改破高低数据
router.get('/l_h_Edit',async function(req, res, next) {
  //原始数据{"btc":{"l":"2","h":"2"},"bch":{"l":"2","h":"2"},"eth":{"l":"2","h":"2"}}
  let newData={
    btc:JSON.parse(req.query.btc),
    btc1h:JSON.parse(req.query.btc1h),
    btc4h:JSON.parse(req.query.btc4h)
  };
  fs.writeFile(`date/smsg/l_h_tip.txt`, JSON.stringify(newData), function(err) {
    if (err) {
      res.send({"code":400,result:{},"message":"失败"});
      throw err;
    }else{
      res.send({"code":200,result:{},"message":"成功"});
    }
  });  
});


//牛熊压力数据
router.get('/niu_ya_Datas',async function(req, res, next) {
  let fileDatas= await get_smsgFileDatas('niu_ya_msg');
  if(fileDatas=='文件不在'){ return } ;
  let oldDatas=JSON.parse(fileDatas); 
  res.send({"code":200,result:oldDatas,"message":"成功"});
});
//添加牛熊压力数据
router.get('/niu_ya_Edit',async function(req, res, next) {
  //原始数据[{"name":"btc","dx":"1","niu":"8","price":""},{"name":"eth","dx":"1","niu":"8","price":""},{"name":"bch","dx":"1","niu":"8","price":""}]
  let fileDatas= await get_smsgFileDatas('niu_ya_msg');
  if(fileDatas=='文件不在'){ return } ;
  let oldDatas=JSON.parse(fileDatas); 
  oldDatas.unshift(req.query);
  if(Array.isArray(oldDatas)){
    fs.writeFile(`date/smsg/niu_ya_msg.txt`, JSON.stringify(oldDatas), function(err) {
      if (err) {
        res.send({"code":400,result:{},"message":"失败"});
        throw err;
      }else{
        res.send({"code":200,result:{},"message":"成功"});
      }
    });  
  }
});
//删除牛熊压力数据
router.get('/niu_ya_Delete',async function(req, res, next) {
  let fileDatas= await get_smsgFileDatas('niu_ya_msg');
  if(fileDatas=='文件不在'){ return } ;
  let oldDatas=JSON.parse(fileDatas); 
  oldDatas.splice(req.query.index,1);
  fs.writeFile(`date/smsg/niu_ya_msg.txt`, JSON.stringify(oldDatas), function(err) {
    if (err) {
      res.send({"code":400,result:{},"message":"失败"});
      throw err;
    }else{
      res.send({"code":200,result:{},"message":"成功"});
    }
  });    
});

//日期监控数据
router.get('/date_Datas',async function(req, res, next) {
  let fileDatas= await get_smsgFileDatas('time_oclock');
  if(fileDatas=='文件不在'){ return } ;
  let oldDatas=JSON.parse(fileDatas); 
  res.send({"code":200,result:oldDatas,"message":"成功"});
});
//添加日期监控数据
router.get('/date_Edit',async function(req, res, next) {
  let fileDatas= await get_smsgFileDatas('time_oclock');
  if(fileDatas=='文件不在'){ return } ;
  let oldDatas=JSON.parse(fileDatas); 
  oldDatas.unshift(req.query);
  fs.writeFile(`date/smsg/time_oclock.txt`, JSON.stringify(oldDatas), function(err) {
    if (err) {
      res.send({"code":400,result:{},"message":"失败"});
      throw err;
    }else{
      res.send({"code":200,result:{},"message":"成功"});
    }
  });    
});
//删除日期监控数据
router.get('/date_Delete',async function(req, res, next) {
  let fileDatas= await get_smsgFileDatas('time_oclock');
  if(fileDatas=='文件不在'){ return } ;
  let oldDatas=JSON.parse(fileDatas); 
  oldDatas.splice(req.query.index,1);
  fs.writeFile(`date/smsg/time_oclock.txt`, JSON.stringify(oldDatas), function(err) {
    if (err) {
      res.send({"code":400,result:{},"message":"失败"});
      throw err;
    }else{
      res.send({"code":200,result:{},"message":"成功"});
    }
  });    
});

//获取macd数据
router.get('/macd_Datas',async function(req, res, next) {
  let fileDatas= await get_smsgFileDatas('macd');
  if(fileDatas=='文件不在'){ return } ;
  let oldDatas=JSON.parse(fileDatas); 
  res.send({"code":200,result:oldDatas,"message":"成功"});
});
//修改macd数据
router.get('/macd_Edit',async function(req, res, next) {
  let obj={
    btc5:'',
    btc15:'',
    btc15eth:'',
    btc1h:'',
    btc4h:''
  }
  obj.btc5=JSON.parse(req.query.btc5);
  obj.btc15=JSON.parse(req.query.btc15);
  obj.btc15eth=JSON.parse(req.query.btc15eth);
  obj.btc1h=JSON.parse(req.query.btc1h);
  obj.btc4h=JSON.parse(req.query.btc4h);
  fs.writeFile(`date/smsg/macd.txt`, JSON.stringify(obj), function(err) {
    if (err) {
      res.send({"code":400,result:{},"message":"失败"});
      throw err;
    }else{
      res.send({"code":200,result:{},"message":"成功"});
    }
  });    
});

//获取ws数据
router.get('/ws_Datas',async function(req, res, next) {
  let fileDatas= await get_smsgFileDatas('wsOn');
  if(fileDatas=='文件不在'){ return } ;
  let oldDatas=JSON.parse(fileDatas); 
  res.send({"code":200,result:oldDatas,"message":"成功"});
});
//修改ws数据
router.get('/ws_Edit',async function(req, res, next) {
  fs.writeFile(`date/smsg/wsOn.txt`, JSON.stringify(req.query), function(err) {
    if (err) {
      res.send({"code":400,result:{},"message":"失败"});
      throw err;
    }else{
      wsBinance.re_fn_changeWs();
      res.send({"code":200,result:{},"message":"成功"});
    }
  });    
});


//币安下单测试
router.get('/xiadan_ba',async function(req, res, next) {
  wsBinance.testKey2Api();
  res.send({"code":200,result:{},"message":"成功"}); 
});

//获取穿越时间数据
router.get('/cy_Datas',async function(req, res, next) {
  let fileDatas= await get_smsgFileDatas('add_cy_time');
  if(fileDatas=='文件不在'){ return } ;
  let oldDatas=JSON.parse(fileDatas); 
  res.send({"code":200,result:oldDatas,"message":"成功"});
});
//修改穿越时间数据
router.get('/cy_Edit',async function(req, res, next) {
  let fileDatas= await get_smsgFileDatas('add_cy_time');
  if(fileDatas=='文件不在'){ return } ;
  let oldDatas=JSON.parse(fileDatas); 
  let addTime=60*60*1000;
  let get_number=0;
  if(+req.query.number>=10){
    get_number=+req.query.number/10;
    let futureTime=addTime*(get_number)+new Date().getTime();
    let futureChneseTime=public_gg.get_time(futureTime);
    if(req.query.type=="15"){
      oldDatas.btc.timeChina=futureChneseTime;
      oldDatas.btc.timeNum=futureTime;
      oldDatas.btc.duiZi=req.query.duiZi;
    }else if(req.query.type=="1h"){
      oldDatas.btc1h.timeChina=futureChneseTime;
      oldDatas.btc1h.timeNum=futureTime;
      oldDatas.btc1h.duiZi=req.query.duiZi;
    }else if(req.query.type=="4h"){
      oldDatas.btc4h.timeChina=futureChneseTime;
      oldDatas.btc4h.timeNum=futureTime;
      oldDatas.btc4h.duiZi=req.query.duiZi;
    }   
  }else{
    get_number=(+req.query.number);
    let futureTime=addTime*(get_number)+new Date().getTime();
    let futureChneseTime=public_gg.get_time(futureTime);
    if(req.query.type=="15"){
      oldDatas.ma_btc.timeChina=futureChneseTime;
      oldDatas.ma_btc.timeNum=futureTime;
    }else if(req.query.type=="1h"){
      oldDatas.ma_btc1h.timeChina=futureChneseTime;
      oldDatas.ma_btc1h.timeNum=futureTime;
    }else if(req.query.type=="4h"){
      oldDatas.ma_btc4h.timeChina=futureChneseTime;
      oldDatas.ma_btc4h.timeNum=futureTime;
    }     
  }

  fs.writeFile(`date/smsg/add_cy_time.txt`, JSON.stringify(oldDatas), function(err) {
    if (err) {
      res.send({"code":400,result:{},"message":"失败"});
      throw err;
    }else{
      res.send({"code":200,result:{},"message":"成功"});
    }
  });    
});
//日志数据
router.get('/log_Datas',async function(req, res, next) {
  let fileDatas= await get_smsgFileDatas('log');
  if(fileDatas=='文件不在'){ return } ;
  let oldDatas=JSON.parse(fileDatas); 
  res.send({"code":200,result:oldDatas,"message":"成功"});
});


module.exports = router;