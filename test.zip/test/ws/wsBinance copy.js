
const ws = require('ws');
const pako = require('pako');

const fs = require("fs");
const nodews = require('nodejs-websocket');

const cheerio = require('cheerio');
const request = require('request')

const ReconnectingWebSocket = require('reconnecting-websocket'); //如果关闭连接，将自动重新连接的WebSocket
const Fcoin = require('./api/apiFcoin.js');
let Api = new Fcoin({});//常规

const userSecretList= require('./datas/biAnsecret.js').userSecretList;
const Binance = require('./api/buySell.js');
//Important  币安下单
let binance = new Binance({
  userSecretList:userSecretList
})

// const { ESTALE } = require('constants');
// 火币连接
var huobiWsSub={
  // urlSave:"wss://api.huobiasia.vip/ws"  //非常快
  url:"wss://api.huobi.pro/ws",
  huobiWsSub5eth:{
    "sub": "market.ethusdt.kline.5min",
    "id": "id15meth"
  }, 
  huobiWsSub1heth:{
    "sub": "market.ethusdt.kline.60min",
    "id": "id60meth"
  },     
  huobiWsSub5:{
    "sub": "market.btcusdt.kline.5min",
    "id": "id5m"
  },  
  huobiWsSub15:{
    "sub": "market.btcusdt.kline.15min",
    "id": "id15m"
  },
  huobiWsSub1h:{
    "sub": "market.btcusdt.kline.60min",
    "id": "id1h"
  },  
  huobiWsSub4h:{
    "sub": "market.btcusdt.kline.4hour",
    "id": "id4h"
  }, 
}

//静态
var staticData = {

  wsFrom:"ba",//ws数据来源

  status439:true,//439资源防止频繁调用
  statusGloEth:true,//全球eth指数调用
  statusGloEthTxt:"",//全球eth当前状态，空和多
  time349tip:0,
  token349tip:'',
  time349:0,
  token349:'',
  per24barTime:0,

  baJingDuList:[],//币安合约精度列表
  status439TokenTime:0,//token更新

  pxgStatus:{  //破新高，破新低状态
    h1pxd:0,
    h1pxg:0
  },

  btc_730:"",//btc730是否交叉
  vucDif_btc:"",//btc慢速线
  vucDea_btc:"",//btc快速线
  vucMacdTime_btc:"",//发送短信时间
  countDatasTime: "",//7日线和30日线第一个静态时间
  countDatasArr:[],//7日线和30日线数据保存

  if_send_msgSave:'',//发送短信保存，常年不改变的变量可以存eg:5分大涨波动
  per5minUp_time:0,//5分大涨发送时间
  per5minDown_time:0,//5分大跌发送时间
  if_send_msgUpdateStaue:true,//if_send_msg文件更新是否完毕一个个来

  beiliUpdateStaue:true,//背离每次只更新一次文件
  publicDZobj:{//对子保存
    dz15d:'2',
    dz15k:'2',
    dz15Time:0,
    dz1hd:'2',
    dz1hk:'2',
    dz1hTime:0,
    dz4hd:'2',
    dz4hk:'2',
    dz4hTime:0
  },

  line7_btc15:0,//15分均线
  line30_btc15:0,//15分均线
  line7_btc1h:0,//15分均线
  line30_btc1h:0,//15分均线
  line7_btc4h:0,//15分均线
  line30_btc4h:0,//15分均线

  price15mHigh:0,//15分高点价格
  price15mLow:0,//15分低点价格
  price15mHighEth:0,//15分高点价格
  price15mLowEth:0,//15分低点价格  

  controlHbFc1s:{  //控制火币调用频率
    m5:true,
    m15:true,
    hour1:true,
    hour4:true,
    m15eth:true,
    hour1eth:true,
  },  

  getBianArr:{   //获取k线状态,没获取回来不能进行第二次
    min5:true,
    min15:true,
    hour1h:true,
    hour4h:true,
    min15eth:true,
    hour1heth:true,
  },
  macdTime5D:0,//macd 5分发送时间
  macdTime15D:0,//macd 15分发送时间
  macdTime15Deth:0,//macd 15分发送时间
  macdTime1hD:0,//macd 1小时发送时间
  macdTime4hD:0,//macd 1小时发送时间

  macdTime5_update:0,//macd文件更新时间
  macdTime15_update:0,//macd文件更新时间
  macdTime15eth_update:0,//macd文件更新时间
  macdTime1h_update:0,//文件更新时间
  macdTime4h_update:0,//文件更新时间

  //悬浮
  btc_XuanfuTime15m:0,//btc730时间15分
  btc_XuanfuTime1h:0,//btc730时间1小时

  //变色
  btc_BianseTime15m:0,//btc730时间15分
  btc_BianseTime1h:0,//btc730时间1小时  


  countDatasArrBtc5m:[],//btc 7日线和30日线数据保存5min
  countDatasTimeBtc5m:"",//btc 7日线和30日线第一个静态时间5min


  countDatasArrEth15m:[],//btc 7日线和30日线数据保存15min
  countDatasTimeEth15m:"",//btc 7日线和30日线第一个静态时间15min

  countDatasArrEth1h:[],//btc 7日线和30日线数据保存15min
  countDatasTimeEth1h:"",//btc 7日线和30日线第一个静态时间15min  

  countDatasArrBtc15m:[],//btc 7日线和30日线数据保存15min
  countDatasTimeBtc15m:"",//btc 7日线和30日线第一个静态时间15min
  btc_730Time15m:0,//btc730时间
  btc_730ABS15m:0,//btc730abs
  btc_Cy15min:0,//穿越


  countDatasArrBtc1h:[],//btc 7日线和30日线数据保存15min
  countDatasTimeBtc1h:"",//btc 7日线和30日线第一个静态时间15min
  btc_730Time1h:0,//btc730时间
  btc_730Abs1h:0,//btc730abs
  btc_Cy1h:0,//穿越


  countDatasArrBtc4h:[],//btc 7日线和30日线数据保存15min
  countDatasTimeBtc4h:"",//btc 7日线和30日线第一个静态时间15min
  btc_730Time4h:0,//btc730时间
  btc_Cy4h:0,//穿越  

  //记录多空和自动开启变色
  recordBianse:{
    bs_15m:{
      now:'',
      time:0
    },
    bs_1h:{
      now:'',
      time:0
    },
    bs_4h:{
      now:'',
      time:0
    },        
  },
  // 破新高是哪个价格触发的
  pxg_151h4h:{
    pxg_4h:{
      price:0,
      type:''
    },
    pxg_1h:{
      price:0,
      type:''
    },
    pxg_15m:{
      price:0,
      type:''
    }
  },

  countDatasArrEth:[],//eth 7日线和30日线数据保存
  countDatasTimeEth:"",//eth 7日线和30日线第一个静态时间  
  //btc尖角发送时间
  btcJqDatas:{
    time15:0,
    time30:0,
    time1h:0,
  },
  sendTime_tongbu:0,
  ws:null,//ws发送回去
  //发送回去的数据
  sendDatas:{
    QqjjObj:{
      junEthPrice:'',
      baEthPrice:'',
      sring:''
    },
    eth5macdObj:{
      jsStatus:'',//金死叉状态
      ballColor:'',//球的颜色
      fanZhuan:'',//破新高，破新低

      zhis:0,//止损价位是多少
      daXiao:'',//大小于
      zhis50:0,//最大止损50%
      zhisSSS:0,//最后止损
      zhiYing:0,//止盈
      kaicangPrice:0,//开仓价
      abv80:'',//是否大于80
      changWei:'',//目前持仓,多还是空
      lvhong:'',//短线是否触发，以上一根为准10秒消失5分钟一次
      oneSuccess:'',//一个金叉只止盈一次，空为此金叉未止盈

      fanZhuan2:'',//破新高，破新低
      zhis2:0,//止损价位是多少
      daXiao2:'',//大小于
      zhis502:0,//最大止损50%
      zhisSSS2:0,//最后止损
      zhiYing2:0,//止盈
      kaicangPrice2:0,//开仓价
      abv802:'',//是否大于80
      changWei2:'',//目前持仓,多还是空
      oneSuccess2:'',//一个金叉只止盈一次，空为此金叉未止盈      

    },
    beiLi23:{
      datas:""
    },
    macdSendObj:{
      h4:0,
      h1:0,
      h15:0          
    },

    wsTitle:"",
    ws4h1h15mUpdate:{//15分，14小时ws是否还连接
      wsm5:{
        type:"5m",
        num:"",
        chiaNum:""
      },      
      wsm15:{
        type:"15m",
        num:"",
        chiaNum:""
      },
      wsm15eth:{
        type:"15m",
        num:"",
        chiaNum:""
      },      
      ws1h:{
        type:"1h",
        num:"",
        chiaNum:""
      },
      ws4h:{
        type:"4h",
        num:"",
        chiaNum:""
      }
    },
    ciGaoDi:{ //次高低
      cidi:0,
      cigao:0,
    },
    pubilcMsg:'',//公共前段显示全信息
    pubilcPhoneMsg:'',//发送短信信息
    oclockAppH5:{//闹钟是否响
      h5:'',
      app:''
    },    
    abs:0,
    eth_abs:0,
    btcPrice:0,//比特币价格
    ethPrice:0,//以太币价格
    //趋势线开始时间秒
    time_btc_start:0, 
    // 红绿线
    red_green:{
      btc:{//间隔15分钟
        red:0,
        green:0
      },
      btc1h:{//间隔1小时
        red:0,
        green:0
      },
      btc4h:{//间隔4小时
        red:0,
        green:0
      }  
    },
    //红绿线次数
    red_green_time:{
      time15red:0,
      time15green:0,
      time1hred:0,
      time1hgreen:0,
      time4hred:0,
      time4hgreen:0     
    },
    coin:{
      btc:{
        h:0,
        l:0
      },
      btc1h:{
        h:0,
        l:0
      },
      btc4h:{
        h:0,
        l:0
      }                  
    },
    now:{
      xj730:0, //7-30是否相交,正发生转变，客户端用       
      current:0,//现在价格
      topJq:0,//上尖角
      botJq:0,//下尖角
      btcjq15min:0,//尖角值
      btcjq30min:0,//尖角值
      btcjq1hmin:0,//尖角值
      bchjq:0,//尖角值
      nowChuanYue:false, //当前是否穿越，客户端会时刻响着，也要结合上一个未穿越来做 
      nowChuanYue_btc:false,
      cy730:0,//穿越 
      cy730_btc:0,//穿越
      cy730_tongbu:0,//穿越
      cy730_tongbu2:0,//穿越
      rank730:0,         
      hight:0,
      low:0
    },
    last:{
      //计算上一个是否穿越
      lastChuanYue:false,
      rank:0,//上一个尖角排名
      name:'',//是上还是下尖角
      jq:'',//上一个尖角
      hight:0,
      low:0      
    },
    //各个时间标记
    timeTag:{
      timeTipJQ:0,//大于0.88的提醒尖角
      timeBigJQ:0,//大于4的尖角
      timeSmallJQ:0,//大于2的尖角
      timeAdd100:0,//穿越
      timeAdd100_btc:0,//穿越
      timeJC160:0,//相交
      timeJC160_btc:0,//相交      
      timeJC160_2:0,//相交防止干扰
      dingjiBch8:0,//顶级角8
      pingJiao:0,//平角
      paixu:0,//排序已暂停
    },    
  },
  //火币大单深度
  timeHb:{
    hbSdbuyTime:0,//火币购买深度时间
  },
  //背离信息
  beiLiObj:{
    time:"",
    zhou:{
      max:"",
      min:"",
      timeMin:"",
      timeMax:""
    },
    bin:{
      btc:{
        max:"",
        min:"",
        timeMin:"",
        timeMax:""
      },
      btc30:{
        max:"",
        min:"",
        timeMin:"",
        timeMax:""       
      },      
      bch:{
        max:"",
        min:"",
        timeMin:"",
        timeMax:""       
      },
      eth:{
        max:"",
        min:"",
        timeMin:"",
        timeMax:""      
      }      
    }
  },
  //日志
  msgLog:{
    time:"",
    msg:""
  }
}
//在后面添加不删除
// fs.writeFile('date/date2.txt', JSON.stringify(newArr), { 'flag': 'a' }, function(err) {
// 火币MACD相交，未完成
//公共
var public_gg={
  get_time(type){
    let date = new Date();
    let year = date.getFullYear();
    let month = date.getMonth() + 1;
    let day = date.getDate();
    let hour = date.getHours();
    let min = date.getMinutes();
    let sec = date.getSeconds();
    if (type == 'day') {
      return `${year}-${month}-${day}`;
    } else {
      return `${year}年${month}月${day}日${hour}时${min}分${sec}秒`;
    }  
  },  
}
//上涨提示
var data_shangZhang={
  //获取公告
  // get_ads58(){
  //   Api.get_58ads().then(async data => {
  //     if(data){
  //       let fileDatas= await data_shangZhang.get_smsgFileDatas('58tf');
  //       if(fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
  //       let oldDatas=JSON.parse(fileDatas);
  //       console.log("监控58公告")
  //       if(oldDatas.title!=data.articles[0].title&&data.articles[0].title.includes("停服")||oldDatas.title!=data.articles[0].title&&data.articles[0].title.includes("升级")){
  //         oldDatas.title=data.articles[0].title;
  //         data_shangZhang.update_fileDatas('58tf',oldDatas);
  //         Api.sendMsg("58wh").then(data => { 
  //           console.log(data)
  //         });           
  //       }
  //     }
  //   }); 
  // },
  //记录h5，app是否响过闹铃
  fn_oclockAppH5(){
    staticData.sendDatas.oclockAppH5.h5="有新闹钟";
    staticData.sendDatas.oclockAppH5.app="有新闹钟";
  },
  //次高次低，背二次离
  async fn_getCiGao(){
    if(!staticData.countDatasArrBtc4h.length){
      return;
    }

    let fileDatas= await data_shangZhang.get_smsgFileDatas('cidi');
    if(fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;//直接打断不继续了
    let oldDatas=JSON.parse(fileDatas);    
    
    let dateToday = new Date();
    let monthToday = dateToday.getMonth() + 1;
    let dayToday = dateToday.getDate();

    let ciGaoDiSave=0;
    staticData.countDatasArrBtc4h.forEach((item,index)=>{
      let dateLast = new Date(item[0]);
      let monthLast = dateLast.getMonth() + 1;
      let dayLast = dateLast.getDate();  
      let hourLast = dateLast.getHours(); 
      if(monthToday==monthLast&&dayToday==dayLast&&hourLast==0){//日期0时都对的上的话
        ciGaoDiSave=item[1];
      }   
    })
    let cigaoPrice=(+oldDatas.price)*1.05035;
    let cidiPrice=(+oldDatas.price)*0.97035;
    staticData.sendDatas.ciGaoDi.cidi=cidiPrice;
    staticData.sendDatas.ciGaoDi.cigao=cigaoPrice;

    if(oldDatas.price!=ciGaoDiSave&&oldDatas.time!=dayToday){//价格和日期都不同时
      oldDatas.price=ciGaoDiSave;
      oldDatas.time=dayToday;
      oldDatas.ifSend="2";
      data_shangZhang.update_fileDatas('cidi',oldDatas);
    }

    //如果已发送则返回
    if(oldDatas.ifSend=="1"||!staticData.sendDatas.btcPrice){
      return
    }

    if(staticData.sendDatas.btcPrice>cigaoPrice){
      staticData.sendDatas.pubilcMsg=`【彬彬科技】计算次高价出现，时间：${public_gg.get_time()}`;
      staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】计算次高价出现，时间：${public_gg.get_time()}`;
      data_shangZhang.fn_oclockAppH5();
      data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"计算次高价");
      
      setTimeout(()=>{
        staticData.sendDatas.pubilcMsg="";
      },10*1000);   
      Api.sendMsg("CGJS").then(data => { 
        console.log(data)
      });         
      oldDatas.ifSend="1";
      data_shangZhang.update_fileDatas('cidi',oldDatas); 
    }
    if(staticData.sendDatas.btcPrice<cidiPrice){
      staticData.sendDatas.pubilcMsg=`【彬彬科技】计算次低价出现，时间：${public_gg.get_time()}`;
      staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】计算次低价出现，时间：${public_gg.get_time()}`;
      data_shangZhang.fn_oclockAppH5();
      data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"计算次低价");
      setTimeout(()=>{
        staticData.sendDatas.pubilcMsg="";
      },10*1000);   
      Api.sendMsg("CDJS").then(data => { 
        console.log(data)
      });         
      oldDatas.ifSend="1"; 
      data_shangZhang.update_fileDatas('cidi',oldDatas);
    }  
  },  
  //重写30条日志文件
  re_writeLog(pubilcMsg,tag){
    // 存信息，记录存信息时间
    let getTime=new Date().getTime();
    let interTime100=30*1000;
    let timeAllow100=getTime-staticData.msgLog.time;      
    if(!staticData.msgLog.msg){
      staticData.msgLog.msg=tag;
      staticData.msgLog.time=getTime;
    };
    //小于30秒，并且短信相同不写入
    if(timeAllow100<interTime100&&staticData.msgLog.msg==tag){
      return;//打断
    }
    staticData.msgLog.time=getTime;
    staticData.msgLog.msg=tag; 
    // 读取，截取写入30条信息
    fs.readFile(`date/smsg/log.txt`,{encoding:"utf-8"}, function (err, fr) {
      if (err) {
      }else {
        let oldDatas=[];
        try {
          oldDatas=JSON.parse(fr); 
        } catch(e) {
          fs.writeFile(`date/smsg/log.txt`, JSON.stringify([]), function(err) {
            if (err) {
              throw err;
            }else{
            }
          });  
          return   //打断不继续了     
        }         
        if(oldDatas.length<30){
          oldDatas.unshift(pubilcMsg);
          // 写入
          fs.writeFile(`date/smsg/log.txt`, JSON.stringify(oldDatas), function(err) {
            if (err) {
              throw err;
            }else{
            }
          });           
        }else{        
          oldDatas.unshift(pubilcMsg);
          let newDatas=oldDatas.slice(0,30);
          fs.writeFile(`date/smsg/log.txt`, JSON.stringify(newDatas), function(err) {
            if (err) {
              throw err;
            }else{
            }
          });          
        };
       }
    });     
  },
  //判断文件是否存在
  get_FileDatas(){
    return new Promise(function(resolve, reject) {
      fs.readFile(`date/${public_gg.get_time('day')}.txt`,{encoding:"utf-8"}, function (err, fr) {
        if (err) {
          resolve('文件不在');
         }else {
          resolve(fr);
         }
      });    
    });
  },
  //读取date/smsg下面的文件
  get_smsgFileDatas(path){
    return new Promise(function(resolve, reject) {
      fs.readFile(`date/smsg/${path}.txt`,{encoding:"utf-8"}, function (err, fr) {
        if (err) {
          resolve('文件不在');
         }else {
          resolve(fr);
         }
      });    
    });
  },  
  //更新文档内容
  update_fileDatas(path,newDatas){
    fs.writeFile(`date/smsg/${path}.txt`, JSON.stringify(newDatas), function(err) {
      if (err) {
        throw err;
      }else{
        // console.log("更新成功")
      }
    });  
  },
  //频繁更新macd(或某个文件)
  update_fileDatas_macd(path,newDatas,type){
    if(!staticData.beiliUpdateStaue){return};
    staticData.beiliUpdateStaue=false;
    fs.writeFile(`date/smsg/${path}.txt`, JSON.stringify(newDatas), function(err) {
      if (err) {
        throw err;
      }else{
        console.log("更新macd成功"+type)
      }
      staticData.beiliUpdateStaue=true;
    }); 
  },
  //频繁更新if_send_msg//文件
  update_fileDatas_ifSend(newDatas){
    return new Promise(function(resolve, reject) {
      if(!staticData.if_send_msgUpdateStaue){return};
      staticData.if_send_msgUpdateStaue=false;
      fs.writeFile(`date/smsg/if_send_msg.txt`, JSON.stringify(newDatas), function(err) {
        if (err) {
          resolve('文件更新失败');
        }else{
          resolve('成功');
        }
        staticData.if_send_msgUpdateStaue=true;
      });   
    });
  },
  //监控日期
  async fn_watch_date(){
    let fileDatas= await data_shangZhang.get_smsgFileDatas('time_oclock');
    if(fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
    let oldDatas=JSON.parse(fileDatas);
    let date = new Date();
    let month = date.getMonth() + 1;
    let day = date.getDate();
    let hour = date.getHours();    
    oldDatas.forEach((item,index)=>{
      if(+item.month==month&&+item.day==day&&+item.hour==hour){  
        let msg="";
        if(item.remark){
          msg= `【彬彬科技】等待日期已到,开启交叉闹钟,${item.remark}，时间：${public_gg.get_time()}`
        }
        staticData.sendDatas.pubilcMsg=msg;
        staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】等待日期已到，时间：${public_gg.get_time()}`;
        data_shangZhang.fn_oclockAppH5();
        data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`等待日期已到`);  
        setTimeout(()=>{
          staticData.sendDatas.pubilcMsg="";
        },10*1000);                          
        Api.sendMsg("DDRQ").then(data => { 
          console.log(data)
        }); 

        oldDatas.splice(index,1);
        fs.writeFile(`date/smsg/time_oclock.txt`, JSON.stringify(oldDatas), function(err) {
          if (err) {
            throw err;
          }
        });                 
      }
    })
  },
  //递归
  fn_digui(n){
    if (n == 1) {
        return 1;
    }
    return n + data_shangZhang.fn_digui(n - 1);
  },
 
  //macd背离（不重要）
  async fn_macdBeiLi(dif_new,dea_new,type,highprice,lowPrice){
    // 首先检查是不是该发送短信了
    // 15分背离多
    // if(staticData.publicDZobj.dz15d=='1'&&staticData.sendDatas.btc15_beili.oneDown=='1'){
    //   let getTime=new Date().getTime();
    //   let interTime100=30*60*1000;
    //   let timeAllow100=getTime-staticData.publicDZobj.dz15Time;   
    //   if(timeAllow100>interTime100){
    //     Api.sendMsg("BL15dzD").then(data => { 
    //       console.log(data)
    //     });         
    //   }    
    // }
    // if(staticData.publicDZobj.dz15k=='1'&&staticData.sendDatas.btc15_beili.oneUp=='1'){
    //   let getTime=new Date().getTime();
    //   let interTime100=30*60*1000;
    //   let timeAllow100=getTime-staticData.publicDZobj.dz15Time;   
    //   if(timeAllow100>interTime100){
    //     Api.sendMsg("BL15dzK").then(data => { 
    //       console.log(data)
    //     });         
    //   }    
    // }    
    // // 1h背离多
    // if(staticData.publicDZobj.dz1hd=='1'&&staticData.sendDatas.btc1h_beili.oneDown=='1'){
    //   let getTime=new Date().getTime();
    //   let interTime100=120*60*1000;
    //   let timeAllow100=getTime-staticData.publicDZobj.dz1hTime;   
    //   if(timeAllow100>interTime100){
    //     Api.sendMsg("BL1hdzD").then(data => { 
    //       console.log(data)
    //     });         
    //   }    
    // }
    // if(staticData.publicDZobj.dz1hk=='1'&&staticData.sendDatas.btc1h_beili.oneUp=='1'){
    //   let getTime=new Date().getTime();
    //   let interTime100=120*60*1000;
    //   let timeAllow100=getTime-staticData.publicDZobj.dz1hTime;   
    //   if(timeAllow100>interTime100){
    //     Api.sendMsg("BL1hdzK").then(data => { 
    //       console.log(data)
    //     });         
    //   }    
    // }  
    // // 4h背离多
    // if(staticData.publicDZobj.dz4hd=='1'&&staticData.sendDatas.btc4h_beili.oneDown=='1'){
    //   let getTime=new Date().getTime();
    //   let interTime100=8*60*60*1000;
    //   let timeAllow100=getTime-staticData.publicDZobj.dz4hTime;   
    //   if(timeAllow100>interTime100){
    //     Api.sendMsg("BL4hdzD").then(data => { 
    //       console.log(data)
    //     });         
    //   }    
    // }
    // if(staticData.publicDZobj.dz4hk=='1'&&staticData.sendDatas.btc4h_beili.oneUp=='1'){
    //   let getTime=new Date().getTime();
    //   let interTime100=8*60*60*1000;
    //   let timeAllow100=getTime-staticData.publicDZobj.dz4hTime;   
    //   if(timeAllow100>interTime100){
    //     Api.sendMsg("BL4hdzK").then(data => { 
    //       console.log(data)
    //     });         
    //   }    
    // }      


    // down底背离  up顶背离
    let fileDatas= await data_shangZhang.get_smsgFileDatas('beili_all');
    if(fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
    let oldDatasMacd=JSON.parse(fileDatas);  
    staticData.sendDatas.beiLi23.datas=oldDatasMacd;//发送前端显示


    if(dif_new<0&&dea_new<0){//底背离，顶背离为0
      for (const key in oldDatasMacd[type+'_up']) {//one two three全部等于0，先不更新，需要更新再更新
        oldDatasMacd[type+'_up'][key].dif="0";
        oldDatasMacd[type+'_up'][key].price="0";
        staticData.sendDatas[type+'_beili'].oneUp="2";//一次背离关闭
        staticData.sendDatas[type+'_beili'].twoUp="2";//二次背离关闭          
      }
      // 开启第一段
      if(oldDatasMacd[type+'_down'].one.dif=="0"&&oldDatasMacd[type+'_down'].one.price=="0"){//都等于0
        console.log("开启第一段底背离"+type);
        oldDatasMacd[type+'_down'].two.dif="0";
        oldDatasMacd[type+'_down'].two.price="0";
        oldDatasMacd[type+'_down'].three.dif="0";
        oldDatasMacd[type+'_down'].three.price="0";//归0  two  three
        oldDatasMacd[type+'_down'].one.dif=dif_new;
        oldDatasMacd[type+'_down'].one.price=lowPrice;//第一次赋值
        data_shangZhang.update_fileDatas_macd('beili_all',oldDatasMacd,type);//更新one
        return;        
      }
      //更新第一段，第一项存在，且是死叉，第二项不存在，第三项不存在
      if(dif_new<dea_new&&oldDatasMacd[type+'_down'].one.dif!="0"&&oldDatasMacd[type+'_down'].one.price!="0"&&oldDatasMacd[type+'_down'].two.dif=="0"&&oldDatasMacd[type+'_down'].two.price=="0"&&oldDatasMacd[type+'_down'].three.dif=="0"&&oldDatasMacd[type+'_down'].three.price=="0"){
        console.log("更新第一段底背离"+type);
        if(oldDatasMacd[type+'_down'].one.dif>dif_new){//在更下面时，更新
          oldDatasMacd[type+'_down'].one.dif=dif_new;
          oldDatasMacd[type+'_down'].one.price=lowPrice;
          data_shangZhang.update_fileDatas('beili_all',oldDatasMacd);//更新one
        }
        return;        
      }
      // 开启第二段，第一项存在，且是金叉dif>dea，第二项不存在，第三项不存在,开启第二段
      if(dif_new>dea_new&&oldDatasMacd[type+'_down'].one.dif!="0"&&oldDatasMacd[type+'_down'].one.price!="0"&&oldDatasMacd[type+'_down'].two.dif=="0"&&oldDatasMacd[type+'_down'].two.price=="0"&&oldDatasMacd[type+'_down'].three.dif=="0"&&oldDatasMacd[type+'_down'].three.price=="0"){          
        console.log("开启第二段底背离"+type);
        oldDatasMacd[type+'_down'].two.dif=dif_new;
        oldDatasMacd[type+'_down'].two.price=lowPrice;
        data_shangZhang.update_fileDatas_macd('beili_all',oldDatasMacd,type);//更新two
        return;      
      }
      //更新第二段，第一项存在，第二项存在，且是死叉，第三项不存在
      if(dif_new<dea_new&&oldDatasMacd[type+'_down'].one.dif!="0"&&oldDatasMacd[type+'_down'].one.price!="0"&&oldDatasMacd[type+'_down'].two.dif!="0"&&oldDatasMacd[type+'_down'].two.price!="0"&&oldDatasMacd[type+'_down'].three.dif=="0"&&oldDatasMacd[type+'_down'].three.price=="0"){
        console.log("更新第二段底背离"+type);
        if(dif_new<oldDatasMacd[type+'_down'].one.dif){//dif比第一次更下面，违背背离，第一项会自动开启
          oldDatasMacd[type+'_down'].two.dif="0";
          oldDatasMacd[type+'_down'].two.price="0";
          oldDatasMacd[type+'_down'].three.dif="0";
          oldDatasMacd[type+'_down'].three.price="0";          
          data_shangZhang.update_fileDatas_macd('beili_all',oldDatasMacd,type);//更新two
          staticData.sendDatas[type+'_beili'].oneDown="2";//一次底背离关闭
          staticData.sendDatas[type+'_beili'].twoDown="2";//二次底背离关闭            
          return
        }else if(+(oldDatasMacd[type+'_down'].two.price)>lowPrice){//在更下面时，更新
          oldDatasMacd[type+'_down'].two.dif=dif_new;
          oldDatasMacd[type+'_down'].two.price=lowPrice;
          data_shangZhang.update_fileDatas_macd('beili_all',oldDatasMacd,type);//更新two
        };
        //检查一次背离，这个位置应该发送短信，但是为了其他考虑，设置背离状态，进入金叉发送
        if(oldDatasMacd[type+'_down'].two.dif>oldDatasMacd[type+'_down'].one.dif&&oldDatasMacd[type+'_down'].two.price<oldDatasMacd[type+'_down'].one.price){
          staticData.sendDatas[type+'_beili'].oneDown="1";//一次底背离开启
        }        
        return;        
      }
      // 开启第三段，第一项存在，且是金叉，且第二次价格小于第一次，第二项存在，第三项不存在,开启第三段
      if(dif_new>dea_new&&oldDatasMacd[type+'_down'].two.price<oldDatasMacd[type+'_down'].one.price&&oldDatasMacd[type+'_down'].one.dif!="0"&&oldDatasMacd[type+'_down'].one.price!="0"&&oldDatasMacd[type+'_down'].two.dif!="0"&&oldDatasMacd[type+'_down'].two.price!="0"&&oldDatasMacd[type+'_down'].three.dif=="0"&&oldDatasMacd[type+'_down'].three.price=="0"){
        console.log("开启第三段底背离"+type);
        oldDatasMacd[type+'_down'].three.dif=dif_new;
        oldDatasMacd[type+'_down'].three.price=lowPrice;
        data_shangZhang.update_fileDatas_macd('beili_all',oldDatasMacd,type);//更新three
        return;    
      }
      //更新第三段，第一项存在，第二项存在，且是死叉，第三项存在
      if(dif_new<dea_new&&oldDatasMacd[type+'_down'].one.dif!="0"&&oldDatasMacd[type+'_down'].one.price!="0"&&oldDatasMacd[type+'_down'].two.dif!="0"&&oldDatasMacd[type+'_down'].two.price!="0"&&oldDatasMacd[type+'_down'].three.dif!="0"&&oldDatasMacd[type+'_down'].three.price!="0"){
        console.log("更新第三段底背离"+type);
        if(dif_new<oldDatasMacd[type+'_down'].two.dif){//dif比第二次更下面，违背背离，第一项会自动开启
          oldDatasMacd[type+'_down'].two.dif="0";
          oldDatasMacd[type+'_down'].two.price="0";
          oldDatasMacd[type+'_down'].three.dif="0";
          oldDatasMacd[type+'_down'].three.price="0";     
          staticData.sendDatas[type+'_beili'].oneDown="2";//一次底背离关闭
          staticData.sendDatas[type+'_beili'].twoDown="2";//二次底背离关闭     
          data_shangZhang.update_fileDatas_macd('beili_all',oldDatasMacd,type);//更新two three
          return
        }else if(+(oldDatasMacd[type+'_down'].three.price)>lowPrice){//在更下面时，更新
          oldDatasMacd[type+'_down'].three.dif=dif_new;
          oldDatasMacd[type+'_down'].three.price=lowPrice;
          data_shangZhang.update_fileDatas_macd('beili_all',oldDatasMacd,type);//更新three
        };
        //检查一次背离，这个位置应该发送短信，但是为了其他考虑，设置背离状态，进入金叉发送
        if(oldDatasMacd[type+'_down'].three.dif>oldDatasMacd[type+'_down'].two.dif&&oldDatasMacd[type+'_down'].three.price<oldDatasMacd[type+'_down'].two.price){
          staticData.sendDatas[type+'_beili'].twoDown="1";//二次底背离开启
        }
      }
    }
    // console.log(dif_new<0&&dea_new<0)
    if(dif_new>0&&dea_new>0){//顶背离，底背离为0
      for (const key in oldDatasMacd[type+'_down']) {//one two three全部等于0，先不更新，需要更新再更新
        oldDatasMacd[type+'_down'][key].dif="0";
        oldDatasMacd[type+'_down'][key].price="0";
        staticData.sendDatas[type+'_beili'].oneDown="2";//一次底背离关闭
        staticData.sendDatas[type+'_beili'].twoDown="2";//二次底背离关闭          
      }
      // 开启第一段
      if(oldDatasMacd[type+'_up'].one.dif=="0"&&oldDatasMacd[type+'_up'].one.price=="0"){//都等于0
        console.log("开启第一段顶背离"+type);
        oldDatasMacd[type+'_up'].two.dif="0";
        oldDatasMacd[type+'_up'].two.price="0";
        oldDatasMacd[type+'_up'].three.dif="0";
        oldDatasMacd[type+'_up'].three.price="0";//归0  two  three
        oldDatasMacd[type+'_up'].one.dif=dif_new;
        oldDatasMacd[type+'_up'].one.price=highprice;//第一次赋值
        data_shangZhang.update_fileDatas_macd('beili_all',oldDatasMacd,type);//更新one
        return;        
      }
      //更新第一段，第一项存在，且是金叉，第二项不存在，第三项不存在
      if(dif_new>dea_new&&oldDatasMacd[type+'_up'].one.dif!="0"&&oldDatasMacd[type+'_up'].one.price!="0"&&oldDatasMacd[type+'_up'].two.dif=="0"&&oldDatasMacd[type+'_up'].two.price=="0"&&oldDatasMacd[type+'_up'].three.dif=="0"&&oldDatasMacd[type+'_up'].three.price=="0"){
        console.log("更新第一段顶背离"+type);
        if(oldDatasMacd[type+'_up'].one.dif<dif_new){//在更上面时，更新
          oldDatasMacd[type+'_up'].one.dif=dif_new;
          oldDatasMacd[type+'_up'].one.price=highprice;
          data_shangZhang.update_fileDatas_macd('beili_all',oldDatasMacd,type);//更新one
        }
        return;        
      }
      // 开启第二段，第一项存在，且是死叉dif>dea，第二项不存在，第三项不存在,开启第二段
      if(dif_new<dea_new&&oldDatasMacd[type+'_up'].one.dif!="0"&&oldDatasMacd[type+'_up'].one.price!="0"&&oldDatasMacd[type+'_up'].two.dif=="0"&&oldDatasMacd[type+'_up'].two.price=="0"&&oldDatasMacd[type+'_up'].three.dif=="0"&&oldDatasMacd[type+'_up'].three.price=="0"){          
        console.log("开启第二段顶背离"+type);
        oldDatasMacd[type+'_up'].two.dif=dif_new;
        oldDatasMacd[type+'_up'].two.price=highprice;
        data_shangZhang.update_fileDatas_macd('beili_all',oldDatasMacd,type);//更新two
        return;      
      }
      //更新第二段，第一项存在，第二项存在，且是金叉，第三项不存在
      if(dif_new>dea_new&&oldDatasMacd[type+'_up'].one.dif!="0"&&oldDatasMacd[type+'_up'].one.price!="0"&&oldDatasMacd[type+'_up'].two.dif!="0"&&oldDatasMacd[type+'_up'].two.price!="0"&&oldDatasMacd[type+'_up'].three.dif=="0"&&oldDatasMacd[type+'_up'].three.price=="0"){
        console.log("更新第二段顶背离"+type);
        if(dif_new<oldDatasMacd[type+'_up'].one.dif){//dif比第一次更下面，违背背离，第一项会自动开启
          oldDatasMacd[type+'_up'].two.dif="0";
          oldDatasMacd[type+'_up'].two.price="0";
          oldDatasMacd[type+'_up'].three.dif="0";
          oldDatasMacd[type+'_up'].three.price="0";          
          data_shangZhang.update_fileDatas_macd('beili_all',oldDatasMacd,type);//更新two
          staticData.sendDatas[type+'_beili'].oneUp="2";//一次顶背离还原
          staticData.sendDatas[type+'_beili'].twoUp="2";//二次背背离还原           
          return
        }else if(+(oldDatasMacd[type+'_up'].two.price)<highprice){//在更上面时，更新
          oldDatasMacd[type+'_up'].two.dif=dif_new;
          oldDatasMacd[type+'_up'].two.price=highprice;
          data_shangZhang.update_fileDatas_macd('beili_all',oldDatasMacd,type);//更新two
        };
        //检查一次背离，这个位置应该发送短信，但是为了其他考虑，设置背离状态，进入金叉发送
        if(oldDatasMacd[type+'_up'].two.dif<oldDatasMacd[type+'_up'].one.dif&&oldDatasMacd[type+'_up'].two.price>oldDatasMacd[type+'_up'].one.price){
          staticData.sendDatas[type+'_beili'].oneUp="1";//一次背离开启
        }        
        return;        
      }
      // 开启第三段，第一项存在，且是死叉，且第二次价格大于第一次，第二项存在，第三项不存在,开启第三段
      if(dif_new<dea_new&&oldDatasMacd[type+'_up'].two.price>oldDatasMacd[type+'_up'].one.price&&oldDatasMacd[type+'_up'].one.dif!="0"&&oldDatasMacd[type+'_up'].one.price!="0"&&oldDatasMacd[type+'_up'].two.dif!="0"&&oldDatasMacd[type+'_up'].two.price!="0"&&oldDatasMacd[type+'_up'].three.dif=="0"&&oldDatasMacd[type+'_up'].three.price=="0"){
        console.log("开启第三段顶背离"+type);
        oldDatasMacd[type+'_up'].three.dif=dif_new;
        oldDatasMacd[type+'_up'].three.price=highprice;
        data_shangZhang.update_fileDatas_macd('beili_all',oldDatasMacd,type);//更新three
        return;    
      }
      //更新第三段，第一项存在，第二项存在，且是金叉，第三项存在
      if(dif_new>dea_new&&oldDatasMacd[type+'_up'].one.dif!="0"&&oldDatasMacd[type+'_up'].one.price!="0"&&oldDatasMacd[type+'_up'].two.dif!="0"&&oldDatasMacd[type+'_up'].two.price!="0"&&oldDatasMacd[type+'_up'].three.dif!="0"&&oldDatasMacd[type+'_up'].three.price!="0"){
        console.log("更新第三段顶背离"+type);
        if(dif_new>oldDatasMacd[type+'_up'].two.dif){//dif比第二次更下面，违背背离，第一项会自动开启
          oldDatasMacd[type+'_up'].two.dif="0";
          oldDatasMacd[type+'_up'].two.price="0";
          oldDatasMacd[type+'_up'].three.dif="0";
          oldDatasMacd[type+'_up'].three.price="0";     
          staticData.sendDatas[type+'_beili'].oneUp="2";//一次顶背离关闭
          staticData.sendDatas[type+'_beili'].twoUp="2";//二次顶背离关闭     
          data_shangZhang.update_fileDatas_macd('beili_all',oldDatasMacd,type);//更新two three
          return
        }else if(+(oldDatasMacd[type+'_up'].three.price)<highprice){//在更上面时，更新
          oldDatasMacd[type+'_up'].three.dif=dif_new;
          oldDatasMacd[type+'_up'].three.price=highprice;
          data_shangZhang.update_fileDatas_macd('beili_all',oldDatasMacd,type);//更新three
        };
        //检查一次背离，这个位置应该发送短信，但是为了其他考虑，设置背离状态，进入死叉发送
        if(oldDatasMacd[type+'_up'].three.dif<oldDatasMacd[type+'_up'].two.dif&&oldDatasMacd[type+'_up'].three.price>oldDatasMacd[type+'_up'].two.price){
          staticData.sendDatas[type+'_beili'].twoUp="1";//二次顶背离开启
        }
      }
    }
  },  
  //只有5分开启自动，计算macd5分 ,macd全体注意更新macd文件需要延迟，因为获取kline后只调用一次，必须延迟保证成功
  async fn_contMacd5(parseDatas,type){
    // console.log(type)
    let canGo=true;//防止为更新完就获取数据
    if(!canGo||!staticData.line30_btc15){return};//用15分数据没事，因为先调用了15分数据
    //静态数据 _______________________________________________________________
    let fileDatas= await data_shangZhang.get_smsgFileDatas('macd');
    if(fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
    let oldDatasMacd=JSON.parse(fileDatas); 
    let deaQian=+oldDatasMacd.btc5.deaQian;   //记录前一个的dea
    let difQian=+oldDatasMacd.btc5.difQian;  //记录前一个的dif
    let cQian=+oldDatasMacd.btc5.cQian;  //记录前一个的收盘close
    let difShang=+oldDatasMacd.btc5.difShang; //记录前前一个的dif
    // ————————————————————————————————————————————————————————————————
    let yShang=cQian+difShang*297/28-difQian*351/28;
    let xShang=difShang+yShang;
    let yQian=yShang*25/27+cQian*2/27;
    let xQian=xShang*11/13+cQian*2/13;

    //且距离上次更新不能少于5分钟
    let getTime_update=new Date().getTime();
    let interTime100_update=3*60*1000;
    let timeAllow100_update=getTime_update-staticData.macdTime5_update;      
    
    if(type=="更新5分macd"&&oldDatasMacd.btc5.time!==parseDatas[0]&&timeAllow100_update>interTime100_update){//不是常规,获取直接更新，不用查看是不是要发短信
      //macd出错
      if(parseDatas[0]-oldDatasMacd.btc5.time>17*60*1000){
        console.log("macd5需要手动更新")
        // Api.sendMsg("mac5f").then(data => { 
        //   console.log(data)
        // }); 
        data_shangZhang.re_writeLog('macd5需要手动更新',`macd5需要手动更新`);                
      }
      canGo=false;
      staticData.macdTime5_update=getTime_update;
      let c_new=parseDatas[4];
      let y_new=yQian*25/27+c_new*2/27;
      let x_new=xQian*11/13+c_new*2/13;
      let dif_new=x_new-y_new;
      let dea_new=deaQian*8/10+dif_new*2/10; 
      let difShangSave=oldDatasMacd.btc5.difQian;
      // 更新数据
      oldDatasMacd.btc5.difShang=difShangSave;//前前的dif,换为上次的
      oldDatasMacd.btc5.cQian=+parseDatas[4];
      oldDatasMacd.btc5.deaQian=dea_new;
      oldDatasMacd.btc5.difQian=dif_new;
      oldDatasMacd.btc5.time=parseDatas[0];//上跟开盘时间减去这个大于31分未更新则报错
      fs.writeFile(`date/smsg/macd.txt`, JSON.stringify(oldDatasMacd), function(err) {
        canGo=true;
        if (err) {
          throw err;
        }
      });         
    }
    
    if(type=="常规触发"){
      let c_new=parseDatas.k.c;
      let y_new=yQian*25/27+c_new*2/27;
      let x_new=xQian*11/13+c_new*2/13;
      let dif_new=x_new-y_new;
      let dea_new=deaQian*8/10+dif_new*2/10; 

      let fileif_send_msg= await data_shangZhang.get_smsgFileDatas('if_send_msg');
      if(fileif_send_msg=='文件不在'){ console.log("错误文件暂停位置");return } ;
      let if_send_msgJson=JSON.parse(fileif_send_msg); 

      if(dif_new-dea_new>0&&if_send_msgJson.upMacd_5m=="1"){//符合金叉，但还要验证能不能发送,为了前端显示不一起写if了
        if_send_msgJson.upMacd_5m="2";
        if_send_msgJson.downMacd_5m="1";
        let fileDatas= await data_shangZhang.update_fileDatas_ifSend(if_send_msgJson);//直接更新文件
        // let getTime=new Date().getTime();
        // let interTime100=20*60*1000;//4跟
        // let timeAllow100=getTime-staticData.macdTime5D;  

        if(staticData.macdTime5D!=parseDatas.k.t&&dif_new<0&&dea_new<0){
            staticData.macdTime5D=parseDatas.k.t;
            // staticData.macdTime5D=getTime;
            staticData.sendDatas.pubilcMsg=`【彬彬科技】macd5分多，时间：${public_gg.get_time()}`;
            staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】macd5分多，时间：${public_gg.get_time()}`;
            data_shangZhang.fn_oclockAppH5();
            data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"macd5分多");
            setTimeout(()=>{
              staticData.sendDatas.pubilcMsg="";
            },10*1000);   
            Api.sendMsg("ma5D").then(data => { 
              console.log(data)
            });                      
        }

      }

      if(dea_new-dif_new>0&&if_send_msgJson.downMacd_5m=="1"){
        if_send_msgJson.upMacd_5m="1";
        if_send_msgJson.downMacd_5m="2";
        let fileDatas= await data_shangZhang.update_fileDatas_ifSend(if_send_msgJson);//更新文件
        // let getTime=new Date().getTime();
        // let interTime100=20*60*1000;//4跟
        // let timeAllow100=getTime-staticData.macdTime5D;             
        if(staticData.macdTime5D!=parseDatas.k.t&&dif_new>0&&dea_new>0){
          staticData.macdTime5D=parseDatas.k.t;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】macd5分空，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】macd5分空，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"macd5分空");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);     
          Api.sendMsg("ma5K").then(data => { 
            console.log(data)
          });   
        }         
      }      
    }

  },
  async fn_contMacd15eth(parseDatas,type){
    let canGo=true;//防止为更新完就获取数据
    if(!canGo||!staticData.line30_btc15){return};//用15分数据没事，因为先调用了15分数据
    //静态数据 _______________________________________________________________
    let fileDatas= await data_shangZhang.get_smsgFileDatas('macd');
    if(fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
    let oldDatasMacd=JSON.parse(fileDatas); 
    let deaQian=+oldDatasMacd.btc15eth.deaQian;   //记录前一个的dea
    let difQian=+oldDatasMacd.btc15eth.difQian;  //记录前一个的dif
    let cQian=+oldDatasMacd.btc15eth.cQian;  //记录前一个的收盘close
    let difShang=+oldDatasMacd.btc15eth.difShang; //记录前前一个的dif
    // ————————————————————————————————————————————————————————————————
    let yShang=cQian+difShang*297/28-difQian*351/28;
    let xShang=difShang+yShang;
    let yQian=yShang*25/27+cQian*2/27;
    let xQian=xShang*11/13+cQian*2/13;

    //且距离上次更新不能少于3分钟
    let getTime_update=new Date().getTime();
    let interTime100_update=3*60*1000;
    let timeAllow100_update=getTime_update-staticData.macdTime15eth_update;      
    
    if(type=="更新15分macdeth"&&oldDatasMacd.btc15eth.time!==parseDatas[0]&&timeAllow100_update>interTime100_update){//不是常规,获取直接更新，不用查看是不是要发短信
      //macd出错
      if(parseDatas[0]-oldDatasMacd.btc15eth.time>7*60*1000){
        // console.log("macd5eth需要手动更新")
        // Api.sendMsg("maethf").then(data => { 
        //   console.log(data)
        // }); 
        // data_shangZhang.re_writeLog('macd5eth需要手动更新',`macd5eth需要手动更新`);                
      }
      canGo=false;
      staticData.macdTime15eth_update=getTime_update;
      let c_new=parseDatas[4];
      let y_new=yQian*25/27+c_new*2/27;
      let x_new=xQian*11/13+c_new*2/13;
      let dif_new=x_new-y_new;
      let dea_new=deaQian*8/10+dif_new*2/10; 
      let difShangSave=oldDatasMacd.btc15eth.difQian;
      // 更新数据
      oldDatasMacd.btc15eth.difShang=difShangSave;//前前的dif,换为上次的
      oldDatasMacd.btc15eth.cQian=+parseDatas[4];
      oldDatasMacd.btc15eth.deaQian=dea_new;
      oldDatasMacd.btc15eth.difQian=dif_new;
      oldDatasMacd.btc15eth.time=parseDatas[0];//上跟开盘时间减去这个大于7分未更新则报错     
      fs.writeFile(`date/smsg/macd.txt`, JSON.stringify(oldDatasMacd), function(err) {
        canGo=true;
        if (err) {
          throw err;
        }
      }); 

      //金死叉还原，每5分钟检查是否还是上一个金死叉状态，如果不是则全部还原。
      if(dif_new-dea_new>0){//上一根符合金叉
        if(!staticData.sendDatas.eth5macdObj.jsStatus||staticData.sendDatas.eth5macdObj.jsStatus=='死叉'){
          staticData.sendDatas.eth5macdObj.jsStatus='金叉';
          staticData.sendDatas.eth5macdObj.ballColor='';
          staticData.sendDatas.eth5macdObj.fanZhuan='';
          staticData.sendDatas.eth5macdObj.fanZhuan2='';
        }
      }
      if(dif_new-dea_new<0){//上一根符合死叉
        if(!staticData.sendDatas.eth5macdObj.jsStatus||staticData.sendDatas.eth5macdObj.jsStatus=='金叉'){
          staticData.sendDatas.eth5macdObj.jsStatus='死叉';
          staticData.sendDatas.eth5macdObj.ballColor='';
          staticData.sendDatas.eth5macdObj.fanZhuan='';
          staticData.sendDatas.eth5macdObj.fanZhuan2='';
        }    
      } 
      // 如果状态一致则返回，下面不可以加其他东西，否则return就回不来了,顺便检测一下上一根是否符合短线
      if(staticData.sendDatas.eth5macdObj.jsStatus=='金叉'){
        //金叉检查绿色
        if(staticData.countDatasArrEth15m[1][4]<staticData.countDatasArrEth15m[1][1]){
          staticData.sendDatas.eth5macdObj.lvhong='金叉绿色多';
          setTimeout(()=>{//10秒后还原
            staticData.sendDatas.eth5macdObj.lvhong="";
          },10*1000);           
        }
        //下单控制
        // if(staticData.sendDatas.eth5macdObj.oneSuccess&&staticData.sendDatas.eth5macdObj.oneSuccess!='金叉'){
        //   staticData.sendDatas.eth5macdObj.oneSuccess='';
        // }
        return;
      }
      if(staticData.sendDatas.eth5macdObj.jsStatus=='死叉'){
        // 死叉检查红色
        if(staticData.countDatasArrEth15m[1][4]>staticData.countDatasArrEth15m[1][1]){
          staticData.sendDatas.eth5macdObj.lvhong='死叉红色空';
          setTimeout(()=>{//10秒后还原
            staticData.sendDatas.eth5macdObj.lvhong="";
          },10*1000);           
        }
        //下单控制
        // if(staticData.sendDatas.eth5macdObj.oneSuccess&&staticData.sendDatas.eth5macdObj.oneSuccess!='死叉'){
        //   staticData.sendDatas.eth5macdObj.oneSuccess='';
        // }        
        return;
      }            
      
    }

    
    if(type=="常规触发"){
      let c_new=parseDatas.k.c;
      let y_new=yQian*25/27+c_new*2/27;
      let x_new=xQian*11/13+c_new*2/13;
      let dif_new=x_new-y_new;
      let dea_new=deaQian*8/10+dif_new*2/10; 

      let fileif_send_msg= await data_shangZhang.get_smsgFileDatas('if_send_msg');
      if(fileif_send_msg=='文件不在'){ console.log("错误文件暂停位置");return } ;
      let if_send_msgJson=JSON.parse(fileif_send_msg); 
      // &&if_send_msgJson.upMacd_15meth=="1"
      if(dif_new-dea_new>0&&if_send_msgJson.upMacd_15meth=="1"){//符合金叉，但还要验证能不能发送,为了前端显示不一起写if了 
        if(staticData.macdTime15Deth!=parseDatas.k.t){
          if_send_msgJson.upMacd_15meth="2";
          if_send_msgJson.downMacd_15meth="1";
          let fileDatas= await data_shangZhang.update_fileDatas_ifSend(if_send_msgJson);//直接更新文件          
          //金叉范围看蓝球s
            staticData.macdTime15Deth=parseDatas.k.t;
            staticData.sendDatas.pubilcMsg=`【彬彬科技】eth多，时间：${public_gg.get_time()}`;
            staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】eth多，时间：${public_gg.get_time()}`;
            data_shangZhang.fn_oclockAppH5();
            //data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.ethPrice.toString(),"eth分多");
            setTimeout(()=>{
              staticData.sendDatas.pubilcMsg="";
            },10*1000);   
            // Api.sendMsg("ma15D",[13025407962]).then(data => { 
            //   console.log(data)
            // });                   
        }

      }
      // &&if_send_msgJson.downMacd_15meth=="1"
      if(dea_new-dif_new>0&&if_send_msgJson.downMacd_15meth=="1"){            
        if(staticData.macdTime15Deth!=parseDatas.k.t){
          if_send_msgJson.upMacd_15meth="1";
          if_send_msgJson.downMacd_15meth="2";     
          let fileDatas= await data_shangZhang.update_fileDatas_ifSend(if_send_msgJson);//直接更新文件          s     
          // 金叉范围看红球
            staticData.macdTime15Deth=parseDatas.k.t;
            staticData.sendDatas.pubilcMsg=`【彬彬科技】eth空，时间：${public_gg.get_time()}`;
            staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】eth空，时间：${public_gg.get_time()}`;
            data_shangZhang.fn_oclockAppH5();
            //data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.ethPrice.toString(),"eth空");
            setTimeout(()=>{
              staticData.sendDatas.pubilcMsg="";
            },10*1000);     
            // Api.sendMsg("ma15K",[13025407962]).then(data => { 
            //   console.log(data)
            // });              

        }         
      }      
    }

  },
  //kdj方案
  async fn_contKdj5(parseDatas,arrList){

  },
  async fn_contMacd15(parseDatas,type){
    let canGo=true;//防止为更新完就获取数据
    if(!canGo||!staticData.line30_btc15){return};
    //静态数据 _______________________________________________________________
    let fileDatas= await data_shangZhang.get_smsgFileDatas('macd');
    if(fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
    let oldDatasMacd=JSON.parse(fileDatas); 
    let deaQian=+oldDatasMacd.btc15.deaQian;   //记录前一个的dea
    let difQian=+oldDatasMacd.btc15.difQian;  //记录前一个的dif
    let cQian=+oldDatasMacd.btc15.cQian;  //记录前一个的收盘close
    let difShang=+oldDatasMacd.btc15.difShang; //记录前前一个的dif
    // ————————————————————————————————————————————————————————————————
    let yShang=cQian+difShang*297/28-difQian*351/28;
    let xShang=difShang+yShang;
    let yQian=yShang*25/27+cQian*2/27;
    let xQian=xShang*11/13+cQian*2/13;

    //且距离上次更新不能少于5分钟
    let getTime_update=new Date().getTime();
    let interTime100_update=5*60*1000;
    let timeAllow100_update=getTime_update-staticData.macdTime15_update;  
    
    if(type=="更新15分macd"&&oldDatasMacd.btc15.time!==parseDatas[0]&&timeAllow100_update>interTime100_update){//不是常规,获取直接更新，不用查看是不是要发短信
      //macd出错
      if(parseDatas[0]-oldDatasMacd.btc15.time>17*60*1000){
        console.log("macd15需要手动更新")
        // Api.sendMsg("mac15f").then(data => { 
        //   console.log(data)
        // }); 
        data_shangZhang.re_writeLog('macd15需要手动更新',`macd15需要手动更新`);                 
      }
      canGo=false;
      staticData.macdTime15_update=getTime_update;
      let c_new=parseDatas[4];
      let y_new=yQian*25/27+c_new*2/27;
      let x_new=xQian*11/13+c_new*2/13;
      let dif_new=x_new-y_new;
      let dea_new=deaQian*8/10+dif_new*2/10; 
      let difShangSave=oldDatasMacd.btc15.difQian;
      // 更新数据
      oldDatasMacd.btc15.difShang=difShangSave;//前前的dif,换为上次的
      oldDatasMacd.btc15.cQian=+parseDatas[4];
      oldDatasMacd.btc15.deaQian=dea_new;
      oldDatasMacd.btc15.difQian=dif_new;
      oldDatasMacd.btc15.time=parseDatas[0];//上跟开盘时间减去这个大于31分未更新则报错

      // data_shangZhang.fn_macdBeiLi(dif_new,dea_new,"btc15",parseDatas[2],parseDatas[3]);//上一跟
      fs.writeFile(`date/smsg/macd.txt`, JSON.stringify(oldDatasMacd), function(err) {
        canGo=true;
        if (err) {
          throw err;
        }
      });         
    }
    if(type=="常规触发"){
      let c_new=parseDatas.k.c;
      let y_new=yQian*25/27+c_new*2/27;
      let x_new=xQian*11/13+c_new*2/13;
      let dif_new=x_new-y_new;
      let dea_new=deaQian*8/10+dif_new*2/10; 

      staticData.sendDatas.macdSendObj.h15=dif_new-dea_new;//传送检查
      if(dif_new-dea_new>3){//符合金叉，但还要验证能不能发送,为了前端显示不一起写if了
        let fileif_send_msg= await data_shangZhang.get_smsgFileDatas('if_send_msg');
        if(fileif_send_msg=='文件不在'){ console.log("错误文件暂停位置");return } ;
        let if_send_msgJson=JSON.parse(fileif_send_msg);  
        let cy_fileDatas= await data_shangZhang.get_smsgFileDatas('add_cy_time');
        if(cy_fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
        let cy_oldDatas=JSON.parse(cy_fileDatas);  
        let getTime=new Date().getTime();
        // let interTime100=60*60*1000;//4跟
        // let timeAllow100=getTime-staticData.macdTime15D;         
        if(staticData.macdTime15D!=parseDatas.k.t&&if_send_msgJson.upMacd_15m=="1"&&getTime-cy_oldDatas.ma_btc.timeNum>0){
          staticData.macdTime15D=parseDatas.k.t;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】macd15分多，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】macd15分多，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"macd15分多");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);
          Api.sendMsg("ma15D").then(data => { 
            console.log(data)
          });           
          
          // &&staticData.line7_btc15>staticData.line30_btc15 
          // if(dif_new>0&&dea_new>0){//金叉，大于0，且730在上 
          //   if(if_send_msgJson.macd15AllOn=='1'){//打开全
          //     Api.sendMsg("ma15SD").then(data => { 
          //       console.log(data)
          //     });  
          //   }            
          // }else{
          //   Api.sendMsg("ma15D").then(data => { 
          //     console.log(data)
          //   }); 
          // };
          // 开启死叉 15分默认不更新  
          // if_send_msgJson.upMacd_15m="2" ;
          // if_send_msgJson.downMacd_15m="1";
          // data_shangZhang.update_fileDatas('if_send_msg',if_send_msgJson);//更新文件
        }

      }

      if(dea_new-dif_new>3){
        let fileif_send_msg= await data_shangZhang.get_smsgFileDatas('if_send_msg');
        if(fileif_send_msg=='文件不在'){ console.log("错误文件暂停位置");return } ;
        let if_send_msgJson=JSON.parse(fileif_send_msg);  
        let cy_fileDatas= await data_shangZhang.get_smsgFileDatas('add_cy_time');
        if(cy_fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
        let cy_oldDatas=JSON.parse(cy_fileDatas);  
        let getTime=new Date().getTime();
        // let interTime100=60*60*1000;//4跟
        // let timeAllow100=getTime-staticData.macdTime15D;         
        if(staticData.macdTime15D!=parseDatas.k.t&&if_send_msgJson.downMacd_15m=="1"&&getTime-cy_oldDatas.ma_btc.timeNum>0){
          staticData.macdTime15D=parseDatas.k.t;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】macd15分空，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】macd15分空，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"macd15分空");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000); 
          
          Api.sendMsg("ma15K").then(data => { 
            console.log(data)
          });           

          // &&staticData.line7_btc15<staticData.line30_btc15
          // if(dif_new<0&&dea_new<0){//死叉，大于0，且730在上    
          //   if(if_send_msgJson.macd15AllOn=='1'){//打开全
          //     Api.sendMsg("ma15SK").then(data => { 
          //       console.log(data)
          //     });  
          //   }
          // }else{
          //     Api.sendMsg("ma15K").then(data => { 
          //       console.log(data)
          //     }); 
          // };
          // 开启金叉   15分默认不更新  
          // if_send_msgJson.upMacd_15m="1" ;
          // if_send_msgJson.downMacd_15m="2";
          // data_shangZhang.update_fileDatas('if_send_msg',if_send_msgJson);//更新文件          
        }         
      }      
    }

  },
  async fn_contMacd1h(parseDatas,type){
    let canGo=true;//防止为更新完就获取数据
    if(!canGo||!staticData.line30_btc1h){return};
    //静态数据 _______________________________________________________________
    let fileDatas= await data_shangZhang.get_smsgFileDatas('macd');
    if(fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
    let oldDatasMacd=JSON.parse(fileDatas); 
    let deaQian=+oldDatasMacd.btc1h.deaQian;   //记录前一个的dea
    let difQian=+oldDatasMacd.btc1h.difQian;  //记录前一个的dif
    let cQian=+oldDatasMacd.btc1h.cQian;  //记录前一个的收盘close
    let difShang=+oldDatasMacd.btc1h.difShang; //记录前前一个的dif
    // ————————————————————————————————————————————————————————————————
    let yShang=cQian+difShang*297/28-difQian*351/28;
    let xShang=difShang+yShang;
    let yQian=yShang*25/27+cQian*2/27;
    let xQian=xShang*11/13+cQian*2/13;

    //且距离上次更新不能少于5分钟
    let getTime_update=new Date().getTime();
    let interTime100_update=5*60*1000;
    let timeAllow100_update=getTime_update-staticData.macdTime1h_update;  

    
    
    if(type=="更新1hmacd"&&oldDatasMacd.btc1h.time!==parseDatas[0]&&timeAllow100_update>interTime100_update){//时间不等，且距离上次更新不能少于5分钟
      //macd出错
      if(parseDatas[0]-oldDatasMacd.btc1h.time>65*60*1000){
        console.log("macd1h需要手动更新");
        data_shangZhang.re_writeLog("macd1小时故障时间："+oldDatasMacd.btc1h.time,"macd1小时故障");
        Api.sendMsg("mac1hf").then(data => { 
          console.log(data)
        });   
        data_shangZhang.re_writeLog('macd1h需要手动更新',`macd1h需要手动更新`);               
      }
      canGo=false;
      staticData.macdTime1h_update=getTime_update;
      let c_new=parseDatas[4];
      let y_new=yQian*25/27+c_new*2/27;
      let x_new=xQian*11/13+c_new*2/13;
      let dif_new=x_new-y_new;
      let dea_new=deaQian*8/10+dif_new*2/10; 
      let difShangSave=oldDatasMacd.btc1h.difQian;
      // 更新数据
      oldDatasMacd.btc1h.difShang=difShangSave;//前前的dif,换为上次的
      oldDatasMacd.btc1h.cQian=+parseDatas[4];
      oldDatasMacd.btc1h.deaQian=dea_new;
      oldDatasMacd.btc1h.difQian=dif_new;
      oldDatasMacd.btc1h.time=parseDatas[0];//上跟开盘时间减去这个大于31分未更新则报错
      setTimeout(() => {
        // data_shangZhang.fn_macdBeiLi(dif_new,dea_new,"btc1h",parseDatas[2],parseDatas[3]);//上一跟
      }, 5000);
      fs.writeFile(`date/smsg/macd.txt`, JSON.stringify(oldDatasMacd), function(err) {
        canGo=true;
        if (err) {
          throw err;
        }
      });         
    }
    
    if(type=="常规触发"){
      let c_new=parseDatas.k.c;
      let y_new=yQian*25/27+c_new*2/27;
      let x_new=xQian*11/13+c_new*2/13;
      let dif_new=x_new-y_new;
      let dea_new=deaQian*8/10+dif_new*2/10; 
      staticData.sendDatas.macdSendObj.h1=dif_new-dea_new;//传送检查
      
      if(dif_new-dea_new>5){
        let fileif_send_msg= await data_shangZhang.get_smsgFileDatas('if_send_msg');
        if(fileif_send_msg=='文件不在'){ console.log("错误文件暂停位置");return } ;
        let if_send_msgJson=JSON.parse(fileif_send_msg);  
        let cy_fileDatas= await data_shangZhang.get_smsgFileDatas('add_cy_time');
        if(cy_fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
        let cy_oldDatas=JSON.parse(cy_fileDatas);  
        let getTime=new Date().getTime();        
        // let interTime100=3*60*60*1000;//4跟
        // let timeAllow100=getTime-staticData.macdTime1hD;         
        if(staticData.macdTime1hD!=parseDatas.k.t&&if_send_msgJson.upMacd_1h=="1"&&getTime-cy_oldDatas.ma_btc1h.timeNum>0){
          staticData.macdTime1hD=parseDatas.k.t;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】macd1h多，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】macd1h多，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"macd1h多");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);  
          Api.sendMsg("ma1hD",[13025407962]).then(data => { 
            console.log(data)
          })      
          // 开启死叉   
          if_send_msgJson.upMacd_1h="2" ;
          if_send_msgJson.downMacd_1h="1";
          data_shangZhang.update_fileDatas('if_send_msg',if_send_msgJson);//更新文件                 
        }         
      }

      if(dea_new-dif_new>5){
        let fileif_send_msg= await data_shangZhang.get_smsgFileDatas('if_send_msg');
        if(fileif_send_msg=='文件不在'){ console.log("错误文件暂停位置");return } ;
        let if_send_msgJson=JSON.parse(fileif_send_msg);  
        let cy_fileDatas= await data_shangZhang.get_smsgFileDatas('add_cy_time');
        if(cy_fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
        let cy_oldDatas=JSON.parse(cy_fileDatas);  
        let getTime=new Date().getTime();        
        // let interTime100=3*60*60*1000;//4跟
        // let timeAllow100=getTime-staticData.macdTime1hD;         
        if(staticData.macdTime1hD!=parseDatas.k.t&&if_send_msgJson.downMacd_1h=="1"&&getTime-cy_oldDatas.ma_btc1h.timeNum>0){
          staticData.macdTime1hD=parseDatas.k.t;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】macd1h空，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】macd1h空，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"macd1h空");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);    
          Api.sendMsg("ma1hK",[13025407962]).then(data => { 
            console.log(data)
          });
          // 开启金叉   
          if_send_msgJson.upMacd_1h="1" ;
          if_send_msgJson.downMacd_1h="2";
          data_shangZhang.update_fileDatas('if_send_msg',if_send_msgJson);//更新文件                 
        }         
      }      
    }

  },  
  async fn_contMacd4h(parseDatas,type){
    let canGo=true;//防止为更新完就获取数据
    if(!canGo||!staticData.line30_btc4h){return};
    //静态数据 _______________________________________________________________
    let fileDatas= await data_shangZhang.get_smsgFileDatas('macd');
    if(fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
    let oldDatasMacd=JSON.parse(fileDatas); 
    let deaQian=+oldDatasMacd.btc4h.deaQian;   //记录前一个的dea
    let difQian=+oldDatasMacd.btc4h.difQian;  //记录前一个的dif
    let cQian=+oldDatasMacd.btc4h.cQian;  //记录前一个的收盘close
    let difShang=+oldDatasMacd.btc4h.difShang; //记录前前一个的dif
    // ————————————————————————————————————————————————————————————————
    let yShang=cQian+difShang*297/28-difQian*351/28;
    let xShang=difShang+yShang;
    let yQian=yShang*25/27+cQian*2/27;
    let xQian=xShang*11/13+cQian*2/13;

    //且距离上次更新不能少于5分钟
    let getTime_update=new Date().getTime();
    let interTime100_update=5*60*1000;
    let timeAllow100_update=getTime_update-staticData.macdTime4h_update;  

    

    if(type=="更新4hmacd"&&oldDatasMacd.btc4h.time!==parseDatas[0]&&timeAllow100_update>interTime100_update){//时间不等，且距离上次更新不能少于5分钟
      //macd出错
      if(parseDatas[0]-oldDatasMacd.btc4h.time>245*60*1000){
        console.log("macd4h需要手动更新");
        data_shangZhang.re_writeLog("macd4小时故障时间："+oldDatasMacd.btc4h.time,"macd4小时故障");
        // Api.sendMsg("mac4hf").then(data => { 
        //   console.log(data)
        // });  
        data_shangZhang.re_writeLog('macd4h需要手动更新',`macd4h需要手动更新`);                
      }
      canGo=false;
      staticData.macdTime4h_update=getTime_update;
      let c_new=parseDatas[4];
      let y_new=yQian*25/27+c_new*2/27;
      let x_new=xQian*11/13+c_new*2/13;
      let dif_new=x_new-y_new;
      let dea_new=deaQian*8/10+dif_new*2/10; 
      let difShangSave=oldDatasMacd.btc4h.difQian;
      // 更新数据
      oldDatasMacd.btc4h.difShang=difShangSave;//前前的dif,换为上次的
      oldDatasMacd.btc4h.cQian=+parseDatas[4];
      oldDatasMacd.btc4h.deaQian=dea_new;
      oldDatasMacd.btc4h.difQian=dif_new;
      oldDatasMacd.btc4h.time=parseDatas[0];//上跟开盘时间减去这个大于31分未更新则报错
      setTimeout(() => {
        // data_shangZhang.fn_macdBeiLi(dif_new,dea_new,"btc4h",parseDatas[2],parseDatas[3]);//上一跟
      }, 10000);
      fs.writeFile(`date/smsg/macd.txt`, JSON.stringify(oldDatasMacd), function(err) {
        canGo=true;
        if (err) {
          throw err;
        }
      });         
    }
    
    if(type=="常规触发"){
      let c_new=parseDatas.k.c;
      let y_new=yQian*25/27+c_new*2/27;
      let x_new=xQian*11/13+c_new*2/13;
      let dif_new=x_new-y_new;
      let dea_new=deaQian*8/10+dif_new*2/10; 

      staticData.sendDatas.macdSendObj.h4=dif_new-dea_new;//传送检查

      if(dif_new-dea_new>10){
        let fileif_send_msg= await data_shangZhang.get_smsgFileDatas('if_send_msg');
        if(fileif_send_msg=='文件不在'){ console.log("错误文件暂停位置");return } ;
        let if_send_msgJson=JSON.parse(fileif_send_msg);  
        let cy_fileDatas= await data_shangZhang.get_smsgFileDatas('add_cy_time');
        if(cy_fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
        let cy_oldDatas=JSON.parse(cy_fileDatas);  
        let getTime=new Date().getTime();
        // let interTime100=8*60*60*1000;
        // let timeAllow100=getTime-staticData.macdTime4hD;  
        if(staticData.macdTime4hD!=parseDatas.k.t&&if_send_msgJson.upMacd_4h=="1"&&getTime-cy_oldDatas.ma_btc4h.timeNum>0){
          staticData.macdTime4hD=parseDatas.k.t;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】macd4h多，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】macd4h多，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"macd4h多");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);  
          //全部开启金叉
          Api.sendMsg("ma4hD").then(data => { 
            console.log(data)
          });              
          // if(dif_new>0&&dea_new>0){//金叉，大于0，且730在上
          // }else{
          //   Api.sendMsg("ma4hD").then(data => { 
          //     console.log(data)
          //   }); 
          // };
          // if(if_send_msgJson.macd4hAllOn=='1'){
          //   Api.sendMsg("ma4hSD").then(data => { 
          //     console.log(data)
          //   });             
          // }           
          // 开启死叉   
          // if_send_msgJson.upMacd_4h="2" ;
          // if_send_msgJson.downMacd_4h="1";
          // data_shangZhang.update_fileDatas('if_send_msg',if_send_msgJson);//更新文件                   
        }         
      }

      if(dea_new-dif_new>10){
        let fileif_send_msg= await data_shangZhang.get_smsgFileDatas('if_send_msg');
        if(fileif_send_msg=='文件不在'){ console.log("错误文件暂停位置");return } ;
        let if_send_msgJson=JSON.parse(fileif_send_msg);  
        let cy_fileDatas= await data_shangZhang.get_smsgFileDatas('add_cy_time');
        if(cy_fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
        let cy_oldDatas=JSON.parse(cy_fileDatas);  
        let getTime=new Date().getTime();
        // let interTime100=8*60*60*1000;
        // let timeAllow100=getTime-staticData.macdTime4hD;      if(timeAllow100>interTime100&&        
        if(staticData.macdTime4hD!=parseDatas.k.t&&if_send_msgJson.downMacd_4h=="1"&&getTime-cy_oldDatas.ma_btc4h.timeNum>0){
          staticData.macdTime4hD=parseDatas.k.t;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】macd4h空，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】macd4h空，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"macd4h空");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);   
          //全部开启死叉
          Api.sendMsg("ma4hK").then(data => { 
            console.log(data)
          });           
          // if(dif_new<0&&dea_new<0){//金叉，大于0，且730在上
          // }else{//if_send_msgJson.macd4hAllOn=='1'
          //   Api.sendMsg("ma4hK").then(data => { 
          //     console.log(data)
          //   }); 
          // };
          // 开启金叉   
          // if_send_msgJson.upMacd_4h="1" ;
          // if_send_msgJson.downMacd_4h="2";
          // data_shangZhang.update_fileDatas('if_send_msg',if_send_msgJson);//更新文件  
        }         
      }      
    }

  }, 

  // 开空，带止盈止损的
  async eth5_sell(quantity,zhiying,zhisun,key){  //0.01 2000  4000
    //开空
    binance.createOrder('SELL',quantity,key).then(data => {
      if (data.orderId) {
        binance.createProfit('BUY','STOP_MARKET',quantity,zhisun,key).then(data3 => {
          if (data3.orderId) {
            console.log('空单止损设置成功');
          }else{
            data_shangZhang.re_writeLog(`空单止损失败，${data3.msg}，时间：${public_gg.get_time()}`,"eth设置止损日志");
          }
        });
        setTimeout(()=>{
          binance.createProfit('BUY','TAKE_PROFIT_MARKET',quantity,zhiying,key).then(data2 => {
            if (data2.orderId) {
              console.log('空单止盈设置成功');
            }else{
              data_shangZhang.re_writeLog(`空单止盈失败，${data2.msg}，时间：${public_gg.get_time()}`,"eth设置止盈日志");
            }
          });   
        },1500);                         
      }
    }) 
  },  
  // 15分钟的eth，下单开单逻辑先关闭了
  async fn_counter_eth15m(parseDatas){
    if(!staticData.getBianArr.min15eth){
      return
    }  

    
    staticData.sendDatas.ws4h1h15mUpdate.wsm15eth.num=new Date().getTime();//释放时间戳
    staticData.sendDatas.ws4h1h15mUpdate.wsm15eth.chiaNum=public_gg.get_time();//转为中文
    //这根K线推送的开盘时间跟之前记录时间不同就去获取
    if(!staticData.countDatasTimeEth15m||parseDatas.k.t!=staticData.countDatasTimeEth15m){
      staticData.countDatasArrEth15m=[];
      staticData.getBianArr.min15eth=false;
      Api.getKlineBN_eth15m().then(async data => {
        let data2=[];
        if(data.ch&&data.data){
          data.data.forEach((item,index)=>{
            data2.push([
              item.id*1000,
              item.open,
              item.high,
              item.low,
              item.close,
            ]);
          });
        }else{
          data2=data.reverse();//币安是倒过来的
        }
        staticData.getBianArr.min15eth=true;
        let reverDatas=data2;
        staticData.countDatasTimeEth15m=reverDatas[0][0];
        staticData.countDatasArrEth15m=reverDatas; 
        setTimeout(()=>{//延缓3秒更新，怕跟15分一起更新会冲突
          data_shangZhang.fn_contMacd15eth(staticData.countDatasArrEth15m[1],"更新15分macdeth"); 
        },1500);           
            
      }); 
    } 
    return
    //检查红绿球和破新高
    if(staticData.countDatasArrEth15m.length>0&&staticData.sendDatas.ethPrice&&staticData.if_send_msgSave){
      if(staticData.if_send_msgSave.jj15MinOn=='2'){
        let saveONE={
          jsStatus:'',//金死叉状态
          ballColor:'',//球的颜色
          fanZhuan:'',//破新高，破新低
    
          zhis:0,//止损价位是多少
          daXiao:'',//大小于
          zhis50:0,//最大止损50%
          zhisSSS:0,//最后止损
          zhiYing:0,//止盈
          kaicangPrice:0,//开仓价
          abv80:'',//是否大于80
          changWei:'',//目前持仓,多还是空
          lvhong:'',//短线是否触发，以上一根为准10秒消失5分钟一次
          oneSuccess:'',//一个金叉只止盈一次，空为此金叉未止盈
    
          fanZhuan2:'',//破新高，破新低
          zhis2:0,//止损价位是多少
          daXiao2:'',//大小于
          zhis502:0,//最大止损50%
          zhisSSS2:0,//最后止损
          zhiYing2:0,//止盈
          kaicangPrice2:0,//开仓价
          abv802:'',//是否大于80
          changWei2:'',//目前持仓,多还是空
          oneSuccess2:'',//一个金叉只止盈一次，空为此金叉未止盈      
    
        };
        // 还原
        staticData.sendDatas.eth5macdObj=saveONE;
        console.log('开单已关闭');
        return;
      }
      console.log('监控开单');
      //监控开仓是否回退盈利
      if(staticData.sendDatas.eth5macdObj.kaicangPrice){
        if(staticData.sendDatas.eth5macdObj.abv80&&staticData.sendDatas.eth5macdObj.changWei=='多'&&staticData.sendDatas.ethPrice<=staticData.sendDatas.eth5macdObj.kaicangPrice*1.001||
          staticData.sendDatas.eth5macdObj.abv80&&staticData.sendDatas.eth5macdObj.changWei=='空'&&staticData.sendDatas.ethPrice>=staticData.sendDatas.eth5macdObj.kaicangPrice*0.999
        ){
          Api.sendMsg("abv80",[13025407962]).then(data => { 
            console.log(data);
          });           
          staticData.sendDatas.eth5macdObj.kaicangPrice=0;
          staticData.sendDatas.eth5macdObj.abv80='';
        }

        if(staticData.sendDatas.eth5macdObj.changWei=='多'&&staticData.sendDatas.ethPrice>=staticData.sendDatas.eth5macdObj.kaicangPrice*1.008){
          staticData.sendDatas.eth5macdObj.abv80='大于80';
        }
        if(staticData.sendDatas.eth5macdObj.changWei=='空'&&staticData.sendDatas.ethPrice<=staticData.sendDatas.eth5macdObj.kaicangPrice*0.992){
          staticData.sendDatas.eth5macdObj.abv80='大于80';
        }        
      }

      //时时刻刻发送短信用
      // if(staticData.sendDatas.eth5macdObj.jsStatus=='金叉'&&staticData.sendDatas.eth5macdObj.ballColor=='蓝球'&&staticData.sendDatas.eth5macdObj.fanZhuan==1||
      // staticData.sendDatas.eth5macdObj.jsStatus=='死叉'&&staticData.sendDatas.eth5macdObj.ballColor=='红球'&&staticData.sendDatas.eth5macdObj.fanZhuan==1
      // ){
      //   staticData.sendDatas.eth5macdObj.fanZhuan='';
      //   Api.sendMsg("eth15",[13025407962]).then(data => { 
      //     console.log(data);
      //   });  
      // }


      data_shangZhang.fn_testKey2(parseDatas);//搞计划2


      // 有止损价未破,未破止盈，则不用进行下面操作，但这块要放在最后面，防止以后加东西
      if(staticData.sendDatas.eth5macdObj.daXiao=='大于'&&staticData.sendDatas.ethPrice<staticData.sendDatas.eth5macdObj.zhisSSS&&staticData.sendDatas.ethPrice>staticData.sendDatas.eth5macdObj.zhiYing
      ||staticData.sendDatas.eth5macdObj.daXiao=='小于'&&staticData.sendDatas.ethPrice>staticData.sendDatas.eth5macdObj.zhisSSS&&staticData.sendDatas.ethPrice<staticData.sendDatas.eth5macdObj.zhiYing){
        return
      }

      // 如果破了止损位或者破了止盈位则还原所有，写下日志
      if(staticData.sendDatas.eth5macdObj.daXiao=='大于'&&parseDatas.k.h>=staticData.sendDatas.eth5macdObj.zhisSSS
      ||staticData.sendDatas.eth5macdObj.daXiao=='小于'&&parseDatas.k.l<=staticData.sendDatas.eth5macdObj.zhisSSS){
        data_shangZhang.re_writeLog(`已止损，${staticData.sendDatas.eth5macdObj.changWei}单，时间：${public_gg.get_time()}`+staticData.sendDatas.eth5macdObj.daXiao+staticData.sendDatas.ethPrice.toString(),"eth止损");
        
        staticData.sendDatas.eth5macdObj.ballColor='';//还原重新计算，不能无限制地开单 8月23日
        
        staticData.sendDatas.eth5macdObj.zhis=0;
        staticData.sendDatas.eth5macdObj.zhis50=0;  
        staticData.sendDatas.eth5macdObj.zhisSSS=0;          
        staticData.sendDatas.eth5macdObj.daXiao='';
        staticData.sendDatas.eth5macdObj.zhiYing=0;    
        staticData.sendDatas.eth5macdObj.fanZhuan='';    
        staticData.sendDatas.eth5macdObj.changWei='';
        // staticData.sendDatas.eth5macdObj.oneSuccess='';//止损还原，继续下单
        staticData.sendDatas.eth5macdObj.kaicangPrice=0;
        staticData.sendDatas.eth5macdObj.abv80='';
        //平币安的仓位，全部清除委托
        setTimeout(()=>{//延缓15秒
          binance.deleteOrder('key').then(data2 => {
            if(data2.code==200){
              console.log('清除委托成功');
            };
          }) 
        },10000);             
        return
      }      
      if(staticData.sendDatas.eth5macdObj.daXiao=='大于'&&parseDatas.k.l<=staticData.sendDatas.eth5macdObj.zhiYing
      ||staticData.sendDatas.eth5macdObj.daXiao=='小于'&&parseDatas.k.h>=staticData.sendDatas.eth5macdObj.zhiYing){
        data_shangZhang.re_writeLog(`已止盈，${staticData.sendDatas.eth5macdObj.changWei}单，时间：${public_gg.get_time()}`+staticData.sendDatas.eth5macdObj.daXiao+staticData.sendDatas.ethPrice.toString(),"eth止盈");
        
        staticData.sendDatas.eth5macdObj.ballColor='';//还原重新计算，不能无限制地开单8月23日
        
        staticData.sendDatas.eth5macdObj.zhis=0;
        staticData.sendDatas.eth5macdObj.zhis50=0;  
        staticData.sendDatas.eth5macdObj.zhisSSS=0;
        staticData.sendDatas.eth5macdObj.daXiao='';
        staticData.sendDatas.eth5macdObj.zhiYing=0; 
        staticData.sendDatas.eth5macdObj.fanZhuan=''; 
        staticData.sendDatas.eth5macdObj.changWei='';  
        staticData.sendDatas.eth5macdObj.kaicangPrice=0;
        staticData.sendDatas.eth5macdObj.abv80='';
        //平币安的仓位，全部清除委托
        setTimeout(()=>{//延缓15秒
          binance.deleteOrder('key').then(data2 => {
            if(data2.code==200){
              console.log('清除委托成功');
            };
          }) 
        },10000);              
        return
      }   
      //--------------------------------------死叉
      //死叉红球
      if(staticData.sendDatas.eth5macdObj.jsStatus=='死叉'&&staticData.countDatasArrEth15m[1][4]>staticData.countDatasArrEth15m[2][2]){
        staticData.sendDatas.eth5macdObj.ballColor='红球';
      }
      //开单，先有红球,死叉且红球且破低点，且不能已盈利，则发送一次短信
      if(staticData.sendDatas.eth5macdObj.jsStatus=='死叉'&&staticData.sendDatas.eth5macdObj.ballColor=='红球'
        &&staticData.sendDatas.ethPrice<staticData.countDatasArrEth15m[1][3]){//&&!staticData.sendDatas.eth5macdObj.oneSuccess

        staticData.sendDatas.eth5macdObj.kaicangPrice=staticData.sendDatas.ethPrice;
        // staticData.sendDatas.eth5macdObj.oneSuccess='死叉';
        staticData.sendDatas.eth5macdObj.fanZhuan=1;
        staticData.sendDatas.eth5macdObj.daXiao='大于';
        staticData.sendDatas.eth5macdObj.changWei='空';
        staticData.sendDatas.eth5macdObj.zhis= Math.max(+parseDatas.k.h,staticData.countDatasArrEth15m[1][2]);//对比当前和上一根的最高价，没确定50%
        staticData.sendDatas.eth5macdObj.zhis50=(+staticData.sendDatas.ethPrice)*0.005+(+staticData.sendDatas.ethPrice);
        staticData.sendDatas.eth5macdObj.zhisSSS=Math.min(staticData.sendDatas.eth5macdObj.zhis,staticData.sendDatas.eth5macdObj.zhis50);
        staticData.sendDatas.eth5macdObj.zhiYing=(+staticData.sendDatas.ethPrice)-(+staticData.sendDatas.ethPrice)*0.01;
        data_shangZhang.re_writeLog(`已下kong单，开仓价：${staticData.sendDatas.ethPrice.toString()},`+`止损价为：${staticData.sendDatas.eth5macdObj.zhisSSS.toFixed(2)},`+`止盈价为：${staticData.sendDatas.eth5macdObj.zhiYing.toFixed(2)},时间：${public_gg.get_time()}`,"eth已下单");

        data_shangZhang.eth5_sell(0.5,staticData.sendDatas.eth5macdObj.zhiYing.toFixed(1),staticData.sendDatas.eth5macdObj.zhisSSS.toFixed(1),'key');
        // Api.sendMsg("eth15K",[13025407962]).then(data => { 
        //   console.log(data)
        // });        
      }

      //--------------------------------------金叉
      //金叉蓝球
      if(staticData.sendDatas.eth5macdObj.jsStatus=='金叉'&&staticData.countDatasArrEth15m[1][4]<staticData.countDatasArrEth15m[2][3]){
        staticData.sendDatas.eth5macdObj.ballColor='蓝球';
      }
      //开单，先有蓝球,金叉且蓝球且破高点，且不能已盈利，则发送一次短信
      if(staticData.sendDatas.eth5macdObj.jsStatus=='金叉'&&staticData.sendDatas.eth5macdObj.ballColor=='蓝球'
        && staticData.sendDatas.ethPrice>staticData.countDatasArrEth15m[1][2]){//&&!staticData.sendDatas.eth5macdObj.oneSuccess

        staticData.sendDatas.eth5macdObj.kaicangPrice=staticData.sendDatas.ethPrice;
        // staticData.sendDatas.eth5macdObj.oneSuccess='金叉';
        staticData.sendDatas.eth5macdObj.fanZhuan=1;
        staticData.sendDatas.eth5macdObj.daXiao='小于';
        staticData.sendDatas.eth5macdObj.changWei='多';
        staticData.sendDatas.eth5macdObj.zhis= Math.min(+parseDatas.k.l,staticData.countDatasArrEth15m[1][3]);//对比当前和上一根的最高价，没确定50%
        staticData.sendDatas.eth5macdObj.zhis50=(+staticData.sendDatas.ethPrice)-(+staticData.sendDatas.ethPrice)*0.005;
        staticData.sendDatas.eth5macdObj.zhisSSS=Math.max(staticData.sendDatas.eth5macdObj.zhis,staticData.sendDatas.eth5macdObj.zhis50);
        staticData.sendDatas.eth5macdObj.zhiYing=(+staticData.sendDatas.ethPrice)+(+staticData.sendDatas.ethPrice)*0.01;
        data_shangZhang.re_writeLog(`已下duo单，开仓价：${staticData.sendDatas.ethPrice.toString()},`+`止损价为：${staticData.sendDatas.eth5macdObj.zhisSSS.toFixed(2)},`+`止盈价为：${staticData.sendDatas.eth5macdObj.zhiYing.toFixed(2)},时间：${public_gg.get_time()}`,"eth已下单");
        data_shangZhang.eth5_buy(0.5,staticData.sendDatas.eth5macdObj.zhiYing.toFixed(1),staticData.sendDatas.eth5macdObj.zhisSSS.toFixed(1),'key');      

        // Api.sendMsg("eth15D",[13025407962]).then(data => { 
        //   console.log(data)
        // });        
      }
    }
  },
  async fn_testKey2(parseDatas){
    return
      // 有止损价未破,未破止盈，则不用进行下面操作，但这块要放在最后面，防止以后加东西
      if(staticData.sendDatas.eth5macdObj.daXiao2=='大于'&&staticData.sendDatas.ethPrice<staticData.sendDatas.eth5macdObj.zhisSSS2&&staticData.sendDatas.ethPrice>staticData.sendDatas.eth5macdObj.zhiYing2
      ||staticData.sendDatas.eth5macdObj.daXiao2=='小于'&&staticData.sendDatas.ethPrice>staticData.sendDatas.eth5macdObj.zhisSSS2&&staticData.sendDatas.ethPrice<staticData.sendDatas.eth5macdObj.zhiYing2){
        return
      }

      // 如果破了止损位或者破了止盈位则还原所有，写下日志
      if(staticData.sendDatas.eth5macdObj.daXiao2=='大于'&&staticData.sendDatas.ethPrice>=staticData.sendDatas.eth5macdObj.zhisSSS2
      ||staticData.sendDatas.eth5macdObj.daXiao2=='小于'&&staticData.sendDatas.ethPrice<=staticData.sendDatas.eth5macdObj.zhisSSS2){
        staticData.sendDatas.eth5macdObj.zhis2=0;
        staticData.sendDatas.eth5macdObj.zhis502=0;  
        staticData.sendDatas.eth5macdObj.zhisSSS2=0;          
        staticData.sendDatas.eth5macdObj.daXiao2='';
        staticData.sendDatas.eth5macdObj.zhiYing2=0;    
        staticData.sendDatas.eth5macdObj.fanZhuan2='';    
        staticData.sendDatas.eth5macdObj.changWei2='';
        staticData.sendDatas.eth5macdObj.oneSuccess2='';//止损还原，继续下单
        staticData.sendDatas.eth5macdObj.kaicangPrice2=0;
        staticData.sendDatas.eth5macdObj.abv802='';
        //平币安的仓位，全部清除委托
        setTimeout(()=>{//延缓15秒
          binance.deleteOrder('key2').then(data2 => {
            if(data2.code==200){
              console.log('清除委托成功');
            };
          }) 
        },5000);             
        return
      }      
      if(staticData.sendDatas.eth5macdObj.daXiao2=='大于'&&staticData.sendDatas.ethPrice<=staticData.sendDatas.eth5macdObj.zhiYing2
      ||staticData.sendDatas.eth5macdObj.daXiao2=='小于'&&staticData.sendDatas.ethPrice>=staticData.sendDatas.eth5macdObj.zhiYing2){
        staticData.sendDatas.eth5macdObj.zhis2=0;
        staticData.sendDatas.eth5macdObj.zhis502=0;  
        staticData.sendDatas.eth5macdObj.zhisSSS2=0;
        staticData.sendDatas.eth5macdObj.daXiao2='';
        staticData.sendDatas.eth5macdObj.zhiYing2=0; 
        staticData.sendDatas.eth5macdObj.fanZhuan2=''; 
        staticData.sendDatas.eth5macdObj.changWei2='';  
        staticData.sendDatas.eth5macdObj.kaicangPrice2=0;
        staticData.sendDatas.eth5macdObj.abv802='';
        //平币安的仓位，全部清除委托
        setTimeout(()=>{//延缓15秒
          binance.deleteOrder('key2').then(data2 => {
            if(data2.code==200){
              console.log('清除委托成功');
            };
          }) 
        },5000);              
        return
      }   
      //--------------------------------------死叉
      //死叉红球
      if(staticData.sendDatas.eth5macdObj.jsStatus=='死叉'&&staticData.countDatasArrEth15m[1][4]>staticData.countDatasArrEth15m[2][2]){
        staticData.sendDatas.eth5macdObj.ballColor='红球';
      }
      //开单，先有红球,死叉且红球且破低点，且不能已盈利，则发送一次短信
      if(staticData.sendDatas.eth5macdObj.jsStatus=='死叉'&&staticData.sendDatas.eth5macdObj.ballColor=='红球'
        &&staticData.sendDatas.ethPrice<staticData.countDatasArrEth15m[1][3]&&!staticData.sendDatas.eth5macdObj.oneSuccess2){

        staticData.sendDatas.eth5macdObj.kaicangPrice2=staticData.sendDatas.ethPrice;
        staticData.sendDatas.eth5macdObj.oneSuccess2='死叉';
        staticData.sendDatas.eth5macdObj.fanZhuan2=1;
        staticData.sendDatas.eth5macdObj.daXiao2='大于';
        staticData.sendDatas.eth5macdObj.changWei2='空';
        staticData.sendDatas.eth5macdObj.zhis2= Math.min(+parseDatas.k.h,staticData.countDatasArrEth15m[1][2]);//对比当前和上一根的最高价，没确定50%
        let teskey2zhiSun=Math.max(staticData.sendDatas.eth5macdObj.zhis2,(+staticData.sendDatas.ethPrice)+(+staticData.sendDatas.ethPrice)*0.0015);
        
        staticData.sendDatas.eth5macdObj.zhis502=(+staticData.sendDatas.ethPrice)*0.005+(+staticData.sendDatas.ethPrice);
        staticData.sendDatas.eth5macdObj.zhisSSS2=Math.min(teskey2zhiSun,staticData.sendDatas.eth5macdObj.zhis502);
        staticData.sendDatas.eth5macdObj.zhiYing2=(+staticData.sendDatas.ethPrice)-30; 
        data_shangZhang.eth5_sell(1.2,staticData.sendDatas.eth5macdObj.zhiYing2.toFixed(1),staticData.sendDatas.eth5macdObj.zhisSSS2.toFixed(1),'key2'); 
      }

      //--------------------------------------金叉
      //金叉蓝球
      if(staticData.sendDatas.eth5macdObj.jsStatus=='金叉'&&staticData.countDatasArrEth15m[1][4]<staticData.countDatasArrEth15m[2][3]){
        staticData.sendDatas.eth5macdObj.ballColor='蓝球';
      }
      //开单，先有蓝球,金叉且蓝球且破高点，且不能已盈利，则发送一次短信
      if(staticData.sendDatas.eth5macdObj.jsStatus=='金叉'&&staticData.sendDatas.eth5macdObj.ballColor=='蓝球'
        && staticData.sendDatas.ethPrice>staticData.countDatasArrEth15m[1][2]&&!staticData.sendDatas.eth5macdObj.oneSuccess2){

        staticData.sendDatas.eth5macdObj.kaicangPrice2=staticData.sendDatas.ethPrice;
        staticData.sendDatas.eth5macdObj.oneSuccess2='金叉';
        staticData.sendDatas.eth5macdObj.fanZhuan2=1;
        staticData.sendDatas.eth5macdObj.daXiao2='小于';
        staticData.sendDatas.eth5macdObj.changWei2='多';
        staticData.sendDatas.eth5macdObj.zhis2= Math.max(+parseDatas.k.l,staticData.countDatasArrEth15m[1][3]);//对比当前和上一根的最高价，没确定50%
        let teskey2zhiSun=Math.min(staticData.sendDatas.eth5macdObj.zhis2,(+staticData.sendDatas.ethPrice)-(+staticData.sendDatas.ethPrice)*0.0015);
        
        staticData.sendDatas.eth5macdObj.zhis502=(+staticData.sendDatas.ethPrice)-(+staticData.sendDatas.ethPrice)*0.005;
        staticData.sendDatas.eth5macdObj.zhisSSS2=Math.max(teskey2zhiSun,staticData.sendDatas.eth5macdObj.zhis502);
        staticData.sendDatas.eth5macdObj.zhiYing2=(+staticData.sendDatas.ethPrice)+30;
        data_shangZhang.eth5_buy(1.2,staticData.sendDatas.eth5macdObj.zhiYing2.toFixed(1),staticData.sendDatas.eth5macdObj.zhisSSS2.toFixed(1),'key2');              
      }
  },
  // 1小时的eth，暂时不用
  async fn_counter_eth1h(parseDatas){
    if(!staticData.getBianArr.hour1heth){
      return
    }  
    //这根K线推送的开盘时间跟之前记录时间不同就去获取
    if(!staticData.countDatasTimeEth1h||parseDatas.k.t!=staticData.countDatasTimeEth1h){
      staticData.countDatasArrEth1h=[];
      staticData.getBianArr.hour1heth=false;
      Api.getKlineBN_eth1h().then(async data => {
        let data2=[];
        if(data.ch&&data.data){
          data.data.forEach((item,index)=>{
            data2.push([
              item.id*1000,
              item.open,
              item.high,
              item.low,
              item.close,
            ]);
          });
        }else{
          data2=data.reverse();//币安是倒过来的
        }
        staticData.getBianArr.hour1heth=true;
        let reverDatas=data2;
        staticData.countDatasTimeEth1h=reverDatas[0][0];
        staticData.countDatasArrEth1h=reverDatas; 
        // setTimeout(()=>{//延缓3秒更新，怕跟15分一起更新会冲突
        //   data_shangZhang.fn_contMacd15eth(staticData.countDatasArrEth15m[1],"更新15分macdeth"); 
        // },1500);           
            
      }); 
    } 
    if(staticData.countDatasArrEth1h.length>0){
      // 破新高，破新低s————————————————————————————————————————————————————————————————————
      if(parseDatas.k.h>staticData.countDatasArrEth1h[1][2]){//高
        console.log(11)
      }
      if(parseDatas.k.l<staticData.countDatasArrEth1h[1][3]){//低
        console.log(2222888)
      }   
    }
   
  },     
  //计算btc 7-30日均线15min监控到达某个价格、推送
  async fn_counter_btc15m(parseDatas){
    if(!staticData.getBianArr.min15){
      return
    }   
    staticData.sendDatas.ws4h1h15mUpdate.wsm15.num=new Date().getTime();//释放时间戳
    staticData.sendDatas.ws4h1h15mUpdate.wsm15.chiaNum=public_gg.get_time();//转为中文
    //这根K线推送的开盘时间跟之前记录时间不同就去获取
    if(!staticData.countDatasTimeBtc15m||parseDatas.k.t!=staticData.countDatasTimeBtc15m){
      staticData.countDatasArrBtc15m=[];
      staticData.getBianArr.min15=false;
      Api.getKlineBN_btc15m().then(async data => {
        let data2=[];
        if(data.ch&&data.data){
          data.data.forEach((item,index)=>{
            data2.push([
              item.id*1000,
              item.open,
              item.high,
              item.low,
              item.close,
            ]);
          });
        }else{
          data2=data.reverse();//币安是倒过来的
        }
        staticData.getBianArr.min15=true;
        let reverDatas=data2;
        staticData.countDatasTimeBtc15m=reverDatas[0][0];
        staticData.countDatasArrBtc15m=reverDatas;  
        staticData.sendDatas.coin.btc.h=0;
        staticData.sendDatas.coin.btc.l=0;  
        staticData.publicDZobj.dz15d="2";
        staticData.publicDZobj.dz15k="2";
        setTimeout(()=>{//延缓3秒更新，怕跟15分一起更新会冲突
          data_shangZhang.fn_contMacd15(staticData.countDatasArrBtc15m[1],"更新15分macd");  
        },3000);        
           
      }); 
    }  
    if(staticData.countDatasArrBtc15m.length>0){
      // 现在7-30线s————————————————————————————————————————————————————————————————————
      let count7=0;//当前的均线7日线
      for (let index = 1; index < 7; index++) {
        count7+=+staticData.countDatasArrBtc15m[index][4];
      }
      count7=count7+(+parseDatas.k.c);
      let now_averSevent7=count7/7;
      //当前的均线30日线
      let count30=0;
      for (let index = 1; index < 30; index++) {
        count30+=+staticData.countDatasArrBtc15m[index][4];
      }
      count30=count30+(+parseDatas.k.c);
      let now_averSevent30=count30/30;
      // 均线
      staticData.line30_btc15=now_averSevent30;
      staticData.line7_btc15=now_averSevent7;
      let ABS= Math.abs(now_averSevent7-now_averSevent30);
      // 监控7-30金死叉s————————————————————————————————————————————————————————————————————
      let fileDatasMacdJk= await data_shangZhang.get_smsgFileDatas('if_send_msg');
      if(fileDatasMacdJk=='文件不在'){ return } ;
      let oldDatasMacd=JSON.parse(fileDatasMacdJk);
      staticData.if_send_msgSave=oldDatasMacd;//保存不变的数据，防止文件访问过大

      let fileDatas= await data_shangZhang.get_smsgFileDatas('l_h_tip');
      if(fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
      let oldDatas=JSON.parse(fileDatas);   
      //悬浮最低点大于30，多
      if(oldDatasMacd.upXuanfu_15m=="1"&&staticData.countDatasArrBtc15m[1][3]>=now_averSevent30){
        let getTime=new Date().getTime();
        let interTime100=15*60*1000;
        let timeAllow100=getTime-staticData.btc_XuanfuTime15m;           
        if(timeAllow100>interTime100){
          staticData.btc_XuanfuTime15m=getTime;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】15分悬浮多，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】15分悬浮多，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"15分悬浮多");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);  
          oldDatasMacd.upXuanfu_15m="2";//关闭悬浮多
          oldDatasMacd.downXuanfu_15m="1";//开启悬浮空
          data_shangZhang.update_fileDatas('if_send_msg',oldDatasMacd);//后面因为没有更新这个文件所以这里可以更新
          // 同时开启对子空
          oldDatas.btc.red="1";
          data_shangZhang.update_fileDatas('l_h_tip',oldDatas);//后面只有破新高需要改，那个跟这个不冲突，没必要获取2次          
          // Api.sendMsg("XF15D").then(data => { 
          //   console.log(data)
          // });   
        }          
      }
      //悬浮最高点小于30，空
      if(oldDatasMacd.downXuanfu_15m=="1"&&staticData.countDatasArrBtc15m[1][2]<=now_averSevent30){
        let getTime=new Date().getTime();
        let interTime100=15*60*1000;
        let timeAllow100=getTime-staticData.btc_XuanfuTime15m;           
        if(timeAllow100>interTime100){
          staticData.btc_XuanfuTime15m=getTime;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】15分悬浮空，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】15分悬浮空，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"15分悬浮空");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);        
          oldDatasMacd.upXuanfu_15m="1";//开启悬浮多
          oldDatasMacd.downXuanfu_15m="2";//关闭悬浮空
          data_shangZhang.update_fileDatas('if_send_msg',oldDatasMacd);//后面因为没有更新这个文件所以这里可以更新
          // 同时开启对子多
          oldDatas.btc.green="1";
          data_shangZhang.update_fileDatas('l_h_tip',oldDatas);//后面只有破新高需要改，那个跟这个不冲突，没必要获取2次             
          // Api.sendMsg("XF15K").then(data => { 
          //   console.log(data)
          // });   
        } 
      }
      // 变色,多  上跟红开盘大于收盘，本跟破新高上跟绿，||上上跟红，上跟绿，但上跟没破上上跟新高
      if(now_averSevent7>now_averSevent30&&oldDatasMacd.upBianse_15m=="1"&&staticData.countDatasArrBtc15m[1][1]>staticData.countDatasArrBtc15m[1][4]&&parseDatas.k.h>staticData.countDatasArrBtc15m[1][2]||
      now_averSevent7>now_averSevent30&&oldDatasMacd.upBianse_15m=="1"&&staticData.countDatasArrBtc15m[2][1]>staticData.countDatasArrBtc15m[2][4]&&staticData.countDatasArrBtc15m[1][1]<staticData.countDatasArrBtc15m[1][4]
      ){
        let getTime=new Date().getTime();
        let interTime100=15*60*1000;
        let timeAllow100=getTime-staticData.btc_BianseTime15m;           
        if(timeAllow100>interTime100){
          staticData.btc_BianseTime15m=getTime;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】15m变色多，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】15m变色多，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"15m变色多");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);         
          Api.sendMsg("BS15D").then(data => { 
            console.log(data)
          });   
        } 
      }
      // 变色,空  上跟绿，本跟破新低，||上上跟绿，上跟红，但上跟没破新低
      if(now_averSevent7<now_averSevent30&&oldDatasMacd.downBianse_15m=="1"&&staticData.countDatasArrBtc15m[1][1]<staticData.countDatasArrBtc15m[1][4]&&parseDatas.k.l<staticData.countDatasArrBtc15m[1][3]||
      now_averSevent7<now_averSevent30&&oldDatasMacd.downBianse_15m=="1"&&staticData.countDatasArrBtc15m[2][1]<staticData.countDatasArrBtc15m[2][4]&&staticData.countDatasArrBtc15m[1][1]>staticData.countDatasArrBtc15m[1][4]
      ){
        let getTime=new Date().getTime();
        let interTime100=15*60*1000;
        let timeAllow100=getTime-staticData.btc_BianseTime15m;           
        if(timeAllow100>interTime100){
          staticData.btc_BianseTime15m=getTime;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】15m变色空，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】15m变色空，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"15m变色空");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);         
          Api.sendMsg("BS15K").then(data => { 
            console.log(data)
          });   
        } 
      }
      // 交叉
      if(oldDatasMacd.up730_15m=="1"&&now_averSevent7>now_averSevent30){
        let getTime=new Date().getTime();
        let interTime100=15*60*1000;
        let timeAllow100=getTime-staticData.btc_730Time15m;           
        if(timeAllow100>interTime100){
          staticData.btc_730Time15m=getTime;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】15分钟黄线白线相交多，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】15分钟黄线白线相交多，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"15分钟黄线白线相交多");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);         
          Api.sendMsg("XJ15D").then(data => { 
            console.log(data)
          });   
        }       
      }
      if(oldDatasMacd.down730_15m=="1"&&now_averSevent7<now_averSevent30){
        let getTime=new Date().getTime();
        let interTime100=15*60*1000;
        let timeAllow100=getTime-staticData.btc_730Time15m;           
        if(timeAllow100>interTime100){
          staticData.btc_730Time15m=getTime;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】15分钟黄线白线相交空，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】15分钟黄线白线相交空，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"15分钟黄线白线相交空");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);         
          Api.sendMsg("XJ15K").then(data => { 
            console.log(data)
          });   
        }
      }       

        // if(ABS<=8&&oldDatasMacd.abs15MinOn=="1"){          
        //   if(!staticData.btc_730ABS15m||staticData.btc_730ABS15m!=parseDatas.k.t){
        //     staticData.btc_730ABS15m=parseDatas.k.t;
        //     staticData.sendDatas.pubilcMsg=`【彬彬科技】15分钟黄线白线abs，时间：${public_gg.get_time()}`;
        //     staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】15分钟黄线白线abs，时间：${public_gg.get_time()}`;
        //     data_shangZhang.fn_oclockAppH5();
        //     data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"15分钟黄线白线abs");
        //     setTimeout(()=>{
        //       staticData.sendDatas.pubilcMsg="";
        //     },10*1000);         
        //     Api.sendMsg("abs15").then(data => { 
        //       console.log(data)
        //     });   
        //   }       
        // }    
      // 穿越
      if(now_averSevent7>now_averSevent30&&now_averSevent30-parseDatas.k.l>-50||now_averSevent7<now_averSevent30&&parseDatas.k.h-now_averSevent30>-50){

        let getTime=new Date().getTime();

        if(oldDatasMacd.yellowCy15MinOn=="1"){
          let interTime100=15*60*1000;
          let timeAllow100=getTime-staticData.btc_Cy15min;     
          if(timeAllow100>interTime100){
            staticData.btc_Cy15min=getTime;
            staticData.sendDatas.pubilcMsg=`【彬彬科技】15分钟cy，时间：${public_gg.get_time()}`;
            staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】15分钟cy，时间：${public_gg.get_time()}`;
            data_shangZhang.fn_oclockAppH5();
            data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"15分钟cy");
            setTimeout(()=>{
              staticData.sendDatas.pubilcMsg="";
            },10*1000);   
            // 关闭穿越
            oldDatasMacd.yellowCy15MinOn="2";
            data_shangZhang.update_fileDatas('if_send_msg',oldDatasMacd);
            // 并启动破新高低
            // fs.readFile(`date/smsg/l_h_tip.txt`,{encoding:"utf-8"}, function (err, po_fileDatas) {
            //   if (err) {
            //       throw err;
            //   }else {
            //       let po_oldDatas=JSON.parse(po_fileDatas);
            //       let timeType="btc";
            //       if(now_averSevent7>now_averSevent30){
            //         po_oldDatas[timeType].cyh='1';  //新高，顺着7-30
            //       }else{
            //         po_oldDatas[timeType].cyl='1'; //新低，顺着7-30
            //       }                                   
            //       fs.writeFile(`date/smsg/l_h_tip.txt`, JSON.stringify(po_oldDatas), function(err) {
            //         if (err) {
            //           throw err;
            //         }
            //       });                     
            //   }
            // });               
            Api.sendMsg("15Cy").then(data => { 
              console.log(data)
            }); 
          }            
        }
  
      }
      // e————————————————————————————————————————————————————————————————————
      

      // 破压力位牛熊，启动破新高低s————————————————————————————————————————————————————————————————————
      // &&staticData.sendDatas.ethPrice&&staticData.sendDatas.now.current
        if(staticData.sendDatas.btcPrice){
          
          let ya_fileDatas= await data_shangZhang.get_smsgFileDatas('niu_ya_msg');
          if(ya_fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
          let ya_oldDatas=JSON.parse(ya_fileDatas);
          let niu_ya_msg_Staus=true;
          
          ya_oldDatas.forEach((item,index)=>{          
            if(item.vip=="btc"&&item.dx=='1'&&staticData.price15mHigh>=item.price&&niu_ya_msg_Staus||item.vip=="btc"&&item.dx=='2'&&staticData.price15mLow<=item.price&&niu_ya_msg_Staus||item.vip=="eth"&&item.dx=='1'&&staticData.price15mHighEth>=item.price&&niu_ya_msg_Staus||item.vip=="eth"&&item.dx=='2'&&staticData.price15mLowEth<=item.price&&niu_ya_msg_Staus){
                niu_ya_msg_Staus=false;
                //发短信
                let msg="";
                if(item.remark){
                  msg= `【彬彬科技】${item.type=='1'?'15m':item.type=='2'?'1h':'4h'}，${item.dx=='1'?'大于':'小于'}，${item.price}，${item.remark}，时间：${public_gg.get_time()}`
                }else{
                  msg= `【彬彬科技】${item.type=='1'?'15m':item.type=='2'?'1h':'4h'}，${item.dx=='1'?'大于':'小于'}，${item.price}，${item.niu=='8'?'牛熊':'压力'}位，时间：${public_gg.get_time()}`;
                } 
                staticData.sendDatas.pubilcMsg=msg;
                staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】到达设定价格,时间：${public_gg.get_time()}`;
                data_shangZhang.fn_oclockAppH5();
                data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`${item.name}压力破位`);  
                setTimeout(()=>{
                  staticData.sendDatas.pubilcMsg="";
                },10*1000);                
                if(item.vip=="eth"){  //看到有eth到价格直接提示了
                  Api.sendMsg("DYeth").then(data => { 
                    console.log(data)
                  }); 
                }else if(item.niu=='8'||item.niu=='7'){  //只要niu 9多盈 78直接发短信 10（上）则开始跟踪  duizi
                  Api.sendMsg("DYXY").then(data => { 
                    console.log(data)
                  });                   
                }else if(item.niu=='9'){//多止盈，开启macd顺势，并开启破新低
                  let timeType="macd15AllOn";
                  if(item.type=='1'){
                    timeType="macd15AllOn";
                  }
                  if(item.type=='2'){
                    timeType="macd1hAllOn";
                  }     
                  if(item.type=='3'){
                    timeType="macd4hAllOn";
                  }                   
                  oldDatasMacd[timeType]='1';
                  data_shangZhang.update_fileDatas('if_send_msg',oldDatasMacd);

                  // 启动破新高低
                  fs.readFile(`date/smsg/l_h_tip.txt`,{encoding:"utf-8"}, function (err, po_fileDatas) {
                    if (err) {
                        throw err;
                    }else {
                        let po_oldDatas=JSON.parse(po_fileDatas);
                        let timeType="btc";
                        if(item.type=='1'){
                          timeType="btc";
                        }
                        if(item.type=='2'){
                          timeType="btc1h";
                        }     
                        if(item.type=='3'){
                          timeType="btc4h";
                        }   
                        if(item.dx=='1'){//启动破新高
                          po_oldDatas[timeType].dyxyl='1'; 
                        }else{
                          po_oldDatas[timeType].dyxyh='1'; 
                        }                                                            
                        fs.writeFile(`date/smsg/l_h_tip.txt`, JSON.stringify(po_oldDatas), function(err) {
                          if (err) {
                            throw err;
                          }
                        });                     
                    }
                  });                       

                }else if(item.niu=='10'){  //当item.niu不打勾时
                  // 启动破新高低
                  fs.readFile(`date/smsg/l_h_tip.txt`,{encoding:"utf-8"}, function (err, po_fileDatas) {
                    if (err) {
                        throw err;
                    }else {
                        let po_oldDatas=JSON.parse(po_fileDatas);
                        let timeType="btc";
                        if(item.type=='1'){
                          timeType="btc";
                        }
                        if(item.type=='2'){
                          timeType="btc1h";
                        }     
                        if(item.type=='3'){
                          timeType="btc4h";
                        }   
                        //现在只要15m,4h破新高
                        if(item.duizi=='7'){   //破新
                          // 大于启动破新低
                          if(item.dx=='1'){
                            po_oldDatas[timeType].dyxyl='1'; //btc 1小时用bch代替
                          }else{
                            po_oldDatas[timeType].dyxyh='1';  //btc 1小时用bch代替
                          }   
                        }else if(item.duizi=='9'){//空止盈延迟顺对子开启
                          if(item.dx=='1'){//和下面相反
                            po_oldDatas[timeType].green='1'; 
                          }else{
                            po_oldDatas[timeType].red='1';  
                          }  
                        }else{  //逆对子duizi
                          // 大于启动破新低
                          if(item.dx=='1'){
                            po_oldDatas[timeType].red='1'; //btc 1小时用bch代替
                          }else{
                            po_oldDatas[timeType].green='1';  //btc 1小时用bch代替
                          }    
                        }                                    
                        fs.writeFile(`date/smsg/l_h_tip.txt`, JSON.stringify(po_oldDatas), function(err) {
                          if (err) {
                            throw err;
                          }
                        });                     
                    }
                  });                    
                  
                }     
                //删除这个并更新
                ya_oldDatas.splice(index,1);
                if(Array.isArray(ya_oldDatas)){
                  fs.writeFile(`date/smsg/niu_ya_msg.txt`, JSON.stringify(ya_oldDatas), function(err) {
                    if (err) {
                      throw err;
                    };
                    niu_ya_msg_Staus=true;
                  }); 
                }                                                               
            }  
            // 只要列表有数据24小时监控的，只要大于，价格对于就发，15分最高点大于现在，或者最低点小于防止止损了没开启
      
          })      
        }
      // e————————————————————————————————————————————————————————————————————


      // 破新高，破新低s————————————————————————————————————————————————————————————————————
        if(parseDatas.k.h>staticData.countDatasArrBtc15m[1][2]){//高
          staticData.sendDatas.coin.btc.h=1;
        }
        if(parseDatas.k.l<staticData.countDatasArrBtc15m[1][3]){//低
          staticData.sendDatas.coin.btc.l=1;
        }  
            

 
        //新高
        if(staticData.sendDatas.coin.btc.h){
          if(oldDatas.btc.h=='1'&&oldDatas.btc.dyxyh=='1'&&oldDatas.btc.cyh=='1'){
            oldDatas.btc.h='2';
            oldDatas.btc.dyxyh='2';
            oldDatas.btc.cyh='2';
            data_shangZhang.update_fileDatas('l_h_tip',oldDatas);
            Api.sendMsg("PXG333").then(data => {
              console.log(data)
            }); 
          }else if(oldDatas.btc.h=='1'&&oldDatas.btc.dyxyh=='1'||oldDatas.btc.h=='1'&&oldDatas.btc.cyh=='1'||oldDatas.btc.cyh=='1'&&oldDatas.btc.dyxyh=='1'){
            oldDatas.btc.h='2';
            oldDatas.btc.dyxyh='2';
            oldDatas.btc.cyh='2'; 
            data_shangZhang.update_fileDatas('l_h_tip',oldDatas);          
            Api.sendMsg("PXG22").then(data => {
              console.log(data)
            }); 
          } else if(oldDatas.btc.h=='1'){ //常规破新高
            oldDatas.btc.h='2';
            data_shangZhang.update_fileDatas('l_h_tip',oldDatas);
            staticData.sendDatas.pubilcMsg=`【彬彬科技】btc15m破新高常规，时间：${public_gg.get_time()}`;
            staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】btc15m破新高常规，时间：${public_gg.get_time()}`;
            data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`btc15m常规破新高`);
            Api.sendMsg("PXG15").then(data => {
              console.log(data)
            });  
            setTimeout(()=>{
              staticData.sendDatas.pubilcMsg="";
            },10*1000);                          
          }else if(oldDatas.btc.dyxyh=='1'){ //压力破新高
            oldDatas.btc.dyxyh='2';
            data_shangZhang.update_fileDatas('l_h_tip',oldDatas);
            staticData.sendDatas.pubilcMsg=`【彬彬科技】btc15m破新高压力，时间：${public_gg.get_time()}`;
            staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】btc15m破新高压力，时间：${public_gg.get_time()}`;
            data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`btc15m压力破新高`);
            Api.sendMsg("PXG5dy").then(data => {
              console.log(data)
            });    
            setTimeout(()=>{
              staticData.sendDatas.pubilcMsg="";
            },10*1000);                        
          }else if(oldDatas.btc.cyh=='1'){ //穿越破新高
            oldDatas.btc.cyh='2';
            data_shangZhang.update_fileDatas('l_h_tip',oldDatas);
            staticData.sendDatas.pubilcMsg=`【彬彬科技】btc15m破新高穿越，时间：${public_gg.get_time()}`;
            staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】btc15m破新高穿越，时间：${public_gg.get_time()}`;
            data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`btc15m常规破穿越`);
            Api.sendMsg("PXG5cy").then(data => {
              console.log(data)
            });  
            setTimeout(()=>{
              staticData.sendDatas.pubilcMsg="";
            },10*1000);                         
          }                          
        } 
        // 新低
        if(staticData.sendDatas.coin.btc.l){             
          if(oldDatas.btc.l=='1'&&oldDatas.btc.dyxyl=='1'&&oldDatas.btc.cyl=='1'){
            oldDatas.btc.l='2';
            oldDatas.btc.dyxyl='2';
            oldDatas.btc.cyl='2';
            data_shangZhang.update_fileDatas('l_h_tip',oldDatas);
            Api.sendMsg("PXD333").then(data => {
              console.log(data)
            }); 
          }else if(oldDatas.btc.l=='1'&&oldDatas.btc.dyxyl=='1'||oldDatas.btc.l=='1'&&oldDatas.btc.cyl=='1'||oldDatas.btc.cyl=='1'&&oldDatas.btc.dyxyl=='1'){
            oldDatas.btc.l='2';
            oldDatas.btc.dyxyl='2';
            oldDatas.btc.cyl='2'; 
            data_shangZhang.update_fileDatas('l_h_tip',oldDatas);          
            Api.sendMsg("PXD22").then(data => {
              console.log(data)
            }); 
          } else if(oldDatas.btc.l=='1'){ //常规破新低
            oldDatas.btc.l='2';
            data_shangZhang.update_fileDatas('l_h_tip',oldDatas);
            staticData.sendDatas.pubilcMsg=`【彬彬科技】btc15m破新低常规，时间：${public_gg.get_time()}`;
            staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】btc15m破新低常规，时间：${public_gg.get_time()}`;
            data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`btc15m常规破新低`);
            Api.sendMsg("PXD15").then(data => {
              console.log(data)
            });  
            setTimeout(()=>{
              staticData.sendDatas.pubilcMsg="";
            },10*1000);                          
          }else if(oldDatas.btc.dyxyl=='1'){ //压力破新低
            oldDatas.btc.dyxyl='2';
            data_shangZhang.update_fileDatas('l_h_tip',oldDatas);
            staticData.sendDatas.pubilcMsg=`【彬彬科技】btc15m破新低压力，时间：${public_gg.get_time()}`;
            staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】btc15m破新低压力，时间：${public_gg.get_time()}`;
            data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`btc15m压力破新低`);
            Api.sendMsg("PXD5dy").then(data => {
              console.log(data)
            });    
            setTimeout(()=>{
              staticData.sendDatas.pubilcMsg="";
            },10*1000);                        
          }else if(oldDatas.btc.cyl=='1'){ //穿越破新低
            oldDatas.btc.cyl='2';
            data_shangZhang.update_fileDatas('l_h_tip',oldDatas);
            staticData.sendDatas.pubilcMsg=`【彬彬科技】btc15m破新低穿越，时间：${public_gg.get_time()}`;
            staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】btc15m破新低穿越，时间：${public_gg.get_time()}`;
            data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`btc15m常规破穿越`);
            Api.sendMsg("PXD5cy").then(data => {
              console.log(data)
            });  
            setTimeout(()=>{
              staticData.sendDatas.pubilcMsg="";
            },10*1000);                        
          }              
        }   
      // 初始化7-30红绿
      if(now_averSevent7<now_averSevent30){
        staticData.sendDatas.red_green_time.time15red=0;
      }else{
        staticData.sendDatas.red_green_time.time15green=0;
      }
      
      //红色空，且破新低，且上一根为红色（开>收）
      if(staticData.sendDatas.coin.btc.l&&staticData.countDatasArrBtc15m[1][1]>staticData.countDatasArrBtc15m[1][4]){
        staticData.publicDZobj.dz15k='1';
        staticData.publicDZobj.dz15d='2';
        if(oldDatas.btc.red=="1"){
          // let getTime=new Date().getTime();
          // let interTimeSmall=18*60*1000;
          // let timeAllowSmall=getTime-staticData.sendDatas.red_green.btc.red;
          
          if(parseDatas.k.t!=staticData.sendDatas.red_green.btc.red){
            staticData.sendDatas.red_green_time.time15red=staticData.sendDatas.red_green_time.time15red+1;        
            staticData.sendDatas.pubilcMsg=`【彬彬科技】15m红,次数：${staticData.sendDatas.red_green_time.time15red}，时间：${public_gg.get_time()}`;
            staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】15m红，次数：${staticData.sendDatas.red_green_time.time15red}，时间：${public_gg.get_time()}`;
            data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`15m红`);
            setTimeout(()=>{
              staticData.sendDatas.pubilcMsg="";
            },10*1000);   
            Api.sendMsg("ho15"+staticData.sendDatas.red_green_time.time15red.toString()).then(data => { 
              console.log(data)
            });                        
            staticData.sendDatas.red_green.btc.red=parseDatas.k.t;             
          } 
        }           
      } 
      //绿色多，且破新高，且上一根为绿色（开<收）
      if(staticData.sendDatas.coin.btc.h&&staticData.countDatasArrBtc15m[1][1]<staticData.countDatasArrBtc15m[1][4]){
        staticData.publicDZobj.dz15k='2';
        staticData.publicDZobj.dz15d='1';
        if(oldDatas.btc.green=="1"){
          // let getTime=new Date().getTime();
          // let interTimeSmall=18*60*1000;
          // let timeAllowSmall=getTime-staticData.sendDatas.red_green.btc.green;
          if(parseDatas.k.t!=staticData.sendDatas.red_green.btc.green){
            staticData.sendDatas.red_green_time.time15green=staticData.sendDatas.red_green_time.time15green+1;
            staticData.sendDatas.pubilcMsg=`【彬彬科技】15m绿,次数：${staticData.sendDatas.red_green_time.time15green}，时间：${public_gg.get_time()}`;
            staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】15m绿，次数：${staticData.sendDatas.red_green_time.time15green}，时间：${public_gg.get_time()}`;
            data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`15m绿`);
            setTimeout(()=>{
              staticData.sendDatas.pubilcMsg="";
            },10*1000);   
            Api.sendMsg("lv15m"+staticData.sendDatas.red_green_time.time15green.toString()).then(data => { 
              console.log(data)
            });                        
            staticData.sendDatas.red_green.btc.green=parseDatas.k.t;             
          }
        }  
      }  

      // e————————————————————————————————————————————————————————————————————

      // 推送s————————————————————————————————————————————————————————————————————
      if(staticData.ws){
        // console.log('ws均线开始')   
        let wsUser= staticData.ws.connections.length;
        staticData.sendDatas.wsUser=wsUser;
        staticData.sendDatas.musicOn=oldDatasMacd.musicOn;
        staticData.ws.connections.forEach((connect)=>{
          // console.log(connect);
          connect.sendText(JSON.stringify(staticData.sendDatas))
        });
      }  
      // e————————————————————————————————————————————————————————————————————
      //启动自动监控变色,只开启15分钟，放后面是因为有return  注意了
      // if(now_averSevent7>now_averSevent30){
      //   if(staticData.recordBianse.bs_15m.now=='duo'){
      //     return  //打断
      //   }
      //   if(!staticData.recordBianse.bs_15m.now){
      //     staticData.recordBianse.bs_15m.now="duo";
      //     return  //打断
      //   }
      //   if(staticData.recordBianse.bs_15m.now=='kong'){
      //     let getTime=new Date().getTime();
      //     let interTimeSmall=15*60*1000;
      //     let timeAllowSmall=getTime-staticData.recordBianse.bs_15m.time;
      //     if(timeAllowSmall>=interTimeSmall){
      //       staticData.recordBianse.bs_15m.time=getTime;
      //       staticData.recordBianse.bs_15m.now="duo";
      //       oldDatasMacd.upBianse_15m='1';
      //       oldDatasMacd.downBianse_15m='2';
      //       data_shangZhang.update_fileDatas('if_send_msg',oldDatasMacd);            
      //     } 
      //   }
      // }else{
      //   if(staticData.recordBianse.bs_15m.now=='kong'){
      //     return
      //   }
      //   if(!staticData.recordBianse.bs_15m.now){
      //     staticData.recordBianse.bs_15m.now="kong";
      //     return
      //   }
      //   if(staticData.recordBianse.bs_15m.now=='duo'){
      //     let getTime=new Date().getTime();
      //     let interTimeSmall=15*60*1000;
      //     let timeAllowSmall=getTime-staticData.recordBianse.bs_15m.time;
      //     if(timeAllowSmall>=interTimeSmall){
      //       staticData.recordBianse.bs_15m.time=getTime;
      //       staticData.recordBianse.bs_15m.now="kong";
      //       oldDatasMacd.upBianse_15m='2';
      //       oldDatasMacd.downBianse_15m='1';
      //       data_shangZhang.update_fileDatas('if_send_msg',oldDatasMacd);            
      //     } 
      //   }        
      // }


    }  
  },     
  // 计算btc 1h小时相交
  async fn_counter_btc1h(parseDatas){
    if(!staticData.getBianArr.hour1h){
      return
    }    
    staticData.sendDatas.ws4h1h15mUpdate.ws1h.num=new Date().getTime();//释放时间戳
    staticData.sendDatas.ws4h1h15mUpdate.ws1h.chiaNum=public_gg.get_time();//转为中文    
    //这根K线推送的开盘时间跟之前记录时间不同就去获取
    if(!staticData.countDatasTimeBtc1h||parseDatas.k.t!=staticData.countDatasTimeBtc1h){
      staticData.countDatasArrBtc1h=[];
      staticData.getBianArr.hour1h=false;
      Api.getKlineBN_btc1h().then(async data => {
        let data2=[];
        if(data.ch&&data.data){
          data.data.forEach((item,index)=>{
            data2.push([
              item.id*1000,
              item.open,
              item.high,
              item.low,
              item.close,
            ]);
          });
        }else{
          data2=data.reverse();//币安是倒过来的
        }
        staticData.getBianArr.hour1h=true;
        let reverDatas=data2;
        staticData.countDatasTimeBtc1h=reverDatas[0][0];
        staticData.countDatasArrBtc1h=reverDatas; 
        staticData.sendDatas.coin.btc1h.h=0;
        staticData.sendDatas.coin.btc1h.l=0; 
        staticData.publicDZobj.dz1hd="2";
        staticData.publicDZobj.dz1hk="2";
        setTimeout(()=>{//延缓3秒更新，怕跟15分一起更新会冲突
          data_shangZhang.fn_contMacd1h(staticData.countDatasArrBtc1h[1],"更新1hmacd"); 
        },6000);
                          
      }); 
    }  
    if(staticData.countDatasArrBtc1h.length){
      // 现在7-30线s————————————————————————————————————————————————————————————————————
      let count7=0;//当前的均线7日线
      for (let index = 1; index < 7; index++) {
        count7+=+staticData.countDatasArrBtc1h[index][4];
      }
      count7=count7+(+parseDatas.k.c);
      let now_averSevent7=count7/7;
      //当前的均线30日线
      let count30=0;
      for (let index = 1; index < 30; index++) {
        count30+=+staticData.countDatasArrBtc1h[index][4];
      }
      count30=count30+(+parseDatas.k.c);
      let now_averSevent30=count30/30;
      // 监控7-30金死叉s————————————————————————————————————————————————————————————————————
      let fileDatasMacdJk= await data_shangZhang.get_smsgFileDatas('if_send_msg');
      if(fileDatasMacdJk=='文件不在'){ return } ;
      let oldDatasMacd=JSON.parse(fileDatasMacdJk);
      
      let fileDatas= await data_shangZhang.get_smsgFileDatas('l_h_tip');
      if(fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
      let oldDatas=JSON.parse(fileDatas);           
      staticData.line30_btc1h=now_averSevent30;
      staticData.line7_btc1h=now_averSevent7;
      let ABS=Math.abs(now_averSevent7-now_averSevent30);
      staticData.sendDatas.abs=ABS;
      let yellow_cy=Math.abs(staticData.sendDatas.btcPrice-now_averSevent30);
      //悬浮最低点大于30，多
      if(oldDatasMacd.upXuanfu_1h=="1"&&staticData.countDatasArrBtc1h[1][3]>=now_averSevent30){
        let getTime=new Date().getTime();
        let interTime100=60*60*1000;
        let timeAllow100=getTime-staticData.btc_XuanfuTime1h;           
        if(timeAllow100>interTime100){
          staticData.btc_XuanfuTime1h=getTime;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】1h悬浮多，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】1h悬浮多，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"1h悬浮多");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);   
          oldDatasMacd.upXuanfu_1h="2";//关闭悬浮多
          oldDatasMacd.downXuanfu_1h="1";//开启悬浮空
          data_shangZhang.update_fileDatas('if_send_msg',oldDatasMacd);//后面因为没有更新这个文件所以这里可以更新
          // 同时开启对子空
          oldDatas.btc1h.red="1";
          data_shangZhang.update_fileDatas('l_h_tip',oldDatas);//后面只有破新高需要改，那个跟这个不冲突，没必要获取2次
          // Api.sendMsg("XF1hD").then(data => { 
          //   console.log(data)
          // });   
        }          
      }
      //悬浮最高点小于30，空
      if(oldDatasMacd.downXuanfu_1h=="1"&&staticData.countDatasArrBtc1h[1][2]<=now_averSevent30){
        let getTime=new Date().getTime();
        let interTime100=60*60*1000;
        let timeAllow100=getTime-staticData.btc_XuanfuTime1h;           
        if(timeAllow100>interTime100){
          staticData.btc_XuanfuTime1h=getTime;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】1h悬浮空，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】1h悬浮空，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"1h悬浮空");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);  

          oldDatasMacd.upXuanfu_1h="1";//开启悬浮多
          oldDatasMacd.downXuanfu_1h="2";//关闭悬浮空
          data_shangZhang.update_fileDatas('if_send_msg',oldDatasMacd);//后面因为没有更新这个文件所以这里可以更新
          // 同时开启对子多
          oldDatas.btc1h.green="1";
          data_shangZhang.update_fileDatas('l_h_tip',oldDatas);//后面只有破新高需要改，那个跟这个不冲突，没必要获取2次                 
          // Api.sendMsg("XF1hK").then(data => { 
          //   console.log(data)
          // });   
        } 
      }  
      // 变色,多  上跟红开盘大于收盘，本跟破新高上跟绿，||上上跟红，上跟绿，但上跟没破上上跟新高
      if(now_averSevent7>now_averSevent30&&oldDatasMacd.upBianse_1h=="1"&&staticData.countDatasArrBtc1h[1][1]>staticData.countDatasArrBtc1h[1][4]&&parseDatas.k.h>staticData.countDatasArrBtc1h[1][2]||
      now_averSevent7>now_averSevent30&&oldDatasMacd.upBianse_1h=="1"&&staticData.countDatasArrBtc1h[2][1]>staticData.countDatasArrBtc1h[2][4]&&staticData.countDatasArrBtc1h[1][1]<staticData.countDatasArrBtc1h[1][4]
      ){
        let getTime=new Date().getTime();
        let interTime100=60*60*1000;
        let timeAllow100=getTime-staticData.btc_BianseTime1h;           
        if(timeAllow100>interTime100){
          staticData.btc_BianseTime1h=getTime;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】1h变色多，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】1h变色多，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"1h变色多");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);         
          Api.sendMsg("BS1hD").then(data => { 
            console.log(data)
          });   
        } 
      }
      // 变色,空  上跟绿，本跟破新低，||上上跟绿，上跟红，但上跟没破新低
      if(now_averSevent7<now_averSevent30&&oldDatasMacd.downBianse_1h=="1"&&staticData.countDatasArrBtc1h[1][1]<staticData.countDatasArrBtc1h[1][4]&&parseDatas.k.l<staticData.countDatasArrBtc1h[1][3]||
      now_averSevent7<now_averSevent30&&oldDatasMacd.downBianse_1h=="1"&&staticData.countDatasArrBtc1h[2][1]<staticData.countDatasArrBtc1h[2][4]&&staticData.countDatasArrBtc1h[1][1]>staticData.countDatasArrBtc1h[1][4]
      ){
        let getTime=new Date().getTime();
        let interTime100=60*60*1000;
        let timeAllow100=getTime-staticData.btc_BianseTime1h;           
        if(timeAllow100>interTime100){
          staticData.btc_BianseTime1h=getTime;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】1h变色空，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】1h变色空，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"1h变色空");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);         
          Api.sendMsg("BS1hK").then(data => { 
            console.log(data)
          });   
        } 
      }      
      

      // 相交
      if(oldDatasMacd.up730_1h=="1"&&now_averSevent7>now_averSevent30){
        let getTime=new Date().getTime();
        let interTime100=60*60*1000;
        let timeAllow100=getTime-staticData.btc_730Time1h;           
        if(timeAllow100>interTime100){
          staticData.btc_730Time1h=getTime;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】1小时黄线白线相交多，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】1小时黄线白线相交多，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"1小时黄线白线相交多");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);  
          Api.sendMsg("XJ1hD",[13025407962]).then(data => { 
            console.log(data)
          });                                                
        }       
      }
      if(oldDatasMacd.down730_1h=="1"&&now_averSevent30>now_averSevent7){
        let getTime=new Date().getTime();
        let interTime100=60*60*1000;
        let timeAllow100=getTime-staticData.btc_730Time1h;           
        if(timeAllow100>interTime100){
          staticData.btc_730Time1h=getTime;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】1小时黄线白线相交空，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】1小时黄线白线相交空，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"1小时黄线白线相交空");
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000); 
          Api.sendMsg("XJ1hK",[13025407962]).then(data => { 
            console.log(data)
          });                                                   
        }
      }   
      // if(ABS<oldDatasMacd.abs_1h&&oldDatasMacd.abs1HOn=="1"){//已经去掉
      //   let getTime=new Date().getTime();
      //   let interTime100=120*60*1000;
      //   let timeAllow100=getTime-staticData.btc_730Abs1h;           
      //   if(timeAllow100>interTime100){
      //     staticData.btc_730Abs1h=getTime;
      //     staticData.sendDatas.pubilcMsg=`【彬彬科技】1小时abs，时间：${public_gg.get_time()}`;
      //     staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】1小时abs间隔小于，时间：${public_gg.get_time()}`;
      //     data_shangZhang.fn_oclockAppH5();
      //     data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"1小时abs间隔小于");
      //     setTimeout(()=>{
      //       staticData.sendDatas.pubilcMsg="";
      //     },10*1000);         
      //     Api.sendMsg("abs60").then(data => { 
      //       console.log(data)
      //     });  
      //   }        
      // }  

      // 穿越
      if(now_averSevent7>now_averSevent30&&now_averSevent30-parseDatas.k.l>-100||now_averSevent7<now_averSevent30&&parseDatas.k.h-now_averSevent30>-100){
        let getTime=new Date().getTime();      
        if(oldDatasMacd.yellowCy1hOn=="1"){
          let interTime100=120*60*1000;
          let timeAllow100=getTime-staticData.btc_Cy1h;     
          if(timeAllow100>interTime100){
            staticData.btc_Cy1h=getTime;
            staticData.sendDatas.pubilcMsg=`【彬彬科技】1小时cy，时间：${public_gg.get_time()}`;
            staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】1小时cy，时间：${public_gg.get_time()}`;
            data_shangZhang.fn_oclockAppH5();
            data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),"1小时cy");
            setTimeout(()=>{
              staticData.sendDatas.pubilcMsg="";
            },10*1000);   
            // 关闭穿越
            oldDatasMacd.yellowCy1hOn="2";
            data_shangZhang.update_fileDatas('if_send_msg',oldDatasMacd);
            // 并启动破新高低
            // fs.readFile(`date/smsg/l_h_tip.txt`,{encoding:"utf-8"}, function (err, po_fileDatas) {
            //   if (err) {
            //       throw err;
            //   }else {
            //       let po_oldDatas=JSON.parse(po_fileDatas);
            //       let timeType="btc1h";
            //       if(now_averSevent7>now_averSevent30){
            //         po_oldDatas[timeType].cyh='1';  //新高，顺着7-30
            //       }else{
            //         po_oldDatas[timeType].cyl='1'; //新低，顺着7-30
            //       }                                   
            //       fs.writeFile(`date/smsg/l_h_tip.txt`, JSON.stringify(po_oldDatas), function(err) {
            //         if (err) {
            //           throw err;
            //         }
            //       });                     
            //   }
            // });                   
            Api.sendMsg("1hcy").then(data => { 
              console.log(data)
            }); 
          }  
        }
      }      
      // e————————————————————————————————————————————————————————————————————
      // 破新高，破新低s————————————————————————————————————————————————————————————————————
      if(parseDatas.k.h>staticData.countDatasArrBtc1h[1][2]){//高
        staticData.sendDatas.coin.btc1h.h=1;
      }
      if(parseDatas.k.l<staticData.countDatasArrBtc1h[1][3]){//低
        staticData.sendDatas.coin.btc1h.l=1;
      }   
      // 获取要发短信的
      //新高
      if(staticData.sendDatas.coin.btc1h.h){
        if(oldDatas.btc1h.h=='1'&&oldDatas.btc1h.dyxyh=='1'&&oldDatas.btc1h.cyh=='1'){
          oldDatas.btc1h.h='2';
          oldDatas.btc1h.dyxyh='2';
          oldDatas.btc1h.cyh='2';
          data_shangZhang.update_fileDatas('l_h_tip',oldDatas);
          Api.sendMsg("G1h33").then(data => {
            console.log(data)
          }); 
        }else if(oldDatas.btc1h.h=='1'&&oldDatas.btc1h.dyxyh=='1'||oldDatas.btc1h.h=='1'&&oldDatas.btc1h.cyh=='1'||oldDatas.btc1h.cyh=='1'&&oldDatas.btc1h.dyxyh=='1'){
          oldDatas.btc1h.h='2';
          oldDatas.btc1h.dyxyh='2';
          oldDatas.btc1h.cyh='2'; 
          data_shangZhang.update_fileDatas('l_h_tip',oldDatas);          
          Api.sendMsg("G1h22").then(data => {
            console.log(data)
          }); 
        } else if(oldDatas.btc1h.h=='1'){ //常规破新高
          if(parseDatas.k.t!=staticData.pxgStatus.h1pxg){
            // oldDatas.btc1h.h='2';
            // data_shangZhang.update_fileDatas('l_h_tip',oldDatas);
            staticData.pxgStatus.h1pxg= parseDatas.k.t;
            staticData.sendDatas.pubilcMsg=`【彬彬科技】btc1h破新高常规，时间：${public_gg.get_time()}`;
            staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】btc1h破新高常规，时间：${public_gg.get_time()}`;
            data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`btc1h常规破新高`);
            Api.sendMsg("PXG1h").then(data => {
              console.log(data)
            });  
            setTimeout(()=>{
              staticData.sendDatas.pubilcMsg="";
            },10*1000);  
          }       
                        
        }else if(oldDatas.btc1h.dyxyh=='1'){ //压力破新高
          oldDatas.btc1h.dyxyh='2';
          data_shangZhang.update_fileDatas('l_h_tip',oldDatas);
          staticData.sendDatas.pubilcMsg=`【彬彬科技】btc1h破新高压力，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】btc1h破新高压力，时间：${public_gg.get_time()}`;
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`btc1h压力破新高`);
          Api.sendMsg("G1hdy").then(data => {
            console.log(data)
          });    
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);                        
        }else if(oldDatas.btc1h.cyh=='1'){ //穿越破新高
          oldDatas.btc1h.cyh='2';
          data_shangZhang.update_fileDatas('l_h_tip',oldDatas);
          staticData.sendDatas.pubilcMsg=`【彬彬科技】btc1h破新高穿越，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】btc1h破新高穿越，时间：${public_gg.get_time()}`;
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`btc1h常规破穿越`);
          Api.sendMsg("G1hcy").then(data => {
            console.log(data)
          });  
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);                         
        }                          
      } 
      // 新低
      if(staticData.sendDatas.coin.btc1h.l){             
        if(oldDatas.btc1h.l=='1'&&oldDatas.btc1h.dyxyl=='1'&&oldDatas.btc1h.cyl=='1'){
          oldDatas.btc1h.l='2';
          oldDatas.btc1h.dyxyl='2';
          oldDatas.btc1h.cyl='2';
          data_shangZhang.update_fileDatas('l_h_tip',oldDatas);
          Api.sendMsg("D1h33").then(data => {
            console.log(data)
          }); 
        }else if(oldDatas.btc1h.l=='1'&&oldDatas.btc1h.dyxyl=='1'||oldDatas.btc1h.l=='1'&&oldDatas.btc1h.cyl=='1'||oldDatas.btc1h.cyl=='1'&&oldDatas.btc1h.dyxyl=='1'){
          oldDatas.btc1h.l='2';
          oldDatas.btc1h.dyxyl='2';
          oldDatas.btc1h.cyl='2'; 
          data_shangZhang.update_fileDatas('l_h_tip',oldDatas);          
          Api.sendMsg("D1h22").then(data => {
            console.log(data)
          }); 
        } else if(oldDatas.btc1h.l=='1'){ //常规破新低
          if(parseDatas.k.t!=staticData.pxgStatus.h1pxd){
              // oldDatas.btc1h.l='2';
              // data_shangZhang.update_fileDatas('l_h_tip',oldDatas);
              staticData.pxgStatus.h1pxd=parseDatas.k.t;
              staticData.sendDatas.pubilcMsg=`【彬彬科技】btc1h破新低常规，时间：${public_gg.get_time()}`;
              staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】btc1h破新低常规，时间：${public_gg.get_time()}`;
              data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`btc1h常规破新低`);
              Api.sendMsg("PXD1h").then(data => {
                console.log(data)
              });  
              setTimeout(()=>{
                staticData.sendDatas.pubilcMsg="";
              },10*1000); 
          }
                         
        }else if(oldDatas.btc1h.dyxyl=='1'){ //压力破新低
          oldDatas.btc1h.dyxyl='2';
          data_shangZhang.update_fileDatas('l_h_tip',oldDatas);
          staticData.sendDatas.pubilcMsg=`【彬彬科技】btc1h破新低压力，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】btc1h破新低压力，时间：${public_gg.get_time()}`;
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`btc1h压力破新低`);
          Api.sendMsg("D1hdy").then(data => {
            console.log(data)
          });    
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);                        
        }else if(oldDatas.btc1h.cyl=='1'){ //穿越破新低
          oldDatas.btc1h.cyl='2';
          data_shangZhang.update_fileDatas('l_h_tip',oldDatas);
          staticData.sendDatas.pubilcMsg=`【彬彬科技】btc1h破新低穿越，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】btc1h破新低穿越，时间：${public_gg.get_time()}`;
          data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`btc1h常规破穿越`);
          Api.sendMsg("D1hcy").then(data => {
            console.log(data)
          });  
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);                        
        }              
      }   

      // 初始化7-30红绿
      if(now_averSevent7<now_averSevent30){
        staticData.sendDatas.red_green_time.time1hred=0;
      }else{
        staticData.sendDatas.red_green_time.time1hgreen=0;
      }         
      //红色空，且破新低，且上一根为红色（开>收）
      if(staticData.sendDatas.coin.btc1h.l&&staticData.countDatasArrBtc1h[1][1]>staticData.countDatasArrBtc1h[1][4]){
        staticData.publicDZobj.dz1hk='1';
        staticData.publicDZobj.dz1hd='2';
        if(oldDatas.btc1h.red=="1"){        
          // let getTime=new Date().getTime();
          // let interTimeSmall=1.5*60*60*1000;
          // let timeAllowSmall=getTime-staticData.sendDatas.red_green.btc1h.red;
          if(parseDatas.k.t!=staticData.sendDatas.red_green.btc1h.red){
            staticData.sendDatas.red_green_time.time1hred=staticData.sendDatas.red_green_time.time1hred+1;
            staticData.sendDatas.pubilcMsg=`【彬彬科技】btc1小时红,次数：${staticData.sendDatas.red_green_time.time1hred}，时间：${public_gg.get_time()}`;
            staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】btc1小时红，次数：${staticData.sendDatas.red_green_time.time1hred}，时间：${public_gg.get_time()}`;
            data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`btc1小时红`);
            setTimeout(()=>{
              staticData.sendDatas.pubilcMsg="";
            },10*1000);      
            Api.sendMsg("ho1h"+staticData.sendDatas.red_green_time.time1hred.toString()).then(data => { 
              console.log(data)
            });                      
            staticData.sendDatas.red_green.btc1h.red=parseDatas.k.t;             
          }
        }           
      } 
      //绿色多，且破新高，且上一根为绿色（开<收）
      if(staticData.sendDatas.coin.btc1h.h&&staticData.countDatasArrBtc1h[1][1]<staticData.countDatasArrBtc1h[1][4]){
        staticData.publicDZobj.dz1hk='2';
        staticData.publicDZobj.dz1hd='1';
        if(oldDatas.btc1h.green=="1"){ 
          // let getTime=new Date().getTime();
          // let interTimeSmall=1.5*60*60*1000;
          // let timeAllowSmall=getTime-staticData.sendDatas.red_green.btc1h.green;
          if(parseDatas.k.t!=staticData.sendDatas.red_green.btc1h.green){
            staticData.sendDatas.red_green_time.time1hgreen=staticData.sendDatas.red_green_time.time1hgreen+1;
            staticData.sendDatas.pubilcMsg=`【彬彬科技】btc1小时绿,次数：${staticData.sendDatas.red_green_time.time1hgreen}，时间：${public_gg.get_time()}`;
            staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】btc1小时绿，次数：${staticData.sendDatas.red_green_time.time1hgreen}，时间：${public_gg.get_time()}`;
            data_shangZhang.re_writeLog(staticData.sendDatas.pubilcMsg+staticData.sendDatas.btcPrice.toString(),`btc1小时绿`);
            setTimeout(()=>{
              staticData.sendDatas.pubilcMsg="";
            },10*1000);    
            Api.sendMsg("lv1h"+staticData.sendDatas.red_green_time.time1hgreen.toString()).then(data => { 
              console.log(data)
            });                         
            staticData.sendDatas.red_green.btc1h.green=parseDatas.k.t;            
          } 
        }
      }    
    }      
  }, 
  //开启ws服务
  openWsServer(){
    console.log(`已调用ws`)
    let server =nodews.createServer((connect)=>{
          //链接上来的时候
          connect.on('text',(str)=>{           
            let recieveDatas=JSON.parse(str);
            if(recieveDatas.name=='资金背离'){
              // data_shangZhang.fn_zj_beili(recieveDatas);
            }else if(recieveDatas.name=='闹钟记录'){
              if(recieveDatas.type=="H5"){
                staticData.sendDatas.oclockAppH5.h5="";
              }else if(recieveDatas.type=="APP"){
                staticData.sendDatas.oclockAppH5.app="";
              }
            }            
            // console.log(recieveDatas.name)
            // console.log(JSON.parse(str))
            // console.log("进入房间")
          });
          //关闭链接的时候
          connect.on('close',()=>{
            //离开房间
          });
          //错误处理
          connect.on('error',(err)=>{
            console.log(err);
          })
      }).listen(8080,()=>{
          console.log("running")
      });
      staticData.ws=server;





    // // 引用Server类:
    // const WebSocketServer = ws.Server;
    // // 实例化:
    // const wss = new WebSocketServer({
    //   port: 8080
    // });
    // wss.on('connection', function (ws) {
    //   console.log(`[SERVER] connection()`)
    //   staticData.ws=ws;
    //   // ws.send(`[SERVER] connection()`, (err) => {
    //   //   if (err) {
    //   //     console.log(`[SERVER] error: ${err}`);
    //   //   }
    //   // });      
    //   // ws.on('message', function (message) {
    //   // })
    // });    
  },
  //检查ws是否有断开连接的
  fn_cheakWsOff(){
    let getTime=new Date().getTime();
    let interTime100=3*60*1000;//  3分未更新
    for (const key in staticData.sendDatas.ws4h1h15mUpdate) {
      if((getTime-staticData.sendDatas.ws4h1h15mUpdate[key].num)>interTime100){
        // Api.sendMsg("ws"+staticData.sendDatas.ws4h1h15mUpdate[key].type+"f").then(data => { 
        //   console.log(data)
        // });
        // data_shangZhang.re_writeLog("ws3分钟未更新","ws3分钟未更新");         
      }
    }
  },
  //币安ws,现货
  fn_startBiAn(){
    //连接ws
    let fn_reconnectingWebSocket=function(url){
      return new ReconnectingWebSocket(url, [], {
        WebSocket: ws,
        connectionTimeout: 4e3,
        debug: false,
        maxReconnectionDelay: 10e3,
        maxRetries: Infinity,
        minReconnectionDelay: 4e3,
      })
    }
    // /btcusdt@kline_15m/ethusdt@kline_15m  这两个不能去掉获取以太坊和比特币价格用
    let w= fn_reconnectingWebSocket(
      `wss://stream.binance.com:9443/stream?streams=btcusdt@kline_4h/btcusdt@kline_15m/ethusdt@kline_15m`
    ); 

    w.onmessage = async msg => { 
      if(staticData.wsFrom=="hb"){
        return;
      };  
      staticData.sendDatas.wsTitle="币安ws";
      if(!msg.data) return;
      let parseDatas=JSON.parse(msg.data).data;
      parseDatas.s=parseDatas.s.toLowerCase();//需要小写
      if (parseDatas.k) {
        data_shangZhang.wsHbBa(parseDatas);  
      } 
    }

    w.onopen = msg => {
      console.log('币安：已链接');
    }

    w.onerror = msg => {
      console.log('币安：发生错误');
    }

    w.onclose = msg => {
      console.log('币安：自动重连');
    }    
  },
  //控制调用频率1秒一次
  controlFc1s(){
    setTimeout(()=>{
      staticData.controlHbFc1s.m5=true;
      staticData.controlHbFc1s.m15=true;
      staticData.controlHbFc1s.hour1=true;
      staticData.controlHbFc1s.hour4=true;
      staticData.controlHbFc1s.m15eth=true;
      staticData.controlHbFc1s.hour1eth=true;
    },1000);
  },  
  //火币币安公共数据
  wsHbBa(parseDatas){
    if(parseDatas.k.i=="30m"&&parseDatas.s=="ethusdt"){
      data_shangZhang.fn_contMacd15(parseDatas,"常规触发"); 
    }else if(parseDatas.k.i=="4h"&&parseDatas.s=="ethusdt"){
      data_shangZhang.fn_contMacd4h(parseDatas,"常规触发");
    }
  },
  //获取数据资源
  async fn_changeWs(){
    let fileDatasMacdJk= await data_shangZhang.get_smsgFileDatas('wsOn');
    if(fileDatasMacdJk=='文件不在'){ return } ;
    let oldDatasMacd=JSON.parse(fileDatasMacdJk);     
    staticData.wsFrom=oldDatasMacd.title;
  },
}

//开始ws
// data_shangZhang.get_439tip();//查看439老师的提醒,本地需要注释
data_shangZhang.fn_startBiAn();//开始获取币安数据
// data_shangZhang.openWsServer();//打开推送









// data_shangZhang.get_jingduList();//获取币安精确度
// data_shangZhang.get_439data();
// setInterval(()=>{
//   data_shangZhang.get_439tip();//10分钟查看439老师的提醒
// },10*1000*60);

// data_shangZhang.get_439tip();




// Api.get_general().then(async data => {
//   console.log(data);
// }).catch(err=>{
//   console.log(err);
// });

// 不常用
// data_shangZhang.fn_startHuoBi();
// setInterval(()=>{
//   data_shangZhang.fn_cheakWsOff();//监控5分钟价格不变，服务器出错(少见)+监控停服
// },5*1000*60);









// binance.createOrder('ETHUSDT','BUY',0.01,1).then(data => {
//   console.log(data)
// }) 
// binance.createOrder('ETHUSDT','BUY',0.01,'key').then(data => {
//   console.log(data)
// }) 
// binance.jianCangOrder('NEARUSDT','BUY',10,'key').then(data => {
//   console.log(data)
// }) 
// data_shangZhang.eth5_sell(0.01,2000,4000,'key2');
// data_shangZhang.eth5_buy(0.01,4000,2000,'key2');
// binance.deleteOrder('key2').then(data2 => {
//   if(data2.code==200){
//     console.log('清除委托成功');
//   };
// }) 
// Api.sendMsg("ma15D",[13025407962]).then(data => { 
//   console.log(data)
// }); 


// 调用接口用
exports.re_fn_changeWs = data_shangZhang.fn_changeWs;













// Api.sendMsg("ma15SSD",[13025407962]).then(data => { 
//   console.log(data)
// });  



// 方法是记录每个macd对应的开盘时间，如果时间对得上，从这个开始往后算，并记录上一个对应得macd,这个算完直接在
// 3个完整的，每1秒分钟去更新查看，对应的开盘时间是否收盘，收盘立马更新，nowMacd,并去除末尾的对象，同时把nowmacd更新上，或者时间不同立马更新
// {
//   timeopen:1
//   lastMacd:
//   nowMacd:4
// }

