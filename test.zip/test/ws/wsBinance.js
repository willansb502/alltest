const ws = require('ws');
const fs = require("fs");
const ReconnectingWebSocket = require('reconnecting-websocket'); //如果关闭连接，将自动重新连接的WebSocket
const Fcoin = require('./api/apiFcoin.js');
let Api = new Fcoin({});//常规

//静态
var staticData = {
  macdSendMsg:false
}

var public_gg={
  get_time(type){
    let date = new Date();
    let year = date.getFullYear();
    let month = date.getMonth() + 1;
    let day = date.getDate();
    let hour = date.getHours();
    let min = date.getMinutes();
    let sec = date.getSeconds();
    if (type == 'day') {
      return `${year}-${month}-${day}`;
    } else {
      return `${year}年${month}月${day}日${hour}时${min}分${sec}秒`;
    }  
  },  
}

var data_shangZhang={
  //读取date/smsg下面的文件
  get_smsgFileDatas(path){
    return new Promise(function(resolve, reject) {
      fs.readFile(`date/smsg/${path}.txt`,{encoding:"utf-8"}, function (err, fr) {
        if (err) {
          resolve('文件不在');
         }else {
          resolve(fr);
         }
      });    
    });
  },  
  async fn_contMacd4h(parseDatas,type){
    return
    let canGo=true;//防止为更新完就获取数据
    if(!canGo||!staticData.line30_btc4h){return};
    //静态数据 _______________________________________________________________
    let fileDatas= await data_shangZhang.get_smsgFileDatas('macd');
    if(fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
    let oldDatasMacd=JSON.parse(fileDatas); 
    let deaQian=+oldDatasMacd.btc4h.deaQian;   //记录前一个的dea
    let difQian=+oldDatasMacd.btc4h.difQian;  //记录前一个的dif
    let cQian=+oldDatasMacd.btc4h.cQian;  //记录前一个的收盘close
    let difShang=+oldDatasMacd.btc4h.difShang; //记录前前一个的dif
    // ————————————————————————————————————————————————————————————————
    let yShang=cQian+difShang*297/28-difQian*351/28;
    let xShang=difShang+yShang;
    let yQian=yShang*25/27+cQian*2/27;
    let xQian=xShang*11/13+cQian*2/13;

    //且距离上次更新不能少于5分钟
    let getTime_update=new Date().getTime();
    let interTime100_update=5*60*1000;
    let timeAllow100_update=getTime_update-staticData.macdTime4h_update;  

    

    if(type=="更新4hmacd"&&oldDatasMacd.btc4h.time!==parseDatas[0]&&timeAllow100_update>interTime100_update){//时间不等，且距离上次更新不能少于5分钟
      //macd出错
      if(parseDatas[0]-oldDatasMacd.btc4h.time>245*60*1000){
        console.log("macd4h需要手动更新");            
      }
      canGo=false;
      staticData.macdTime4h_update=getTime_update;
      let c_new=parseDatas[4];
      let y_new=yQian*25/27+c_new*2/27;
      let x_new=xQian*11/13+c_new*2/13;
      let dif_new=x_new-y_new;
      let dea_new=deaQian*8/10+dif_new*2/10; 
      let difShangSave=oldDatasMacd.btc4h.difQian;
      // 更新数据
      oldDatasMacd.btc4h.difShang=difShangSave;//前前的dif,换为上次的
      oldDatasMacd.btc4h.cQian=+parseDatas[4];
      oldDatasMacd.btc4h.deaQian=dea_new;
      oldDatasMacd.btc4h.difQian=dif_new;
      oldDatasMacd.btc4h.time=parseDatas[0];//上跟开盘时间减去这个大于31分未更新则报错
      setTimeout(() => {
        // data_shangZhang.fn_macdBeiLi(dif_new,dea_new,"btc4h",parseDatas[2],parseDatas[3]);//上一跟
      }, 10000);
      fs.writeFile(`date/smsg/macd.txt`, JSON.stringify(oldDatasMacd), function(err) {
        canGo=true;
        if (err) {
          throw err;
        }
      });         
    }
    
    if(type=="常规触发"){
      let c_new=parseDatas.k.c;
      let y_new=yQian*25/27+c_new*2/27;
      let x_new=xQian*11/13+c_new*2/13;
      let dif_new=x_new-y_new;
      let dea_new=deaQian*8/10+dif_new*2/10; 

      staticData.sendDatas.macdSendObj.h4=dif_new-dea_new;//传送检查

      if(dif_new-dea_new>10){
        let fileif_send_msg= await data_shangZhang.get_smsgFileDatas('if_send_msg');
        if(fileif_send_msg=='文件不在'){ console.log("错误文件暂停位置");return } ;
        let if_send_msgJson=JSON.parse(fileif_send_msg);  
        let cy_fileDatas= await data_shangZhang.get_smsgFileDatas('add_cy_time');
        if(cy_fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
        let cy_oldDatas=JSON.parse(cy_fileDatas);  
        let getTime=new Date().getTime();
        // let interTime100=8*60*60*1000;
        // let timeAllow100=getTime-staticData.macdTime4hD;  
        if(staticData.macdTime4hD!=parseDatas.k.t&&if_send_msgJson.upMacd_4h=="1"&&getTime-cy_oldDatas.ma_btc4h.timeNum>0){
          staticData.macdTime4hD=parseDatas.k.t;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】macd4h多，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】macd4h多，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);  
          //全部开启金叉
          Api.sendMsg("ma4hD").then(data => { 
            console.log(data)
          });              
          // if(dif_new>0&&dea_new>0){//金叉，大于0，且730在上
          // }else{
          //   Api.sendMsg("ma4hD").then(data => { 
          //     console.log(data)
          //   }); 
          // };
          // if(if_send_msgJson.macd4hAllOn=='1'){
          //   Api.sendMsg("ma4hSD").then(data => { 
          //     console.log(data)
          //   });             
          // }           
          // 开启死叉   
          // if_send_msgJson.upMacd_4h="2" ;
          // if_send_msgJson.downMacd_4h="1";
          // data_shangZhang.update_fileDatas('if_send_msg',if_send_msgJson);//更新文件                   
        }         
      }

      if(dea_new-dif_new>10){
        let fileif_send_msg= await data_shangZhang.get_smsgFileDatas('if_send_msg');
        if(fileif_send_msg=='文件不在'){ console.log("错误文件暂停位置");return } ;
        let if_send_msgJson=JSON.parse(fileif_send_msg);  
        let cy_fileDatas= await data_shangZhang.get_smsgFileDatas('add_cy_time');
        if(cy_fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
        let cy_oldDatas=JSON.parse(cy_fileDatas);  
        let getTime=new Date().getTime();
        // let interTime100=8*60*60*1000;
        // let timeAllow100=getTime-staticData.macdTime4hD;      if(timeAllow100>interTime100&&        
        if(staticData.macdTime4hD!=parseDatas.k.t&&if_send_msgJson.downMacd_4h=="1"&&getTime-cy_oldDatas.ma_btc4h.timeNum>0){
          staticData.macdTime4hD=parseDatas.k.t;
          staticData.sendDatas.pubilcMsg=`【彬彬科技】macd4h空，时间：${public_gg.get_time()}`;
          staticData.sendDatas.pubilcPhoneMsg= `【彬彬科技】macd4h空，时间：${public_gg.get_time()}`;
          data_shangZhang.fn_oclockAppH5();
          setTimeout(()=>{
            staticData.sendDatas.pubilcMsg="";
          },10*1000);   
          //全部开启死叉
          Api.sendMsg("ma4hK").then(data => { 
            console.log(data)
          });           
          // if(dif_new<0&&dea_new<0){//金叉，大于0，且730在上
          // }else{//if_send_msgJson.macd4hAllOn=='1'
          //   Api.sendMsg("ma4hK").then(data => { 
          //     console.log(data)
          //   }); 
          // };
          // 开启金叉   
          // if_send_msgJson.upMacd_4h="1" ;
          // if_send_msgJson.downMacd_4h="2";
          // data_shangZhang.update_fileDatas('if_send_msg',if_send_msgJson);//更新文件  
        }         
      }      
    }

  }, 
  async fn_contMacd30(parseDatas){
    //静态数据 _______________________________________________________________
    let fileDatas= await data_shangZhang.get_smsgFileDatas('macd');
    if(fileDatas=='文件不在'){ console.log("错误文件暂停位置");return } ;
    let oldDatasMacd=JSON.parse(fileDatas); 
    let deaQian=oldDatasMacd.eth30.deaQian;   //记录前一个的dea
    let difQian=oldDatasMacd.eth30.difQian;  //记录前一个的dif
    let cQian=oldDatasMacd.eth30.cQian;  //记录前一个的收盘close
    let difShang=oldDatasMacd.eth30.difShang; //记录前前一个的dif
    // ————————————————————————————————————————————————————————————————
    let yShang=cQian+difShang*297/28-difQian*351/28;
    let xShang=difShang+yShang;
    let yQian=yShang*25/27+cQian*2/27;
    let xQian=xShang*11/13+cQian*2/13;
    let c_new=parseDatas.k.c;
    let y_new=yQian*25/27+c_new*2/27;
    let x_new=xQian*11/13+c_new*2/13;
    let dif_new=x_new-y_new;
    let dea_new=deaQian*8/10+dif_new*2/10; 

    if(oldDatasMacd.eth30.time!=parseDatas.k.t){
      oldDatasMacd.eth30.time=parseDatas.k.t;
      oldDatasMacd.eth30.deaQian=?
      oldDatasMacd.eth30.difQian=?
      oldDatasMacd.eth30.cQian=?

    }

    console.log(dif_new)
    console.log(dea_new)



    // let difShangSave=oldDatasMacd.eth30.difQian;
    // 更新数据
    // oldDatasMacd.eth30.difShang=difShangSave;//前前的dif,换为上次的
    // oldDatasMacd.eth30.cQian=+parseDatas[4];
    // oldDatasMacd.eth30.deaQian=dea_new;
    // oldDatasMacd.eth30.difQian=dif_new;
    // oldDatasMacd.eth30.time=parseDatas[0];  


    // if(dif_new-dea_new>0){
    //   console.log("macd金叉")
    // }
    // if(dif_new-dea_new<0){
    //   console.log("macd死叉") 
    // } 
  },  
  //币安ws,现货MACD
  fn_startBiAn(){
    let fn_reconnectingWebSocket=function(url){
      return new ReconnectingWebSocket(url, [], {
        WebSocket: ws,
        connectionTimeout: 4e3,
        debug: false,
        maxReconnectionDelay: 10e3,
        maxRetries: Infinity,
        minReconnectionDelay: 4e3,
      })
    }
    let w= fn_reconnectingWebSocket(
      `wss://stream.binance.com:9443/stream?streams=ethusdt@kline_4h/ethusdt@kline_30m`
    )
    w.onmessage = async msg => { 
      if(!msg.data) return;
      let parseDatas=JSON.parse(msg.data).data;
      parseDatas.s=parseDatas.s.toLowerCase();
      if (parseDatas.k) {
        if(parseDatas.k.i=="30m"&&parseDatas.s=="ethusdt"){
          data_shangZhang.fn_contMacd30(parseDatas); 
        }else if(parseDatas.k.i=="4h"&&parseDatas.s=="ethusdt"){
          data_shangZhang.fn_contMacd4h(parseDatas);
        }        
      } 
    }
    w.onopen = msg => {
      console.log('币安：已链接');
    }
    w.onerror = msg => {
      console.log('币安：发生错误');
    }
    w.onclose = msg => {
      console.log('币安：自动重连');
    }    
  }
}

data_shangZhang.fn_startBiAn();//开始获取币安数据

