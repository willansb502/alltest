# -*- coding: utf-8 -*-
#作者：淘小白 VX:TXB2196
import sys,importlib
import urllib
from urllib import parse
from urllib.parse import unquote
from urllib.parse import quote
import json
import requests
import re
import random
import time

from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.nlp.v20190408 import nlp_client, models


baidu_headers = {
    "Accept": 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36",
    # "Accept-Encoding": "gzip, deflate, br",
    'Cookie': r'BIDUPSID=CEF1338F44765EC23480122A7F10F8B6; PSTM=1634311024; BD_UPN=12314753; __yjs_duid=1_d286337bedf9d98c777f066c635043201634349611846; MAWEBCUID=web_QgpedAsAQclowbQHzWtEsheWvcpjPsYofgyNccjInittlDybin; BAIDUID=8E2C67B0E72EE3FBB40683CE4F6D0B79:SL=0:NR=10:FG=1; BAIDUCUID=l8H980irSa0OuviugivQaguq2t_NOHupgavZu0i5vu8RkQaFyISOaIUmA; MSA_WH=576_748; H_WISE_SIDS=107314_110085_179345_188747_194530_196427_197711_199583_204911_208721_209568_210300_210322_212295_212798_212869_213034_213158_213306_213348_214109_214130_214137_214143_214797_215730_216428_216447_216616_216741_216842_216883_216943_217084_217168_217185_218445_218458_218548_218567_218598_218853_219360_219363_219448_219452_219548_219558_219667_219713_219726_219733_219737_219818_219819_219845_219854_219863_219942_219946_219948_220068_220071_220299_220315_220323_220394_220607_220662_220766_220801_221018_221108_221117_221118_221120_221369_221457_221474_221501; H_WISE_SIDS_BFESS=107314_110085_179345_188747_194530_196427_197711_199583_204911_208721_209568_210300_210322_212295_212798_212869_213034_213158_213306_213348_214109_214130_214137_214143_214797_215730_216428_216447_216616_216741_216842_216883_216943_217084_217168_217185_218445_218458_218548_218567_218598_218853_219360_219363_219448_219452_219548_219558_219667_219713_219726_219733_219737_219818_219819_219845_219854_219863_219942_219946_219948_220068_220071_220299_220315_220323_220394_220607_220662_220766_220801_221018_221108_221117_221118_221120_221369_221457_221474_221501; BDUSS_BFESS=jNXTGpBaWJjLVJuYUpoWTQ1RnFuVG9QbkZPRFRQaUI2WGRKVy1yTW5KcnNTUlZqRUFBQUFBJCQAAAAAAAAAAAEAAADg~VYO0KEx0KExusUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOy87WLsvO1ic; MCITY=-288:; newlogin=1; BAIDUCUID_BFESS=l8H980irSa0OuviugivQaguq2t_NOHupgavZu0i5vu8RkQaFyISOaIUmA; H_PS_PSSID=36557_36463_36885_34812_36805_37136_26350_37096_37204_37234; BDORZ=B490B5EBF6F3CD402E515D22BCDA1598; BAIDUID_BFESS=8E2C67B0E72EE3FBB40683CE4F6D0B79:SL=0:NR=10:FG=1; SIGNIN_UC=70a2711cf1d3d9b1a82d2f87d633bd8a04117516400aQeYzTRuScKKKbjqJRYmVxRabqkYz1kxIcpfDanKq/osZgklFtAvqleQErsHPhaH3vIVEmGEcKX2/0U47MFBfyZ/t2KrRtp0rPjQaFxwCrJachL067Lgp45iqvib1JJeqiPrZ4AXn7vdnCOpW7PrVKZPZCQa7MC+KMzpa4QCN6yqI+tngBefu92cI6lbs+tUx5zqQHWO6auAjNMn0EDJ/fWZx3TUslJwOC5Wdx8qSBGxn4/8pQvzEJMz6EmX4THeKk/PsvJa+z1KS1NjmSOi/SV5rfSXWUoJn4Vcm1gmCWg=45098439381894870733854960444441; uc_login_unique=c1ff1dd20daf4db5b2c5c35544f65242; uc_recom_mark=cmVjb21tYXJrXzY2MTk4MDM=; delPer=0; BD_CK_SAM=1; PSINO=1; BA_HECTOR=2kah0k8l81ah852l21a2f09f1hgo88l17; ZFY=B0i4MNf30lB1kOerplDvH3hrf6EQCXl8OZUipTX1:Bkg:C; COOKIE_SESSION=138125_0_8_8_4_19_1_1_8_7_3_2_138192_0_6_0_1661739289_0_1661739283|9#473_20_1660363729|9; BD_HOME=1; sug=3; sugstore=1; ORIGIN=0; bdime=0'

    }
    
tt_headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    # 'Accept-Encoding': 'gzip, deflate, br',
    # 'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    # 'Connection': 'keep-alive',
    # 'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"',
    # 'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    # 'Sec-Fetch-Dest': 'document',
    # 'Sec-Fetch-Mode': 'navigate',
    # 'Sec-Fetch-Site': 'same-origin',
    # 'Sec-Fetch-User': '?1',
    # 'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36',
    'Cookie': r'ttwid=1%7CU2ZGeGVg-FvELopWrFfOzy0EhP4WPRQVZ-3_-Snmw1k%7C1667738841%7Cb1311ff686438cc8809741555ec64d000ce1c4d8498df1671a704fa16d4db250; tt_webid=7131544698497418760; _S_WIN_WH=1536_721; _S_DPR=1.25; _S_IPAD=0; MONITOR_WEB_ID=7131544698497418760; s_v_web_id=verify_l92ddh0p_XSZIkHOC_p5eo_4nkT_8cjy_x1tU8LklMnER; msToken=_dJBacZr5vGLtTC-YHV_MSHCuuxrmZEsXSpRJqBzYZ0bqXZks1qFQKIjea5bQydM8qmmNLDOhE3pOLdYZkEMLXvgiBWTqaTew9ecG2Hk5do=; _S_UA=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20Win64%3B%20x64%3B%20rv%3A97.0)%20Gecko%2F20100101%20Firefox%2F97.0; _tea_utm_cache_4916=undefined'


    }
'''
公共方法1、排序提取关键词，相关度微调修改这里
'''
def paixu(key):
    fu_title_list = sorted(key, key=lambda s: s[1])
    fu_title = fu_title_list[-1][0] 
    return fu_title

'''
公共方法2、 腾讯ai 短文本相似度 
'''
def tx_xsd(key,keylist):
    # 腾讯ai_key
    cred = credential.Credential("AKIDX6c8appdHivyqXGn8UjnfaTZnvtsfGqO", "W0NkwxnTzQsFXaP7csviR1TkrrgJjAWh")
    httpProfile = HttpProfile()
    httpProfile.endpoint = "nlp.tencentcloudapi.com"

    clientProfile = ClientProfile()
    clientProfile.httpProfile = httpProfile
    client = nlp_client.NlpClient(cred, "ap-guangzhou", clientProfile)

    req = models.TextSimilarityProRequest()
    params = {
        "SrcText": key,
        "TargetText": keylist
    }
    req.from_json_string(json.dumps(params))
    resp = client.TextSimilarityPro(req)
    result = resp.to_json_string()
    pat = re.compile(r'{"Text": "(.*?)", "Score": (.*?)}')
    key_socre = re.findall(pat,result)
    return key_socre

'''
主体：标题生成相关方法
'''

#百度下拉词 相关方法
bd_xl_url = 'https://www.baidu.com/sugrec?pre=1&p=3&ie=utf-8&json=1&prod=pc&from=pc_web&&wd={}'
def get_bdxl_link_keys(key):
    try:
        link_keys = []
        tt_req = requests.get(bd_xl_url.format(''.join(key)),headers=baidu_headers,timeout=20)
        tt_resp = tt_req.text
        link_key_pre = re.findall(r'"q":"(.*?)"',''.join(tt_resp))
        for i in link_key_pre:
            if i != key:
                link_keys.append(i)
            else:
                pass
        return link_keys
    except:
        return None

def get_bdxl_key(key):
    try:  
        keylist = get_bdxl_link_keys(''.join(key))
        keyword_list = tx_xsd(key,keylist)
        keyword = paixu(keyword_list)
        return keyword
    except:
         None

#百度相关词 相关方法
bd_xg_url = "https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&rsv_idx=1&tn=baidu&wd={}&usm=3&rsv_idx=2&rsv_page=1"
def get_bdxg_link_keys(key):
    try:
        xg_req = requests.get(bd_xg_url.format(''.join(key)),headers=baidu_headers,timeout=20)
        xg_res = xg_req.text
        link_keys = re.findall(r'"word":"(.*?)"',xg_res)
        return link_keys
    except:
        var = None

def get_bdxg_key(key): 
    try: 
        keylist = get_bdxg_link_keys(''.join(key))

        keyword_list = tx_xsd(key,keylist)
        keyword = paixu(keyword_list)
        return keyword
    except:
        return None


#1、获取头条urls
def get_list_title_urls(key,num,comment_onoff):
    result_titles = []
    qx_content_divs=[]
    for i in range(int(num)):
        url = 'https://so.toutiao.com/search?keyword={}&pd=information&source=search_subtab_switch&dvpf=pc&aid=4916&page_num={}'.format(key,i)
        req = requests.get(url,headers =tt_headers,timeout=10)
        time.sleep(3)
        if req.status_code == 200:
            res = req.text
            # print(res)
            content_ten_divs=re.findall(r'<div class="cs-view cs-view-block cs-card-content">(.*?)<script>PerfTag',res)
            for content_div in content_ten_divs:
                if comment_onoff == '关':   
                    if '<span class="text-ellipsis margin-right-4">' in content_div:
                        qx_content_divs.append(content_div)
                    else:
                        pass
                else:
                    qx_content_divs.append(content_div)
            else:
                pass
        else:
            pass
    if len(qx_content_divs)>0:
        tt_ids = re.findall(r'<div data-log-click.*?www.toutiao.com%2Fa(.*?)%2F',''.join(qx_content_divs))
        tt_titles = re.findall(r'<div data-log-click.*?class="text-ellipsis text-underline-hover">(.*?)</a>',''.join(qx_content_divs))
        for tt_title in tt_titles:
            result_titles.append(qx_bd(tt_title))
        return tt_ids,result_titles
    else:
        pass

#2、清洗标题标签
def  qx_bd(cons):
    bd_fhs=[r'\\u003cem\\u003e',r'\\u003c/em\\u003e','</em>','<em>']
    for i in bd_fhs:
        pat = re.compile(i,re.I)
        cons = pat.sub('',cons)
    return cons

#3、分割标题
def fg_bt(title):
    title1 = re.split('[，,!！?？ -——# ]', title)
    return title1

#4、提取头条内容
def tq_cons(url):
    req = requests.get(url,headers=tt_headers,timeout=10)
    if req.status_code == 200:
        res = req.text
        json_data = json.loads(res)
        cons = re.findall(r'<article>(.*?)</article>',str(json_data))
        return ''.join(cons)
    else:
        pass 
#5、清洗p，慎用，可能清洗的没内容了
def qx_p(html):
    contents = []
    pat  = re.compile(r'<p>(.*?)</p>',re.S)
    cons = re.findall(pat,html)
    keywords = ['编辑','公众号','关注','快手','大家好','新闻客户端','原标题','抖音','小编','APP','图源','来源','收藏','留言','探讨','评论区','点赞','了解更多','专栏','咨询','二维码','记者','报导','讯','必究','版权','作者','责编','审稿','百度app','习近平','军事','培训学校','图片仅供参考','更多文章','@','摄图网','如图所示','报道','时报','图虫创意','侵权','摘自网络','文/','文|','来自网络','资料图','记者','By','文案：','图：','海报：','#','参考资料' ,'搜索','微信号']
    for i in cons:
        if any(keyword in i for keyword in keywords): continue
        j = ''.join(i)
        contents.append('<p>'+j+'</p>')
    return ''.join(contents)

#6、清洗html标签
def qx_html(m):
    pat_bqs = re.compile(r'<.*?>',re.I)
    all_bqs = re.findall(pat_bqs,m)
    a_pat = re.compile(r'<a class="image".*?url=',re.I)
    width_pat = re.compile(r'width.*?>',re.I)
    p_pat = re.compile(r'<p.*?>',re.I)

    all_set_bqs = set(all_bqs)
    for i in list(all_set_bqs):

        if '<p' not in ''.join(i) and r'</p>' not in ''.join(i) and '<a class="image"' not in ''.join(i):
            pre_m1 = ''.join(m).replace(''.join(i),'')
            m = pre_m1
        else:
            pass
    m = urllib.parse.unquote(m).replace(r'\u200b','')
    m = p_pat.sub('<p>',m)
    m = a_pat.sub('<img src="',m)
    m = width_pat.sub('width="360px",height="auto" />',m)
    
    return m.replace(r'<p></p>','')
#7、匹配度方法
def pd_key_title(key,title):
    key_lst = set(list(key))
    sx_key = []
    for i in key_lst:
        if '\u4e00' <= i <= '\u9fff':
            if i not in title:
                pass 
            else:
                sx_key.append(i)
        else:
            pass

    key_in_rate = len(sx_key)/len(key_lst)
    if key_in_rate>0.5:
        return title
    else:
        pass

#6、主要的提取数据方法
def main_tq_content(key,num,comment_onoff):
    urls_titles = []
    ids_titles = get_list_title_urls(key,num,comment_onoff)
    if ids_titles:
        for x,y in zip(ids_titles[0],ids_titles[1]):
            urls_titles.append('http://a6.pstatp.com/article/content/21/1/'+x+'/1/0/?iid=0'+',,'+y)
    else:
        pass
    #网址标题组合在一个一起，',,'分割
    ok_urls_titles = []
    for i in urls_titles:
        pre_i = re.split(',,',i)
        pd_ok_title = pd_key_title(key,pre_i[1])
        if pd_ok_title :
            ok_urls_titles.append(i)
        else:
            pass
    #腾讯ai提取最相关标题
    tx_titles = []
    for j in ok_urls_titles:
        tt_titles = re.split(',,',j)
        tx_titles.append(tt_titles[1])
    if len(tx_titles)>0:
        tt_title_list = tx_xsd(key,tx_titles)
        tt_title = paixu(tt_title_list)
        if tt_title:
            for url_title in ok_urls_titles:
                db_url_title = re.split(',,',url_title)
                if tt_title == db_url_title[1]:
                    pre_cons = tq_cons(db_url_title[0])
                    if pre_cons:
                        result_cons = qx_html(pre_cons)
                        p_img_pat = re.compile(r'</p>rom=.*?</p>',re.I)
                        result_new_cons = p_img_pat.sub('</p>',result_cons)
                        result_new_cons = result_new_cons.replace(r'<img','<p style="text-align: center;"><img').replace(r'/>','/></p>')
                        return tt_title,result_new_cons
                    else:
                        pass
                else:
                    pass
        else:
            pass
    else:
        pass
#7、主逻辑
def run_main(key,title_onoff,page_num,comment_onoff,pic_onoff):
    
    if title_onoff == '开':
        zhu_title = get_bdxl_key(key)
        if zhu_title:
            fu_title = get_bdxg_key(key)
            main_title = zhu_title+'('+fu_title+')'
            result_content = main_tq_content(key,page_num,comment_onoff)
            if result_content:
                if pic_onoff == '开':
                    if 'img'  in result_content[1]:
                        return main_title,result_content[1]
                    else:
                        pass
                else:
                    return main_title,result_content[1]
        else:
            pass
    elif title_onoff == '关':
        zhu_title = get_bdxl_key(key)
        result_content = main_tq_content(key,page_num,comment_onoff)
        if result_content:
            fu_title = fg_bt(result_content[0])
            main_title = zhu_title+'('+''.join(fu_title)+')'
            return main_title,result_content[1]
        else:
            pass 
    else:
        return '标题开关切换设置错误，只能是‘开’或者‘关’！','标题开关切换设置错误，只能是‘开’或者‘关’！'

# if __name__ == '__main__':
#     key='干海参如何泡发'
#     title = '淡干海参泡发流程'
#     aa = pd_key_title(key,title)
#     print(aa)
#     title_onoff = '开' #标题两种方法切换，默认是：双标题 = 搜索词的百度下拉词+百度下拉词的百度相关词
#     page_num = 2 #提取几个列表的数据
#     comment_onoff = '关' #是否卡带评论的文章，默认不打开
#     pic_onoff = '关' #是否卡带图片的文章，默认不打开
#     key = '番茄炒蛋'
#     aa=run_main(key,title_onoff,page_num,comment_onoff,pic_onoff)
#     print(aa)

# 火车头默认格式
if len(sys.argv)!= 5:
    print(len(sys.argv))
    print("命令行参数长度不为5")
    sys.exit()
else:
    LabelCookie = parse.unquote(sys.argv[1])
    LabelUrl = parse.unquote(sys.argv[2])
    #PageType为List,Content,Pages分别代表列表页，内容页，多页http请求处理，Save代表内容处理
    PageType=sys.argv[3]
    SerializerStr = parse.unquote(sys.argv[4])
    if (SerializerStr[0:2] != '''{"'''):
        file_object = open(SerializerStr)
        try:
            SerializerStr = file_object.read()
            SerializerStr = parse.unquote(SerializerStr)
        finally:
            file_object.close()
    LabelArray = json.loads(SerializerStr)

#以下是用户编写代码区域

    if(PageType=="Save"):
        
        key = LabelArray['搜词']
        title_onoff = LabelArray['标题开关'] #标题两种方法切换，默认是：双标题 = 搜索词的百度下拉词+百度下拉词的百度相关词
        page_num = LabelArray['翻页数量'] #提取几个列表的数据
        comment_onoff = LabelArray['评论开关'] #是否卡带评论的文章，默认不打开
        pic_onoff = LabelArray['图片开关'] #是否卡带图片的文章，默认不打开
        result_title_content=run_main(key,title_onoff,page_num,comment_onoff,pic_onoff)
        if result_title_content:
            LabelArray['标题'] = result_title_content[0]
            LabelArray['内容'] = result_title_content[1].replace('\t','')
        else:
            LabelArray['标题'] = ''
            LabelArray['内容'] = ''

    else:
        LabelArray['Html']='当前页面的网址为:'+ LabelUrl +"\r\n页面类型为:" + PageType + "\r\nCookies数据为:"+LabelCookie+"\r\n接收到的数据是:" + LabelArray['Html']
#以上是用户编写代码区域
    LabelArray = json.dumps(LabelArray)
    print(LabelArray)
