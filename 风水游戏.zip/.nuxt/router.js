import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _ace6c5fe = () => interopDefault(import('..\\pages\\mine\\index.vue' /* webpackChunkName: "pages/mine/index" */))
const _9a9019c4 = () => interopDefault(import('..\\pages\\works\\index.vue' /* webpackChunkName: "pages/works/index" */))
const _fd1060ba = () => interopDefault(import('..\\pages\\auth\\login.vue' /* webpackChunkName: "pages/auth/login" */))
const _ae5f2da8 = () => interopDefault(import('..\\pages\\auth\\regist.vue' /* webpackChunkName: "pages/auth/regist" */))
const _3a4c7f72 = () => interopDefault(import('..\\pages\\mine\\my-post\\index.vue' /* webpackChunkName: "pages/mine/my-post/index" */))
const _651eb482 = () => interopDefault(import('..\\pages\\mine\\password-setting.vue' /* webpackChunkName: "pages/mine/password-setting" */))
const _33c2379a = () => interopDefault(import('..\\pages\\mine\\userName-setting.vue' /* webpackChunkName: "pages/mine/userName-setting" */))
const _974dafae = () => interopDefault(import('..\\pages\\mine\\users-admin\\index.vue' /* webpackChunkName: "pages/mine/users-admin/index" */))
const _be4fdbea = () => interopDefault(import('..\\pages\\mine\\users-coin\\index.vue' /* webpackChunkName: "pages/mine/users-coin/index" */))
const _eb0c2f44 = () => interopDefault(import('..\\pages\\mine\\wechat-robot\\index.vue' /* webpackChunkName: "pages/mine/wechat-robot/index" */))
const _9ae00422 = () => interopDefault(import('..\\pages\\mine\\works-admin\\index.vue' /* webpackChunkName: "pages/mine/works-admin/index" */))
const _3c998035 = () => interopDefault(import('..\\pages\\works\\detail.vue' /* webpackChunkName: "pages/works/detail" */))
const _a274b84a = () => interopDefault(import('..\\pages\\works\\publish.vue' /* webpackChunkName: "pages/works/publish" */))
const _da9c54ba = () => interopDefault(import('..\\pages\\works\\teacher-works.vue' /* webpackChunkName: "pages/works/teacher-works" */))
const _3a063e34 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'hash',
  base: './',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/mine",
    component: _ace6c5fe,
    name: "mine"
  }, {
    path: "/works",
    component: _9a9019c4,
    name: "works"
  }, {
    path: "/auth/login",
    component: _fd1060ba,
    name: "auth-login"
  }, {
    path: "/auth/regist",
    component: _ae5f2da8,
    name: "auth-regist"
  }, {
    path: "/mine/my-post",
    component: _3a4c7f72,
    name: "mine-my-post"
  }, {
    path: "/mine/password-setting",
    component: _651eb482,
    name: "mine-password-setting"
  }, {
    path: "/mine/userName-setting",
    component: _33c2379a,
    name: "mine-userName-setting"
  }, {
    path: "/mine/users-admin",
    component: _974dafae,
    name: "mine-users-admin"
  }, {
    path: "/mine/users-coin",
    component: _be4fdbea,
    name: "mine-users-coin"
  }, {
    path: "/mine/wechat-robot",
    component: _eb0c2f44,
    name: "mine-wechat-robot"
  }, {
    path: "/mine/works-admin",
    component: _9ae00422,
    name: "mine-works-admin"
  }, {
    path: "/works/detail",
    component: _3c998035,
    name: "works-detail"
  }, {
    path: "/works/publish",
    component: _a274b84a,
    name: "works-publish"
  }, {
    path: "/works/teacher-works",
    component: _da9c54ba,
    name: "works-teacher-works"
  }, {
    path: "/",
    component: _3a063e34,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
