import qs from "qs" //  get请求时需要序列化请求参数
const axiosapi = (
  { app: { $axios } },
  inject
) => {
  // -----------mine start-----------
  //获取用户信息
  // inject('getUserInfo', data => $axios.$post(BASEURL + '/user/info', data))
  // inject('mineRedeemcodeList', data => $axios.$get(BASEURL + '/redeemcode/list', {params: data}))
  
  // 首页列表
  inject('forumGetList', data => $axios.$get('/api/forum/getList', {params: data}))
  // 首页老师
  inject('forumGetTeachersRankLis', data => $axios.$get('/api/forum/getTeachersRankList', {params: data}))
  // 首页客户积分
  inject('forumGetCoinsRankList', data => $axios.$get('/api/forum/getCoinsRankList', {params: data}))
  // 获取用户昵称
  inject('getUserChinaName', data => $axios.$get('/api/forum/getUserChinaName', {params: data}))
  // 机器人
  inject('getRootCode', data => $axios.$get('/api2/getRootCode', {params: data}))  
    
  // 我提交的作业
  inject('forumGetMySend', data => $axios.$get('/api/forum/getMySend', {params: data}))  
  // 文章详情
  inject('forumArticle', data => $axios.$get('/api/forum/article', {params: data}))  
  // 发布文章
  inject('forumPostForm', data => $axios.$post('/api/forum/postForm', data)) 
  // 删除文章
  inject('forumDeleteArtical', data => $axios.$post('/api/forum/deleteArtical ', data))   
  // 顶置文章
  inject('forumAdreTop', data => $axios.$post('/api/forum/adreTop ', data))   
  // 获取验证码
  inject('getAuthCode', data => $axios.$post('/api/auth/code', data))
  // 登录
  inject('authLogin', data => $axios.$post('/api/auth/login', data))
  // 注册
  inject('authRegiste', data => $axios.$post('/api/auth/register', data))
  // 获取更新用户信息
  inject('authBalance', data => $axios.$get('/api/auth/balance', {params: data}))
  // 修改昵称
  inject('authSetName', data => $axios.$post('/api/auth/setName', data))
  // 修改密码
  inject('authSetPwd', data => $axios.$post('/api/auth/setPwd', data))


  


  inject('forumGetUser', data => $axios.$get('/api/forum/getUser', {params: data})) 
  //启用，禁用账户
  inject('forumForbitUser', data => $axios.$post('/api/forum/forbitUser', data))
  //启用，禁用作业
  inject('forumForbitWork', data => $axios.$post('/api/forum/forbitWork', data))  
  //清空用户积分
  inject('forumClearUserCoin', data => $axios.$post('/api/forum/clearUserCoin', data))

  

     // authSetName:'/api/auth/setName',//修改昵称
  // authSetPwd:'/api/auth/setPwd',//修改密码
  

  
  //获取文章列表
  // apiForumGetList: "/api/forum/getList",
  // videoCateList: "/mobile/video/cateList",
  // mobileUser: '/mobile/user/indexs',
  // mobileIndexIndex:'/mobile/index/index',//广告轮播图接口
  // mobileVideoSearch: '/mobile/video/search',//全部视频
  // mobileUserLogin: '/api/auth/login',//登录
  // mobileVideoIndex:'/mobile/video/index',
  // mobileUserRegister:'/api/auth/register',//注册
  // mobileUserJq:'/mobile/user/jq',//下载次数这里获取传uuid
  // mobileIndexSc:'/mobile/index/sc',//收藏
  // orumSearch:'/api/forum/search',//搜索
  // apiForumPostForm:'/api/forum/postForm',//添加编辑文章
  // forumArticle:'/api/forum/article',//文章详情
  // forumArtBuyList:'/api/forum/getContact',//购买联系方式
  // authBalance:'/api/auth/balance',
  // forumSetLike:'/api/forum/setLike',//点赞和踩 评论

  // forumHistoryList:'/api/forum/historyList',//发布记录
  // forumBuyList:'/api/forum/buyList',//购买记录
  // payBillChange:'/api/pay/billChange',//资金明细
  
  // authSetName:'/api/auth/setName',//修改昵称
  // authSetPwd:'/api/auth/setPwd',//修改密码
  // authSetPicture:'/api/auth/setPicture',//修改头像
  // payBuyVip:'/api/pay/buyVip',//vip购买
  // payBuyCoin:'/api/pay/buyCoin',//套餐充值
  // forumDeleteArtical:'/api/forum/deleteArtical',//删除帖子
  // forumCommentList:'/api/forum/commentList',//评论列表
  // forumPostModelXf:'/api/forum/postModelXf/',//添加
  // forumArticleXf:'/api/forum/articleXf',
  // forumGetListXf:'/api/forum/getListXf',//列表
  // forumGetBuyStatus:'/api/forum/getBuyStatus',//是否购买
  // apiAuthTokenExp:'/api/auth/tokenExp',
  // forumSetOpinion:'/api/forum/setOpinion' 
}

export default axiosapi
