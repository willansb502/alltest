<template>
  <div class="footer-wrap">
    <div
      v-for="(item, index) in menuList"
      :key="index"
      class="footer-item"
      @click="setActive(item)"
    >
      <div class="ico">
        <img :src="item.imgDefault" alt="">
      </div>
      <div class="text">
        {{ item.text }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    footerIndex:{
      type: Number,
      default() {
        return 0
      },
    },
  },
  data() {
    return {
      // 按钮列表
      menuList: [
        {
          text:'首页',
          index: 0,
          imgDefault:'/images/footerBar/p1.png',
          url: '/',
        },
        {
          text:'作业',
          index: 1,
          imgDefault:'/images/footerBar/p2.png',
          url: '/works',

        },
        {
          text:'我的',
          index: 2,
          imgDefault:'/images/footerBar/p3.png',
          url: '/mine',
        }
      ],
    }
  },
  methods: {
    setActive(item) {
      this.$router.push(item.url);
    },  
  },
  mounted() {
  },
  computed: {
  }  
}
</script>

<style scoped lang="scss">
.footer-wrap {
  box-shadow: 0px 0px 0.08rem 0px rgba(0,0,0,0.5);
  position: fixed;
  bottom: 0;
  display: flex;
  width: 100%;
  max-width: $pcMaxWidth;
  z-index: 10;
  background: #fff;
  .footer-item {
    padding-top: 0.17rem;
    padding-bottom: constant(safe-area-inset-bottom);  /*兼容 IOS&gt;11.2*/
    padding-bottom: env(safe-area-inset-bottom);  /*兼容 IOS&gt;11.2*/
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex: 1;
    font-size: 0.26rem;
    .ico {
      width: 0.5rem;
      height: 0.5rem;
      img {
        width: 100%;
        height: 100%;
      }
    }
    .text {
      margin-top: 0.06rem;
      &.active {
        color: #408ceb;
      }
    }
  }
}
</style>


