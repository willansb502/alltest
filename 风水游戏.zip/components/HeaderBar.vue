<template>
  <div class="header-wrap">
    <van-icon v-if="showBack" @click="$router.go(-1)" class="arrow-lef" name="arrow-left" />
    <div class="navText">{{navText}}</div>
    <slot></slot>
  </div>
</template>

<script>
export default {
  props: {
    navText:{
      type: String,
      default() {
        return ''
      },
    },
    showBack:{
      type: Boolean,
      default() {
        return true
      },
    },
  },
  data() {
    return {
    }
  },
  methods: { 
  },
  mounted() {
  },
  computed: {
  }  
}
</script>

<style scoped lang="scss">
.header-wrap {
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 99;
  position: fixed;
  top: 0;
  left:auto;
  width: 100%;
  max-width: $pcMaxWidth;
  height: 1rem;
  background: #EFEFEF;
  color: #000;
  .arrow-lef{
    left: 0;
    position: absolute;
    padding-left: 0.1rem;
    color: #000;
    font-size: 0.54rem;
  }
  .navText{
    font-weight: 700;
    font-size: 0.35rem;
  } 
}
</style>


