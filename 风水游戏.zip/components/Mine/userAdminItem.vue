<template>
  <div class="note-item ">
    <div class="top-box">
      <div class="left">
        <div class="top-txt free" v-if="item.status==1">启用中</div>
        <div class="top-txt" v-else>禁用中</div>
        {{item.userName}}<template v-if="+item.vip==1">(管)</template><br>{{item.account}} <span style="padding-left:3px" v-if="item.remarks">({{item.remarks}})</span>
      </div>
      <div class="right" v-if="type=='积分管理'">
       <span class="fenshu" >总积分:{{item.coinTotal}}<br></span> 
       <span class="clear">清空积分</span>        
      </div>
      <div class="right" v-else>
        <span v-if="item.wechat">{{'微信:'+item.wechat}}<br></span> 
        <span v-if="item.qq">{{'QQ:'+item.qq}}</span>
      </div>   
    </div>
  </div>	
</template>

<script>
export default {
  props: {
    type:{
      type: String,
      default() {
        return ''
      },
    },    
    item:{
      type: Object,
      default() {
        return {}
      },
    },
  },
  data() {
    return {
    }
  },
  methods: {
  },
  mounted() {
  },
  computed: {
  }  
}
</script>

<style scoped lang="scss">
  .note-item{
    padding-top: 0.40rem;
    padding-bottom: 0.40rem;
    border-bottom:  1px solid #979797;	
    &:last-child{
      border-bottom: 0;	
    }		
    color:#000;
    .top-box{
      display: flex;
      align-items: center;
      justify-content: space-between;
      .left{
        display: flex;
        align-items: center;
        font-size: 0.35rem;
        .top-txt{
          font-size: 0.24rem;
          padding: 0 0.1rem;
          text-align: center;
          color: #fff;
          background: #D93233;
          border: 1px solid #D93233;
          margin-right: 0.20rem;
          &.free{
            color: #fff;
            background: #07c160;
            border: 1px solid #07c160;
          }
        }
      }
      .right{
        // color: #fff;
        // background-color: #ee0a24;
        border-radius: 0.04rem;
        padding: 0 0.1rem; 
        text-align: center;
        font-size: 0.26rem;
        .clear{
          background: #D93233;
          border: 1px solid #D93233;
          color: #fff;
          padding: 0.02rem 0.1rem;
        }
        .fenshu{
          max-width: 100%;
          text-align: center;
          line-height: .56rem;
          margin-right: 0.25rem;
          font-weight: 600;
          text-overflow: ellipsis;
          overflow: hidden;
          white-space: nowrap;
          color: transparent;
          background: -webkit-linear-gradient(left,#f4ce4e,#ef0c0c);
          background: linear-gradient(90deg,#f4ce4e,#ef0c0c);
          -webkit-background-clip: text;
         font-size: 0.30rem;
        }
      }
    } 		
  }
</style>


