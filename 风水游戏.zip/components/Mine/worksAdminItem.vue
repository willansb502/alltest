<template>
  <div  @click="goDetail(item)" class="note-item ">
    <div class="top-box">
      <div class="left-wrap">
        <div class="top-txt" v-if="item.status==2">未审核</div>
        <div class="top-txt free" v-else>已审核</div>
        {{item.teacherName}} <span style="padding-left:3px" v-if="item.remarks">({{item.remarks}})</span>
      </div>
      <div class="right-wrap">
        <div class="right" @click.stop.prevent="fn_forbitWork" v-if="item.status==2">
          审核按钮
        </div>             
        <div class="right">
          {{item.mark||8}}分
        </div>        
      </div>

    </div>
    <div class="bottom-box">
      <span>昵称:{{item.userName}}</span>
      <span v-if="item.wechat">微信:{{item.wechat}}</span> 
      <span class="copy" @click.stop.prevent="fn_copy">复制</span>
      <span v-if="item.qq">qq:{{item.qq}}</span>
    </div>
    <div class="decial">查看详情</div>
  </div>	
</template>
<script>
export default {
  props: {
    item:{
      type: Object,
      default() {
        return {}
      },
    },
  },
  data() {
    return {
    }
  },
  methods: {
    //拷贝
    fn_copy(){
				this.$copyText(
					'作业详情:\n'+
					'地址:'+window.location.host+'/works/detail?formID='+this.item.formID+'\n'+
					'老师:'+this.item.teacherName+'\n'+	
					'学费:'+this.item.price+'P\n'+
					'学生网站昵称:'+this.item.userName+'\n'+
					'微信:'+this.item.wechat+'\n'+
					'qq:'+this.item.qq
				).then(message => {
					this.$toast('复制成功');
				}).catch(err => {
					this.$toast("复制失败！") ;
				})
    },
    //禁用作业
    fn_forbitWork(){
      this.$emit('fn_forbitWork',this.item)
    },
    //作业详情 
    goDetail(){
      this.$router.push({
        path:'/works/detail',
        query:{
          formID:this.item.formID
        }
      });
    }   
  },
  mounted() {
  },
  computed: {
  }  
}
</script>

<style scoped lang="scss">
  .note-item{
    padding-top: 0.20rem;
    padding-bottom: 0.20rem;
    border-bottom:  1px solid #979797;	
    &:last-child{
      border-bottom: 0;	
    }		
    color:#000;
    .top-box{
      .left-wrap{
        display: flex;
        align-items: center;
        font-size: 0.35rem;
        .top-txt{
          font-size: 0.24rem;
          height: 0.45rem;
          padding: 0 0.1rem;
          line-height: 0.45rem;
          text-align: center;
          color: #D93233;
          border: 1px solid #D93233;
          margin-right: 0.20rem;
          &.free{
            color: #fff;
            background: #07c160;
            border: 1px solid #07c160;
          }          
        }
      }
      .right-wrap{
        display: flex;
        .right{
          margin: 0.1rem 0;
          margin-right:0.1rem;
          color: #fff;
          background-color: #ee0a24;
          border-radius: 0.04rem;
          height: 0.45rem;
          padding: 0 0.1rem;
          line-height: 0.45rem;
          text-align: center;
          font-size: 0.26rem;
        }        
      }

    } 
    .bottom-box{
      font-size: 0.32rem;
      .copy{
        font-size: 0.26rem;
        padding: 0.05rem 0.1rem;
        border: 1px solid #ccc;
      }
    }	
    .decial{
      padding-top: 0.1rem;
      font-size: 0.28rem;
      text-decoration: underline;
      color: #5BA7E5;
    }	
  }
</style>


