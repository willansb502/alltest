<template>
  <div @click="goDetail(item)" class="note-item ">
    <div class="top-box">
      <div class="left">
        <div class="color-num" :style="{background:colorItem.color}">{{index_num+1}}</div>
        <div class="top-txt">💖</div>
        {{item.teacherName}}<div v-if="item.coinTotal>=8">🔥</div>
        <div v-else>🌷</div>

        
      </div>
      <div class="right">
        作业数:{{item.coinTotal||0}}篇
      </div>
    </div>
  </div>	
</template>

<script>
export default {
  props: {
    index_num:{
      type: Number,
      default() {
        return 0
      },
    },
    item:{
      type: Object,
      default() {
        return {}
      },
    },
  },
  data() {
    return {
      colorItem:{}
    }
  },
  methods: {
    //随机获取排行颜色
    randomColor(){
      let colorArr=[
        {title: '嫣红',name: '🌙',color: '#e54d42'},
        {title: '桔橙',name: '💕',color: '#f37b1d'},
        {title: '明黄',name: '💥',color: '#fbbd08'},
        {title: '橄榄',name: '💖',color: '#8dc63f'},
        {title: '森绿',name: '💓',color: '#39b54a'},
        {title: '天青',name: '💝',color: '#1cbbb4'},
        {title: '海蓝',name: '💙',color: '#0081ff'},
        {title: '姹紫',name: '💛',color: '#6739b6'},
        {title: '木槿',name: '🌟',color: '#9c26b0'},
        {title: '桃粉',name: '👑',color: '#e03997'},
        {title: '棕褐',name: '🥰',color: '#a5673f'},
        {title: '玄灰',name: '🎁',color: '#8799a3'},
      ];
      return  colorArr[Math.floor((Math.random()*colorArr.length))];
    },    
    //作者详情 
    goDetail(item){   
      this.$router.push({
        path:'/works/teacher-works',
        query:{
          teacherName:item.teacherName
        }
      });
    }
  },
  mounted() {
    this.colorItem=this.randomColor();
  },
	computed: {
		token({ $store }) {
			return $store.state.user.token
		}	
	},
}
</script>

<style scoped lang="scss">
  .note-item{
    padding-top: 0.40rem;
    padding-bottom: 0.40rem;
    border-bottom:  1px solid #979797;	
    &:last-child{
      border-bottom: 0;	
    }		
    color:#000;
    .top-box{
      display: flex;
      justify-content: space-between;
      .left{
        display: flex;
        align-items: center;
        font-size: 0.35rem;
        .color-num{
          box-sizing: border-box;
          min-width: 0.45rem;
          padding: 0.05rem;
          height: 0.45rem;
          line-height: 0.45rem;
          margin-right: 0.1rem;
          color: #fff;
          background: #d93233;
          text-align: center;
        }
        .top-txt{
          font-size: 0.24rem;
          width: 0.70rem;
          height: 0.45rem;
          line-height: 0.45rem;
          text-align: center;
          color: #D93233;
          border: 1px solid #D93233;
          margin-right: 0.20rem;
        }
      }
      .right{
        max-width: 100%;
        text-align: center;
        line-height: 0.56rem;
        margin-right: 0.25rem;
        font-weight: 600;
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
        color: transparent;
        background: linear-gradient(90deg, #f4ce4e, #ef0c0c);
        -webkit-background-clip: text;
        font-size: 0.3rem;
      }
    } 		
  }
</style>