<template>
  <div @click="goDetail(item)" class="note-item ">
    <div class="top-box">
      <div class="left">
        <div v-if="item.top==1" class="top-txt">{{'顶置'}}</div>
        <div v-if="showNew&&item.top!=1" class="top-txt">{{'最新'}}</div>
        {{item.teacherName}} <span style="padding-left:3px" v-if="item.remarks">({{item.remarks}})</span>
        <span class="upDateTime">{{$moment(item.upDateTime).format("YYYY-MM-DD")}}</span>
      </div>
      <div v-if="item.status==2" class="right status">
        未审核
      </div>      
      <div class="right">
        {{item.mark||8}}分
      </div>
    </div>
  </div>	
</template>

<script>
export default {
  props: {
    item:{
      type: Object,
      default() {
        return {}
      },
    },
  },
  data() {
    return {
      showNew:false
    }
  },
  methods: {    
    //作业详情 
    goDetail(){
      
      this.$router.push({
        path:'/works/detail',
        query:{
          formID:this.item.formID
        }
      });
    }
  },
  mounted() {
    if(+this.item.upDateTime>=new Date(new Date().setHours(0,0,0,0)).getTime()){
      this.showNew=true;
    }
  },
  computed: {
  }  
}
</script>

<style scoped lang="scss">
  .note-item{
    padding-top: 0.40rem;
    padding-bottom: 0.40rem;
    border-bottom:  1px solid #979797;	
    &:last-child{
      border-bottom: 0;	
    }		
    color:#000;
    .top-box{
      display: flex;
      justify-content: space-between;
      .left{
        display: flex;
        align-items: center;
        font-size: 0.35rem;    
        .upDateTime{
          padding-left: 0.1rem;
          font-size: 0.28rem;
        }
        .top-txt{
          font-size: 0.24rem;
          width: 0.70rem;
          height: 0.45rem;
          line-height: 0.45rem;
          text-align: center;
          color: #D93233;
          border: 1px solid #D93233;
          margin-right: 0.20rem;
        }
      }
      .right{
        color: #fff;
        background-color: #ee0a24;
        border-radius: 0.04rem;
        width: 0.70rem;
        height: 0.45rem;
        line-height: 0.45rem;
        text-align: center;
        font-size: 0.26rem;
        &.status{
          padding: 0 0.1rem;
          width: auto;
        }
      }
    } 		
  }
</style>


