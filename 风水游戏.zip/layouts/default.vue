<template>
<div class="main-content-wrap">
  <Nuxt 
      keep-alive 
      :keep-alive-props="{
        include: [
          'pageAlive'
        ]
      }"
   />  
  <FooterBar></FooterBar>
</div>

</template>

<script>
export default {
  components: {
    FooterBar: () => import('@/components/footerBar.vue')
  },		
};
</script>
<style lang="scss" scoped>
.main-content-wrap{
  margin-bottom: 1.5rem;
}
</style>

