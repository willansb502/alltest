
const routerPrefix = process.env.NODE_ENV === 'production' ? './' : '';
const config = {
  router: {
    mode: 'hash',
    base: routerPrefix
  },  
  // Global page headers: https://go.nuxtjs.dev/config-head
  head: {
    title: '免费看手相,免费看脸相,星座配对,mbti人格职业测试',
    htmlAttrs: {
      lang: 'en'
    },
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'keywords', name: 'keywords', content: '免费看手相,免费看脸相,星座配对,mbti人格职业测试' },
      { hid: 'description', name: 'description', content: '缘起缘落风水之家旨在免费为每一个人提供星座配对、占星资讯、生肖分析、塔罗抽卡、命理资讯、姓名取名、八字测算、情感分析建议，风水装修建，寻求生命的缘起缘落，风水装修请认准-缘起缘落风水之家网' },
      { name: 'format-detection', content: 'telephone=no' }
    ],
    link: [
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' }
    ],
    script: [
      { src: routerPrefix +'/lib/rem.js', type: 'text/javascript', charset: 'utf-8'}
    ],    
  },

  // Global CSS: https://go.nuxtjs.dev/config-css
  css: [
    'vant/lib/index.css',
    '@/assets/scss/common.scss'
  ],

  // Plugins to run before rendering page: https://go.nuxtjs.dev/config-plugins
  plugins: [
    { src: '@/plugins/userInfo.js', mode: 'client' },
    '@/plugins/axios',
    '@/api/api',
    '@/plugins/vant',
  ],

  // Auto import components: https://go.nuxtjs.dev/config-components
  components: false,

  // Modules for dev and build (recommended): https://go.nuxtjs.dev/config-modules
  buildModules: ['@nuxtjs/style-resources','@nuxtjs/moment'],
  styleResources: {
    scss:[
      '@/assets/scss/index.scss'
    ]
  },
  axios: {
    proxy: true,
    browserBaseURL: '/',
    headers: {
      'Content-Type': 'application/json'
    }
  },
  proxy: {
    '/api': {
      target:'http://localhost:27019/',
      pathRewrite: {
        '^/api': '/api'
      }
    },
    '/api2': {
      target:'http://localhost:27020/',
      pathRewrite: {
        '^/api2': '/api'
      }
    },    
  },  
  // Modules: https://go.nuxtjs.dev/config-modules
  modules: [
    '@nuxtjs/axios'   
  ],
  // Build Configuration: https://go.nuxtjs.dev/config-build
  build: {
    productionSourceMap: false
  },
  server:{
    port: 8000,//端口
    host: '0.0.0.0' // default: localhost   
  }  
};
export default config;