<template>
	<div class="content_page" >
		<!-- 头部导航 -->
    <HeaderBar :showBack="false" :navText="'登录'"></HeaderBar>		
		<div class="login_box">
			<div class="tip1">
				<img src="/images/login-img1.png">
				登录后查看全部内容
			</div>
			<div class="tip2">
				<img src="/images/login-img2.png">
				已开放注册，注册后请联系管理员审核账号
			</div>
			<div class="form">
				<div class="uni-form-item">
					<div class="left_title">用户名:</div>	
					<input type="text"  autocomplete="off"  class="username" placeholder="请输入用户名"
					 v-model.trim="loginInfo.account" />
				</div>
				<div class="uni-form-item">
					<div class="left_title">密码:</div>	
					<input type="password"  autocomplete="off"  class="username" placeholder="请输入密码"
					 v-model.trim="loginInfo.pwd" />
				</div>	
				<div class="uni-form-item">
					<div class="left_title">验证码:</div>	
					<input type="text"  autocomplete="off"  class="username" placeholder="请输入验证码"
					 v-model.trim="loginInfo.code" />
					<div @click="getAuthCode" class="codeImg" v-html="codeImg">
					</div>					 
				</div>														
			</div>
			<div class="button_gloup">
				<div class="login_btn primary" formType="submit" @click="signUp">
					立即登录
				</div>
				<div class="login_btn register" formType="submit" @click="$router.push(`/auth/regist`)">
					立即注册
				</div>
			</div>
		</div>
	</div>
</template>

<script>
export default {
	head() {
		return {
			title: "这是登录页",
			meta: [
				{
					hid: 'description',
					name: 'description',
					content: 'My custom description'
				}
			]
		}
	},	
  components: {
		HeaderBar: () => import('@/components/HeaderBar.vue')
  },    
  data() {
    return {
      loginInfo:{
        account:'',
        pwd:'',
        code:''				
      },
      codeImg:'',
      codeObj:{}
    };
  },
  methods: {
    //登录
    async signUp() {	
      if(!this.loginInfo.account||!this.loginInfo.pwd||!this.loginInfo.code){
        return this.$toast("输入信息不全")
      }
      if(this.loginInfo.code.toLowerCase()!=this.codeObj.code.toLowerCase()){
        this.getAuthCode();
        this.loginInfo.code='';
        return this.$toast("验证码有误") 
      }
      this.$toast('登录中...');
      const res = await this.$authLogin(this.loginInfo)
      if (res.code == 200) {
        this.$store.commit('user/setUserInfo', res.result);
        this.$store.commit('user/setToken', res.result.token);
				localStorage.xhToken=res.result.token;
				localStorage.xhUserInfo=JSON.stringify(res.result);
        this.$router.push('/');
        this.$toast.success('登录成功');
      } else {
        this.$toast(res.message);
      }	
    },
    //获取验证码
    async getAuthCode(){
      const res = await this.$getAuthCode({})
      if (res.code == 200) {
        this.codeObj=res.result;
        this.codeImg=res.result.img;
      } else {
        this.$toast(res.message);
      }		
    }
  },
  mounted(){
    if(this.token){
      return this.$router.push('/mine');
    }			
    this.getAuthCode();	
  },
	computed: {
		token({ $store }) {
			return $store.state.user.token;
		}	
	},	
};
</script>

<style scoped lang="scss">
	.content_page {
		padding-top: 1rem;
		.login_box {
			background: rgba(255, 255, 255, 0.8);
			padding-top: 0.20rem;
			box-sizing: border-box;
			.tip1,.tip2{
				width: 6.90rem;
				margin: 0 auto;
				padding-left: 0.20rem;
				color: #3483D6;
				background: rgb(236, 249, 255);	
				height: 0.80rem;
				font-size: 0.30rem;
				display: flex;
				align-items: center;
				img{
					width:0.35rem;
					height:0.43rem;
					margin-right: 0.20rem;
				}									
			}
			.tip2{
				color: #D07427;
				background: #FFFBE8;
				margin-top: 0.20rem;
				margin-bottom: 0.20rem;
			}

			.form {
				uni-input {
					height: 0.70rem;
					line-height: 0.70rem;
					width: 4.60rem;
				}
				.uni-form-item{	
					position: relative;
					height: 1rem;
					display: flex;
					align-items: center;	
					border-bottom:1px solid #979797 ;	
					.left_title{
						font-size: 0.35rem;
						color: #000;
						text-align: left;
						line-height: 0.70rem;
						word-wrap: break-word;
						width: 1.90rem;
						padding-left: 0.20rem;					
					}
					.codeImg{
						z-index: 9;
						position: absolute;
						top: 0;
						right: 0;
					}	
          input{
            outline: 0;
            border: 0;
          }				
				}
			}

			.button_gloup {
        text-align: center;
				.login_btn {
					color: #fff;
					background-color: #1989fa;
					border: 1px solid #1989fa;
					border-radius: 999px;
					width: 6.90rem;
					height: 1rem;
          line-height: 1rem;
					margin: 0 auto;
					font-size: 0.35rem;
					margin-top: 1rem;
					&.register{
						margin-top: 0.50rem;
						background: #05BF5E;
						border: 1px solid #05BF5E;
					}
				}
			}

		}
	}

</style>
