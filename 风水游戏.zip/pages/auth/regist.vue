<template>
	<div class="content_page" >
		<HeaderBar :showBack="false" :navText="'注册'"></HeaderBar>	
		<div class="login_box">
			<div class="tip1">
				<img src="/images/login-img1.png">
				登录后查看全部内容
			</div>
			<div class="tip2">
				<img src="/images/login-img2.png">
				已开放注册，注册后请联系管理员审核账号
			</div>
			<template v-if="!showCopyText">
				<div class="form" >
					<div class="uni-form-item">
						<div class="left_title">用户名:</div>	
						<input type="text"  autocomplete="off"  class="username" placeholder="请输入用户名"
						v-model.trim="registInfo.account" />
					</div>
					<div class="uni-form-item">
						<div class="left_title">密码:</div>	
						<input type="password"  autocomplete="off"  class="username" placeholder="请输入密码"
						v-model.trim="registInfo.pwd" />
					</div>	
					<div class="uni-form-item">
						<div class="left_title">确认密码:</div>	
						<input type="password"  autocomplete="off"  class="username" placeholder="请再次输入密码"
						v-model.trim="registInfo.comPwd" />
					</div>		
					<div class="uni-form-item">
						<div class="left_title">昵称:</div>	
						<input type="text"  autocomplete="off"  class="username" placeholder="请输入您的昵称"
						v-model.trim="registInfo.userName" />
					</div>		
					<div class="uni-form-item">
						<div class="left_title">微信ID:</div>	
						<input type="text"  autocomplete="off"  class="username" placeholder="微信号或QQ号至少写一个"
						v-model.trim="registInfo.wechat" />
					</div>	
					<div class="uni-form-item">
						<div class="left_title">QQ号:</div>	
						<input type="number"  autocomplete="off"  class="username" placeholder="微信号或QQ号至少写一个"
						v-model.trim="registInfo.qq" />
					</div>																	
					<div class="uni-form-item">
						<div class="left_title">验证码:</div>	
						<input type="text"  autocomplete="off"  class="username" placeholder="请输入验证码"
						v-model.trim="code" />
						<div @click="getAuthCode" class="codeImg" v-html="codeImg">
						</div>					 
					</div>																					
				</div>
				<div class="button_gloup">
					<div class="login_btn primary" formType="submit" @click="fn_register">
						<div>提交</div>
					</div>
				</div>
			</template>
			<template v-if="showCopyText">
				<div class="copy-msg">
					<img class="success" src="/images/success.png">
					<div>注册成功:</div>
					<div style="color:#4867D8;padding-bottom:0.50rem;">复制以下内容发送给管理员</div>
					<div style="text-align:left;">尊敬的管理员，请帮忙审批账号</div>
					<div style="text-align:left;padding-bottom:0.1rem;">账号:{{registInfo.account}}</div>
					<div style="text-align:left;padding-bottom:0.1rem;">昵称:{{registInfo.userName}}</div>
					<div style="text-align:left;padding-bottom:0.1rem;">微信:{{registInfo.wechat}}</div>
					<div style="text-align:left;padding-bottom:0.1rem;">QQ号:{{registInfo.qq}}</div>
				</div>	

				<div class="button_gloup">
					<div class="login_btn primary" formType="submit" @click="copyContact">
						<div>复制审核信息</div>
					</div>
				</div>				
			</template>
		</div>
	</div>
</template>

<script>
export default {
	components: {
		HeaderBar: () => import('@/components/HeaderBar.vue')
	},  		
	data() {
		return {
			//复制显示
			showCopyText:false,
			//注册需要
			codeObj:'',
			codeImg:'',
			code:'',
			registInfo:{
				account:'',
				pwd:'',
				comPwd:'',
				userName:'',
				wechat:'',
				qq:''			
			},
			
		};
	},
	methods: {
    //获取验证码
    async getAuthCode(){
      const res = await this.$getAuthCode({})
      if (res.code == 200) {
        this.codeObj=res.result;
        this.codeImg=res.result.img;
      } else {
        this.$toast(res.message);
      }		
    },					
		async fn_register() {	
			if(
				!this.code||
				!this.registInfo.account||
				!this.registInfo.pwd||
				!this.registInfo.comPwd||
				!this.registInfo.userName||
				!this.registInfo.wechat&&!this.registInfo.qq
			){
				return this.$toast("输入信息不全") ;
			}
			if(this.code.toLowerCase()!=this.codeObj.code.toLowerCase()){
				this.getAuthCode();
				return this.$toast("验证码有误") ;
			}
			this.$toast("注册中...") ;
      const res = await this.$authRegiste(this.registInfo)
      if (res.code == 200) {
				this.$toast.success('注册成功，请联系管理员通过审核');
				this.showCopyText=true;
      } else {
        this.$toast(res.message);
      }
		},
		//复制成功信息
		copyContact () {

			this.$copyText(
				'尊敬的管理员，请帮忙审批账号:\n'+
				'账号:'+this.registInfo.account+'\n'+	
				'昵称:'+this.registInfo.userName+'\n'+	
				'微信:'+this.registInfo.wechat+'\n'+	
				'QQ号:'+this.registInfo.qq+'\n'
			).then(message => {
				this.$toast.success('复制成功');
			}).catch(err => {
				this.$toast("复制失败！") ;
			})
		}						
	},
	mounted(){
		this.getAuthCode();
	}
};
</script>

<style scoped lang="scss">
	.content_page {
			padding-top: 1rem;
	  	padding-bottom: 2rem;
		.login_box {
			background: rgba(255, 255, 255, 0.8);
			padding-top: 0.20rem;
			box-sizing: border-box;
			.tip1,.tip2{
				width: 6.90rem;
				margin: 0 auto;
				padding-left: 0.20rem;
				color: #3483D6;
				background: rgb(236, 249, 255);	
				height: 0.80rem;
				font-size: 0.30rem;
				display: flex;
				align-items: center;
				img{
					width:0.35rem;
					height: 0.43rem;
					margin-right: 0.20rem;
				}									
			}
			.tip2{
				color: #D07427;
				background: #FFFBE8;
				margin-top: 0.20rem;
				margin-bottom: 0.20rem;
			}

			.form {
				uni-input {
					height: 0.70rem;
					line-height: 0.70rem;
					width: 4.60rem;
				}
				input{
					outline: 0;
					border: 0;
				}
				.uni-form-item{	
					position: relative;
					padding-right: 0.2rem;
					height: 1rem;
					display: flex;
					align-items: center;	
					border-bottom:1px solid #979797 ;
					.codeImg{
						position: absolute;
						right: 0;
					}	
					.left_title{
						white-space: nowrap;
						font-size: 0.35rem;
						color: #000;
						text-align: left;
						line-height: 0.70rem;
						word-wrap: break-word;
						width: 1.90rem;
						padding-left: 0.20rem;					
					}
				}
			}

			.button_gloup {
				.login_btn {
					color: #fff;
					background-color: #1989fa;
					border: 1px solid #1989fa;
					border-radius: 999px;
					width: 6.90rem;
					height: 1rem;
					line-height: 1rem;
					margin: 0 auto;
					font-size: 0.35rem;
					margin-top: 0.5rem;
					text-align: center;
					&.register{
						margin-top: 0.50rem;
						background: #05BF5E;
						border: 1px solid #05BF5E;
					}
				}
			}

		}
		.copy-msg{
			text-align: center;
			.success{
				width: 0.80rem;
				height: 0.80rem;
			}
			padding: 0.40rem 0.40rem 0 0.40rem;
			font-size: 0.35rem;
		}
	}

</style>
