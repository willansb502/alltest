<template>
	<div class="home-index" >

	</div>
</template>
<script>
export default {
	name:"pageAlive",
  components: {
		// WorkCard: () => import('@/components/WorkCard.vue'),
  },	
	data() {
		return {
			loading:false,
			refreshing:false,
			finished:false,
      pageNum: 1,
      pageSize: 10,			
			typeObj:{
				active:"最新作业",
				list:[
					"最新作业",
					"老师排行榜",
					// "客户积分榜"
				]
			},
			dataList:[],
			teacherList:[],
			userCoinsList:[]
		};
	},
	methods: {
		
	},
	async mounted() {
	},	
	computed: {
	},		
};
</script>

<style lang="scss" scoped>
.home-index{

}
</style>
