<template>
  <div>
    <div class="page-title">
      我的信息
    </div>	
    <div class="welcome">昵称【{{userInfo.userName}}】</div>
    <div class="welcome">等级【{{level}}】- 积分【{{userInfo.coinTotal?userInfo.coinTotal:'0'}}分】</div>
    <div class="main-wrap">
      <div class="my-work" @click="$router.push('/mine/my-post')">我提交的作业</div>
      <div class="setting">
        <div @click="$router.push('/mine/userName-setting')">修改昵称</div>
        <div @click="$router.push('/mine/password-setting')">修改密码</div>
      </div>
      <div class="logout" @click="logout">退出登录</div>
    </div>
    <div class="admin-space" v-if="userInfo.vip==1">
      <div class="title">以下仅管理员可见：</div>
      <div class="setting">
        <div @click="$router.push('/mine/works-admin')">审核作业</div>
        <div @click="$router.push('/mine/users-admin')">用户审核</div>
      </div>
      <div class="setting">
        <!-- <div @click="$router.push('/mine/works-admin')">发布公告</div> -->
        <div @click="$router.push('/mine/wechat-robot')">机器人登录</div>
        <div @click="$router.push('/mine/users-coin')">积分管理</div>
      </div>             
    </div>	
  </div>
</template>

<script>
// this.$router.push('/pages/userCenter/机器人登录');

export default {
  name:"pageAlive",
  components: {
  },	  
  data() {
    return {
      level:'新手',
      listData: [
        {
          url: "/pages/userCenter/我提交的作业",
          style: {
            width: '2rem',
            height: '2rem',
            marginLeft: '-2px'
          },
          icon: "#iconxunzhang1",
          title: "我提交的作业"
        },									
        {
          url: "/pages/userCenter/账号管理",
          style: {
            width: '2.1rem',
            height: '2.3rem',
            marginLeft: '-3px'
          },
          icon: "#iconbiaoqian1",
          title: "修改昵称"
        },
        {
          url: "/pages/userCenter/账号管理",
          style: {
            width: '2rem',
            height: '2rem'
          },
          icon: "#iconaixin2",
          title: "修改密码"
        },
        // {
        // 	url: "/pages/userCenter/修改标签",
        // 	style: {
        // 		width: '2rem',
        // 		height: '2rem'
        // 	},
        // 	icon: "#iconyoujian",
        // 	title: "修改标签"
        // },
        {
          url: "",
          style: {
            width: '2rem',
            height: '2rem'
          },
          icon: "#iconanquan1",
          title: "退出登录"
        }

      ],
      token:'',
      userInfo:{}
    };
  },
  async activated(){
   
    this.token=JSON.parse(JSON.stringify(this.$store.state.user.token))
    this.userInfo=JSON.parse(JSON.stringify(this.$store.state.user.userInfo))

    if(!this.token||!this.userInfo||!this.userInfo.userName){
      return this.$router.push('/auth/login');
    }
    await this.$store.dispatch('user/authBalance');
    if(!this.userInfo.coinTotal&&this.userInfo.coinTotal<10){
      this.level='新手';
    }
    if(this.userInfo.coinTotal&&this.userInfo.coinTotal>=10&&this.userInfo.coinTotal<100){
      this.level='初级';
    }
    if(this.userInfo.coinTotal&&this.userInfo.coinTotal>=100&&this.userInfo.coinTotal<200){
      this.level='中级';
    }
    if(this.userInfo.coinTotal&&this.userInfo.coinTotal>=200){
      this.level='高级';
    };
    
  },
  mounted(){
  },
  computed: {
		// token({ $store }) {
		// 	return $store.state.user.token
		// },	    
		// userInfo({ $store }) {
		// 	return $store.state.user.userInfo
		// }	
  },
  methods:{
    //登出
    logout(){
      this.$store.commit('user/clearInfo');    
      this.$router.push('/auth/login');
    },
  }
};
</script>
<style lang="scss" scoped>
	.page-title{
		position: relative;
		background: #efefef;
		width: 100%;
		height: 1rem;
		color: #000;
		font-weight: 700;
		text-align: center;
		line-height: 1rem;
		font-size: 0.35rem;	
		.tohome{
			position: absolute;
			top: 0;
			left: 0.10rem;
			font-size: 0.56rem;
		}		 
	}
	.welcome{
		padding: 0 0.2rem;
		display: flex;
		align-items: center;
		justify-content: center;
		height: 1rem;
		color: #000;
		font-size: 0.35rem;
		border-bottom:1px solid #979797;
	}
	.main-wrap{
		.my-work,.logout{
      font-size: 0.35rem;
			width: 6.90rem;
			height: 1rem;
			line-height: 1rem;
			background: #EA5F48;
			color: #fff;
			text-align: center;
			margin: 0.50rem auto 0.20rem;
		}
		.logout{
			background: #C72D33;
		}
	}
  .setting{
    display: flex;
    justify-content: space-between;
    margin: 0 0.30rem;
    div{
      width: 3.35rem;
      height: 1rem;
      line-height:1rem;
      text-align: center;
      border:1px solid #CFCFCF;
      color: #000;
      font-size: 0.35rem;
    }
  }  
  .admin-space{
    padding-left: 0.3rem;
    padding-right: 0.3rem;
    .title{
      padding-bottom: 0.3rem;
    }
    .setting{
      margin: 0;
      margin-bottom: 0.3rem;
    }
  }

</style>
