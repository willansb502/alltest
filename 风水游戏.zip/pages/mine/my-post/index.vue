<template>
	<div class="home-index" >
		<!-- 头部导航 -->
    <HeaderBar :showBack="false" :navText="'我提交的作业'"></HeaderBar>
		<van-pull-refresh v-model="refreshing" @refresh="onRefresh">
      <van-list
        v-model="loading"
        :finished="finished"
        finished-text="暂时没有更多数据！"
        @load="onLoad"
        :immediate-check="false"
      >			
				<div class="content-outBox">
					<div class="teacher-card-list">
						<WorkCard :item="item" v-for="(item,index) in dataList" :key="index"></WorkCard>	
					</div>			
				</div>
			</van-list>
		</van-pull-refresh>		
	</div>
</template>
<script>
export default {
	name:"pageAlive",
  components: {
		WorkCard: () => import('@/components/WorkCard.vue'),
    HeaderBar: () => import('@/components/HeaderBar.vue')
  },	
	data() {
		return {
			loading:false,
			refreshing:false,
			finished:false,
			dataList:[],
      pageNum: 1,
      pageSize: 10,
			searchTxt:''
		};
	},
	methods: {
		//获取列表
		async forumGetList(type) {
			this.loading=true;
      const res = await this.$forumGetMySend({
				page: this.pageNum,
				searchTxt: this.searchTxt,
				pageSize: this.pageSize
      })
      if (res.code == 200) {
				this.refreshing = false;
				this.loading=false;

        if(type == "pull") this.dataList=[];
        
        if(!res||!res.result ||!res.result.data||res.result.data.length<this.pageSize){
          this.finished = true;
        }
				this.dataList=[... this.dataList,...res.result.data||[]];
      } else {
        this.refreshing = false;
        this.loading = false;
        this.finished = true;
        this.$toast(res.message);
      }
    }, 
    //下拉加载
    onLoad() {
      this.pageNum ++;
      this.forumGetList();
    },
     //上拉刷新
    onRefresh() {
      this.finished = false;
      this.loading = true;
      this.pageNum = 1;
			this.forumGetList('pull');
    },					
	},
	async mounted() {
		this.onRefresh();
	},	
	computed: {
		token({ $store }) {
			return $store.state.user.token
		}	
	},		
};
</script>

<style lang="scss" scoped>
.home-index{
	padding-top: 1rem;
	padding-bottom: 1.5rem;
	.content-outBox{
		padding: 0 0.2rem;			
	}	
}
</style>
