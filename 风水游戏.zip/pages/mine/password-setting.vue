<template>
	<div class="content_page" >
		<HeaderBar :navText="'修改密码'"></HeaderBar>
		<div class="login_box">
			<div class="form">
				<div class="uni-form-item">
					<div class="left_title">旧密码:</div>	
					<input type="text"  autocomplete="off"  class="username" placeholder="请输入旧密码"
					 v-model.trim="changePasswordForm.old_password" />
				</div>					
				<div class="uni-form-item">
					<div class="left_title">新密码:</div>	
					<input type="text"  autocomplete="off"  class="username" placeholder="请输入新密码"
					 v-model.trim="changePasswordForm.password" />
				</div>	
				<div class="uni-form-item">
					<div class="left_title">新密码:</div>	
					<input type="text"  autocomplete="off"  class="username" placeholder="再次输入新密码"
					 v-model.trim="changePasswordForm.confirm_password" />
				</div>																
			</div>
			<div class="button_gloup ">
				<div class="login_btn primary" formType="submit" @click="changePassword">
					<div>立即修改</div>
				</div>
			</div>
		</div>
	</div>		
</template>

<script>
export default {
	components: {
		HeaderBar: () => import('@/components/HeaderBar.vue')
	},  		
	data() {
		return {
			changePasswordForm: {
				old_password:'',
				password: "",
				confirm_password: ""
			}
		}
	},		
	methods: {
		async	changePassword() {				
			if(
				!this.changePasswordForm.old_password||
				!this.changePasswordForm.password||
				!this.changePasswordForm.confirm_password||
				this.changePasswordForm.confirm_password!=this.changePasswordForm.password
			){
				return	 this.$toast("信息输入有误");
			}
			this.$toast('修改中...');
			const res = await this.$authSetPwd(this.changePasswordForm)
			if (res.code == 200) {
				this.$toast.success('修改成功');
				this.$store.commit('user/clearInfo'); 
				this.$router.push('/auth/login');
			} else {
				this.$toast(res.message);
			}	
		}
	}
};
</script>

<style scoped lang="scss">
	.content_page {
		padding-top: 0.88rem;
		.login_box {
			background: rgba(255, 255, 255, 0.8);
			padding-top: 0.20rem;
			box-sizing: border-box;
			.form {
				uni-input {
					height: 0.70rem;
					line-height: 0.70rem;
					width: 4.60rem;
				}
				.uni-form-item{	
					position: relative;
					height: 1rem;
					display: flex;
					align-items: center;	
					border-bottom:1px solid #979797 ;	
					input{
						border: 0;
						outline: 0;
					}
					.left_title{
						font-size: 0.35rem;
						color: #000;
						text-align: left;
						line-height: 0.70rem;
						word-wrap: break-word;
						width: 1.90rem;
						padding-left: 0.20rem;					
					}
					.codeImg{
						z-index: 9;
						position: absolute;
						top: 0;
						right: 0;
					}					
				}
			}

			.button_gloup {
				.login_btn {
					text-align: center;
					color: #fff;
					background-color: #1989fa;
					border: 1px solid #1989fa;
					border-radius: 999px;
					width: 6.90rem;
					height: 1rem;
					line-height: 1rem;
					margin: 0 auto;
					font-size: 0.35rem;
					margin-top: 0.50rem;
				}
			}

		}
	}
</style>
