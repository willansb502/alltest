<template>
	<div class="content_page" >
		<HeaderBar :navText="'修改昵称'"></HeaderBar>
		<div class="login_box">
			<div class="form">
				<div class="uni-form-item">
					<div class="left_title">昵称:</div>	
					<input type="text"  autocomplete="off"  class="username" placeholder="请输入昵称"
					 v-model.trim="userMsg.userName" />
				</div>														
			</div>
			<div class="button_gloup">
				<div class="login_btn primary" formType="submit" @click="changeNickName">
					<div>立即修改</div>
				</div>
			</div>
		</div>
	</div>		
</template>

<script>
export default {
	components: {
		HeaderBar: () => import('@/components/HeaderBar.vue')
	}, 		
	data() {
		return {
			userMsg:{},
		}
	},		
	methods: {
		async changeNickName() {
			console.log(this.userMsg.userName);
			if(!this.userMsg.userName) this.$toast("请输入昵称"); 
			if(this.userMsg.userName.length<2||this.userMsg.userName.length>8) this.$toast("昵称2-8位数");
			this.$toast("修改中..."); 
			const res = await this.$authSetName({
				userName:this.userMsg.userName
			});
			if (res.code == 200) {
				this.$toast.success('修改成功');
				this.$router.push('/mine');
			} else {
				this.$toast(res.message);
			}	
		}
	},
	mounted(){
		this.userMsg=JSON.parse(JSON.stringify(this.$store.state.user.userInfo));
	}
};
</script>

<style scoped lang="scss">
.content_page {
	padding-top: 0.88rem;
	.login_box {
		background: rgba(255, 255, 255, 0.8);
		padding-top: 0.20rem;
		box-sizing: border-box;
		.form {
			uni-input {
				height: 0.70rem;
				line-height: 0.70rem;
				width: 4.60rem;
			}
			.uni-form-item{	
				position: relative;
				height: 1rem;
				display: flex;
				align-items: center;	
				border-bottom:1px solid #979797 ;
				input{
					outline: 0;
					border: 0;
				}	
				.left_title{
					font-size: 0.35rem;
					color: #000;
					text-align: left;
					line-height: 0.70rem;
					word-wrap: break-word;
					width: 1.90rem;
					padding-left: 0.20rem;					
				}				
			}
		}

		.button_gloup {
			.login_btn {
				text-align: center;
				color: #fff;
				background-color: #1989fa;
				border: 1px solid #1989fa;
				border-radius: 999px;
				width: 6.90rem;
				height: 1rem;
				line-height: 1rem;
				margin: 0 auto;
				font-size: 0.35rem;
				margin-top: 0.50rem;
			}
		}

	}
}
</style>
