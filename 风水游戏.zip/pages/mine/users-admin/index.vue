<template>
	<div class="home-index" >
		<!-- 头部导航 -->
		<HeaderBar :navText="'用户审核'"></HeaderBar>
		<van-pull-refresh v-model="refreshing" @refresh="onRefresh">
      <van-list
        v-model="loading"
        :finished="finished"
        finished-text="暂时没有更多用户！"
        @load="onLoad"
        :immediate-check="false"
      >			
				<div class="search-wrap">
					<input @keyup.enter="onRefresh" v-model="searchTxt" placeholder="请输入用户账号、昵称搜索" type="text">
					<van-icon class="ico-img" name="search" />
					<div class="search" @click="onRefresh">搜索</div>
				</div>
				<div class="content-outBox">
					<div class="teacher-card-list">
						<UserAdminItem @click.native="fn_forbit(item)" :item="item" v-for="(item,index) in dataList" :key="index"></UserAdminItem>	
					</div>			
				</div>
			</van-list>
		</van-pull-refresh>		
	</div>
</template>
<script>
import {Dialog} from 'vant'
export default {
  components: {
		UserAdminItem: () => import('@/components/Mine/userAdminItem.vue'),
		HeaderBar: () => import('@/components/HeaderBar.vue')
  },	
	data() {
		return {
			loading:false,
			refreshing:false,
			finished:false,
			dataList:[],
      pageNum: 1,
      pageSize: 10,
			searchTxt:''
		};
	},
	methods: {
		//禁用用户
		async fn_forbit(item){
			Dialog.confirm({
				cancelButtonText:'取消并复制',
				title:item.status==1?'禁用':'启用',
				message: item.status==1?`确认禁用${item.userName}？`:`确认启用${item.userName}？`,
			}).then(async () => {
					const res = await this.$forumForbitUser({
						status:item.status==1?2:1,
						account:item.account
					});
					if (res.code == 200) {
						this.$toast.success(item.status==1?'禁用成功':'启用成功');		
						item.status==1?item.status=2:item.status=1;
					} else {
						this.$toast(res.message);
					}					
			}).catch(() => {
				this.$copyText(
					'账号:'+item.account+'\n'+	
					'昵称:'+item.userName+'\n'+	
					'微信:'+item.wechat+'\n'+	
					'QQ号:'+item.qq+'\n'					
				).then(message => {
					this.$toast('复制账号:'+item.account+'成功');
				}).catch(err => {
					this.$toast("复制失败！") ;
				})
			});;				
		},
		//获取列表
		async forumGetList() {
			this.loading=true;
      const res = await this.$forumGetUser({
				page: this.pageNum,
				searchTxt: this.searchTxt,
				pageSize: this.pageSize
      })
      if (res.code == 200) {
				this.refreshing = false;
				this.loading=false;
        if(!res||!res.result ||!res.result.data||res.result.data.length<this.pageSize){
          this.finished = true;
        }
				this.dataList=[... this.dataList,...res.result.data||[]];
      } else {
        this.refreshing = false;
        this.loading = false;
        this.finished = true;
        this.$toast(res.message);
      }
    }, 
    //下拉加载
    onLoad() {
      this.pageNum ++;
      this.forumGetList();
    },
     //上拉刷新
    onRefresh() {
      this.finished = false;
      this.loading = true;
      this.pageNum = 1;
			this.dataList=[];
			this.forumGetList();
    },					
	},
	async mounted() {
		if(!this.token||this.userInfo.vip!=1) return this.$router.go(-1);
		this.onRefresh();
	},	
	computed: {
		token({ $store }) {
			return $store.state.user.token
		},
		userInfo({ $store }) {
			return $store.state.user.userInfo
		}					
	},		
};
</script>

<style lang="scss" scoped>
.home-index{
	padding-top: 1rem;
	padding-bottom: 1.5rem;
	.search-wrap{
		position: relative;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 0.2rem;
		.ico-img{
			position: absolute;
			left: 0.4rem;
			font-size: 0.35rem;
			font-weight: 700;
		}
		.search{
			white-space: nowrap;
			padding: 0 0.1rem 0 0.3rem;
			font-size: 0.35rem;
		}
		input{
			text-indent: 0.6rem;
			width: 6rem;
			height: 0.6rem;
			background: #f1f1f1;			
			border: 0;
			outline: none;
		}	
		@include placeholderColor;		
	}
	.content-outBox{
		padding: 0 0.2rem;	
	}		
}
</style>
