<template>
	<div class="home-index" >
		<!-- 头部导航 -->
		<HeaderBar :navText="'积分管理'"></HeaderBar>
		<van-pull-refresh v-model="refreshing" @refresh="onRefresh">
      <van-list
        v-model="loading"
        :finished="finished"
        finished-text="暂时没有更多用户！"
        @load="onLoad"
        :immediate-check="false"
      >			
				<div class="search-wrap">
					<input @keyup.enter="onRefresh" v-model="searchTxt" placeholder="请输入用户账号、昵称搜索" type="text">
					<van-icon class="ico-img" name="search" />
					<div class="search" @click="onRefresh">搜索</div>
				</div>
				<div class="content-outBox">
					<div class="teacher-card-list">
						<UserAdminItem :type="'积分管理'" @click.native="fn_forbit(item)" :item="item" v-for="(item,index) in dataList" :key="index"></UserAdminItem>	
					</div>			
				</div>
			</van-list>
		</van-pull-refresh>		
	</div>
</template>
<script>
import {Dialog} from 'vant'
export default {
  components: {
		UserAdminItem: () => import('@/components/Mine/userAdminItem.vue'),
		HeaderBar: () => import('@/components/HeaderBar.vue')
  },	
	data() {
		return {
			loading:false,
			refreshing:false,
			finished:false,
			dataList:[],
      pageNum: 1,
      pageSize: 10,
			searchTxt:''
		};
	},
	methods: {
		//禁用用户
		async fn_forbit(item){
			Dialog.confirm({
				cancelButtonText:'取消',
				title:'清空'+item.account+'积分',
				message: "清空积分",
			}).then(async () => {
					const res = await this.$forumClearUserCoin({
						account:item.account
					});
					if (res.code == 200) {
						this.$toast.success(res.result);	
						item.coinTotal=0;
					} else {
						this.$toast(res.message);
					}					
			}).catch(() => {

			});;				
		},
		//获取列表
		async forumGetList() {
			this.loading=true;
      const res = await this.$forumGetUser({
				page: this.pageNum,
				searchTxt: this.searchTxt,
				pageSize: this.pageSize,
				sortBy:'coinTotal'
      })
      if (res.code == 200) {
				this.refreshing = false;
				this.loading=false;
        if(!res||!res.result ||!res.result.data||res.result.data.length<this.pageSize){
          this.finished = true;
        }
				this.dataList=[... this.dataList,...res.result.data||[]];
      } else {
        this.refreshing = false;
        this.loading = false;
        this.finished = true;
        this.$toast(res.message);
      }
    }, 
    //下拉加载
    onLoad() {
      this.pageNum ++;
      this.forumGetList();
    },
     //上拉刷新
    onRefresh() {
      this.finished = false;
      this.loading = true;
      this.pageNum = 1;
			this.dataList=[];
			this.forumGetList();
    },					
	},
	async mounted() {
		if(!this.token||this.userInfo.vip!=1) return this.$router.go(-1);
		this.onRefresh();
	},	
	computed: {
		token({ $store }) {
			return $store.state.user.token
		},
		userInfo({ $store }) {
			return $store.state.user.userInfo
		}					
	},		
};
</script>

<style lang="scss" scoped>
.home-index{
	padding-top: 1rem;
	padding-bottom: 1.5rem;
	.search-wrap{
		position: relative;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 0.2rem;
		.ico-img{
			position: absolute;
			left: 0.4rem;
			font-size: 0.35rem;
			font-weight: 700;
		}
		.search{
			white-space: nowrap;
			padding: 0 0.1rem 0 0.3rem;
			font-size: 0.35rem;
		}
		input{
			text-indent: 0.6rem;
			width: 6rem;
			height: 0.6rem;
			background: #f1f1f1;			
			border: 0;
			outline: none;
		}	
		@include placeholderColor;		
	}
	.content-outBox{
		padding: 0 0.2rem;	
	}		
}
</style>
