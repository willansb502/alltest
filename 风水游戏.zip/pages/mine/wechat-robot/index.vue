<template>
	<div class="content_page" >
		<div class="login_box">
			<div class="tip1">
				获取扫码，截屏微信二维码，扫码确认登录。
			</div>
			<div class="tip2">
				ipad在线即为登录成功，否则再次获取扫码。
			</div>
			<template >
				<div class="form">
					<img :src="imgUrl" mode="widthFix">																	
				</div>
				<div class="button_gloup">
					<div class="login_btn primary" @click="signUp">
						点击获取登录二维码
					</div>
				</div>
			</template>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				imgUrl:'',
				registInfo:{
					account:'',
					pwd:'',
					comPwd:'',
					userName:'',
					wechat:'',
					qq:''					
				}
			};
		},
		methods: {
			async signUp() {	
				const res = await this.$getRootCode({});
				if(res.code==200&&res.result.data&&res.result.data.qrCodeUrl){
					this.$toast("获取二维码成功！！！");
					this.imgUrl=res.result.data.qrCodeUrl;
				}else{
					this.$toast(res.result.message);
				}
			},
		},
		async mounted() {
			if(!this.token||this.userInfo.vip!=1) return this.$router.go(-1);
		},	
		computed: {
			token({ $store }) {
				return $store.state.user.token
			},
			userInfo({ $store }) {
				return $store.state.user.userInfo
			}					
		},		
	};
</script>

<style scoped lang="scss">
	.offsite-login-box {
		.uni-inline-item {
			margin-top: 10px;
		}
	}

	.content_page {
		 .page-title{
			position: relative;
			background: #efefef;
			width: 100%;
			height: 0.9rem;
			color: #323233;
			font-weight: 500;
			text-align: center;
			line-height: 0.90rem;
			font-size: 0.32rem;	
			.tohome{
				position: absolute;
				top: 0;
				left: 0.01rem;
				font-size: 0.56rem;
			}		 
		 }
		.login_box {
			background: rgba(255, 255, 255, 0.8);
			padding: 0.20rem  0.26rem;
			box-sizing: border-box;
			.tip1,.tip2{
				color: rgb(25, 137, 250);
				background: rgb(236, 249, 255);	
				height: auto;
				padding: 0.16rem 0.32rem;	
				font-size: 0.28rem;
				line-height: 0.48rem;
				margin: 0px 0px 0.30rem 0px;										
			}
			.tip2{
				color: #ed6a0c;
				background: #FFFBE8;
			}

			.form {
				img{

				}
			}

		}
	}
	.tipBox{
		.title{
			padding: 30rem 0;
			font-size: 32rem;
		}
		.content{
			.t{
				font-size: 32rem;	
				padding-bottom: 10rem;
			}
		}
	}
	.button_gloup {
		text-align: center;
		.login_btn {
			color: #fff;
			background-color: #1989fa;
			border: 1px solid #1989fa;
			border-radius: 999px;
			width: 6.90rem;
			height: 1rem;
			line-height: 1rem;
			margin: 0 auto;
			font-size: 0.35rem;
			margin-top: 1rem;
			&.register{
				margin-top: 0.50rem;
				background: #05BF5E;
				border: 1px solid #05BF5E;
			}
		}
	}
</style>
