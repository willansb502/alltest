<template>
<div class="content_page" >
	<HeaderBar :navText="'看作业'">
		<img @click="fn_share" class="share-img" src="/images/share.png" alt="">
	</HeaderBar>
	<main class="detail-main" v-if="articleDetailData.formID">
		<ul class="item-list">
			<li class="item" v-if="!articleDetailData.privacy">
				学生：{{articleDetailData.userName||articleDetailData.account}}
			</li>			
			<li class="item server-type">
				课节：
				<div class="learnType-list">
					<div class="learnType-list-item" v-for="(item, index) in learnTypeArr" :key="index">
						<img v-if="item.bool" src="/images/checkbox-active.png" alt="">	
						<img v-else src="/images/checkbox-default.png" alt="">
						<div>{{item.name}}</div>		
					</div>
				</div>
			</li>
			<li class="item">
				老师：{{articleDetailData.teacherName}} ({{articleDetailData.remarks}})
			</li>			
			<li class="item">
				学费：{{articleDetailData.price}}p
			</li>
			<li class="item">
				评分：<van-rate v-model="articleDetailData.mark" readonly :count="10" />
			</li>	
			<li class="item">
				日期：{{articleDetailData.learnTime}}
			</li>	
			<li class="item">
				位置：{{articleDetailData.location}}
			</li>			
			<li class="item feature">
				硬件/优缺点：{{articleDetailData.feature}}
			</li>
			<li class="item feature">
				详细过程：{{articleDetailData.learnDetails}}
			</li>																				
		</ul>
	</main>
	<div class="clickBox">
		<div class="admin-box" v-if="userInfo.vip==1">
			<div class="top-active" @click="fn_forbitWork(articleDetailData)">
				<img v-if="articleDetailData.status==2" src="/images/verify.png" alt="">
			</div>			
			<div class="top-active" @click="fn_toTop()">
				<img v-if="articleDetailData.top==1" src="/images/top-active.png" alt="">
				<img v-else src="/images/top-default.png" alt="">
			</div>
			<div class="delete" @click="fn_toDelte()">
				<img src="/images/delete.png" alt="">
			</div>
		</div>
	</div>
</div>
</template>

<script>
import {Dialog} from 'vant'
export default {
	components: {
		HeaderBar: () => import('@/components/HeaderBar.vue')
	},		
	data() {
		return {
			userInfo:{},
			//作业详情
			articleDetailData:{
				mark:0,
				learnType:'',
				learnTypeArr:[]				
			},
			//静态类型
			learnTypeArr:[
				{name:'P',bool:false},
				{name:'PP',bool:false},
				{name:'YE',bool:false},
				{name:'双',bool:false},
				{name:'包',bool:false},
			],
			//作业formID
			formID:''
		};
	},
	methods: {
		//分享作业
		fn_share(){
			this.$copyText(
				'作业详情:\n'+
				'地址:'+window.location.href.toString()+'\n'+
				'昵称:'+((this.articleDetailData.privacy?'匿名':this.articleDetailData.userName)||this.articleDetailData.account)+'\n'+
				'老师:'+this.articleDetailData.teacherName+'\n'	
			).then(message => {
				this.$toast.success('复制成功');
			}).catch(err => {
				this.$toast("复制失败！") ;
			})
		},
		//审核作业
		async fn_forbitWork(item){
			Dialog.confirm({
				cancelButtonText:'复制作业',
				title:item.status==1?'禁用':'启用',
				message: item.status==1?'确认禁用作业？':'确认启用作业？',
			}).then(async () => {
					const res = await this.$forumForbitWork({
						status:item.status==1?2:1,
						formID:item.formID,
						teacherName:item.teacherName
					});
					if (res.code == 200) {
						this.$toast.success(item.status==1?'禁用作业成功':'启用作业成功');		
						item.status==1?item.status=2:item.status=1;
					} else {
						this.$toast(res.message);
					}					
			}).catch(() => {
				this.fn_share();
			});				
		},			
		//获取作业详情
		async	getDetail() {
			this.$toast.loading({ duration: 0 });
			const res = await this.$forumArticle({
				formID:this.formID
			})
			if (res.code == 200) {
				this.$toast.clear();
				//积分是字符串转化数字
				res.result.mark=+res.result.mark;
				//类型匹配
				if(res.result.learnType){
					this.learnTypeArr.forEach((item)=>{
						if(res.result.learnType==item.name){
							item.bool=true;	
						}
					});					
				}else{
					this.learnTypeArr.forEach((item)=>{
						res.result.learnTypeArr.forEach((sitem)=>{
							if(item.name==sitem){
								item.bool=true;
							}
						});
					});						
				};
				this.articleDetailData = res.result;	
			} else {
				this.$toast.clear();
				this.$router.go(-1);
				this.$toast(res.message);
			}	
		},	
		// 设置顶置
		async	fn_toTop(){
			const res = await this.$forumAdreTop({
				formID: this.formID,
				topStatus:this.articleDetailData.top==1?1:2,
			});
			if (res.code == 200) {
				if(this.articleDetailData.top==1){
					this.articleDetailData.top=2;
					this.$toast.success('取消顶置');
				}else{
					this.articleDetailData.top=1;
					this.$toast.success('顶置成功');		
				}
			} else {
				this.$toast(res.message);
			}		
		},	
		// 删除		
		fn_toDelte(){
			Dialog.confirm({
				title: '删除',
				message: '确认该删除帖子吗？',
			}).then(async () => {
					const res = await this.$forumDeleteArtical({
						formID: this.formID
					});
					if (res.code == 200) {
						this.$toast.success('删除成功');	
						this.$router.go(-1);		
					} else {
						this.$toast(res.message);
					}					
			}).catch(() => {
			});;			
		}
	},
	mounted(){
		this.userInfo=JSON.parse(JSON.stringify(this.$store.state.user.userInfo));
		if(this.$route.query.formID){
			this.formID = this.$route.query.formID;
			this.getDetail();
		}
	}
};
</script>

<style scoped lang="scss">
.content_page {
	padding-top: 1rem;
	padding-bottom: 1.5rem;
	.share-img{
		position: absolute;
		right: 0.2rem;
		width: 0.6rem;
	}
	.detail-main{
		.item-list{
			.item{
				padding: 0.32rem 0;
				display: flex;
				align-items: center;
				padding-left: 0.2rem;
				color: #000;
				font-size: 0.35rem;
				width: 100%;
				border-bottom: 1px solid #979797;
				&:last-child{
					border-bottom:0;
				}
				//课节
				&.server-type{
					.learnType-list{
						display: flex;
						align-items: center;
						.learnType-list-item{
							display: flex;
							align-items: center;
							div{
								padding-left: 0.1rem;
								padding-right: 0.17rem;
							}
						}
					}
					img{
						width: 0.4rem;
						height: 0.4rem;
					}
					
				}
				&.feature{
					font-size: 0.35rem;
					padding-right:0.2rem ;
					padding-top: 0;
					white-space: pre-line;
				}

				    
			}
		}
	}
	.clickBox{
		position: fixed;
		top:5rem;		
		right: 50%;
		margin-right:- calc($pcMaxWidth/2 - 0.2rem);
		.admin-box{
			display: flex;
			flex-direction: column;
			align-items: center;
			.top-active{
				padding-bottom: 0.3rem;
				img{
					width: 0.88rem;
				}				
			}
			.delete{
				img{
					width: 0.6rem;
				}						
			}

		}			
	}
}
</style>
