<template>
	<div class="home-index" >
		<!-- 头部导航 -->
		<HeaderBar :showBack="false" :navText="'查作业'"></HeaderBar>
		<van-pull-refresh v-model="refreshing" @refresh="onRefresh">
      <van-list
        v-model="loading"
        :finished="finished"
        :finished-text="!token?'未登录只能查看10篇哦':'暂时没有更多数据！'"
        @load="onLoad"
        :immediate-check="false"
      >			
				<div class="search-wrap">
					<input @keyup.enter="onRefresh" v-model="searchTxt" placeholder="请输入老师名称或地区搜索" type="text">
					<van-icon class="ico-img" name="search" />
					<div class="search" @click="onRefresh">搜索</div>
				</div>
				<div class="content-outBox">
					<div class="teacher-card-list">
						<WorkCard :item="item" v-for="(item,index) in dataList" :key="index"></WorkCard>	
					</div>			
				</div>
			</van-list>
		</van-pull-refresh>		
		<div class="btn-wrap">
			<button v-if="!token" class="login-btn" @click="$router.push('/auth/login')">立即登录</button>
			<button v-else class="login-btn" @click="$router.push('/works/publish')">写作业</button>			
		</div>

	</div>
</template>
<script>
export default {
	name:"pageAlive",
  components: {
		WorkCard: () => import('@/components/WorkCard.vue'),
		HeaderBar: () => import('@/components/HeaderBar.vue')
  },	
	data() {
		return {
			loading:false,
			refreshing:false,
			finished:false,
			dataList:[],
      pageNum: 1,
      pageSize: 10,
			searchTxt:''
		};
	},
	methods: {
		//获取列表
		async forumGetList(type) {
			this.loading=true;
      const res = await this.$forumGetList({
				page: this.pageNum,
				searchTxt: this.searchTxt,
				pageSize: this.pageSize,
				status:1
      })
      if (res.code == 200) {
				this.refreshing = false;
				this.loading=false;

        if(type == "pull") this.dataList=[];
        
        if(!res||!res.result ||!res.result.data||res.result.data.length<this.pageSize){
          this.finished = true;
        }
				this.dataList=[... this.dataList,...res.result.data||[]];
				//未登录仅仅展示10篇
				if(!this.token){
					this.finished = true;
				}				
      } else {
        this.refreshing = false;
        this.loading = false;
        this.finished = true;
        this.$toast(res.message);
      }
    }, 
    //下拉加载
    onLoad() {
      this.pageNum ++;
      this.forumGetList();
    },
     //上拉刷新
    onRefresh() {
      this.finished = false;
      this.loading = true;
      this.pageNum = 1;
			this.forumGetList('pull');
    },					
	},
	async mounted() {
		this.onRefresh();
	},	
	computed: {
		token({ $store }) {
			return $store.state.user.token
		}	
	},		
};
</script>

<style lang="scss" scoped>
.home-index{
	padding-top: 1rem;
	padding-bottom: 1.5rem;
	.search-wrap{
		position: relative;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 0.2rem;
		.ico-img{
			position: absolute;
			left: 0.4rem;
			font-size: 0.35rem;
			font-weight: 700;
		}
		.search{
			white-space: nowrap;
			padding: 0 0.1rem 0 0.3rem;
			font-size: 0.35rem;
		}
		input{
			text-indent: 0.6rem;
			width: 6rem;
			height: 0.6rem;
			background: #f1f1f1;			
			border: 0;
			outline: none;
		}	
		@include placeholderColor;		
	}
	.content-outBox{
		padding: 0 0.2rem;	
	}	
	.login-btn{
		white-space: nowrap;
		position: fixed;
    bottom: calc(1.5rem + constant(safe-area-inset-bottom));
		bottom: calc(1.5rem + env(safe-area-inset-bottom));
		left: 50%;
		margin-left:- calc($pcMaxWidth/2 - 0.2rem);
    width: 1.84rem;
    height: 0.80rem;
		color: #fff;
		background-color: #07c160;
		border: 1px solid #07c160;
		border-radius:0.50rem;
		font-size: 0.32rem;		
	}		
}
</style>
