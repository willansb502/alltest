<template>
<div class="content_page" >
	<HeaderBar :navText="'写作业'"></HeaderBar>
	<main class="detail-main" v-if="hideSubmit">
		<ul class="item-list">
			<li class="item userName">
				学生：<input readonly type="text" v-model="userInfo.userName">
				<img @click="formInputData.privacy=!formInputData.privacy" v-if="formInputData.privacy" src="/images/dg-active.png" alt="">
				<img @click="formInputData.privacy=!formInputData.privacy" v-else src="/images/dg-default.png" alt="">
				<div @click="formInputData.privacy=!formInputData.privacy">匿名</div>
			</li>					
			<li class="item server-type">
				课节：
				<div class="learnType-list">
					<div class="learnType-list-item" @click="item.bool=!item.bool" v-for="(item, index) in learnTypeArr" :key="index">
						<img v-if="item.bool" src="/images/checkbox-active.png" alt="">	
						<img v-else src="/images/checkbox-default.png" alt="">	
						<div>{{item.name}}</div>	
					</div>
				</div>
			</li>			
			<li class="item">
				老师：
				<input placeholder="请输入老师昵称" type="text" v-model="formInputData.teacherName">
			</li>			
			<li class="item">
				学费：
				<input placeholder="请输入金额" type="number" v-model="formInputData.price">
			</li>
			<li class="item">
				评分：
				<van-rate v-model="formInputData.mark" :count="10" />
			</li>	
			<li class="item">
				上课日期：
				<input :placeholder="'请输入日期'" type="text" v-model="formInputData.learnTime">
			</li>	
			<li class="item">
				位置：
				<input placeholder="请输入上课位置" type="text" v-model="formInputData.location">
			</li>		
			<li class="item remark">
				备注：
				<input placeholder="请输入备注例如:3刷,默认:首刷" maxlength="4" type="text" v-model="formInputData.remarks">
			</li>					
			<li class="item feature">
				硬件/优缺点：
				<van-field
					class="feature-textarea"
					v-model="formInputData.feature"
					rows="1"
					autosize
					label=""
					type="textarea"
					placeholder="请输入硬件 态度等"
				/>
			</li>
			<li class="item feature">
				详细过程：				
				<van-field
					class="feature-textarea"
					v-model="formInputData.learnDetails"
					rows="1"
					autosize
					label=""
					type="textarea"
					placeholder="请输入详细过程"
				/>
			</li>																				
		</ul>
		<div class="button_gloup">
			<div class="login_btn primary" formType="submit" @click="submitFromData">
				提交
			</div>
		</div>		
	</main>
	<template v-else>
		<div class="copy-msg">
			<img class="success" src="/images/success.png">
			<div>提交成功:</div>
			<div style="color:#4867D8;padding-bottom:0.50rem;">复制以下内容发送给管理员</div>
			<div style="text-align:left;padding-bottom:0.1rem;">尊敬的管理员，请帮忙审批作业</div>
			<div style="text-align:left;padding-bottom:0.1rem;">地址:{{locationHref}}</div>
			<div style="text-align:left;padding-bottom:0.1rem;">老师:{{formInputData.teacherName}}</div>
			<div style="text-align:left;padding-bottom:0.1rem;">学费:{{formInputData.price}} P</div>
			<div style="text-align:left;padding-bottom:0.1rem;">学生网站昵称:{{userInfo.userName}}</div>
			<div style="text-align:left;padding-bottom:0.1rem;" v-if="userInfo.wechat">微信:{{userInfo.wechat}}</div>
			<div style="text-align:left;padding-bottom:0.1rem;" v-if="userInfo.qq">qq:{{userInfo.qq}}</div>
		</div>	
		<div class="button_gloup2">
			<div class="login_btn primary" formType="submit" @click="copyPublish">
				<div>复制审核信息</div>
			</div>
		</div>
		<div class="button_gloup2 view">
			<div class="login_btn primary" formType="submit" @click="viewWorks">
				<div>查看该作业</div>
			</div>
		</div>
		<div class="button_gloup2 view">
			<div class="login_btn primary" formType="submit" @click="fn_rewrite">
				<div>再写一篇</div>
			</div>
		</div>										
	</template>	
</div>
</template>

<script>
export default {
	name:"pageAlive",
	components: {
		HeaderBar: () => import('@/components/HeaderBar.vue')
	},		
	data() {
		return {
			locationHref:'',
			//显示提交
			hideSubmit:true,
			//静态类型
			learnTypeArr:[
				{name:'P',bool:false},
				{name:'PP',bool:false},
				{name:'YE',bool:false},
				{name:'双',bool:false},
				{name:'包',bool:false},
			],			
			formInputData: {
				privacy:false,
				price: ''  ,            // 价格
				mark:  0 ,           // 打分
				feature:  '' ,            // 老师特点      
				teacherName:'',              // 老师名字
				learnTime: ''  ,      // 学生学习时间
				learnDetails:  ''  ,         // 过程
				location:'' ,         // 位置
				remarks:'' , // 备注限制2个字 例如：首刷，显示在老师标题中
				learnTypeArr:[],
				wechat:''
			},
			formID:'',
			userInfo:{}			
		};
	},		
	methods: {
		//重写
		fn_rewrite(){
			this.locationHref='';
			//显示提交
			this.hideSubmit=true;
			//静态类型
			this.learnTypeArr=[
				{name:'P',bool:false},
				{name:'PP',bool:false},
				{name:'YE',bool:false},
				{name:'双',bool:false},
				{name:'包',bool:false},
			];			
			this.formInputData= {
				privacy:false,
				price: ''  ,            // 价格
				mark:  0 ,           // 打分
				feature:  '' ,            // 老师特点      
				teacherName:'',              // 老师名字
				learnTime: ''  ,      // 学生学习时间
				learnDetails:  ''  ,         // 过程
				location:'' ,         // 位置
				remarks:'' , // 备注限制2个字 例如：首刷，显示在老师标题中
				learnTypeArr:[],
				wechat:''
			};
			this.formID='';
			this.userInfo={};	
		},
		//查看作业
		viewWorks(){
      this.$router.push({
        path:'/works/detail',
        query:{
          formID:this.formID
        }
      });
		},
		// 复制发布
		copyPublish(){
			this.$copyText(
				'尊敬的管理员，请帮忙审批作业:\n'+
				'地址:'+this.locationHref+'\n'+
				'老师:'+this.formInputData.teacherName+'\n'+
				'学费:'+this.formInputData.price+'P\n'+
				'学生网站昵称:'+this.userInfo.userName+'\n'+
				'微信:'+this.userInfo.wechat+'\n'+
				'qq:'+this.userInfo.qq
			).then(message => {
				this.$toast.success('复制成功');
			}).catch(err => {
				this.$toast("复制失败！") ;
			})
		},		
		async submitFromData(){
			this.formInputData.wechat=this.userInfo.wechat;
			this.formInputData.qq=this.userInfo.qq;
			this.formInputData.learnTypeArr=[];
			this.learnTypeArr.forEach((item)=>{
				if(item.bool){
					this.formInputData.learnTypeArr.push(item.name);	
				}
			});
			if(
				!this.formInputData.feature||
				!this.formInputData.learnDetails||
				!this.formInputData.learnTime||
				!this.formInputData.location||
				!this.formInputData.price||
				!this.formInputData.remarks||
				!this.formInputData.teacherName
			){
				return this.$toast('输入发布信息不全！！！');
			}
			if(this.formInputData.learnTypeArr==0) return this.$toast('请选择课节');
			if(!this.formInputData.mark) return this.$toast('请输入评分');
			this.formInputData.price=+this.formInputData.price;
			this.formInputData.mark=+this.formInputData.mark;
			this.formInputData.remarks=this.formInputData.remarks.trim();
			if(this.formInputData.remarks.length>4) return this.$toast('备注不能大于5字');
      this.$toast.loading({message: '提交中...', duration: 0,overlay:true });
      const res = await this.$forumPostForm(this.formInputData)
      if (res.code == 200) {
				this.$toast.clear();
        this.$toast.success('作业提交成功，请联系管理员审核');	
				this.locationHref=window.location.host+'/works/detail?formID='+res.result.formID;
				this.formID=res.result.formID;			
				this.hideSubmit=false;		
      } else {
				this.$toast.clear();
        this.$toast(res.message);
      }							
		}		
	},
	mounted(){
		if(!this.token) return this.$router.push('/');
		this.userInfo=JSON.parse(JSON.stringify(this.$store.state.user.userInfo));
		this.formInputData.learnTime=this.$moment().format("YYYY-MM-DD");
	},
	computed: {
		token({ $store }) {
			return $store.state.user.token
		}		
	},	
};
</script>

<style scoped lang="scss">
.content_page {
	padding-top: 1rem;
	.detail-main{
		.item-list{
			.item{
				padding: 0.32rem 0;
				display: flex;
				align-items: center;
				padding-left: 0.2rem;
				color: #000;
				font-size: 0.35rem;
				width: 100%;
				border-bottom: 1px solid #979797;
				input{
					width: 5rem;
					color: #9B9B9B;
				}
				@include placeholderColor;
				&:last-child{
					border-bottom:0;
				}
				//名字
				&.userName{
					input{
						width: auto;
					}					
					img{
						width: 0.4rem;
						height: 0.4rem;
					}
					div{
						padding-left: 0.2rem;
					}
				}				
				//课节
				&.server-type{
					.learnType-list{
						display: flex;
						align-items: center;
						.learnType-list-item{
							display: flex;
							align-items: center;
							div{
								padding-left: 0.1rem;
								padding-right: 0.17rem;
							}
						}
					}
					img{
						width: 0.4rem;
						height: 0.4rem;
					}
					
				}
				// 备注
				&.remark{
					input{
						width: 6rem;
					}
				}
				//优缺点
				&.feature{
					white-space: nowrap;
					
					::v-deep{
						.feature-textarea{
							textarea{
								font-size: 0.35rem;
							}
					  }
					}
				}

				    
			}
		}
		.button_gloup {
			text-align: center;
			.login_btn {
				color: #fff;
				background-color: #05BF5E;
				border: 1px solid #05BF5E;
				border-radius: 999px;
				width: 6.90rem;
				height: 1rem;
				line-height: 1rem;
				margin: 0 auto;
				font-size: 0.35rem;
				margin-top: 0.5rem;
				margin-bottom: 1.5rem;
			}
		}		
	}
	.copy-msg{
		text-align: center;
		.success{
			width: 0.80rem;
			height: 0.80rem;
		}
		padding: 0.40rem 0.40rem 0 0.40rem;
		font-size: 0.35rem;
	}	
	.button_gloup2 {
		.login_btn {
			color: #fff;
			background: #05BF5E;
			border: 1px solid #05BF5E;
			border-radius: 999px;
			width: 6.90rem;
			height: 1rem;
			line-height: 1rem;
			margin: 0 auto;
			font-size: 0.35rem;
			margin-top: 0.5rem;
			text-align: center;
		}
		&.view{
			.login_btn{
				background: #fff;
				border: 1px solid #ccc;	
				color: #000;	
			}
		}
	}	
}
</style>
