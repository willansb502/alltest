<template>
	<div class="home-index" >
		<!-- 头部导航 -->
		<HeaderBar :navText="navText"></HeaderBar>
		<van-pull-refresh v-model="refreshing" @refresh="onRefresh">
      <van-list
        v-model="loading"
        :finished="finished"
        finished-text="暂时没有更多作业！"
        @load="onLoad"
        :immediate-check="false"
      >			
				<div class="content-outBox">
					<div class="teacher-card-list">
						<TeachersWork :item="item" v-for="(item,index) in dataList" :key="index"></TeachersWork>	
					</div>			
				</div>
			</van-list>
		</van-pull-refresh>		

	</div>
</template>
<script>
export default {
	name:"pageAlive",
  components: {
		TeachersWork: () => import('@/components/TeachersWork.vue'),
		HeaderBar: () => import('@/components/HeaderBar.vue')
  },	
	data() {
		return {
			loading:false,
			refreshing:false,
			finished:false,
			dataList:[],
      pageNum: 1,
      pageSize: 10,
      navText:'',
			remark:''
		};
	},
	methods: {
		//获取列表
		async forumGetList(type) {
			this.loading=true;
			let params={};
			if(this.$route.query.teacherName){
				params={
					page: this.pageNum,
					pageSize: this.pageSize,
					teacherName:this.$route.query.teacherName				
				}
			}else{
				params={
					page: this.pageNum,
					pageSize: this.pageSize,
					account:this.$route.query.userAccount			
				}					
			}
      const res = await this.$forumGetList(params);
      if (res.code == 200) {
				this.refreshing = false;
				this.loading=false;

        if(type == "pull") this.dataList=[];
        
        if(!res||!res.result ||!res.result.data||res.result.data.length<this.pageSize){
          this.finished = true;
        }
				this.dataList=[... this.dataList,...res.result.data||[]];
      } else {
        this.refreshing = false;
        this.loading = false;
        this.finished = true;
        this.$toast(res.message);
      }
    }, 
		//获取用户昵称
		async getUserChinaName() {
      const res = await this.$getUserChinaName({
				account: this.$route.query.userAccount,
      })
      if (res.code == 200) {
				this.navText=res.result.userName+'📖';
      } else {
        this.$toast(res.message);
      }
    }, 
		
    //下拉加载
    onLoad() {
      this.pageNum ++;
      this.forumGetList();
    },
     //上拉刷新
    onRefresh() {
      this.finished = false;
      this.loading = true;
      this.pageNum = 1;
			this.forumGetList('pull');
    },
		fn_start(){
			this.dataList=[];
			if(this.$route.query.teacherName){
				this.navText=this.$route.query.teacherName;
				return this.onRefresh();
			}

			if(this.$route.query.userAccount){
				this.getUserChinaName();	
				return this.onRefresh();
			}			
		}					
	},
	activated(){
		if(this.remark&&this.remark==this.$route.query.teacherName||this.remark&&this.remark==this.$route.query.userAccount) return;
		this.remark=this.$route.query.teacherName||this.$route.query.userAccount;
		this.navText='';
		this.fn_start();
	},
	// watch: {
	// 		'navText': {
	// 				handler(newVal, oldVal) {
	// 					if(oldVal){
	// 						this.fn_start();
	// 					}
						
	// 				},
	// 				deep: true,
	// 				immediate: true
	// 		}
	// }
};
</script>

<style lang="scss" scoped>
.home-index{
	padding-top: 1rem;
	padding-bottom: 1.5rem;
	.content-outBox{
		padding: 0 0.2rem;	
	}	
}
</style>
