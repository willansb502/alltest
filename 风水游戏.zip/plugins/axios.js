import {Toast} from 'vant';
export default function ({
  req,
  $axios,
  store,
  query,
  error,
  redirect,
}) {
  $axios.setHeader('Content-Type', 'application/json')
  $axios.onRequest((config) => {
    config.headers['Authorization'] = localStorage.xhToken;
  })
  $axios.interceptors.response.use(
    (response) => {
      if (response.status === 200) {
        return response
      }
    },
    (error) => {
      if (error.response) {
        return error.response
      }
    }
  )

}
