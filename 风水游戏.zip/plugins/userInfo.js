export default function ({
  store
}) {
  if(localStorage.xhUserInfo){
    store.commit('user/setUserInfo', JSON.parse(localStorage.xhUserInfo));
    store.commit('user/setToken', localStorage.xhToken);    
  }
}