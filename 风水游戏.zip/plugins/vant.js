import Vue from 'vue'
import VueClipboard from 'vue-clipboard2'
import {
  List,
  PullRefresh,
  Icon,
  Toast,
  Rate,
  Field 
} from 'vant'
Vue.use(List);
Vue.use(PullRefresh);
Vue.use(Icon);
Vue.use(Rate);
Vue.use(Field);
Vue.prototype.$toast = Toast;

VueClipboard.config.autoSetContainer = true;
Vue.use(VueClipboard);
