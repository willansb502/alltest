import {Toast} from 'vant';
export const state = () => ({
  // auth
  token: '',
  // 用户信息
  userInfo: '',
})
export const getters = {
}
export const mutations = {
  setToken(state, token) {
    state.token = token;
  },
  setUserInfo(state, userInfo) {
    state.userInfo = userInfo;
  },
  clearInfo(state) {
    state.token = '';
    state.info = '';
    localStorage.xhUserInfo='';
    localStorage.xhToken='';
  }  
}
export const actions = {
  async authBalance({ commit }) {
    const res = await this.$authBalance();
    if (res.code == 200) {
      if(res.result.status==2){
        commit('clearInfo');
        return Toast("用户已禁用,请联系管理员") ;
      }      
      commit('setUserInfo', res.result);
      localStorage.xhUserInfo=JSON.stringify(res.result);
    }
  },
}
